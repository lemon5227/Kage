# Task 1 implementation report — C1.2 native AX engineering subpackage

Status: DONE_WITH_CONCERNS for the assigned engineering package. Full C1.2 capability acceptance is still pending real native model decision-chain evaluation and an OCR candidate/provider path where AX is missing. Not a model capability score. No push.

## Commits and ownership

- `4a4c890`: bounded window-scoped macOS AX driver/adapter, ToolRegistry tools, ToolExecutor structured error history, optional Darwin dependency, dedicated TextEdit fixture/pilot, eight initial platform-independent behavior tests.
- `b6e95c2`: independent-review fixes: retain application-menu target provenance, recheck AXMainWindow immediately before menu dispatch, native-API race regression, final cleanup disappearance acceptance, pilot native teardown waits.
- `0facc2b`: final public experiment report, queue, handoff, master-plan and experiment index, separate from source. Parent owns root roadmap.md; not edited or staged by this agent.

Worktree exclusively `/Users/wenbo/.codex/worktrees/c2-learning-loop/Kage`, branch `codex/c2-learning-loop`, assigned base `8dea7c4`. Main checkout untouched. All evidence/private settings retained; no cloud calls, model requests, UI changes or unrelated refactors.

## Implementation

`core/computer_use/native_ax.py`: lazily imports ApplicationServices/AppKit/CoreFoundation only on native use; nonmacOS and missing bridge explicit NotAvailable, untrusted process AXPermissionDenied. Identifies one exact running bundle application and at most 40 windows; window/control identity uses CFEqual. Per adapter surface ID and current observation ID; full snapshot revision includes identity, value digest, geometry, main-window state, available operations. Driver reobserves before dispatch; menu targets receive a final immediate selected-main-window equality check. No driver in AgenticLoop, no parallel scoring system. Registry tools are native_windows/native_observe/native_act; handlers return structured JSON used through existing ToolExecutor, whose history preserves full native errors/new observations.

AX windows traversal cap 400 nodes/12 levels, check 5s deadline, per-message timeout 0.2s; no claim of strict wall-clock timeout because whole AXValue copying/digest and in-flight synchronous requests can scale. Only selected window controls and its main-document menu/Save/Close are exposed; no Apple/system/recent/other-window menu traversal. No coordinate guessing or global keyboard commands. Stale rejection reobserves without mutation. action_applied=false for known predispatch rejections, null for unknown dispatch errors, true for completed driver call even if reobservation fails. Closed-window observation invalidates current state. OCR fallback explicitly unavailable/source=null/no provider, no fabricated candidates.

## Tests and review

TDD: observed module-missing red before initial implementation; permission-at-dispatch red, closure red, mocked native main-window-switch red (DID NOT RAISE), completion-disappearance red before fixes. Focused final `tests/test_native_ax.py tests/test_tool_executor.py tests/test_registry_defaults.py`: 31 passed in 0.20s; native tests 10. `git diff --check` clean.

Native tests exercise real adapter/registry/executor with fake drivers plus a mocked low-level native API: actual fill changes value, invalidation returns fresh target, crosssurface identity rejected, unsupported action no mutation, explicit permission failure retained in history, postwrite observation failure applied=true, dispatch failure applied=null, optional attribute not queried if unsupported, closed observation, main-window switch during final native traversal makes zero AXPress calls, cleanup completion requires actual disappearance.

Parent pre-collected regression: 992 passed, 4 skipped, 1 xfailed, 1 warning in 313.37s. Source added during that run, so preliminary regression, not pristine baseline/final. First full run after 4a4c890 interrupted upon review fixes, exit 2, 98 passed,1 skipped, 1 warning in 59.85s; raw log retained. Final full run after b6e95c2 (source frozen): **1002 passed, 4 skipped, 1 xfailed, 1 warning in 302.27s**, exit 0. Raw artifacts/native-ax-2026-10-07/final-pytest-b6e95c2.txt; existing pygame/pkg_resources deprecation warning. Local documentation relative-link validation passed.

Independent review `.superpowers/sdd/execution-handoff-2026-10-03/task-1-review.md`: P1/P2 accepted after b6e95c2, no new blocker. Minor P3 retained rather than restarting full suite: permission loss only during completion helper retains raw trace/error but pilot classifier may say failed instead of blocked because helper results are not added to report stages. Documented publicly.

## Actual native pilot / raw evidence

Host ApplicationServices AXIsProcessTrusted=true. Deterministic script, model_driven=false. New copy of tracked dedicated plaintext fixture for setup; AX execution edits/status target, observed document menu Save, observed Close; confirms window disappearance before reopen; reread via AX and independent file; final AX Close followed by another disappearance check. No direct execution writes, no user document edits, no process quits.

Final accepted `artifacts/native-ax-2026-10-07/pilot-9/report.json`: passed, saved_file_matches=true, window_disappeared_after_close=true, reopened_ax_matches=true, independent_file_matches=true, cleanup_close_applied=true, cleanup_window_disappeared=true. 3989.598 ms total, zero model/cloud requests, SHA256 3856d48b5ee096074a2ae75e94288cf6f0c8e5f72214cf47ba7720b0b05453cb. Raw per-action trace: pilot-9/trace.jsonl; real file: pilot-9/kage-native-ax-pilot-9.txt.

Development evidence all retained: probe.jsonl optional AXDescription failures and early unbounded-menu exploration; pilot-1 failed safe on duplicate dedicated title before editing; pilot-2/3 deterministic saves/rereads passed but lacked full close cleanup acceptance; pilot-4/5 stale native menu teardown rejected before mutation; pilot-6 passed prior cleanup dispatch-only check (superseded); pilot-7/8 native AXCannotComplete(-25204) failures before action; pilot-9 passed revised settling/reobservation and all completion fields. No failed record changed or scored as a blind/model run.

Development-window cleanup separately closed six leftover dedicated fixture/artifact documents, checked AXDocument URL ownership before selecting observed AXCloseButton, verified final TextEdit window list empty; evidence development-cleanup.json / development-cleanup-trace.jsonl. Application remained running. All raw artifacts stay in worktree per existing .gitignore, reports/plans in Git.

## Remaining limitations

Native model chain and missing-AX OCR/provider acceptance pending, queue not advanced to C4.5-AX. TextEdit plain text only, no rich text/file chooser/broader apps/skills/crossapplication or model capability claim. AX lacks atomic selected-window-check + application-menu-dispatch, immediate recheck removes avoidable traversal gap but unavoidable last read/request race remains. Bounded AX calls synchronously block asyncio; large values cost memory/time. Actual permission-unavailable pilot not produced because host granted access; fake tests verify denied semantics. P3 classifier concern retained. Public report docs/experiments/2026-10-07-macos-ax.md records exact outcomes and scoped next work.

## Final handoff

DONE_WITH_CONCERNS. Commits 4a4c890, b6e95c2, 0facc2b. Final full suite 1002 passed / 4 skipped / 1 xfailed / 1 existing warning in 302.27s, exit 0; focused 31 passed. Deterministic TextEdit pilot9 passed in 3989.598 ms; model/OCR acceptance pending. Independent scoped source review accepted P1/P2; P3 minor report-classification debt documented. Worktree has only parent-owned roadmap.md unstaged; raw evidence and this report retained adjacent to brief. No push.
