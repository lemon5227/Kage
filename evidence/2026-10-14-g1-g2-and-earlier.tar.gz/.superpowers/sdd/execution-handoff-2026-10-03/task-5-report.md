# Task 5 implementation handoff

Implemented `scripts/experiments/native_inactive_acceptance.py` and focused regression tests only; production core remains unchanged.

The frozen CLI creates exactly two fresh owned text files, sequentially in `main` and `run_sync`. It reuses `NativeDocumentEnvironment`, `ScopedNativeAdapter`, owned trace filtering, the editor4/checker-cleanup4/total8 attempt adapter, and the existing trusted disk/reopened AX checker. Every activation/fill/menu/Save mutation is dispatched at most once. Output must be fresh, and dirty diagnostic dependencies prevent probing. Freeze includes source/test/dependency hashes, helper source hash, protocol, revision, Python/platform, polling/deadline and thread semantics.

A subprocess runs its own AppKit application/window on its own main thread. It activates only itself, records readiness and PID, and polls actual foreground PID read-only within the same fixed three-second readiness window, and never hides, changes, or quits another application. Its Popen lifetime is explicitly owned and cleaned in `finally`, including readiness/setup failures. Terminate/kill targets only that Popen process. No TextEdit quit operation exists.

Before activation, the CLI requires successful setup/helper readiness, observed inactive TextEdit, independently observed foreground helper PID, and an exact owned main window. Unsupported activation stops before fill. After one scoped activation dispatch, independent AX/AppKit state must show the same TextEdit PID frontmost and the same owned main window, alongside the adapter's active observation. Already-active controls cannot pass. Unverified results preserve the document and original stage results. Checker statuses are retained without overrides; completion and activation verification are separately reported. Overall `acceptance_passed` additionally requires successful owned document cleanup and helper shutdown; cleanup failure preserves a passed checker result but makes overall acceptance false.

## Verification

- RED: new tests run before CLI implementation: 8 failed with explicit `controlled inactive acceptance CLI missing`.
- GREEN: initial focused set: 8 passed. Review gates were also RED/GREEN: missing foreground sample/aggregate fields failed before implementation, then 14 CLI tests passed.
- Final focused command: `python -m pytest -q tests/test_native_inactive_acceptance.py tests/test_native_menu_repair.py tests/test_native_lifecycle_diagnosis.py tests/test_native_save_readiness.py`: 30 passed in 0.68s. CLI `--help` also exits successfully without probing.
- Regression coverage: setup/readiness zero actions, false activation-success frontmost/main-window gates, changed owned window, already-active rejection, verified activation allowing only one fill, original failed action result retention, owned helper cleanup and early helper exit status, two fresh contexts/no overwrite, helper actual-frontmost polling without relaunch, and cleanup failure preventing overall acceptance.

## Boundaries

No actual desktop probe, AppKit helper launch, model/cloud request, full test suite, public status edit, or merge was performed. Actual AppKit subprocess foreground activation, macOS permissions, worker-thread AX behavior, and native Save/close/reopen timing remain untested until parent review and authorized live run. Read deadlines are cooperative; an individual blocking AX call is not force-cancelled. Failed/uncertain editor attempts preserve owned TextEdit documents rather than responding to destructive prompts. Existing evidence is untouched.

Source/test commit: `536d926` (`Add controlled inactive native acceptance diagnostic CLI`). This report lives under the existing ignored `.superpowers` handoff directory and is retained locally, outside the source commit. Parent owns review and live execution.
