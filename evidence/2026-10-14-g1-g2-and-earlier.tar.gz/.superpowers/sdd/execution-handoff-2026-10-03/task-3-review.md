# Task 3 review — source 6ded6f5

Spec verdict: changes required before the two live probes.
Quality verdict: one actionable evidence-preservation blocker.

## [P1] Preserve failed audits and finish the diagnostic envelope

`scripts/experiments/native_lifecycle_diagnosis.py:124–130` calls `document.read_text()` twice and dereferences target fields outside `safe()`. The same unguarded file read occurs in the cleanup condition at line 168 and final report at line 175. If the owned file becomes unavailable, or an audit encounters malformed/unavailable data, the exception leaves `probe()` after its passive-task cancellation. No final `report.json` or cleanup assessment is written, and `run()` never starts its second context. This conflicts with the brief's requirement to preserve all errors/unavailable outcomes and produce two bounded diagnostic contexts. These failures are particularly relevant to a lifecycle diagnostic.

Make audit/disk read failures explicit stage results; retain unavailable disk status without treating it as a content mismatch, and ensure report finalization/cleanup assessment occurs even after a diagnostic failure. The two-context orchestrator should retain a failed first probe result and continue to its one second probe without retries. Add a focused fake-environment case where the owned file/read becomes unavailable after fill, demonstrating retained error/report and bounded cancellation; no live probe is required to validate this.

## Verified by static inspection

- Diff adds only the diagnostic script and its focused tests; production runtime is unchanged.
- Three diagnostic primitive attempts are guarded by `ScopedNativeAdapter(max_actions=3)`. Trusted checker/cleanup actions are separate existing environment operations with their own bounded observation/close loops.
- Exactly two context call sites exist, main async first, then existing `run_sync` called from the still-active main event loop, selecting its thread branch.
- Delays are 10/10/10 seconds; passive sampling has a 21-sample ceiling, 2-second interval, and cancellation in a finally block. AX calls are synchronous and can delay event-loop scheduling, so sample cadence is best effort; the separate driver protects active identity caches, not timing independence.
- Fill intentionally uses initial refs after the first delay. Fresh observation precedes menu, and Save uses menu action's returned observation. This permits stale-ref diagnosis without passive cache invalidation or rescue retries.
- Expected full text contains its terminal newline. Fill value is trace-recorded; audits retain hashes/newline counts/exact comparisons. Setup/checker/cleanup actor attribution is recorded by the trusted environment; named timeline stages identify deterministic fill/menu/Save.
- Exact resolved file URL plus document title scopes active and passive ownership. Identification trace output filters unrelated windows; passive output includes only owned metadata and scalar count/PID/main-owned flag. No unrelated content snapshot, global keystroke, app quit, cloud call, or model dispatch is added.
- Fresh output directory is enforced before freeze; tracked diagnostic/runtime source status and hashes are recorded before setup. Existing controlled documents are not referenced.
- Cleanup is intentionally withheld for unsaved/uncertain state. Successful Save plus matching disk gates trusted close/reopen and cleanup.

Review used the supplied brief/diff and read-only inspection of relevant existing adapter/environment/run_sync implementations. No live desktop operations, tests, or source changes were performed. The reported 49 focused passes were not independently rerun.

## Scoped fix review — source 3e373d4

Spec verdict: pass for the authorized two live probes.
Quality verdict: pass; the P1 finding above is resolved.

Reviewed `task-3-fix-review.diff` (6ded6f5..3e373d4). Audit failures now produce structured unknown stages. Final disk-read failure records an explicit error and keeps `disk_matches=None`, withholding trusted close/reopen/cleanup for uncertain state. The outer probe envelope retains existing timeline stages and writes a failed report for exceptions escaping the inner implementation; it returns that result so the second existing `run_sync` context still executes once. Passive-task cancellation remains in the inner finally block. No additional live action, retry, desktop scope, or runtime change was introduced.

The added fake regression directly checks first-context escaped file failure, partial evidence/report retention, uncertain cleanup preservation, second-context execution, and summary creation. It exercises the outer failure envelope rather than the internal audit path, whose handling was verified by inspection. Reported 50 focused passes were not rerun. No tests, live desktop actions, or source edits were performed during this fix review.

## Actual evidence/document review — 2026-10-08-dev1

Evidence verdict: bounded execution accepted. Document verdict: one factual qualification required before acceptance.

Verified source hashes match freeze.json and current source for all five listed files. Summary probes equal their report.json files and timeline entries. Each context has 16 successful passive samples with one exact owned window, main-owned true, stable PID 2832, scalar count 1/main and 2/worker. Each trace contains exactly fill and menu press; no Save dispatch. Main menu retains applied true with -25204 error; worker menu retains applied true/success. Recorded audit stages and final reports show initial disk content and saved=false/actions=2. All inspected document URLs are the corresponding owned URL, with no foreign URL metadata in these artifacts. No desktop actions or test reruns were performed.

### [P1] Qualify recorded disk evidence and disclose subsequent disk change

`docs/experiments/2026-10-08-native-lifecycle-diagnosis.md` opening paragraph and exact-value paragraph describe unchanged disk fixtures without a time boundary. At this review, both retained .txt files actually contain 67 characters, 2 newlines and the terminal newline, SHA-256 `74ae6be3ab959a2757925c71f6df8b4e3dab82df99d78c1cec8aabdb614dbc75` (expected text). This differs from the initial 50-character/bf5d hash recorded by the probes' stage audits and final reports. Preserve those recorded results, qualify them as the state at probe completion, and add a subsequent read-only disk check with the changed hash. No deterministic Save action was dispatched; the actor, timing, and cause of the later disk change are unestablished. Do not attribute it to autosave without separate evidence. This affects current artifact interpretation, not the verified no-Save-dispatch finding.

The remainder of the report appropriately distinguishes nonreproduced disappearance from unknown cause, diagnostic controls from model capability, 50 focused tests from prior production full-suite verification, and unattempted cleanup from successful cleanup.

## Final documentation acceptance — report commit 2d90f41

Document/evidence verdict: accepted. The disk-state finding is resolved: the report distinguishes initial disk state at recorded probe completion from the separately timestamped later filesystem audit, retains no-Save-dispatch attribution, and leaves subsequent change cause unknown. `postprobe-disk-audit.json` agrees with the report's timestamp, mtime, exact-value metrics and hashes. No prior stage result is reinterpreted as successful Save or trusted independent reopen.

Reviewed the pending master-plan, roadmap, queue, handoff and experiment-index status changes. They consistently place bounded menu/activation diagnosis next, retain old controlled2 0/2 unknown, distinguish no-model controls from capability results, and do not claim a production fix or reproduced disappearance. The focused 50-pass checks and prior 1036-pass production verification remain distinct; neither is represented as a new diagnostic full-suite run. No actionable drift found. Review was limited to read-only report/artifact/status inspection; no source inspection rerun, tests, or desktop actions.
