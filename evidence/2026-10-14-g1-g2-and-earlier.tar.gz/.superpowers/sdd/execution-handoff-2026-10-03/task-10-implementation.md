# Task 10 — C1.2-R-text-dev4 implementation

Source/test commit: `e3e7ccb` (base `354ba18`). Dedicated experiment is `scripts/experiments/native_text_observed_dev.py`; existing menu dev and production core are unchanged. No desktop or real model attempt was executed by the implementation agent.

Fresh task `native_text_observed_dev4` uses only `kage-text-observed-dev4.txt`, exact requested text `文档复核\n结论：已确认\n操作：保存并验证\n` (21 Unicode characters, three LF including final LF). Actual soul is imported `RECOVERY_SOUL`; freeze hashes the selected task, protocol, soul, all core Python, experiment Python, native tests and `main.py`, plus Git and runtime/model/server provenance before task submission. Dirty frozen source and existing output are rejected.

Existing `NativeChainProvider` receives `max_model_calls=8`, which sets the actual chain request limit; `EvolutionRunner` kernel reserves eight API calls with its actual 3000 output-token reservation. Budget output configuration is 3000, rather than the incompatible 2400 actual-request aggregate. The normal chain sets temperature zero and output 300, loop eight/actions sixteen/cooperative timeout 480. Existing environment checker and cleanup perform two menu/Close pairs, plus setup/reopen (four trusted native actions, two opens). LocalService/broker/model, evaluator, runner, journal and budget are reused.

Environment setup retains its actual native environment and starts an independent observer only after the owned document setup. It disables raw adapter AX trace and sanitizes setup records. Before setup returns into the model chain it requires a valid retained original observer baseline and fresh child baseline, coherent original/baseline/fresh PID and exact URL, with owned count one. Fifteen-second startup and start gates are bounded. `DispatchModel` retains an additional readiness gate and records monotonic actual request/response/error events; first request creates the observer start marker. A failed setup gate prevents even the chain's recorded request counter from incrementing.

The observer reuses long experiment `Reader`, retaining the original object, then fresh independent readonly reader children; reads never write UI. It samples at two-second target intervals, at most 240 samples and 480 cooperative seconds, stopping early on the parent's stop marker. Original read errors retain unknown membership. Every row brackets cached/fresh reads with monotonic timestamps and markers before/after the reads, and stores hash/byte disk metrics without text. Other windows remain counts. Exceptions serialize types/AX code only. Retained/fresh reader calls can overrun a cooperative deadline, so no strict wall-time claim is made.

The atomic marker and append-only events distinguish model, agent native actions, checker Close dispatch/result, checker reopen and cleanup. Close intent alone is not proof that absence is normal: actual action-applied result and temporal read interval must be audited. No automated disappearance classification or causal attribution is added.

The parent outer finally stops its owned observer session/group, preserves observer errors and partial reports, and records budget state. Cleanup errors are reported in instrumentation and make CLI fail even if the trusted score passed. No TextEdit process, unrelated documents, or externally owned model server is terminated. Existing trusted completion retains unknown/failure semantics; there is no rescue or rerun.

TDD: first import failed because new feature/module was absent; baseline coherence, checker dispatch/result, request errors and setup gate tests then failed on missing behaviors before their implementation. Offline tests exercise actual owned subprocess handshake, actual provider→chain→runner eight requests and budget settlement, marker Close boundaries, unknown observations, partial/error cleanup, freeze guards and hash-only disk reads. Fake AX is limited to offline native boundary.

Verification: `82 passed in 5.32s` across dev4, menu dev, model chain, long observer and parent-reference tests; `git diff --check` passed. No current full-suite claim.

Parent next: review source before exactly one actual dev4 command; audit frozen bytes, actual timestamps/counters, observer partial coverage/Close boundaries and owned-group absence; then focused checks/docs/local FF. Suggested command:

```sh
.venv-computer-use/bin/python -m scripts.experiments.native_text_observed_dev --output artifacts/native-text-observed/2026-10-09-dev4
```

## Post-attempt observed-value feedback change

Parent executed the original frozen `e3e7ccb` dev4 exactly once, exit 1/score 0: four actual requests, two applied agent actions (fill/Save), checker failed. Actual saved value was a 26-character quoted JSON string with zero LF and three literal backslash-n sequences; `json.loads(actual)` equals the requested 21-character/three-LF text. Those failed results remain unchanged; no retry was performed.

Narrow follow-up changes only `NativeAXAdapter._observe` and native AX tests. Returned `AXTextArea`/`AXTextField` string targets now contain `value_metrics`: `characters`, `lf_count`, `ends_with_lf`, `literal_backslash_n_count`, and `scope='observed_value'`. This describes the driver-returned observed string (which can already be truncated), not a guaranteed full document value. Target dictionaries and snapshot are copied; the driver data and exact raw string remain untouched. Revision is calculated from the existing original snapshot before adding metrics, preserving stale-action guard semantics. There is no decoding, normalization, correction, rejection of quoted values, or expected/checker knowledge.

Two new tests first failed on missing `value_metrics`, then passed: real adapter observe/fill returns decoded 21/3/final-LF versus raw double-encoded 26/0/literal-three metrics; fill receives exact raw input. Shared driver snapshot remains unchanged; legitimate quoted text is preserved; AXTextField is included and nontext/None values get no invented metrics. Existing stale/read-unavailable behavior tests remain passing. Focused verification: `70 passed in 4.43s` (native AX, model chain, menu repair, observed dev4); diff check passed. This adds observable feedback only; model benefit remains unproven. Parent owns full-suite verification and reporting; frozen experiment/protocol/raw files unchanged.
