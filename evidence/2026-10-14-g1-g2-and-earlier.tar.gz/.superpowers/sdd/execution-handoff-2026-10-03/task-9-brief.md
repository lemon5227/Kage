# Task9 — C1.2-R-parent-reference

Base ce61c77; user authorized continuing the documented next package.

Retain setup environment, driver, original window_ref and AX object. Read same object before/after fixed180s async/passive and synchronous/blocking waits, with independent observer and fresh consumer tracking the two new owned documents. No model/cloud or UI writes after setup. Never refresh/adopt a replacement as original; unknown/error is not absence. Reset cooperative read deadline before each read. Preserve per-stage sanitized errors and partial evidence; unrelated windows only counts.

Reuse Task8 independent observer/process-group cleanup; freeze source/test/transitive helpers and protocol before exactly two new cases. Explicitly distinguish parent reference cache, physical document scope and process identity; sleep proxy lacks inference load. Public fixed protocol, no overwrite. TDD and independent code review before desktop run; final native focused tests, evidence audit and report review. No production changes without reproduced discrepancy. Report and status separately committed, local main fast-forward, preserve all ignored artifacts.

Checklist: source/tests red-green; source review; frozen two-case run; readonly audit; native regressions; report/status/ledger; final review and integration.
