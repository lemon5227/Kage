# Task10 — C1.2-R-text-dev4

Base354ba18. User authorized queue next new single instrumented real local text dev.

One fresh dedicated task with3LF exact text, existing RECOVERY_SOUL and production NativeChainProvider/Evaluator/kernel unchanged. Actual8 local request limit in provider/chain/kernel,16agent+4trusted/20total actions,2opens,480cooperative bound. Freeze source/test/task/prompt/protocol/runtime before exactlyoneattempt. No existingdev repeats/rescore. Observer baseline must be validowned scope beforefirstmodeldispatch, then ownedreadonly original+fresh samples every2s bounded240/480s, timestamps/stage/actor log. Checker Close/reopen/cleanup expectedscopeabsence must not be merged with agentunexpectedabsence. No unrelatedtitles/content; setup rawtrace disabled, partial/errorunknown preserved, ownPGcleanup in finally, no destructive rescue. Service ownedonly cleanup. Use TDD+source review beforeactualrun; actor/request/action/usage/prompt/hash/budget/process audit after; focusednative tests; fix reproducednarrowbug ifneeded, report+queue+roadmap+ledger and localmainff. Source-only diagnostic integration; no production core changes expected.

Checklist: implementation/red-green; independent review; exactlyonefrozen actualattempt; audit/diagnosis; focus; report/finalreview; status/ledger/integration.
