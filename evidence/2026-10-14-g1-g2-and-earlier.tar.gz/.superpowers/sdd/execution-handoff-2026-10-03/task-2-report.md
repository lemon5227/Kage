# Task 2 — native model chain and controlled acceptance

Worktree: `/Users/wenbo/.codex/worktrees/c2-learning-loop/Kage`; branch `codex/c2-learning-loop`.

## Implementation progress

Implemented native-specific reusable `NativeChainProvider` on the existing KageChainProvider / AgenticLoop / PromptBuilder / ToolExecutor chain, plus dedicated registry and scoped native adapter. `EvolutionRunner` remains the execution/budget/journal/scoring kernel; CLI uses inline mode because Objective-C/fork is unsafe, and explicitly reports cooperative timing instead of a hard timeout promise. The owned AX document is verified by exact resolved file URL as well as title. Native window discovery filters unrelated windows before model input. No filesystem tools or global keystroke tools are registered. Save evidence records a successful observed command-s press by the agent, so TextEdit autosave alone cannot earn a pass.

The trusted runtime performs only dedicated fixture setup/open, close/reopen and AX reread, then cleanup. Completion distinguishes failed versus unknown, compares actual disk bytes/text and reopened AX value, and never puts checker expected values or outcomes into model messages. Agent and runtime tool logs have separate attribution. Full model requests, raw server responses/usage, tool traces, chain outcomes and actual documents persist in the experiment workspace.

Tracked CLI: `python -m scripts.experiments.native_model_pilot --output-dir artifacts/native-model/controlled1`. It requires committed source/tests, refuses an existing output directory, freezes source hashes, prompt, two different task definitions, protocol and model/server provenance before inference, uses a fresh local-only ModelBroker config, validates existing service provenance or starts only its own known llama-server configuration, and terminates only that owned process. Fixed protocol: one attempt each, max 8 loop steps / 10 model requests / 16 primitive attempts / 480 cooperative seconds per task, 20 total model requests, no cloud. Existing engine default is unchanged.

## Test evidence before source freeze

TDD red: the initial five native chain tests failed because `native_model` did not exist. After implementation four passed and the request accounting regression exposed denied reservations being counted as actual dispatches; corrected to record actual dispatched requests independently while retaining metered attempts. Focused URL-scope regression failed on missing `document_path`; implemented exact AXDocument URL metadata and ownership binding. Save-evidence regression failed on missing save tracking; added successful observed Save attribution. Kernel integration test failed on missing provider/evaluator, then passed after integrating the existing runner and correcting the test's assumption that final_state_path was a file (it is a directory). Controlled CLI tests failed on absent CLI before its implementation.

Final focused command before source freeze:

```sh
.venv-computer-use/bin/python -m pytest tests/test_native_model_chain.py tests/test_native_controlled_cli.py tests/test_native_ax.py -q
```

Result: **22 passed in 0.28s**. Covers real message/tool exchange and true initial observation, checker isolation, stale recovery, allowed document/window filtering and same-title URL alias rejection, independently failed/unknown/passed checks, action/request/deadline guards, persisted request budget accounting, unknown token usage, successful observed agent Save, and EvolutionRunner/Journal integration.

## Pending

Source commits58e6446/abd0acd; four reviewer findings fixed and scoped re-review accepted. Focused controller re-run44passed0.23s. Frozen controlled2 ran exactly2tasks:0/2 kernel pass, both independent checksunknown; missing terminal newline, no appliedSave, window disappearance cause unestablished.16requests62609input1713output0cloud. Audit21/21consistency checks; owned service stopped. Experiment report and status docs drafted/reviewed; two doc drift findings corrected. Final full suite running after inference ended; report/docs commit remains. OCR remains unavailable; no speculative OCR implementation or full C1.2 completion claim.

Regression audit: first full1failed1035passed4skipped1xfailed298.75s; old170ms overlap threshold194ms. Test-only55c39ceuses2partyBarrier, serial mutation rejected, focus66passed1.57s. Full rerun in progress, source/protocol model hashes unchanged.

Final verification27be3a3:1036passed4skipped1xfailed1existingwarning433.75sec exit0. Two regression timing fixes independently accepted, original failure logs preserved. Source/pilot hashes remainabd0acd. Model chain engineering/experiment package complete; capability0/2unknown2, nextC1.2-R.
