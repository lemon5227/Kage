# Task 2 source review

Reviewed source package `56eed1e..58e6446`, brief, report, implementation, focused tests, and shared runner/provider/completion interfaces. Static review only: no desktop operations, inference, tests, or source edits performed by this reviewer. Reported focused evidence is 22 passing tests; full-suite and real-model acceptance remain pending.

## Verdict

Spec compliance: **changes required before controlled inference**. Quality: **changes required**. The source follows the intended native module separation and existing AgenticLoop/PromptBuilder/ModelBroker/ToolExecutor plus EvolutionRunner/BudgetTracker/Journal architecture. It provides actual initial AX observations, local-only broker configuration, separate agent/runtime logs, persistent full model responses, and independent disk plus reopen-AX checking. Four correctness defects require resolution and focused regressions.

## Findings

1. **P1 — Validate refreshed observations before returning them to the model.** `core/computer_use/native_model.py:97-100`. `ScopedNativeAdapter.act` validates only cached pre-action identity, then returns the unfiltered adapter result. A document identity change during freshness checking produces a stale result containing the newly observed foreign document, leaking its contents into model context. A post-action identity change can do the same. Check every returned observation against the owned path/window, redact foreign observations, and invalidate adapter state. Prior review finding; fix pending.

2. **P1 — Confine the reusable provider's document path to its workspace.** `core/computer_use/native_model.py:303-306`. `workspace / document_name` accepts absolute paths, `..` traversal, and existing symlinks escaping the workspace. The provider then opens and gives the agent editing access to that document. Runner fixture validation does not validate this separate provider field. Reject escapes and symlinks before constructing the environment, require an existing owned fixture, and fail before desktop operations. Prior review finding; fix pending.

3. **P2 — Save evidence must follow the last mutation.** `core/computer_use/native_model.py:95-99`. `save_applied` stays true after later fills. A Save followed by an edit can satisfy disk/AX checks via TextEdit autosave while receiving credit for app Save of the final content. Invalidate evidence on later potentially applied mutations, then require a successful observed Save after them. Prior review finding; fix pending.

4. **P2 — Return the shared runner's chain metadata schema.** `core/computer_use/native_model.py:327-329`. Native report exposes `loop.stop_reason`, `model_requests`, and `agent_actions`; EvolutionRunner consumes top-level `stop_reason`, `model_calls`, `tool_calls`, and `chain_steps`. Thus a real call-limit/step-limit/error run receives a kernel completion reason of `model_returned` and zero chain counters. Native artifacts retain the true values, but journal/results metadata misclassifies the execution. Project loop stop reason and actual counters to the shared schema; verify runner metadata on bounded and normal outcomes.

## Other assessed requirements

- Shared kernel: controlled CLI reserves through EvolutionRunner and settles actual dispatch usage; the inner native chain receives no second budget tracker. Per-task MeteredProvider limits plus kernel reservations bound total requests. Unknown token usage remains unknown for conservative settlement. Timing is correctly documented as cooperative rather than a hard cap.
- Attribution/checker: expected checker data is not injected into model context. Setup/reopen/cleanup operations have separate runtime actor labels. Checker verifies disk before controlled close/reopen and actual AX text afterward; failures and unavailable checks remain distinct in completion.json. Uncertain/unsaved close prompts are preserved instead of answered.
- Scope/cleanup: exact resolved AXDocument matching is stronger than title matching. Close uses an observed owned-window menu and driver main-window checks. The title-only disappearance probe can conservatively fail on an unrelated same-title document; this does not grant that document actions. Unknown results intentionally skip further close attempts. Cleanup failures are retained separately and do not falsify edit/save acceptance.
- Service/provenance: absent service starts the known argv; existing service ownership/path/model alias is observed; only a process spawned by this context is terminated. Source/prompt/task/protocol and actual server command/model/server hashes freeze before inference. Bound version acquisition before real runs: `llama-server --version` currently has no timeout and is being fixed separately.
- Acceptance: no actual inference evidence exists yet. Two distinct one-attempt runs, final full suite, controlled artifacts, OCR coverage investigation/reporting, and experiment report remain necessary. Do not claim full C1.2 completion from this source review.

## Re-review gate

Review the final fix commit and focused regression evidence before inference. Confirm all four findings are closed, version acquisition is bounded, source/tests are committed, and protocol is frozen once before the first request. Retain negative outcomes without retrying for score.


## Scoped fix re-review — `58e6446..abd0acd` (2026-10-07)

Spec compliance: **accept the source fixes for controlled inference**. Quality: **accept within this scoped re-review**. No actionable residual defect was found in the four fixes or bounded version probe. This verdict supersedes the source-change gate above; it does not establish full C1.2 acceptance.

Static verification inspected the committed diff, `task-2-fix-review.diff`, native adapter result paths, workspace resolver, executor accounting, and shared runner metadata consumers:

- Finding 1 closed: both observe and act pass every returned observation, including unsuccessful stale/uncertain results, through window/title/resolved-URL ownership checks. A foreign result is replaced by a content-free rejection, preserves only action-applied attribution, and clears cached adapter state. Regression cases cover changed URL/title/window across stale, successful and uncertain actions plus successful/failed observations.
- Finding 2 closed: the document resolves through the shared workspace confinement helper before environment construction. Absolute paths and escaping traversal/symlinks fail; an existing regular file must match its declared initial text fixture before any desktop setup. Focused cases cover each escape and absent/mismatched fixture.
- Finding 3 closed: an applied or uncertain fill clears previous Save evidence before result filtering; only a successful scoped observed Save restores it. Clearly unapplied fills preserve evidence. Added tests cover applied and uncertain later fills.
- Finding 4 closed: chain metadata now projects loop stop reason, actual dispatched model requests, executor tool entries, and loop steps into the shared schema. Initialization defaults are explicit. The runner regression checks a real call-limit reason and nonzero actual chain counters; the same projection applies to normal/error outcomes.
- CLI version acquisition uses `subprocess.run(..., timeout=3)` and retains timeout partial output, nonzero exit status, OS errors, and available server build-log information. The probe no longer blocks indefinitely.

Focused evidence supplied by the implementation/controller is **44 passed**; this reviewer did not rerun tests, inference, or desktop operations, as requested. Source/test changes are committed in `abd0acd`. The reported initial aborted `controlled1` attempt contains server/cleanup evidence only and no freeze or inference; it supplies no task acceptance evidence. Freeze the committed source/protocol once before the first actual request, retain each of the two distinct one-attempt outcomes without score-driven retries, and complete the already-required full suite, experiment report, and AX/OCR coverage accounting before claiming C1.2 complete.


## Negative experiment and status-document review (2026-10-07)

Source acceptance for `abd0acd` remains unchanged. **Negative experiment report accepted on factual content**: read the new native-model report and current roadmap/queue/handoff/master-plan/index diff against controlled2 `audit.json`, `results.json`, and recorded tool observations. The report correctly separates kernel failed/score0/step_limit from independent unknown, preserves 0/2, 16 local requests and 62,609/1,713 input/output tokens, reports absent effective Save and the missing terminal newline rather than literal-backslash error, and leaves the window-disappearance cause unestablished. Initial observation evidence includes text, document menu and Save targets; it does not establish OCR coverage or general native capability. The 21/21 audit is explicitly evidence consistency, not task acceptance. No inference, test, or desktop operation was performed by this reviewer. The full-suite placeholder correctly remains pending.

Two factual documentation corrections remain before final document acceptance:

1. `docs/plans/execution-handoff-2026-10-03.md` §9's starting instruction still says to continue the original real-model decision-chain package. Replace that current-work instruction with the C1.2-R bounded dev diagnosis now described in the same document's header and new handoff section, retaining the original eventual acceptance requirements.
2. `docs/experiments/README.md` puts the new real-model experiment under “规划复核（非新模型实验）”. Move it into the actual experiment index so its category agrees with the 16 real model requests.

After those corrections and insertion of the actual completed full-suite evidence, the reviewed negative experiment/status package has no other actionable factual inconsistency. C1.2 capability remains unaccepted; no extra runs are requested.


## Documentation corrections and thread-overlap test review (2026-10-07)

**Accept the two documentation corrections and the test-only concurrency regression update.** The handoff §7/§9 now directs current work to C1.2-R bounded dev diagnosis, and the native-model report is in the actual experiment table rather than the non-model planning section. Both prior document findings are closed. Negative experiment/report acceptance and native-source acceptance remain unchanged.

Static review of `tests/test_round5_cleanup.py` confirms that the replacement asserts the intended concurrency property: each of two real synchronous handlers must reach the same two-party `threading.Barrier` before either can return successfully. Serial/event-loop-blocking dispatch cannot satisfy it and produces unsuccessful results; the final assertion checks both success and output. The five-second barrier timeout bounds failure rather than imposing the prior 170ms throughput threshold. The retained `thread-overlap-mutation-red.txt` records rejection of serial dispatch (one failed test in 5.37s), consistent with that reasoning. Production `ToolExecutor` still uses `asyncio.to_thread`; its source and the frozen native pilot source are untouched. No reviewer test rerun was performed.

The controller reports the first full suite as 1 failed / 1035 passed / 4 skipped / 1 xfailed in 298.75s, with the former timing test observing 194ms versus its 170ms threshold. Preserve that attempt in final documentation; subsequent focused and full-suite evidence is pending and must be inserted from actual completed outputs. No new inference or task outcome is needed for this test-only correction.


## Browser restart test condition-wait review (2026-10-07)

**Accept the test-only bounded PID-removal wait** in `test_restart_rejects_post_result_worker_before_parent_clean_exit`. Static diff review confirms it keeps synchronous stopped/service_restart, absent candidate, and stop.requested assertions unchanged, then waits at most two seconds for the same PID-absence condition formerly asserted immediately. The final `pytest.raises(ProcessLookupError)` assertion remains mandatory; the wait neither terminates the worker nor accepts an extant process. A worker left alive by broken recovery therefore still fails the test. The fixture intentionally sleeps 60 seconds after writing its result, so natural completion cannot explain disappearance within this two-second allowance. This accommodates asynchronous parent reaping without relaxing candidate acceptance or ownership behavior. The later restored-service stopped assertion is retained. No production/native-pilot source change or reviewer rerun occurred.

Controller-supplied evidence: second full suite 1 failed / 1035 passed in 407.74s at the former immediate PID check; unchanged focused test passed in 6.24s. Preserve both full-suite failures and focused evidence; the related targeted run and final full-suite result remain pending actual outputs.
