# G1 bounded accounting correction (2026-10-11)

Base a7440f3. Shared BudgetTracker run usage previously summed repeated evaluation IDs from distinct roots/journals. Global budget accounting still counted actual calls correctly; this corrects future per-run attribution. Completed run1/run2 artifacts remain untouched and were not rescored or rerun.

Promoter now accepts optional `run_namespace=''`. Empty default preserves prior evaluation/repeat IDs exactly. A nonempty filename-safe namespace appends `-n{namespace}` after existing ID/repeat segments, retaining split prefixes and compatibility with validation provenance checks. No CLI edit or live/model call occurred here; caller owns deriving a stable unique root namespace.

TDD: namespaced shared-budget fixture and invalid namespace cases failed against missing API. After the minimal addition, focused `tests/test_evolution_promotion.py tests/test_recovery_loop.py` reports 45 passed; diff check clean. Two real Promoter roots and separate Journals share one durable BudgetTracker, identical candidate/task, and each attribution is one actual call; global calls are two. Resume of root2 remains one without spending again. Default/repeated legacy IDs remain exact. Parent owns one full-suite rerun after all fixes.
