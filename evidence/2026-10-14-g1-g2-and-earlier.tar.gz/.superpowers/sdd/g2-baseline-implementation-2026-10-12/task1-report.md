# Task 1: read_preserve evaluator

Only core/evolution/runner.py and tests/test_evolution_read_preserve.py changed.

TDD red: `python -m pytest -q tests/test_evolution_read_preserve.py` before production edits: 29 failed, 2 passed in 0.52s. Failures showed missing history keyword and real runner positive read score 0. Full red log: task1-red.txt.

Final verification: `python -m pytest -q tests/test_evolution_read_preserve.py tests/test_evolution_agent_chain.py tests/test_recovery_loop.py`: 78 passed in 8.69s. `git diff --check` passed.

Evaluator uses exact byte SHA256 and existing workspace path containment. Requires exact criteria keys, lower-case 64 hex digest, valid history rows, explicit successful read_file observation and matching relative path; rejects any actor's skill_call even failed/no effect. Unknown/malformed observations cannot establish successful read. Runner supplies actual history only for read_preserve; two-argument custom evaluator contract remains covered.

Controlled ModelProvider runs through real KageChainProvider and EvolutionRunner: read unchanged succeeds, read plus unavailable skill_call fails with identical final bytes. Prompts and visible_feedback exclude criteria, digest and criterion type.

No private configuration reads, teacher calls, candidate creation, Docker calls or real model experiments. Teacher 0 / candidate 0. This is engineering validation, not G2 growth evidence.
