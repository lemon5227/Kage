def choose(jobs, capacity):
    return []
