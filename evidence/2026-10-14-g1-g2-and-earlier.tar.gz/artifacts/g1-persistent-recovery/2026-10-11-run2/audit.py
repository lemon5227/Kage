import hashlib,json,sqlite3,subprocess
from pathlib import Path
B=Path(__file__).resolve().parent.parent
phases=[B/'2026-10-09-run1',B/'2026-10-11-run2']
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks={};runs=[]
for p in phases:
 f=read(p/'freeze.json');r=read(p/'report.json');s=read(p/'state/recovery_state.json')
 checks[p.name+'_inputs_frozen']=all(sha(p/n)==h for n,h in f['input_hashes'].items()) and sha(p/'driver.py')==f['driver_sha256']
 checks[p.name+'_source_frozen']=all(hashlib.sha256(subprocess.check_output(['git','show',f"{f['git_revision']}:{n}"])).hexdigest()==h for n,h in f['source_hashes'].items())
 rr=[r['source']['result']]+[pair[arm] for pair in r['source']['comparison']['pairs'] for arm in ['parent','child']]
 if r['restart_application']:rr.append(r['restart_application']['result'])
 runs.extend(rr)
 checks[p.name+'_bounded']=all(x['metadata']['chain_model_calls']<=6 and x['metadata']['chain_tool_calls']<=12 and all(c['chain_steps']<=5 for c in x['metadata']['chain']) for x in rr)
 checks[p.name+'_validation_only']=all(pair[arm]['run_id'].startswith('validation-') for pair in r['source']['comparison']['pairs'] for arm in ['parent','child'])
r1=read(phases[0]/'report.json');r2=read(phases[1]/'report.json');app=r2['restart_application'];claim=read(phases[0]/'state/continuation.json')
checks['old_rejection_preserved']=not r1['source']['comparison']['promoted'] and r1['restart_application'] is None
checks['prior_state_preserved']=sha(phases[0]/'state/recovery_state.json')==claim['prior_state_sha256'] and sha(phases[0]/'state/protocol.json')==claim['prior_protocol_sha256']
checks['unique_continuation']=claim['root']==str(phases[1]/'state')
checks['failed_source_then_promotion']=r2['source']['result']['score']==0 and r2['source']['comparison']['promoted'] and r2['source']['comparison']['parent_score']==0 and r2['source']['comparison']['child_score']==1
checks['automatic_application']=app['candidate']['digest']==read(phases[1]/'state/active.json')['candidate']['digest']==r2['source']['comparison']['child']['digest'] and app['result']['score']==1 and app['result']['metadata']['completion']['check_passed']
tr=app['result']['metadata']['chain'][0]['recovery_trace'][0]
checks['generated_source_executed']=sha(Path(tr['module_path']))==tr['module_sha256'] and tr['result']['tool_call']['name']=='skill_call'
checks['two_candidates_seven_runs']=sum(read(p/'state/recovery_state.json')['candidates'] for p in phases)==2 and len(runs)==7
actual_calls=sum(x['metadata']['chain_model_calls'] for x in runs)
actual_usage={key:sum(u[key] for x in runs for c in x['metadata']['chain'] for u in c['call_usage']) for key in ['input_tokens','output_tokens']}
totals={}
for kind in ['local','teacher']:
 con=sqlite3.connect(f"file:{phases[0]/'state'/(kind+'-budget.sqlite')}?mode=ro",uri=True)
 row=con.execute('select sum(input_used),sum(output_used),sum(calls_used),sum(state!=\'settled\') from evolution_budget').fetchone();con.close()
 totals[kind]=dict(zip(['input_tokens','output_tokens','api_calls','unsettled'],row))
 checks[kind+'_shared_no_new_ledger']=not (phases[1]/'state'/(kind+'-budget.sqlite')).exists() and row[3]==0
checks['local_chain_equals_ledger']=actual_calls==totals['local']['api_calls']==21 and all(actual_usage[k]==totals['local'][k] for k in actual_usage)
checks['teacher_two_calls']=sum(len((p/'state/teacher-model.jsonl').read_text().splitlines()) for p in phases)==totals['teacher']['api_calls']==2
cost=(totals['teacher']['input_tokens']*.3+totals['teacher']['output_tokens']*1.2)/1e6
checks['teacher_budget']=cost<=.03
checks['owned_service_stopped']=read(phases[1]/'service-cleanup.json')['owned_service_stopped']
assert all(checks.values()),checks
out={'checks':checks,'actual_runs':len(runs),'actual_local_calls':actual_calls,'shared_budget_totals':totals,'teacher_peak_estimate_usd':cost,'attribution_note':'Run2 validation parent raw usage includes run1 same run_id. Use actual chain call_usage and shared ledger, never sum cumulative RunResult.usage. Original raw records unchanged; namespaces fix future runs only.'}
(phases[1]/'audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'checks_passed':len(checks),'local_calls':actual_calls,'teacher_cost_estimate':cost}))
