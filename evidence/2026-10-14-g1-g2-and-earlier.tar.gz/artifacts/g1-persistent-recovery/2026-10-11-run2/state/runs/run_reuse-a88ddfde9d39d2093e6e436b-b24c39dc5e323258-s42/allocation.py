def pick_projects(jobs, capacity):
    if capacity < 0:
        raise ValueError("capacity must be nonnegative")
    for j in jobs:
        if j['weight'] <= 0:
            raise ValueError("job weight must be positive")

    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for j in jobs:
        w = j['weight']
        v = j['value']
        jid = j['id']
        for cap in range(capacity, w - 1, -1):
            prev = dp[cap - w]
            if prev is None:
                continue
            cand_val = prev[0] + v
            cand_ids = sorted(prev[1] + [jid])
            cur = dp[cap]
            if cur is None or cand_val > cur[0] or (cand_val == cur[0] and cand_ids < cur[1]):
                dp[cap] = (cand_val, cand_ids)

    best = (0, [])
    for cap in range(capacity + 1):
        cur = dp[cap]
        if cur is None:
            continue
        if cur[0] > best[0] or (cur[0] == best[0] and cur[1] < best[1]):
            best = cur
    return best[1]
