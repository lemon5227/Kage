"""Fixed single source learning entry; restart application only after promotion."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

from scripts.experiments.native_model_pilot import LocalService, ROOT

out=Path(__file__).resolve().parent
names=[str(p.relative_to(ROOT)) for p in (ROOT/'core').rglob('*.py')]
names+=['scripts/kage_recover.py','scripts/experiments/task_suite.py','scripts/experiments/native_model_pilot.py']
if subprocess.check_output(['git','status','--porcelain','--',*names],cwd=ROOT,text=True):
    raise RuntimeError('source must be committed before this attempt')
if (out/'freeze.json').exists():
    raise RuntimeError('fixed experiment already started; no overwrite/retry')
started=time.monotonic()
report={'source':None,'restart_application':None,'stop_reason':'not_started'}
with LocalService(18082,out) as service:
    freeze={'git_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
      'source_hashes':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names},
      'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'input_hashes':{n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in ['config.json','bootstrap.json','source.json','validation.json','reuse.json']},
      'runtime':service.runtime,
      'docker_image_id':subprocess.check_output(['docker','image','inspect','kage-evolution:local','--format','{{.Id}}'],text=True).strip(),
      'teacher_authorized_max_cost_usd':.03,'teacher_max_requests':6,'max_candidates':2,'max_evaluations':12,
      'max_local_requests_per_run':6,'max_tool_dispatches_per_run':12,'max_chain_steps':5,'task_timeout_s':150,
      'teacher_input_bytes':12000,'teacher_output_tokens':3000,'teacher_http_timeout_s':60,
      'price_basis':'conservative peak all input cache-miss 0.3/output1.2 USD per million; not account invoice',
      'price_source':'https://api-docs.deepseek.com/quick_start/pricing/',
      'splits':'versioned development; byte-identical exposed validation; first application input not G3 final evaluation',
      'continuation_root':str((out.parent/'2026-10-09-run1/state').resolve()),
      'remaining_candidates':1,'remaining_evaluations':9,'remaining_teacher_requests_before_start':5,
      'prior_run_not_rescored':True,
      'human_intervention':'bootstrap fixed recovery channel and frozen existing skill; no task-specific failure hints/candidate repairs'}
    (out/'freeze.json').write_text(json.dumps(freeze,indent=2))
    for label,filename in [('source','source.json'),('restart_application','reuse.json')]:
        if label=='restart_application' and not (report['source'].get('comparison') or {}).get('promoted'):
            report['stop_reason']='no_promotion';break
        print('Executing '+label+' in a fresh CLI process',flush=True)
        command=[sys.executable,str(ROOT/'scripts/kage_recover.py'),'--config',str(out/'config.json'),
                 '--task',str(out/filename),'--allow-paid-teacher']
        with (out/(label+'.stdout')).open('w') as stdout, (out/(label+'.stderr')).open('w') as stderr:
            process=subprocess.run(command,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=800)
        if process.returncode:
            report['stop_reason']=label+'_entry_error';report[label]={'returncode':process.returncode};break
        report[label]=json.loads((out/(label+'.stdout')).read_text())
        row=report[label]
        print(json.dumps({'phase':label,'status':(row.get('result') or {}).get('status'),'stop_reason':row.get('stop_reason'),
                          'promoted':(row.get('comparison') or {}).get('promoted')}),flush=True)
        report['stop_reason']='application_completed'
report['elapsed_s']=time.monotonic()-started
(out/'report.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'stop_reason':report['stop_reason'],'elapsed_s':report['elapsed_s']}),flush=True)
