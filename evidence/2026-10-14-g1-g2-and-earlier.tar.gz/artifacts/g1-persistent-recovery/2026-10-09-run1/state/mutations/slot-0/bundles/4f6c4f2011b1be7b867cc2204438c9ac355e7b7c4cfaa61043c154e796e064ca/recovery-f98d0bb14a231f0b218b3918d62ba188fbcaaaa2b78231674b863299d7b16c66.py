def recover(error, history, checkpoints):
    file_path = None
    function_name = None

    for row in history:
        if row.get("name") == "read_file" and row.get("success"):
            args = row.get("arguments") or {}
            if isinstance(args, dict) and args.get("path"):
                file_path = args["path"]
            result = row.get("result")
            if isinstance(result, str):
                try:
                    import json
                    parsed = json.loads(result)
                except Exception:
                    parsed = None
                if isinstance(parsed, dict):
                    if parsed.get("path"):
                        file_path = parsed["path"]
                    content = parsed.get("content")
                    if isinstance(content, str):
                        import re
                        m = re.search(r"def\s+([A-Za-z_]\w*)\s*\(", content)
                        if m:
                            function_name = m.group(1)

    if not file_path:
        return {"action": "stop"}

    skills = error.get("available_skills") or []
    for skill in skills:
        if not isinstance(skill, dict):
            continue
        desc = (skill.get("description") or "").lower()
        if "knapsack" in desc and "selection" in desc:
            skill_id = skill.get("skill_id")
            digest = skill.get("digest")
            if not skill_id or not digest:
                continue
            arguments = {"file_path": file_path}
            if function_name:
                arguments["function_name"] = function_name
            return {
                "action": "switch_tool",
                "tool_call": {
                    "name": "skill_call",
                    "arguments": {
                        "skill_id": skill_id,
                        "digest": digest,
                        "arguments": arguments,
                    },
                },
            }

    return {"action": "stop"}