def select_tasks(jobs, capacity):
    return []
