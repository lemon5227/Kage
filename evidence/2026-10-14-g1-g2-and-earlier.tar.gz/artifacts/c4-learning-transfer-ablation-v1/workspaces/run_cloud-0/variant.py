def pick_jobs(jobs, capacity):
    """Select jobs to maximize total value with total weight <= capacity.

    Each job is a dict with keys: id (unique str), weight (positive int),
    value (nonnegative int). Returns a sorted list of selected IDs.
    On equal total value, the lexicographically smallest ID list is chosen.
    Empty selection is allowed. Raises ValueError for negative capacity or
    nonpositive job weight. Does not mutate inputs.
    """
    if capacity < 0:
        raise ValueError("capacity must be nonnegative")

    items = []
    for job in jobs:
        jid = job["id"]
        weight = job["weight"]
        value = job["value"]
        if weight <= 0:
            raise ValueError("job weight must be positive")
        items.append((jid, weight, value))

    # Sort items by id so that we can build lexicographically smallest ID lists.
    items.sort(key=lambda x: x[0])
    n = len(items)

    # dp[w] = best (value, id_list) achievable with capacity w using processed items.
    # id_list stored as tuple of ids in sorted order.
    NEG = None
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for jid, weight, value in items:
        # iterate capacity descending for 0/1 knapsack
        for w in range(capacity, weight - 1, -1):
            prev = dp[w - weight]
            if prev is None:
                continue
            cand_value = prev[0] + value
            # build candidate id list (sorted, since items processed in id order
            # and we insert jid in sorted position)
            cand_ids = _insert_sorted(prev[1], jid)
            cur = dp[w]
            if cur is None:
                dp[w] = (cand_value, cand_ids)
            else:
                if cand_value > cur[0]:
                    dp[w] = (cand_value, cand_ids)
                elif cand_value == cur[0] and cand_ids < cur[1]:
                    dp[w] = (cand_value, cand_ids)

    best = None
    for w in range(capacity + 1):
        cur = dp[w]
        if cur is None:
            continue
        if best is None:
            best = cur
        else:
            if cur[0] > best[0]:
                best = cur
            elif cur[0] == best[0] and cur[1] < best[1]:
                best = cur

    if best is None:
        return []
    return list(best[1])


def _insert_sorted(sorted_ids, jid):
    """Insert jid into a sorted tuple of ids, returning a new sorted tuple."""
    result = []
    inserted = False
    for x in sorted_ids:
        if not inserted and jid < x:
            result.append(jid)
            inserted = True
        result.append(x)
    if not inserted:
        result.append(jid)
    return tuple(result)
