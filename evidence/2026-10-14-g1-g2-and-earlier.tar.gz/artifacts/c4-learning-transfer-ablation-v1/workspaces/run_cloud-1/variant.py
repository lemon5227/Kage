def pick_jobs(jobs, capacity):
    """Select jobs maximizing total value with total weight <= capacity.

    Each job is a dict with keys: id (unique str), weight (positive int),
    value (nonnegative int). Returns a sorted list of selected IDs. On ties
    in total value, the lexicographically smallest ID list is chosen.
    Raises ValueError for negative capacity or nonpositive job weight.
    Does not mutate inputs.
    """
    if capacity < 0:
        raise ValueError("capacity must be nonnegative")

    items = []
    for job in jobs:
        jid = job["id"]
        w = job["weight"]
        v = job["value"]
        if w <= 0:
            raise ValueError("job weight must be positive")
        items.append((jid, w, v))

    # Sort items by id so that we can build lexicographically smallest
    # ID lists deterministically.
    items.sort(key=lambda x: x[0])
    n = len(items)

    # dp[c] = best (value, id_list) using processed items with weight <= c
    # We track the chosen id list to compare lexicographically on ties.
    dp = [(0, []) for _ in range(capacity + 1)]

    for jid, w, v in items:
        # iterate capacity descending for 0/1 knapsack
        for c in range(capacity, w - 1, -1):
            prev_val, prev_ids = dp[c - w]
            cand_val = prev_val + v
            cand_ids = prev_ids + [jid]
            cur_val, cur_ids = dp[c]
            if cand_val > cur_val:
                dp[c] = (cand_val, cand_ids)
            elif cand_val == cur_val:
                if cand_ids < cur_ids:
                    dp[c] = (cand_val, cand_ids)

    best_val, best_ids = dp[capacity]
    return sorted(best_ids)
