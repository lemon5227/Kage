def pick_jobs(jobs, capacity):
    """Select jobs to maximize total value with total weight <= capacity.

    Each job is a dict with keys: id (unique str), weight (positive int),
    value (nonnegative int). Returns a sorted list of selected IDs. On ties
    in total value, the lexicographically smallest ID list is chosen.
    Empty selection is allowed. Raises ValueError for negative capacity or
    nonpositive job weight. Inputs are not mutated.
    """
    if capacity < 0:
        raise ValueError("capacity must be nonnegative")

    items = []
    for job in jobs:
        jid = job["id"]
        weight = job["weight"]
        value = job["value"]
        if weight <= 0:
            raise ValueError("job weight must be positive")
        items.append((jid, weight, value))

    # Sort items by id so that we can build lexicographically smallest
    # ID lists deterministically.
    items.sort(key=lambda x: x[0])
    n = len(items)

    # dp[w] = best (value, id_list) using processed items with weight <= w.
    # id_list kept sorted ascending.
    dp = [(0, []) for _ in range(capacity + 1)]

    for jid, weight, value in items:
        # iterate weights descending for 0/1 knapsack
        for w in range(capacity, weight - 1, -1):
            prev_val, prev_ids = dp[w - weight]
            cand_val = prev_val + value
            cand_ids = sorted(prev_ids + [jid])
            cur_val, cur_ids = dp[w]
            if cand_val > cur_val or (cand_val == cur_val and cand_ids < cur_ids):
                dp[w] = (cand_val, cand_ids)

    best_val, best_ids = dp[capacity]
    return sorted(best_ids)
