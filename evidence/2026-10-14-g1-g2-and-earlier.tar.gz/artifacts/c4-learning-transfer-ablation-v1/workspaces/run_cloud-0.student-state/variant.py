def pick_jobs(jobs, capacity):
    return []
