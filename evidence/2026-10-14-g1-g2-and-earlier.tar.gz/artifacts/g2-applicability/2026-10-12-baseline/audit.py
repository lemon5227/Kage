import hashlib,json,socket,sqlite3,subprocess
from pathlib import Path
B=Path(__file__).resolve().parent;P=B/'state'
import sys
sys.path.insert(0,str(B.parents[2]))
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=read(P/'report.json');f=read(P/'freeze.json');proto=f['protocol'];tasks=proto['tasks'];rows=r['runs'];checks={}
checks['frozen_committed_code']=all(hashlib.sha256(subprocess.check_output(['git','show',f"{f['git_revision']}:{n}"])).hexdigest()==h for n,h in proto['source_hashes'].items())
checks['suite_frozen']=sha(Path(proto['suite_path']))==proto['suite_sha256']
checks['candidate_record_frozen']=sha(Path(proto['candidate_record_path']))==proto['candidate_record_sha256']
manifest=read(Path(proto['candidate']['bundle_path'])/'manifest.json');module=manifest['modules']['recovery'];code=Path(proto['candidate']['bundle_path'])/module['entrypoint'].split(':')[0]
checks['actual_recovery_hash']=sha(code)==module['digest']==proto['candidate_source_sha256']=='0b3fd2a2d5a5e3d7c360a6e8e74237334cdad3e34b36409619e40747211ed790'
from core.evolution.mutator import bundle_digest
checks['candidate_bundle_intact']=bundle_digest(code.parent)==proto['candidate']['digest']
source,old=rows
checks['natural_source_failure']=source['failure_kind']=='capability' and source['result']['score']==0 and any(c['actor']=='recovery_policy' and c['observation']['success'] is True for c in source['skill_calls'])
checks['file_changed']=sha(Path(source['result']['final_state_path'])/'pricing.py')!=tasks[0]['scoring_criteria']['sha256']
checks['successful_old_capability']=old['result']['score']==1 and any(c['actor']=='recovery_policy' and c['observation']['success'] is True and c['action']['arguments']['digest']==f['skill_digests'][c['action']['arguments']['skill_id']] for c in old['skill_calls'])
checks['actual_policy_same']=all(x['result']['metadata']['recovery']['module_sha256']==proto['candidate_source_sha256'] for x in rows)
checks['bounded_runs']=len(rows)==2 and all(x['result']['metadata']['chain_model_calls']<=6 and x['result']['metadata']['chain_tool_calls']<=12 and all(c['chain_steps']<=5 for c in x['result']['metadata']['chain']) for x in rows)
con=sqlite3.connect(f"file:{P/'local-budget.sqlite'}?mode=ro",uri=True);ledger=con.execute("select sum(calls_used),sum(input_used),sum(output_used),sum(state!='settled') from evolution_budget").fetchone();con.close()
log=P/f"student-{proto['candidate']['digest'][:16]}.jsonl";modelrows=[json.loads(s) for s in log.read_text().splitlines()]
checks['requests_and_ledger_agree']=len(modelrows)==sum(x['result']['metadata']['chain_model_calls'] for x in rows)==ledger[0]==r['budget']['total_api_calls']==7 and ledger[3]==0
checks['token_totals']=ledger[1]==r['budget']['total_input_tokens']==9974 and ledger[2]==r['budget']['total_output_tokens']==819
checks['hidden_fields_not_sent']=all('scoring_criteria' not in json.dumps(x['messages']) and tasks[0]['scoring_criteria']['sha256'] not in json.dumps(x['messages']) for x in modelrows)
checks['no_teacher_or_mutation']=r['teacher_calls']==r['candidates_created']==0 and not (P/'mutations').exists() and not (P/'teacher-model.jsonl').exists()
checks['idempotent_reentry']=read(B/'reentry.stdout')==r and len(modelrows)==7
checks['owned_service_stopped']=r['service_cleanup']=={'owned_service':True,'owned_service_stopped':True}
with socket.socket() as sock:
 sock.settimeout(.5);checks['local_listener_closed']=sock.connect_ex(('127.0.0.1',18082))!=0
checks['stage_not_learning']=r['can_learn'] is True and not (P/'active.json').exists()
assert all(checks.values()),checks
(P/'audit.json').write_text(json.dumps({'checks':checks,'counts':{'tasks':2,'local_requests':7,'teacher_requests':0,'candidates':0},'conclusion':'Natural misuse failure with retained old capability; no G2 learning yet.'},indent=2)+'\n')
print(json.dumps({'checks_passed':len(checks),'baseline_gap':r['can_learn'],'actual_requests':ledger[0]}))
