"""Owned production control API, no cloud credentials, no model requests."""
import os
import json
from pathlib import Path
import sys

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
sys.path.insert(0, str(ROOT))
os.environ['KAGE_MODE'] = 'control'
os.environ['KAGE_BROWSER_DEMONSTRATIONS_DIR'] = str(P / 'captures')
os.environ['KAGE_BROWSER_PYTHON'] = str(ROOT / '.venv-computer-use/bin/python')
os.environ['KAGE_BROWSER_DEMONSTRATION_HEADLESS'] = '1'

import uvicorn
import core.server as server

server._load_effective_config = lambda: {'model': {'cloud_api': {}, 'hybrid': {'enabled': False}}}
(P / 'control-owner.json').write_text(json.dumps({'pid': os.getpid(), 'port': 19086, 'root': str(ROOT)}))
uvicorn.run(server.app, host='127.0.0.1', port=19086, log_level='warning')
