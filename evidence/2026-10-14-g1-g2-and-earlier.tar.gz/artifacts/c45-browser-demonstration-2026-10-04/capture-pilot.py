"""Once per frozen lesson: production API, actual worker Page, editable replay."""
import asyncio
from contextlib import suppress
import hashlib
import json
from pathlib import Path
import time
import subprocess
from urllib.request import Request, urlopen
from playwright.async_api import async_playwright

P = Path(__file__).resolve().parent
BASE = 'http://127.0.0.1:19086'
TERMINAL = {'verified', 'completed', 'incomplete', 'failed', 'stopped'}

def save(name, value):
    (P / name).write_text(json.dumps(value, ensure_ascii=False, indent=2))

def request(path, payload=None):
    data = None if payload is None else json.dumps(payload).encode()
    with urlopen(Request(BASE + path, data=data, headers={'Content-Type': 'application/json'}), timeout=10) as response:
        return json.load(response)

def mark(submissions, operation, task_id, payload):
    # Record intent before sending: a lost response can never silently resubmit.
    record = {'operation': operation, 'task_id': task_id, 'payload': payload, 'attempted': True}
    submissions.append(record)
    save('capture-submissions.json', submissions)
    return record

async def poll(run_id, *, ready=False, deadline_s=910):
    started = time.monotonic()
    snapshots = []
    while True:
        job = request('/api/browser/demonstrations/' + run_id)
        snapshots.append(job)
        save(run_id + '-status.json', snapshots)
        if job['status'] in TERMINAL or (ready and job.get('ready') and job.get('automation_cdp_endpoint')):
            return job
        if time.monotonic() - started > deadline_s:
            raise RuntimeError('Owned service did not enforce deadline; preserve evidence.')
        await asyncio.sleep(.3)

def fetch_artifacts(job):
    fetched = []
    for item in (job.get('result') or {}).get('artifacts', []):
        with urlopen(BASE + item['url'], timeout=10) as response:
            digest = hashlib.sha256(response.read()).hexdigest()
        fetched.append({'name': item['name'], 'expected_sha256': item['sha256'],
                        'http_sha256': digest, 'matches': digest == item['sha256']})
    save(job['run_id'] + '-artifact-fetch.json', fetched)

def remember_group(run_id):
    owner_path = P / 'captures' / ('run_' + run_id) / 'worker-owner.json'
    if not owner_path.exists():
        return
    owner = json.loads(owner_path.read_text())
    listing = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid='], text=True)
    members = []
    for line in listing.splitlines():
        fields = line.split()
        if len(fields) == 3 and int(fields[2]) == owner['pgid']:
            members.append({'pid': int(fields[0]), 'ppid': int(fields[1]), 'pgid': int(fields[2])})
    save(run_id + '-owned-group.json', {'owner': owner, 'members': members})

async def main():
    if (P / 'capture-submissions.json').exists():
        raise SystemExit('Capture pilot already attempted; no rerun.')
    if not (P / 'provenance.json').exists():
        raise SystemExit('Freeze provenance before actual capture.')
    protocol = json.loads((P / 'protocol.json').read_text())
    save('demonstration-catalog.json', request('/api/browser/demonstrations/catalog'))
    submissions, captures, replays = [], [], []
    save('capture-submissions.json', submissions)
    async with async_playwright() as p:
        for task_id in protocol['capture']['tasks']:
            run_id = None
            reuse_id = task_id.replace('demo_', 'reuse_')
            try:
                started = time.monotonic()
                payload = {'task_id': task_id, 'source_kind': 'automation'}
                record = mark(submissions, 'demonstration', task_id, payload)
                created = request('/api/browser/demonstrations', payload)
                record['response'] = created
                save('capture-submissions.json', submissions)
                run_id = created['run_id']
                recording = await poll(run_id, ready=True)
                remember_group(run_id)
                browser = None
                try:
                    if recording['status'] not in TERMINAL:
                        browser = await p.chromium.connect_over_cdp(recording['automation_cdp_endpoint'])
                        page = browser.contexts[0].pages[0]
                        if task_id == 'demo_profile':
                            await page.get_by_label('Name', exact=True).fill('Correction example')
                            await page.get_by_label('Email', exact=True).fill('demo@example.test')
                            await page.get_by_label('Name', exact=True).fill('Kage Demo')
                            await page.get_by_role('button', name='Save profile', exact=True).click()
                        else:
                            # Real correction: Email checked, reversed, then corrected again.
                            field = page.get_by_label('Email notifications', exact=True)
                            await field.check()
                            await field.uncheck()
                            await field.check()
                            await page.get_by_label('SMS notifications', exact=True).uncheck()
                            await page.get_by_role('button', name='Save settings', exact=True).click()
                        await page.wait_for_function('document.querySelector("[data-result]").textContent.length > 0')
                        finish = mark(submissions, 'finish', task_id, {})
                        finish['response'] = request('/api/browser/demonstrations/' + run_id + '/finish', {})
                        save('capture-submissions.json', submissions)
                    job = await poll(run_id)
                finally:
                    if browser is not None:
                        with suppress(Exception):
                            await browser.close()
                fetch_artifacts(job)
                captures.append({'task_id': task_id, 'seconds': round(time.monotonic() - started, 3), 'job': job})
                save('capture-results.json', captures)
                print(json.dumps({'capture': task_id, 'status': job['status']}, ensure_ascii=False), flush=True)
                if job['status'] != 'verified':
                    replays.append({'task_id': task_id.replace('demo_', 'reuse_'), 'status': 'blocked',
                                    'reason': 'source demonstration not verified'})
                    save('replay-results.json', replays)
                    continue
                candidate = job['result']['candidate']
                arguments = dict(candidate['arguments'])
                public_values = ({'Name': 'Kage Reuse', 'Email': 'reuse@example.test'} if task_id == 'demo_profile'
                    else {'Email notifications': False, 'SMS notifications': True, 'Weekly digest': True})
                for key, label in list(arguments.items()):
                    if key.endswith('_label') and key != 'save_label':
                        arguments[key.replace('_label', '_value')] = public_values[label]
                reuse_id = task_id.replace('demo_', 'reuse_')
                payload = {'task_id': reuse_id, 'arguments': arguments}
                replay = mark(submissions, 'replay', reuse_id, payload)
                replay['response'] = request('/api/browser/demonstrations/' + run_id + '/replay', payload)
                save('capture-submissions.json', submissions)
                reused = await poll(replay['response']['run_id'], deadline_s=490)
                fetch_artifacts(reused)
                replays.append({'task_id': reuse_id, 'job': reused})
                save('replay-results.json', replays)
                print(json.dumps({'replay': reuse_id, 'status': reused['status']}, ensure_ascii=False), flush=True)
            except Exception as exc:
                failure = {'task_id': task_id, 'error': type(exc).__name__ + ': ' + str(exc),
                           'status': 'pilot_driver_failed', 'submitted_run_id': run_id}
                # Stop only an already-owned active run; do not retry creation,
                # finish, replay, or a failed stop request.
                try:
                    for submitted in reversed(submissions):
                        rid = (submitted.get('response') or {}).get('run_id')
                        if not rid or submitted['task_id'] not in {task_id, reuse_id}:
                            continue
                        current = request('/api/browser/demonstrations/' + rid)
                        if current['status'] not in TERMINAL:
                            cleanup = mark(submissions, 'cleanup_stop', submitted['task_id'], {})
                            cleanup['response'] = request('/api/browser/demonstrations/' + rid + '/stop', {})
                            save('capture-submissions.json', submissions)
                        else:
                            fetch_artifacts(current)
                        failure['last_observed_job'] = current
                        break
                except Exception as cleanup_exc:
                    failure['cleanup_error'] = type(cleanup_exc).__name__ + ': ' + str(cleanup_exc)
                if not any(row['task_id'] == task_id for row in captures):
                    captures.append(failure)
                    save('capture-results.json', captures)
                if not any(row['task_id'] == reuse_id for row in replays):
                    replays.append({'task_id': reuse_id, 'status': 'failed_or_blocked', 'error': failure['error']})
                    save('replay-results.json', replays)
                save(task_id + '-driver-failure.json', failure)
                print(json.dumps(failure, ensure_ascii=False), flush=True)
    save('demonstration-list.json', request('/api/browser/demonstrations'))

if __name__ == '__main__':
    asyncio.run(main())
