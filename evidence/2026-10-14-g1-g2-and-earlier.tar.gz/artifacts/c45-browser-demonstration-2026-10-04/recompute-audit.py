"""Independent file/HTTP hash and saved-state audit, no execution or resampling."""
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = P.parents[1]

def read(path):
    return json.loads(path.read_text())

def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()] if path.exists() else []

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def main():
    provenance = read(P / 'provenance.json')
    protocol = read(P / 'protocol.json')
    assertions = []
    def require(name, condition):
        assertions.append({'check': name, 'passed': bool(condition)})
    require('source_bytes_match_frozen_revision', all(sha(ROOT / name) == digest
        for name, digest in provenance['source_hashes'].items()))
    require('protocol_unchanged', sha(P / 'protocol.json') == provenance['protocol_sha256'])
    require('drivers_unchanged', all(sha(P / name) == digest for name, digest in provenance['driver_hashes'].items()))
    captures, replays = read(P / 'capture-results.json'), read(P / 'replay-results.json')
    require('exact_capture_tasks_once', [row['task_id'] for row in captures] == protocol['capture']['tasks'])
    require('exact_replay_tasks_once', [row['task_id'] for row in replays] == protocol['deterministic_reuse']['tasks'])
    summary = []
    for kind, records in [('demonstration', captures), ('workflow_engine', replays)]:
        for row in records:
            job = row.get('job')
            if not job:
                summary.append({'kind': kind, **row})
                continue
            workspace = P / 'captures' / ('run_' + job['run_id'])
            if not all((workspace / name).exists() for name in ['browser-check.json', 'browser-outcome.json', 'episode.json']):
                require(job['run_id'] + ':missing_final_evidence_not_success', job['status'] not in {'verified', 'completed'})
                summary.append({'kind': kind, 'task_id': row['task_id'], 'status': job['status'], 'error': job.get('error'), 'final_evidence': 'unavailable'})
                continue
            check = read(workspace / 'browser-check.json')
            outcome = read(workspace / 'browser-outcome.json')
            fetched = read(P / (job['run_id'] + '-artifact-fetch.json'))
            require(job['run_id'] + ':published_artifact_http_and_disk_hashes', all(
                item['matches'] and sha(workspace / item['name']) == item['expected_sha256'] for item in fetched))
            require(job['run_id'] + ':one_actual_save_and_readback', check['posts'] == 1
                and check['readback_matches_backend'] is True
                and outcome['record'] == check['record'] and outcome['readback_matches_backend'] is True)
            require(job['run_id'] + ':no_model_call_log', not (workspace / 'model-calls.jsonl').exists())
            episode = read(workspace / 'episode.json')
            require(job['run_id'] + ':not_credited_as_student_AI', episode['browser']['student']['external_passed'] is None)
            if kind == 'demonstration':
                require(job['run_id'] + ':automation_source_explicit', job['source_kind'] == 'automation'
                    and episode['browser']['source_kind'] == 'automation_demonstration')
                candidate = job['result'].get('candidate')
                if candidate:
                    refs = episode['browser']['evidence']
                    require(job['run_id'] + ':all_source_hashes_intact', all(
                        sha(Path(refs[name]['path'])) == digest for name, digest in candidate['source_hashes'].items()))
            else:
                require(job['run_id'] + ':workflow_engine_source', job['executor'] == 'workflow_engine'
                    and episode['browser']['source_kind'] == 'workflow_engine_replay')
            summary.append({'kind': kind, 'task_id': row['task_id'], 'status': job['status'],
                            'posts': check['posts'], 'readback': check['readback_matches_backend'],
                            'record': check['record'], 'events': job.get('event_count')})
    model_results = read(P / 'model-results.json')
    require('exact_model_tasks_once', [row['task_id'] for row in model_results] == protocol['model_reuse']['tasks'])
    total_calls = input_tokens = output_tokens = 0
    for row in model_results:
        result = row.get('result')
        if not result:
            summary.append({'kind': 'local_model', **row})
            continue
        workspace = P / 'model-runs' / ('run_' + result['run_id'])
        calls = rows(workspace / 'model-calls.jsonl')
        requests = [line['request'] for line in calls if 'request' in line]
        responses = [line['response'] for line in calls if 'response' in line]
        errors = [line['error'] for line in calls if 'error' in line]
        actor_tools = rows(workspace / 'actor-tools.jsonl')
        skill_calls = [line for line in actor_tools if line['name'] == 'skill_call']
        check = read(workspace / 'browser-check.json') if (workspace / 'browser-check.json').exists() else None
        require(row['task_id'] + ':model_request_guard', len(requests) <= 6)
        require(row['task_id'] + ':reported_calls_match_recorded_attempts', result['usage'].get('api_calls') == len(requests))
        require(row['task_id'] + ':real_response_or_explicit_error_for_each_attempt', len(requests) == len(responses) + len(errors))
        total_calls += len(requests)
        input_tokens += result['usage'].get('input_tokens', 0)
        output_tokens += result['usage'].get('output_tokens', 0)
        summary.append({'kind': 'local_model', 'task_id': row['task_id'], 'status': result['status'],
            'score': result['score'], 'seconds': row['seconds'], 'usage': result['usage'],
            'skill_calls': len(skill_calls), 'skill_call_outcomes': [line.get('outcome') for line in skill_calls],
            'actual_request_temperatures': sorted({req.get('temperature') for req in requests}),
            'actual_request_max_tokens': sorted({req.get('max_tokens') for req in requests}),
            'posts': check['posts'] if check else None, 'readback': check['readback_matches_backend'] if check else None,
            'errors': errors})
    require('global_model_request_guard', total_calls <= protocol['max_total_model_calls'])
    value = {'assertions': assertions, 'all_passed': all(item['passed'] for item in assertions),
        'runs': summary, 'model_requests': total_calls, 'reported_input_tokens': input_tokens,
        'reported_output_tokens': output_tokens, 'cloud_requests': 0,
        'human_demonstrations': 0, 'claims': 'integration pilot only; no held-out improvement or weight-training claim'}
    (P / 'audit.json').write_text(json.dumps(value, ensure_ascii=False, indent=2))
    print(json.dumps(value, ensure_ascii=False, indent=2))
    if not value['all_passed']:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
