# Single final fix wave — whole public settlement and History ownership

Base: `9bc410576c0ce77ec8d15759a6dc7a4cfb4871b7`. Source/test commit: `ee52cf2` (`fix(browser): gate teaching publication and serialize history loading`). Working directory: `/Users/wenbo/.codex/worktrees/c2-learning-loop/Kage`.

Read the exact two Important findings in `final-review.md`, the preserved `final-review-probes.py` and `final-review-probes.log`, Task 2 brief/global constraints, latest Task 2 report and surrounding production lifecycle/UI/tests before editing. Original probe bytes/evidence were not changed or rerun. Systematic debugging, test-driven development and verification-before-completion instructions were applied; no delegation was performed.

## Changes and contracts

1. Public projection now requires the existing durable parent acceptance identity/status/hash check, plus no in-flight stop, before returning the nested final result, check outcome or final artifact index. Unaccepted raw terminal bytes and a cancelled lane whose stop is still pending project `finalizing`; status heartbeat/event count remain progress. `artifact()` consumes exactly that gated public index and therefore denies downloads before settlement. `_public` no longer invokes `_partial` or constructs an artifact index on reads. Restart ownership blockers retain the conservative stopped/service_restart projection, explicit recovery error, and no final artifact URLs.

2. An in-flight stop owns settlement. The inherited awaited startup/process cleanup still runs. The processor cannot write acceptance while that stop owner is pending; after cleanup the stop owner settles its actual partial result and returns a newly projected job. Duplicate in-flight stop calls return the current pending projection. No shared C5 implementation or hook semantics were changed.

3. Rejected final results remove the public candidate reference and exclude `candidate/` bundle files, `candidate.json` and `parameters.json` from their settled public artifact index. The original candidate files remain on disk for internal audit. Other settled failure/stop evidence remains available; clean verified capture publishes its checked candidate normally. Failure/timeout/launch-error and normal restart/history paths are covered by the focused gate.

4. History selection now owns `busy` until its GET settles, disables competing Start/Replay/other mutations, clears candidate controls immediately, and restores controls in `finally`. Empty selection restores controls directly. A queued/programmatic history event during an accepted mutation cannot increment generation or invalidate the POST response owner. The existing one-attempt Launcher fetch helper and POST behavior remain unchanged.

## Genuine RED/GREEN evidence

New regressions were added before source changes. Command from worktree root:

```sh
.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py -q -k 'public_result_waits or reads_during_delayed_stop or history_serializes' > .superpowers/sdd/browser-demonstration-2026-10-04/final-fix-red.log 2>&1
```

Exit 1: **9 failed, 19 deselected in 15.12s**. Expected failures: both held workers exposed a non-null verified result/candidate before actual exit; reads during awaited stop projected stopped rather than pending finalization; all six actual Launcher History cases kept Start enabled during the pending History GET. The complete failure traces are preserved in `final-fix-red.log`; no failures were omitted.

After the minimal service/module changes, the same command with output directed to `final-fix-green.log` exited 0: **9 passed, 19 deselected in 19.00s**. Two extra assertions were subsequently added: abnormal-worker candidate bundle/descriptor URLs remain 404 even though raw candidate bytes exist; History transport remains one GET attempt through error settlement. These were included in the final covering gate below.

### What the new tests actually operate

- `test_public_result_waits_for_actual_worker_settlement[0/1]` launches the production bootstrap/worker with an executable wrapper that waits for a test-owned release file only after the actual worker returns. Real CDP fills/corrects/saves its actual Page and calls finish. The test reads genuine worker-written verified result/candidate bytes, proves the actual PID is alive and acceptance absent, asserts both GET/list have no nested result/check/artifact URLs and manifest GET is 404, then releases the worker. Exit 0 publishes the genuine digest/manifest after PID exit. Exit 1 produces failed/worker_crashed, no candidate, no bundle/descriptor downloads and replay rejection; raw manifest still exists. No recorder events/results/candidates are fabricated.
- `test_reads_during_delayed_stop_do_not_index_live_worker` operates a real unsaved Page, suspends its owned process group, and delays the existing `_kill` call before actual cleanup. While stop is awaiting cleanup, repeated GET/list/downloads expose only finalizing progress; a test spy on the real `_partial` proves reads never invoke indexing, no acceptance exists, and the real PID remains alive. The harness resumes/releases its owned worker in `finally`. Stop returns settled stopped/user_stop after actual PID disappearance, with each published artifact fetched and SHA-256 checked.
- `test_launcher_history_serializes_mutations_and_releases_controls` uses the real `launcher.html`, its production helper/module, and a real backend candidate made through actual worker Page actions. Transport defers the second History GET and the later already-accepted POST response; backend lifecycle is genuine. Six cases cross Start/Replay with successful, failed (HTTP 500), and emptied selection. During History loading both mutations are disabled and queued click dispatch sends no POST. Error/empty selection releases controls; replay explicitly reselects its candidate. A later accepted Start/Replay sends exactly one POST; a queued history change while POST is pending cannot discard its response. Start shows the new actual run's Finish/Cancel controls; Replay shows the new run's workflow_engine binding. The test claims transport/Launcher race coverage, not human teaching.

## Final focused covering gate and build

Command:

```sh
.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py tests/test_browser_task_service.py tests/test_browser_demonstration.py tests/test_browser_episodes.py tests/test_browser_task_routes.py tests/test_server_helpers.py -q > .superpowers/sdd/browser-demonstration-2026-10-04/final-fix-covering.log 2>&1
```

Exit 0: **102 passed in 109.21s (0:01:49)**. This covers the final amended tests/source, actual worker normal capture/replay, ordinary failure/incomplete/timeout/launch-error, accepted/restarted history, explicit stop, recovery ownership/orphan cases, existing real Launcher/stale GET handling, recorder/episode and unchanged C5 service/routes/notification helpers. No intermediate covering failure occurred.

Frontend source changed, so from `kage-avatar`:

```sh
npm run build > ../.superpowers/sdd/browser-demonstration-2026-10-04/final-fix-build.log 2>&1
```

Exit 0: TypeScript check passed; Vite **113 modules transformed**, **built in 1.17s**. Preserved baseline warnings: the two classic Live2D scripts cannot be bundled without type=module; the existing 674.06 kB chunk exceeds 500 kB. No asset/dependency changes were made.

`git diff --check` and `git diff --cached --check` each exited 0/no output immediately before commit. The staged diff contained exactly 3 files: demonstration_service.py, browser-demonstrations.js, test_browser_demonstration_routes.py (226 insertions, 18 deletions). Commit exited 0. Root-owned readme.md, docs/plans and docs/experiments changes remained unstaged; scratch/log/raw files were not staged.

## Constraints and remaining limits

No full suite, model inference, pilot, cloud/audio operation, GitHub action, push, broad refactor, root report/README mutation, original raw evidence rewrite or worktree deletion was performed. Controller owns the scoped rereview, fresh full gate, frozen production pilot/reports and authorized GitHub push. Automation remains explicit; actual headed human teaching remains pending. Existing POSIX owned-process-group/recovery and trusted local audit-storage boundaries remain. As chosen serialization disables the competing mutation, there is intentionally no overlapping accepted Start/Replay during a pending History GET; tests exercise both attempted mutation kinds and a late history event while the eventual accepted POST response is pending.
