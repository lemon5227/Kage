### Spec Compliance

- ❌ Issues found: four Important gaps in the required restart, artifact, and replay failure behavior. Restart trusts an unaccepted worker result (core/computer_use/demonstration_service.py:33), does not terminate a suspended owned process (core/computer_use/demonstration_service.py:35), freezes artifact hashes before recorder shutdown finishes (core/computer_use/demonstration_service.py:36), and skips RunResult/archive for workflow execution failures (core/computer_use/demonstration_worker.py:111).
- ✅ The requested service signatures, strict payloads, family/schema/hash checks, model-free child requests, controlled task catalog, and indexed confined artifact API are present: core/computer_use/demonstration_service.py:23, :51, :81, :138, :148, :189, :208; core/routes/browser_demonstrations.py:45. The only extra episodes.py branch is within the authorized narrow workflow_engine addendum (core/computer_use/episodes.py:53, :67, :77, :87).
- ✅ Shared C5 default worker selection remains task_worker; the demonstration subclass selects the allowed demonstration_worker module without replacing the existing lane/startup/deadline/kill implementation (core/computer_use/task_service.py:20, :144; core/computer_use/task_bootstrap.py:12; core/computer_use/demonstration_service.py:20).
- ⚠️ Cannot verify human acceptance from this diff: the real Page tests explicitly declare automation (tests/test_browser_demonstration_routes.py:65); headed human teaching remains an external acceptance item. The human mode launch condition is present (core/computer_use/demonstration_worker.py:59).
- ⚠️ Cannot independently confirm the implementer's reported 80-test, later UI/lifecycle follow-up, build, or diff-check results from this package. They were not rerun, as instructed (.superpowers/sdd/browser-demonstration-2026-10-04/task-2-report.md:28, :31, :34, :37). Final whole-branch validation and any actual-model pilot remain controller work, outside this gate.

### Strengths

- Capture and success replay tests exercise the production subprocess/bootstrap and connect CDP to the actual owned worker Page, preserve corrections, edit new target arguments, and inspect actual saved/readback state; these are behavioral tests, not fake event/result fixtures (tests/test_browser_demonstration_routes.py:39, :61, :80, :93, :111).
- Normal completion uses recorder stop/flush, CheckpointExecutor(settle_saves=True), independent Evaluator, RunResult/archive, and compiler; candidate compilation failure stays failed while retaining a true check result (core/computer_use/demonstration_worker.py:69, :95, :117, :120, :126, :139; tests/test_browser_demonstration_routes.py:303).
- Replay uses a fresh fixture/Page and the existing workflow catalog/executor with the shared 16-primitive quota, rather than reusing the teaching Page or deriving parameters from checker state (core/computer_use/demonstration_worker.py:52, :67, :100, :104; core/computer_use/demonstration_service.py:179).
- Launcher renders untrusted text with textContent/form value and has generation/run/GET-sequence checks plus a terminal lock; its real browser test covers explicit history loading, cancellation, a delayed old GET, no-save failure, and late terminal events (kage-avatar/public/browser-demonstrations.js:34, :47, :51, :72, :81, :93, :119; tests/test_browser_demonstration_routes.py:156).
- Notification integration reuses the existing bounded bridge and prevents browser demonstration speech before generic notifications; teardown closes the demonstration service before the shared bridge is drained (core/routes/browser_demonstrations.py:10; core/server.py:483, :910).
- The new units are scoped to service, worker, routes, and a small Launcher module; no new dependency or general-purpose framework was introduced (review-97c4b64..7d98e16.diff:6).

### Issues

#### Critical (Must Fix)

- None found.

#### Important (Should Fix)

1. Persist clean worker acceptance before trusting a terminal result on restart — core/computer_use/demonstration_service.py:33, :42; core/computer_use/demonstration_worker.py:158.

   The constructor treats any worker-written terminal result as completed, even though session.json only records creation metadata and contains no parent-side clean-exit acceptance. While the original service correctly keeps such bytes finalizing until proc.communicate returns, a new service immediately publishes verified and permits replay. If the server exits between result publication and abnormal-exit adaptation, an unaccepted/crashed run becomes usable after restart. The new subclass's worker_crashed adjustment (core/computer_use/demonstration_service.py:124) only runs in the original parent's live processor; it cannot protect this restart path.

   Focused reproduction used a real production bootstrap/recorder/compiler behind an executable wrapper that waits after bootstrap returns and would subsequently exit 1. After real Page Name/Email/save and finish, a second service was constructed while the actual owner was still alive. Exit 0 for the review harness; exact output:

       {"risk": "unaccepted result after restart", "original_status": "finalizing", "original_execution": "running", "restored_status": "verified", "restored_has_candidate": true, "owned_worker_still_alive": true, "stop_marker": false}

   Persist a durable parent acceptance record only after successful child exit and cancellation checks; distinguish unaccepted worker result bytes from accepted terminal history on restart. An unaccepted old run must receive the restart stop policy and no usable candidate. Add the restart-during-post-result/pre-exit case; the existing abnormal-exit test only checks the original service after it has reaped the child (tests/test_browser_demonstration_routes.py:343).

2. Restart must terminate owned workers that cannot consume the stop marker — core/computer_use/demonstration_service.py:34, :35.

   Recovery writes stop.requested and labels the old run stopped, but never uses worker-owner.json to terminate/reap its process group. The actual constructor does not create any recovery task, deadline, or process handle for history jobs. Recording happens to poll the marker; a suspended child or one blocked in a browser operation does not. After a real server crash, the separate-session child also no longer has the original parent's deadline enforcement. It can remain alive while the new service admits another active session. This is a new durable-history recovery gap, not a finding against the unchanged C5 kill helpers.

   Focused reproduction launched the actual demonstration worker, waited for recording, applied SIGSTOP to its owned process group, constructed the new service, then checked the real PID after 1.1 seconds. Exit 0; exact output:

       {"risk": "restart suspended owned worker", "status": "stopped", "stop_reason": "service_restart", "stop_marker": true, "owned_worker_alive_after_1_1s": true}

   Perform bounded ownership-validated cleanup using the existing termination semantics before allowing replacement work; include suspended/non-cooperative recovery. The existing active-restart test covers only a cooperative recorder polling stop (tests/test_browser_demonstration_routes.py:249). The review harness's original service.close killed/reaped the suspended worker in finally.

3. Freeze restart partial metadata and artifact hashes only after child evidence becomes stable — core/computer_use/demonstration_service.py:36, :43, :189; core/computer_use/demonstration_worker.py:77.

   The new constructor immediately computes/persists/caches _partial and its artifact hashes after touching the marker. The recorder subsequently flushes pending DOM input and appends its stop records, changing files in that already-published index. The recovered service keeps the old cached result, so artifact responses no longer match advertised hashes and the partial action count can also precede the final flush. Excluding mutable control files does not address recorder evidence still being mutated during recovery.

   Focused reproduction filled Name=Correction on the actual worker Page, immediately constructed a second service, waited until the real owner exited cooperatively, and compared every indexed file's bytes with the recovered service's advertised SHA-256. Exit 0; exact output:

       {"risk": "restart index before recorder cleanup", "status": "stopped", "worker_exited": true, "hash_mismatches": ["actor-tools.jsonl", "browser.jsonl", "demonstration-events.jsonl", "trace.jsonl"]}

   Coordinate stop/flush or terminate the owned child, wait for evidence quiescence, then snapshot the partial event count and immutable index atomically. Test hashes after recovery of an active session with a pending actual Page input; the existing successful-history hash test and active restart PID test cover these separately (tests/test_browser_demonstration_routes.py:111, :249).

4. Preserve independent failure checking and an archived workflow replay episode when execution fails — core/computer_use/demonstration_worker.py:111, :120, :127, :154.

   A legitimate skill execution failure raises before the common checkpoint/Evaluator/RunResult/archive path. The outer handler then calls it browser_unavailable even though browser startup and some workflow actions succeeded. This leaves check_passed null and no episode/run-result, so the approved workflow_replay_incomplete provenance/status/actor-segment requirement is not implemented for execution failures. The new episodes.py classification cannot repair an episode that was never recorded. Existing episode assertions cover a verified replay only (tests/test_browser_demonstration_routes.py:97).

   Focused reproduction made a real verified profile candidate, then submitted schema-valid edited replay arguments with field_1_value=Kage Reuse and field_2_label=Missing visible label. The real fresh Page executed an observation and a successful first-field action before failing semantic lookup. Exit 0; exact output:

       {"risk": "failed replay archive", "status": "failed", "stop_reason": "browser_unavailable", "error": "RuntimeError: WorkflowExecutionFailed: Missing visible label: expected exactly one visible target", "check_passed": null, "has_episode": false, "has_run_result": false, "has_workflow_result": true, "actor_rows": 3}

   Keep the workflow error and truthful stop reason, finish safe checkpoint/readback/evaluation, and record a failed RunResult and workflow_engine_replay/workflow_replay_incomplete episode with genuine actor segments before closing the Page. Execution success and independent verification must both gate completed. Add a real partial-action workflow-failure case and assert failure archive/provenance and compiler rejection.

#### Minor (Nice to Have)

- Reported frontend build output is not pristine: classic Cubism scripts cannot be bundled without module type and a 674.06 kB chunk exceeds the warning threshold (.superpowers/sdd/browser-demonstration-2026-10-04/task-2-report.md:37). The changed file list does not include the cited index.html source/dependencies, so these are recorded as reported baseline warnings, not attributed to Task 2 or used to block its approval. The baseline warning claim was not independently rebuilt.

### Focused checks and review boundaries

- Read the 77,484-byte supplied review package contiguously in five chunks with no output truncation. No source, index, HEAD, or branch mutations; no git commands. Only this scratch report and its reproduction log were written.
- Named shared-lifecycle risk: read BrowserTaskService._process/stop/close/ownership helpers plus BackgroundWorker/BackgroundLane to establish the subprocess acceptance and recovery contracts (core/computer_use/task_service.py:135, :179, :264, :293, :366, :388; core/background_worker.py:69, :78; core/background_lane.py:60). Changed task_service hunk ended mid-_process, requiring the focused continuation read under the reviewer prompt.
- Named workflow/archive risk: checked CheckpointExecutor actor/action/checkpoint recording, BrowserSkillCatalog.call's semantic lookup and execution-failure return, and ExperienceArchive's real evidence indexing (core/computer_use/experiment.py:54, :100; core/computer_use/skills.py:102, :150; core/evolution/archive.py:19). Checked recorder stop flush and episode normalization/generation boundaries for recovery evidence stability and truthful replay provenance (core/computer_use/demonstration.py:177; core/computer_use/episodes.py:27).
- Named notification/lifespan risk: checked the reused bounded bridge's scheduling and cleanup (core/routes/browser_tasks.py:38, :52, :73); the changed server branches preserve event-only browser notification behavior (core/server.py:910).
- Focused commands were isolated .venv-computer-use/bin/python heredoc harnesses, not existing test-suite reruns. The corrected two-risk harness exited 0 in 5.94s; suspended recovery harness exited 0 in 1.91s; active recovery artifact harness exited 0 in 1.87s. Actual production workers and real Pages were used; wrapper only delayed process exit, SIGSTOP only modeled suspension, and no capture events/results were fabricated. Every owned process was closed/reaped in finally and every temporary run root removed.
- One initial reviewer harness attempt resolved the venv python symlink to its base interpreter and therefore observed ModuleNotFoundError: playwright (exit 1). Corrected harnesses used the absolute venv path without resolving its executable symlink. This was reviewer setup, not an implementation defect; it did not exercise the target cases.
- Exact focused outputs and setup recipes are saved in task-2-review-repros.log beside this report. No AI, cloud, audio, subagents, reported 80-test/UI/lifecycle suites, frontend build, or broad codebase search was run.

### Assessment

**Task quality:** Needs fixes.

**Reasoning:** The main capture and successful replay flow is well separated and supported by real integration tests. Four independently reproduced restart/failure gaps undermine the required ownership, completion acceptance, durable evidence integrity, and truthful replay archive contracts, so this task cannot pass the spec or quality gate yet.
