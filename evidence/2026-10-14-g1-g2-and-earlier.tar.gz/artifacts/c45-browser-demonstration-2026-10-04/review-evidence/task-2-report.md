# Task 2 — durable browser teaching entry

Implemented on Task 1 base `97c4b64`, source/test commit `7d98e16` (`feat(ui): add controlled browser teaching and workflow replay`). Only eleven source/test files staged. Controller's recorder engineering report, this task report, raw experiments, build output and scratch are excluded. No main checkout edits, push, frozen capture pilot, model inference, cloud calls or full suite run by this agent.

## RED / GREEN evidence

1. Initial RED:
   `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py -q -x`
   -> `1 failed in 0.75s`: expected `/api/browser/demonstrations/catalog` 200, actual 404.
2. Launcher RED:
   `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py::test_launcher_real_capture_replay_reload_cancel_and_stale_get -q -x`
   -> `1 failed in 31.61s`: actual Launcher lacked `#demonstration-task`.
3. Real capture exposed archive integrity issue: journal sidecar files inside run evidence changed during record/retrieve, yielding `CandidateCompilationFailed: browser episode evidence changed` despite `check_passed=true`. Journal moved outside run evidence, to `<run_root>/<run_id>-journal.sqlite`.
4. Real replay provenance RED:
   `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py::test_actual_api_capture_candidate_and_edited_fresh_replay -q -x`
   -> `1 failed in 4.21s`: actual replay episode `source_kind=no_action` instead of `workflow_engine_replay`. Controller explicitly approved narrow `episodes.py` extension. Genuine engine actions now form workflow_engine segments, student external_passed is None, failure_status is workflow_replay_verified/workflow_replay_incomplete. Compiler rejects this non-demonstration source.
5. No-save audit RED:
   `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py::test_unsaved_capture_incomplete_and_stop_idempotent -q -x`
   -> `1 failed in 2.29s`: missing initial backend audit file prevented incomplete archive and gave capture_failed. Worker now records actual initial fixture backend state (None/0), then checks actual HTTP/DOM save state. No events/results are fabricated.
6. Abnormal child exit RED:
   `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py::test_verified_bytes_from_abnormal_worker_exit_are_not_a_usable_candidate -q -x`
   -> `1 failed in 26.97s`: wrapper genuinely recorded/compiled the real Page then exited 1, inherited merge incorrectly returned verified with run_status=worker_crashed. Demonstration-specific result adaptation now forces failed/worker_crashed and removes public candidate. Retained files are audit; product replay rejects the run.
7. Deadline RED:
   `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py::test_overall_deadline_failure_stays_failed_after_restart -q -x`
   -> `1 failed in 0.69s`: deadline marker was displayed as stopped/user_stop. Adaptation retains authoritative failed/timeout, including restart, while explicit cancellation/restart markers dominate late success.
8. GREEN Task 2: `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py -q -x`
   -> `12 passed in 24.75s`.
9. Requested focused GREEN:
   `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py tests/test_browser_demonstration.py tests/test_browser_task_service.py tests/test_browser_task_routes.py tests/test_server_helpers.py -q`
   -> `80 passed in 90.59s (0:01:30)`. Includes original C5 service lifecycle tests and original notification behavior.
10. After expanding the same real Launcher scenario with no-save incomplete and unavailable-interpreter failure:
   `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py::test_launcher_real_capture_replay_reload_cancel_and_stale_get -q`
   -> `1 passed in 11.18s`.
11. Final child-only Playwright import adjustment keeps partial status usable when main API environment has no browser package; focused follow-up:
   `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py::test_worker_launch_error_and_no_config_loading tests/test_browser_demonstration_routes.py::test_verified_bytes_from_abnormal_worker_exit_are_not_a_usable_candidate tests/test_browser_demonstration_routes.py::test_overall_deadline_failure_stays_failed_after_restart -q`
   -> `3 passed in 2.70s`.
12. `npm run build` in kage-avatar -> exit 0, `built in 1.73s`. Warnings reference the unchanged index.html classic Cubism scripts (cannot bundle without type=module) and emitted 674.06 kB chunk (>500 kB). Source/dependencies that produce these warnings were unchanged; this agent did not independently rebuild the baseline. `git diff --check` and staged diff check -> exit 0, no output.

## Actual integration coverage

Control TestClient runs actual subprocess workers through production bootstrap. Automation connects to returned CDP and operates the same owned Page. Profile captures Correction -> Email -> corrected Name -> Save profile; preferences captures three real correcting Email checkbox clicks, SMS toggle, Save settings. Finish flushes DOM capture, CheckpointExecutor(settle_saves=True) settles actual save/readback, Evaluator scores independently, RunResult/ExperienceArchive/Journal preserve audit, then compiler produces v2 candidate. Replayed values are independently supplied literal new public targets, never derived from checker. Fresh fixtures reverse field order; saved record and readback match, exactly one POST, <=16 primitives, zero model API calls.

Tests fetch every published artifact and verify actual SHA-256 bytes for demonstration and replay, including after service close/restart. Cross-run/traversal and unindexed reads reject. Invalid schema ->422, mismatched family/unverified/source tampering ->409. Both missing run and missing indexed artifact ->404. Catalog static route resolves before run_id. Duplicate active session ->409. Finish/stop idempotence, next run after cancel, actual owned PID death, old active restart with stop.requested/service_restart and actual child death, late fake-result *guard fixture only*, real closed window, real process-group crash, unavailable interpreter, checked-but-unsupported visible input compilation failure, abnormal worker exit after real capture, deadline/restart, runtime job delivery without speech all covered.

Real Launcher loads module, starts automation, waits for ready, uses child CDP for real correction/save, clicks finish, edits JSON values, clicks direct replay, shows passing replay, reloads without automatically loading old unpromoted candidate, explicitly reloads history candidate, cancels an active run, starts a replacement while an old GET is delayed, releases the old GET, verifies current run controls, cancels current, injects a late recording event for terminal run, and verifies no resurrection. It additionally finishes an unsaved real Page and shows incomplete/no candidate, then attempts start with missing interpreter and shows WorkerLaunchError/check pending. Every POST uses one request attempt; generation/run/sequence checks and terminal lock reject stale responses/events.

## Exact API / worker / candidate interfaces

Service interface matches brief: BrowserDemonstrationService(BrowserTaskService), constructor(run_root, config_loader, on_event=None), catalog(), async submit(payload), async finish(run_id), async replay(run_id,payload); get/list/stop/close/artifact retain original signatures. No config_loader/model configuration is consumed. Child request retains config={} for inherited cleanup only.

- Worker module hook: BrowserTaskService.WORKER_MODULE defaults task_worker; subclass demonstration_worker. Bootstrap optional fourth argv accepts only task_worker/demonstration_worker. Default C5 launch argv remains unchanged. Same serial lane, BackgroundWorker, ownership/startup handles, kill/reap and deadline logic.
- Environment: KAGE_BROWSER_DEMONSTRATIONS_DIR (default ~/.kage/browser-demonstrations); KAGE_BROWSER_PYTHON reused. `KAGE_BROWSER_DEMONSTRATION_HEADLESS=1` permits automation headless. human_declared always headed and never launches remote debugging. Automation capture alone publishes CDP; replay does not publish it.
- POST /api/browser/demonstrations payload exactly task_id (demo_profile/demo_preferences), optional source_kind (human_declared default/automation) ->202 queued job.
- Recording GET job exposes `ready: true`, `automation_cdp_endpoint: "http://127.0.0.1:<ephemeral-port>"` only when automation+recording. Connect Chromium over CDP; the real teaching Page is in browser.contexts[0].pages[0]. Disconnect Playwright client without browser.close to keep worker ownership.
- Public job: task_type browser_demonstration; run_id; operation demonstration/replay; task_id; source_kind; executor (declared source for capture/workflow_engine for replay); status; execution_status; ready; event_count; check_available=true; check_passed; stop_reason; error; result; artifacts.
- Lifecycle: queued -> starting -> recording -> finalizing -> verified/incomplete/failed/stopped; replay -> starting/finalizing -> completed/failed/stopped. Public success waits for actual worker completion. Verified requires independent check and candidate success. Check true plus candidate failure remains failed/candidate_error.
- GET catalog/list/get, POST finish/stop/replay, GET artifacts/{name:path} at the exact brief routes. finish returns current job and is idempotent. Replay payload exactly task_id (same family reuse_profile/reuse_preferences) and arguments (v2 parameter schema); returns202 new run.
- Complete capture result.candidate is compiler return EXACT keys: bundle_path, digest, skill_id, arguments, parameters, source_kind, source_hashes. bundle_path = <run_root>/run_<run_id>/candidate; skill_id form-profile/form-preferences; source_kind automation_demonstration/human_demonstration_declared. Digest is descriptor digest accepted by skill_call. This workflow candidate is unpromoted/uninstalled.
- Profile arguments final order: field_1_label Name, field_1_value Kage Demo; field_2_label Email, field_2_value demo@example.test; save_label Save profile. New replay values Kage Reuse/reuse@example.test.
- Preferences arguments final order: Email notifications true, SMS notifications false, Weekly digest false; save_label Save settings. New replay values false/true/true.
- Replay executor uses actual BrowserSkillCatalog/BrowserAdapter/CheckpointExecutor/ToolExecutor with shared16 primitive quota on fresh Page and fresh HTTP fixture. Schema+descriptor/bundle file/source hash checks precede worker submission. Actual semantic labels and editable values are used, no checker-derived arguments.
- Persisted run directory files: session.json public immutable creation metadata; status.json mutable ready/count/CDP; finish.requested/stop.requested controls; worker-owner.json; recorder originals; backend/browser-check/browser-outcome; run-result.json; episode.json; feedback.json; candidate.json; parameters.json; candidate/{manifest.json,demonstration.json}; result.json terminal/index. Replay also workflow-result.json, actual initial/final DOM and existing tool/browser logs. Journal and .episode-setups are beside run directories, not exposed as indexed run artifacts.
- Artifact URLs are /api/browser/demonstrations/<run_id>/artifacts/<relative name> and include SHA-256. Mutable status/control/result files are excluded from artifact index; all fetched published bytes are hash-verified in integration tests. artifact confines resolved paths to this run and requires its own index.
- Restart loads session/result, marks active old run stopped/service_restart and writes stop.requested; no action restoration. Stop marker wins over late success; timeout failure retains its deadline reason. Successful candidates remain available explicitly after restart.

## Launcher / self-review / remaining limits

Beautiful UI skill applied minimally: existing card/button styles, labelled semantic selects/textarea/buttons, polite status and alert error regions, distinct ready/check/candidate/replay states. No dependencies or redesign. New module initialized with `{request, apiUrl}` using existing fetchJson with attempts=1; listens to existing kage:job. Existing generic handler returns early for browser_demonstration, C5 continues independently. Server singleton/lifespan closes teaching before shared bounded notification bridge; event/log only, no audio. Candidate/model-like text uses textContent/form value. No archived unpromoted candidate automatically loaded.

Self-review checked lane concurrency, early/late PID ownership, marker/result ordering, replay integrity/family/schema, immutable artifact hashes, independent check-before-candidate, truthful workflow engine provenance, correct source declarations, UI request binding and terminal locks. Controller-approved scope extension is only episodes.py's workflow_engine metadata branch; old student/teacher/demo behavior passed focused regressions. Partial count takes persisted raw event line count when newer than heartbeat. Child-only Playwright import avoids dragging browser package into partial status logic.

The 80-test gate predates the two amendments in items10/11; those amendments have the latest focused evidence listed there. Controller owns the final full gate after independent review.

Remaining acceptance limits: engineering captures are automation, not human evidence. Actual headed human teaching acceptance remains to be done by a human. Controlled single forms only; no arbitrary browser task support. Source/result storage is local workspace audit, not a hostile-filesystem trust boundary. No frozen production pilot or AI reuse was run by this agent; those and final full suite/review belong to controller. Existing frontend build warnings remain.

## Fix round 1 — Important review findings at 7d98e16

Source/test commit: `9308906` (`fix(browser): settle owned workers before accepting teaching history`). Five scoped source/test files; no frontend changes, full suite, build, model/cloud/audio calls, pilot, root engineering docs/raw edits, push, or scratch/report staging. Read task-2-review.md's four Important findings and task-2-review-repros.log in full before editing. Findings:

1. “Persist clean worker acceptance before trusting a terminal result on restart” — worker-written result.json alone previously permitted verified after restart while a delayed abnormal wrapper was still alive.
2. “Restart must terminate owned workers that cannot consume the stop marker” — SIGSTOP old owned process survived restart.
3. “Freeze restart partial metadata and artifact hashes only after child evidence becomes stable” — constructor indexed before pending actual input and stop trace flushed.
4. “Preserve independent failure checking and an archived workflow replay episode when execution fails” — a schema-valid missing semantic label after successful first field skipped check/RunResult/archive and misreported browser_unavailable.

### RED/GREEN commands and exact outputs

Added four actual production worker regressions; command:

`.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py -q -k 'post_result or suspended_owner or pending_real_input or failed_replay_after'`

RED (`/tmp/kage-demo-fix1-red.log`): `4 failed, 12 deselected in 9.42s`. Exact observed assertion mismatches: restored `verified` vs expected `stopped`; SIGSTOP PID still existed (`DID NOT RAISE ProcessLookupError`); pending input recovered event_count0 vs expected1; failed replay stop_reason browser_unavailable vs workflow_failed. The tests filled/saved the owned Page and used a real executable delayed abnormal-exit wrapper/SIGSTOP; no capture events or candidate arrays fabricated.

Initial GREEN (`/tmp/kage-demo-fix1-green.log`): `4 passed, 12 deselected in 11.59s`.

Expanded focused command:

`.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py tests/test_browser_task_service.py tests/test_browser_demonstration.py tests/test_browser_episodes.py -q`

An intermediate run (`/tmp/kage-demo-fix1-gate.log`) exposed a real TERM/CONT race: `1 failed, 56 passed in 81.87s (0:01:21)`. killpg could report group gone while its leader still briefly awaited reaping; returning success on that exception released recovery too early. Signal-level ProcessLookupError now retains the bounded PID wait/reap, and TERM cleanup also sends the final group KILL. Focused four-case follow-up: `4 passed, 12 deselected in 12.28s`. The next intermediate gate (`/tmp/kage-demo-fix1-gate-final.log`): `57 passed in 80.59s (0:01:20)`.

After malformed metadata/provisional recovery read guards and the real ownership mismatch test:

`.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py -q`

-> `17 passed in 40.49s` (`/tmp/kage-demo-fix1-routes-final.log`). Ownership test suspends an actual worker, changes only owner.run_id to a different session, proves the recovery refuses to signal it, exposes no unstable artifact index, blocks replacement, and original parent process handle can still clean up. This is an ownership guard test, not fabricated capture evidence.

Final authoritative parent-returncode hook amendment, covering gate on final committed source:

`.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py tests/test_browser_task_service.py tests/test_browser_demonstration.py tests/test_browser_episodes.py -q`

-> `58 passed in 82.38s (0:01:22)` (`/tmp/kage-demo-fix1-authoritative-gate.log`). This latest gate includes all17 amended Task2 route tests and relevant C5 lifecycle/recorder/episode regressions. `git diff --check` and staged check -> exit0/no output. No build rerun because frontend source did not change.

### Final fix contracts and self-review

BrowserTaskService adds only a no-op default `_worker_finished(run_id, returncode)` hook, called synchronously after actual proc.communicate has settled and before reading worker result bytes. Default C5 behavior/result/status/kill/deadline semantics remain unchanged. BrowserDemonstrationService overrides it to retain actual proc.returncode; successful clean acceptance requires `exit_code == 0` and no stop marker. Abnormal actual exit forces failed/worker_crashed and no public candidate independently of merged worker run_status. Parent-handled timeout, launch failure and crash history receives a settled failure record, distinct from unaccepted raw worker success; timeout-after-restart and launch/crash paths remain covered.

Parent writes `<run_root>/<run_id>-acceptance.json` only after owned child/startup settlement and cancellation checks, with run_id, settled=true, clean_worker_exit boolean, task_status and SHA-256 of final result.json. No await between final cancellation check and acceptance publication. Restart requires matching identity/status/hash and clean_worker_exit=true for verified/completed history. Missing/mismatched acceptance applies stopped/service_restart policy, even when result.json says verified. Existing unaccepted pre-fix teaching results therefore fail closed; they cannot become usable merely from terminal bytes. Failure or explicit stop acceptance may have clean_worker_exit=false and remain truthful terminal history.

Recovery controls stay outside immutable archived evidence: `<run_root>/<run_id>-recovery.requested`. Recovery marks it before stopping the child. Original parent's late `_save_partial`/processor callbacks are suppressed from persistent publication, preventing result/acceptance rewrite races with the recovering parent. Provisional recovery reads do not expose candidate or an artifact index. Accepted result, recovery and acceptance controls do not mutate archived session/status/DOM evidence or indexed artifact bytes.

Owned recovery validates existing PID/PGID owner metadata, actual os.getpgid(pid)==pid, matching run identity/root, and the full live `ps -ww -p <pid> -o command=` containing this run/root/bootstrap. Bootstrap now stamps run_id and resolved run_root along with its existing PID/PGID, preserving old readers. Existing owner records can also validate through exact run/root/bootstrap command evidence. Missing/corrupt ownership for an existing capture, mismatched live identity, inaccessible ownership, or failed bounded cleanup prevents replacement (`409` via existing RuntimeError mapping) and publishes no premature artifact index. It never signals an unvalidated live owner.

After stop marker, recovery permits up to1s cooperative disable/flush, then TERM+CONT (suspension support), up to.5s wait, KILL, up to.5s wait, and validated-child nonblocking reap if necessary. Missing process-group errors do not imply PID has already disappeared. TERM path also kills remaining group members after leader exit, consistent with inherited group cleanup semantics. The suspended real-owner test bounds constructor to<3s and proves owner PID dead before replacement submission. Once owned writer is quiescent, recovering parent computes actual committed event count/index and atomically settles partial result/acceptance. Pending real Name=Correction flushes to one normalized event and every indexed SHA-256 matches after recovery and repeated restart. Forced/noncooperative cleanup preserves available partial audit without claiming capture completion.

Replay skill failures keep WorkflowExecutionFailed/error and stop_reason workflow_failed. A failed final observation likewise does not skip safe checkpoint/evaluation/archive. Common safe CheckpointExecutor settle/readback -> Evaluator -> RunResult -> ExperienceArchive/Journal runs on the actual fresh Page even after failed execution. RunResult status and public completed require both execution_success and independent score>=1. Metadata records execution_success/error; real failed partial-action case has check_passed=false, score0, failed archived episode, workflow_engine_replay/workflow_replay_incomplete, student.external_passed=None and three genuine workflow_engine tool calls, including successful first-field Kage Reuse. Compiler rejects that failed non-demonstration episode. No episodes.py extension was needed beyond the already-approved Task2 workflow provenance branch.

Residual limits: constructor recovery is synchronous but individually bounded, occurs before the service admits work, and can report an ownership recovery blocker instead of guessing. Platform assumes the existing POSIX process-group environment plus standard ps (macOS/Linux). Storage/control metadata remain a local trusted audit boundary, not a hostile-filesystem design. Actual headed human teaching acceptance, controller final review/full suite and frozen production/model experiments remain controller work.

## Fix round 2 — surviving process group after leader death at 9308906

Source/test commit: `9bc4105` (`fix(browser): block recovery while orphan worker group survives`). Read task-2-rereview-1.md and task-2-rereview-1-repros.log fully. Original Important finding2 remained open: the production bootstrap leader could disappear while a suspended Playwright descendant still owned the process group, but recovery returned success, froze artifacts and admitted replacement. This round changes only demonstration_service.py and its route tests. Root-owned docs/raw drivers remain unstaged; no frontend/build, full suite, model/cloud/audio, pilot or push work.

### Exact RED/GREEN commands/output

RED on 9308906 plus the new regression:

`.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py::test_restart_blocks_surviving_group_when_actual_bootstrap_leader_is_gone -q`

-> exit1, `1 failed in 2.47s`. Exact failed assertion: `assert 'RecoveryOwnershipUnverified' in (final['error'] or '')`; actual error was None. The real production bootstrap reached recording, an actual CDP Page received Name=Correction, the owned group was SIGSTOPped, and only the leader was killed/reaped. Actual surviving group members had T status. Only minimal session routing metadata was supplied; no observation/event/result/candidate bytes were fabricated. Harness finally explicitly continued/killed its own group and asserted no members remained, including on RED.

First focused GREEN:

`.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py::test_restart_blocks_surviving_group_when_actual_bootstrap_leader_is_gone tests/test_browser_demonstration_routes.py::test_restart_terminates_suspended_owner_before_replacement tests/test_browser_demonstration_routes.py::test_recovery_rejects_mismatched_live_ownership_without_signalling -q`

-> exit0, `3 passed in 5.04s`.

After extending the actual live-owner corruption regression with malformed JSON, final covering gate on committed source:

`.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py tests/test_browser_task_service.py tests/test_browser_demonstration.py tests/test_browser_episodes.py -q`

-> exit0, `60 passed in 85.45s (0:01:25)`. This gate covers all19 amended Task2 route cases, original C5 lifecycle, recorder and episode behavior. `git diff --check` and `git diff --cached --check` -> exit0/no output. No frontend source changed, so no build rerun.

### Final recovery contract / self-review / limits

Group observation uses `os.killpg(pgid, 0)` only: signal zero changes no process; permission uncertainty counts as alive. When the recorded leader is already missing, recovery cannot validate the surviving descendants' ownership. It therefore sends no termination/continue signal to that group. A surviving group yields the existing RecoveryOwnershipUnverified error, status stopped/service_restart, event_count0, artifacts=[], no usable candidate/artifact URL, and replacement rejection through the existing recovery blocker/409 contract. No acceptance/index is written for that provisional result. Matching owner run/root is checked before the missing-leader path; malformed/unreadable or mismatched metadata stays blocked.

For a live leader whose PID/PGID/bootstrap command/run/root ownership was validated, the existing bounded cooperative/TERM+CONT/KILL/reap sequence remains. Each success/exception/final-reap path now requires both leader absence and whole process-group absence. A group that outlives its leader cannot shortcut the remaining bounded cleanup. The partial snapshot path also checks writer quiescence under the recovery token, preventing an old parent's delayed processor callback from indexing evidence while descendants remain.

The exact orphan regression proves the service leaves the suspended group unchanged, returns no artifact URL and rejects replacement. The harness alone uses its actual Popen ownership to clean that group and proves no owned members remain. A fresh service after actual group absence then freezes the genuine available partial evidence; every exposed file matches its declared SHA-256. Existing pending-input flush/hash restart tests, abnormal post-result acceptance, failed checked/archived replay, deadline history, live SIGSTOP cleanup/replacement and normal C5 tests all pass in the final covering gate. Malformed JSON and mismatched run identity each remain provisional and replacement-blocked; their original real parent still cleans its owned process handle.

Intentional limit: an orphan group with a missing/unverifiable leader remains blocked until safe external ownership cleanup establishes group absence and the service is reconstructed. This is the approved conservative spec path; it neither guesses descendant ownership nor claims cleanup success. POSIX process-group/ps assumptions and trusted local audit storage remain unchanged. Root owns fresh review, full gate, production pilot and headed human acceptance.
