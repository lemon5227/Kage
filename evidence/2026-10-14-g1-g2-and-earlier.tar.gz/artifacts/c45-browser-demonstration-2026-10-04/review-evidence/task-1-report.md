# Task 1 report — browser demonstration capture and compilation

Status: implemented and focused gate passed. Resumed the predecessor's preserved uncommitted implementation; did not restart, spawn agents, change dependencies, invoke models/cloud, run the full suite, push, or modify main. Scope is the six source/test/manifest files below, including the approved archive evidence-reference addendum. Report/logs stay in plan scratch for the controller's separate report commit.

## Observed verification

Working directory: `/Users/wenbo/.codex/worktrees/c2-learning-loop/Kage`.

1. Initial fresh command: `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration.py tests/test_browser_episodes.py tests/test_browser_skills.py -q`.
   Output: `1 failed, 33 passed in 33.63s`, exit 1. Existing test `test_page_capture_deadline_flushes_pending_edit_then_stops_accepting` failed at `assert not summary['success'] and summary['error'] == 'CaptureLimitExceeded'` because success was true. Root cause: Python elapsed-time validation only at stop; no Page deadline disabled capture. Added Page timer plus event/stop deadline guard, flushing pending committed edit before disabling capture and returning the limit flag.
2. Focused fix verification: `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration.py::test_page_capture_deadline_flushes_pending_edit_then_stops_accepting -q`.
   Output: `1 passed in 1.09s`, exit 0.
3. Archive RED verification: temporarily removed only the six-line approved evidence-reference extension, ran `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration.py::test_record_archive_compile_and_reuse_actual_form -q`, and restored the exact original file in a Python `finally` block. Output: `2 failed in 4.74s`, pytest exit 1. Both real Page family cases failed specifically at `assert resumed.retrieve(family) == []`, demonstrating raw event/input tampering remained retrievable without the extension. Full observed output: `task-1-archive-red.log` in this scratch directory. This was a controlled regression experiment, not missing-module RED.
4. Final fresh focused gate used the exact command in step 1 via `subprocess.run(..., capture_output=True, text=True)`; full output saved to `task-1-green.log`. Output:
   ```text
   ..................................                                       [100%]
   34 passed in 32.78s
   ```
   Exit 0. Existing episode and skill regressions are included.
5. `git diff --check`: no output, exit 0. `ast.parse` on the five Python source/test files completed with exit 0 (read-only syntax verification).

Predecessor's original missing-module RED evidence is unavailable. No missing-module failure is reconstructed or claimed. The initial preserved code reportedly had prior green results, but only the freshly observed results above support this completion report.

## Exact interfaces for Task 2

```python
BrowserDemonstrationRecorder(page, workspace, *, source_kind)
await recorder.start() -> dict
await recorder.stop() -> dict
compile_demonstration(episode: dict, output_dir, *, skill_id: str) -> dict
demonstration_tasks() -> dict
```

`source_kind` accepts exactly `automation` or `human_declared`; other values raise `ValueError`. `start` returns the initial authoritative DOM observation with `observation_id`, `surface_id`, `source='dom'`, `revision`, inherited SNAPSHOT fields, and `demonstration_forms`. `stop` is idempotent and returns `success`, `error`, `event_count`, `source_kind`, `final_observation`, `capture_error`. Capture failures are `CaptureLimitExceeded`, `CapturePageClosed`, or `CaptureFlushFailed`. Limits are 64 normalized committed edits/clicks and 900 seconds. The 65th action is retained as evidence and fails closed; input keystrokes are separately retained, not each charged as a normalized edit.

The recorder observes Page events; it never executes the demonstrated action. Page snapshots are sampled synchronously and ordered before crossing the binding. Text input samples persist immediately in `demonstration-inputs.jsonl`; edits commit on change, before another target/action, or at stop. The original correction is preserved. At stop/deadline pending edit commits, listening disables, then delivery flushes. `isTrusted` is retained as DOM evidence, not human authentication.

Files written: `initial-observation.json`, `demonstration-inputs.jsonl`, `demonstration-events.jsonl`, `actor-tools.jsonl`, `browser.jsonl`, `trace.jsonl`, `final-observation.json`, `demonstration-summary.json`. `actor-tools.jsonl` uses `name='browser_act'`, BrowserAdapter-compatible `arguments` (`observation_id`, `operation`, `target_ref`, and `value` for fill), actor `human` or `automation`, JSON-string `result`, `outcome='ok'`, `success`, and `seq`. Raw normalized rows retain `seq`, `time`, `event`, `original_event`, `before`, `after`, `target`, `isTrusted`, `source`, `arguments`, and text `input_samples`.

For normalization the worker must provide `RunResult.metadata['environment_kind']='resettable-local-http-browser'` and `RunResult.metadata['demonstration_source']` equal to the recorder source. `human_declared` maps to `human_demonstration_declared`; `automation` maps to `automation_demonstration`. Demonstrations have `student.external_passed=None` and genuine actor segments. Successful verified captures use `failure_status='demonstration_verified'`; unsuccessful capture uses `demonstration_incomplete` and `verification='not_verified'`. Existing student/teacher episode branches remain covered by their original tests.

The caller must settle the real save and invoke independent `checkpoint(page, url, workspace)` before building the scored RunResult and calling `ExperienceArchive.record/retrieve`. Recorder `stop()` flushes capture; it does not perform backend checkpoint or save settlement. Task 2 must independently honor cancellation, closed/failed capture, and overall lifecycle limits before invoking compilation.

Compiler requires an intact verified dev browser episode from `generation_feedback`; it reads public instruction, visible initial/final DOM and recorded DOM actions. Checker/backend bytes are hash-verified for integrity but their data is not projected into generation input or used for parameter extraction. It does not read expected values or call backend during generation. One complete visible form, unique semantic labels, supported editable controls and one actual submit click are required; unsaved or later edited state, unsupported/disabled/read-only fields, multiple forms, too many steps, changed evidence and invalid skill IDs reject with `ValueError`.

Return keys are exactly `bundle_path`, `digest`, `skill_id`, `arguments`, `parameters`, `source_kind`, `source_hashes`. Output must name a new directory. It stages and validates a v2 bundle with existing `BrowserSkillCatalog` before atomic directory rename. Failed validation leaves no valid-looking destination manifest. Bundle files: `manifest.json` (v2 kind, description/schema/workflow/digest only), and `demonstration.json` (example arguments plus source provenance); no installation/promotion occurs.

Parameters follow final visible form order: `field_1_label`, `field_1_value`, ... `field_N_label`, `field_N_value`, `save_label`. Every label is a non-empty string. Text values are strings and checkbox values booleans. All properties are required and `additionalProperties=False`. Text workflow op is `fill` with `label_param`/`value_param`; checkbox op is `ensure_checked` with `label_param`/`checked_param`; final op is `click` with `label_param='save_label'`. Workflow contains no node IDs, coordinates, ports or fixed example values.

Exact profile example arguments: `field_1_label='Name'`, `field_1_value='Kage Demo'`, `field_2_label='Email'`, `field_2_value='demo@example.test'`, `save_label='Save profile'`. Exact preferences example: `field_1_label='Email notifications'`, `field_1_value=True`, `field_2_label='SMS notifications'`, `field_2_value=False`, `field_3_label='Weekly digest'`, `field_3_value=False`, `save_label='Save settings'`. For reuse profile supply `Kage Reuse` and `reuse@example.test`; for reuse preferences supply `False`, `True`, `True` by corresponding label. The same label parameters work across the reversed field order in reuse Pages.

`demonstration_tasks()` reads the trusted local manifest and returns fresh independent definitions keyed exactly by `demo_profile`, `reuse_profile`, `demo_preferences`, `reuse_preferences`; all are dev tasks with independent json_exact_match saved-record/readback checkers. It never returns historical/test grading tasks.

## Coverage and self-review

Real Chromium Page tests cover both teaching families, profile Name correction, rapid checkbox correction clicks, final values, one real save POST plus backend/display readback, scored RunResult archive/retrieve, v2 bundle registration through existing registry/executor/quota, fresh reuse Page with edited arguments and reversed fields, one real reuse POST/readback, stop preventing later archive events, input blur and unblurred stop flush, raw typing evidence, full before DOM, page close preservation, actual file-write failure, event and Page deadline limits. Rejection tests exercise no demonstrated save, duplicate labels, multiple forms, unsupported select, >16 steps, tampered source, edit after save, and invalid skill ID; no invalid manifest remains. Narrow unit projection tests exercise both source declarations; they are not a claim of real human demonstration.

Approved `archive.py` extension preserves existing ordered non-JSONL evidence plus actor/browser order, adds absent normalized browser evidence references, deduplicates by resolved path, and retains trace placement. Both raw demonstration event and raw input tampering now mark retrieval stale. Old episode/skill behavior passed the focused gate.

Self-review found and repaired the concrete deadline gap. No unresolved blocking issue found within Task 1 scope. Browser event delivery and persistence use existing local trusted Page assumptions. Actual human teaching remains pending; all integration traces here are automation and browser isTrusted is not identity proof. Arbitrary pages, navigation/reload recovery, multiple/complex forms and unsupported controls are outside the agreed controlled teaching scope and fail closed for compilation. Task 2 owns service session exclusivity, headed human launch, cancellation, restart metadata, notifications, save settlement, shutdown ordering, and 480-second workflow lifecycle enforcement. Full suite/build/final independent review remain controller gates.

## Source and artifact provenance

SHA-256 of the exact tested Task 1 source bytes:

| File | SHA-256 |
| --- | --- |
| `core/computer_use/demonstration.py` | `de178e5185c9de0652010dbda293c4d9cc574d9ff0c78c5b39aaceb9614aaed3` |
| `core/computer_use/demonstration_compiler.py` | `fc0c8085e1dae45b599259dc24c21af4e2630d589ae037fa6242c8ddad5267c5` |
| `core/computer_use/episodes.py` | `848ad92d4e16a955e271611b498300caf590402c1c645776570bb597d8ce6d70` |
| `core/evolution/archive.py` | `dd191dda88a428688bb5f83502ec0351d03fc93207aa760b4d7f7ae422db504e` |
| `eval/computer-use/browser-demonstration-dev.json` | `d1474cc68b987935602275fd467b5bc41b52f83cf1688c6d0661406e122d4283` |
| `tests/test_browser_demonstration.py` | `725021169a3b3e3dfffbe04416af6754c94612a003c1435326a64282df10ef72` |

Final gate's real Page candidate evidence follows. Both source teaching record directories are intentionally tampered at the end of their regression to prove archive staleness; provenance below records the original hashes compiled before tampering. Candidate manifests and example/provenance files remain separate. Temporary pytest artifacts may later be cleaned by pytest; these captured paths/hashes make the observed source/production relation explicit.

```json
[
  {
    "path": "/private/var/folders/48/yc0_dhc5179bd42lwdjc1c1r0000gn/T/pytest-of-wenbo/pytest-124/test_record_archive_compile_an0/candidate/demonstration.json",
    "manifest_sha256": "fc6d6a38496e9d5f6ff845906b1e9006fe074c75b536ad4bcaea91956f07b30e",
    "digest": "f368b169d2a2c8585572643f09865848e3eb44b65ea8384f1416ac955e1c8b02",
    "arguments": {
      "field_1_label": "Name",
      "field_1_value": "Kage Demo",
      "field_2_label": "Email",
      "field_2_value": "demo@example.test",
      "save_label": "Save profile"
    },
    "source_hashes": {
      "actor-tools.jsonl": "0ea1c15ef0510a0e136e1e21d088477450bac4a323c48ac9f98fe1cfece60c10",
      "backend.json": "5c4c37c6257cf95a944baff67883dbd6451d58fc4a6aec4868b619a442f5875c",
      "browser-check.json": "8430580de6ebe33ee13fcb89668f73cf05643d33cca31a01d0aa1eba084c2897",
      "browser.jsonl": "3f9d5d0b8d2723fd0bae4e90fcd07422178a84ffb2ad4620ec1abe46685693d4",
      "demonstration-events.jsonl": "876e7d26fd0f252efb6976b28e820644af87bb77321220950da7bf9ff6b9ffde",
      "demonstration-inputs.jsonl": "0b884efd0ccb1669236043f59b859ca925a77eea50613db69ce754bd4d02e3b0",
      "demonstration-summary.json": "716cd0a9a4013574eda9fcebf28fee549937d22937bff1aeb0e32cbd52c3863c",
      "final-observation.json": "5e1931229e9a8cf6280308bab38d3124d325fa5f515a75b4a8e6e14bcfbada0c",
      "initial-observation.json": "b062185ca25c0daaf2efc4acbc7bf893c79c3021745bf586fb867bac122652ae",
      "trace.jsonl": "178d90466a7bd07ada814f7b2773bb9ec506acc6fe2de53b0428eb5d03915c97"
    }
  },
  {
    "path": "/private/var/folders/48/yc0_dhc5179bd42lwdjc1c1r0000gn/T/pytest-of-wenbo/pytest-124/test_record_archive_compile_an1/candidate/demonstration.json",
    "manifest_sha256": "46c62b564ed76f81fc4dead943f804cb1fbc76b1c6ceae70a2acdc8173bc2051",
    "digest": "2aeef5ff47f3492a6d56b3ae7da98a6b8e958c4a3a8cae0a86618008b21d3bdf",
    "arguments": {
      "field_1_label": "Email notifications",
      "field_1_value": true,
      "field_2_label": "SMS notifications",
      "field_2_value": false,
      "field_3_label": "Weekly digest",
      "field_3_value": false,
      "save_label": "Save settings"
    },
    "source_hashes": {
      "actor-tools.jsonl": "148d8f69e201973b4ef538ae77017b1a583da8ede81970b394e876f79bd2f714",
      "backend.json": "b7422be19cedec95fc6db3b49ecbaa4c56937c332e4f58a8172607af060edee5",
      "browser-check.json": "32d6474fc2fa611cfd9edf4be3d46125194399d5f9ca6b9c25acb92ebdbbaca0",
      "browser.jsonl": "0ced44c2036ea7640d27e634d178c2f5714e4256d1c4f9dcbb5b58f6bd300a5a",
      "demonstration-events.jsonl": "c8b99d009a148fa18f100fe71aaaf26aeb61aac6a83c0c9bf2f86f398701668c",
      "demonstration-inputs.jsonl": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "demonstration-summary.json": "6fa46738ff6cbf30e9a005b9fd7d435cb1548ab50ea6e1c0167184439a5c7518",
      "final-observation.json": "cd9293ce32f7efd9d3885f3f619ef86953c7f8dc5b0b0beac2d3a60a60244a7c",
      "initial-observation.json": "974aa8e77f6b120c684ab74e08666c7b69c1407de28c8270619183aaf450e81c",
      "trace.jsonl": "e29d11d3dc3cf98a52aa52c81b9127f50cf4f3cbb616076b24f6b345d74167e6"
    }
  }
]
```


## Fix round 1 — persisted stop failure (review of a918264)

Verified the Important finding in `task-1-review.md`: final stopped-trace append failure occurred after a successful summary had already been published. The returned failure was not reflected in persisted capture evidence, allowing normalized final verification and compilation.

Added `test_final_stop_trace_failure_persists_failed_capture_and_blocks_compilation` using a real Chromium Page, actual corrected profile fill/save, and independent checkpoint/Evaluator/archive. Only the final `demonstration_stopped` trace append is fault-injected with OSError. The regression checks returned and persisted CaptureFlushFailed, unchanged raw input/event/actor evidence, idempotent stop, one actual save POST/readback, normalized `verification='not_verified'` and `failure_status='demonstration_incomplete'`, compilation rejection and no candidate directory. A scored passed RunResult may remain in the archive, but its failed browser capture cannot serve as compilation input.

RED command: `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration.py::test_final_stop_trace_failure_persists_failed_capture_and_blocks_compilation -q` before production edit. Observed exit 1, `1 failed in 2.03s`; persisted-summary equality failed with disk `success=True/error=None/capture_error=None` versus returned `success=False/error=CaptureFlushFailed/capture_error=final stopped trace unavailable`.

Fix: persist final observation/browser/trace stop evidence before publishing the capture summary. On any stop I/O error, update the returned summary and best-effort atomically persist the failed summary. If the summary itself cannot be written, its missing required evidence prevents normalization/compilation. Existing raw records are retained. No normalization, archive, Task2, dependency or pilot source changes.

GREEN same focused command: exit 0, `1 passed in 1.39s`.

Final fresh focused gate: `.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration.py tests/test_browser_episodes.py tests/test_browser_skills.py -q` via subprocess capture. Exit 0, `35 passed in 32.99s`; full output saved in `task-1-fix-1-green.log`.

`git diff --check`: exit 0, no output. Self-review confirmed summary publication is now last and failed-summary persistence does not overwrite raw evidence. Existing missing-module RED and real human acceptance limitations remain as disclosed above; no broad/full suite or models were run.

Amended source SHA-256 (supersedes original hashes for these two files):

- `core/computer_use/demonstration.py`: `c66c0c194dfcfab2d79afe724d810a766c859808fcd54206a2692b5d617ab394`

- `tests/test_browser_demonstration.py`: `def85df654317e791f71f2bd5f5cbc8042685873d9990256ca612539bc3161e2`
