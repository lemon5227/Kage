### Task 1: DOM录制、已验证episode与参数化提取

**Files:** Create core/computer_use/demonstration.py, core/computer_use/demonstration_compiler.py, eval/computer-use/browser-demonstration-dev.json; modify core/computer_use/episodes.py; tests/test_browser_demonstration.py。

**Interfaces (verbatim):**
```python
class BrowserDemonstrationRecorder:
    def __init__(self, page, workspace, *, source_kind): ...
    async def start(self) -> dict: ...  # initial observation
    async def stop(self) -> dict: ...   # capture summary, flush, final observation

def compile_demonstration(episode: dict, output_dir, *, skill_id: str) -> dict: ...
# returns bundle_path, digest, skill_id, arguments, parameters, source_kind, source_hashes
def demonstration_tasks() -> dict: ...  # trusted immutable manifest tasks keyed by id
```

Recorder复用BrowserAdapter的SNAPSHOT语义/trace格式，注入Page事件记录click（checkbox/button）和change（文本fill），事件捕获本身不执行动作。写initial-observation.json、demonstration-events.jsonl（seq、时间、event、before/after、isTrusted/source）、actor-tools.jsonl（name=browser_act、arguments、actor=human或automation、result JSON与outcome）、browser.jsonl、trace.jsonl；保持实际修正，不把多次点击压成一个假动作。事件在Page内采样/有序排队，结束禁用监听后等待队列，不能用多个异步Python当前DOM读造成事件错配。最多64后明确CaptureLimitExceeded，不能默默截断形成技能。页面关闭与flush失败保留已发生记录。

episode归一读取result.metadata.demonstration_source声明：human_declared映射human_demonstration_declared，automation映射automation_demonstration；actor_segments包含真实human/automation。示范不得冒充student_passed/teacher接管，现有student/teacher行为不变。generation_feedback仍要求完整hash、verified/dev，只投影公开指令与DOM动作。

编译器调用generation_feedback校验episode；从实际最终可见单form状态和实际保存动作提取，每字段label/value分别参数化，checkbox ensure_checked、文本fill、最后click。保留示例arguments与来源hash到独立JSON，manifest只含v2描述/schema/workflow/digest。参数schemarequired全列、additionalProperties=false。拒绝无实际保存动作、重复语义标签、多个form歧义、控件不支持、超过16步；不读expected或在生成时访问后台。输出先stage再发布，失败不能留下看似有效manifest。

新manifest包含四个dev任务：demo_profile（Name=Kage Demo, Email=demo@example.test），reuse_profile（Name=Kage Reuse, Email=reuse@example.test，字段反序）；demo_preferences（Email notifications=true, SMS notifications=false, Weekly digest=false，初始false/true/false），reuse_preferences（同标签反序，目标false/true/true，初始true/false/false）。保存按钮分别Save profile/Save settings。公开instruction包含全部目标，可信checker独立json_exact_match保存记录+readback。此manifest不修改历史test或成绩。

- [ ] 写真实Page事件回归，先确认模块缺失失败；填写profile并纠正Name，保存/结束，原始轨迹有纠正且最终值正确。支持preferences checkbox，保存实际POST/读回。
```python
recorder = BrowserDemonstrationRecorder(page, tmp_path, source_kind='automation')
await recorder.start()
await page.get_by_label('Name', exact=True).fill('Mistake')
await page.get_by_label('Email', exact=True).fill('demo@example.test')
await page.get_by_label('Name', exact=True).fill('Kage Demo')
await page.get_by_role('button', name='Save profile', exact=True).click()
summary = await recorder.stop()
assert summary['event_count'] >= 4
```
- [ ] 实现录制/来源归一与可信清单；实际checkpoint+Evaluator构造RunResult，ExperienceArchive.record/retrieve→compile。停止后事件不能再入档；快速连续checkbox、输入失焦与结束队列不丢事件。
- [ ] 使用编译bundle和更改后的arguments在fresh reuse Page调用现有BrowserSkillCatalog、注册到现有ToolRegistry/ToolExecutor/BrowserPrimitiveQuota；两个新输入均真实POST/读回。验证无保存不编译、重复label/多form拒绝、篡改源文件后生成失败，旧episode回归不变。
```python
lesson = compile_demonstration(episode, candidate_dir, skill_id='form-demo')
catalog = BrowserSkillCatalog.from_bundle(lesson['bundle_path'])
assert lesson['source_kind'] == 'automation_demonstration'
assert lesson['arguments']  # explicitly editable example; no fixed values in workflow
```
- [ ] 聚焦`.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration.py tests/test_browser_episodes.py tests/test_browser_skills.py -q`，保存红/绿结果与源码/产物关系；git diff --check，独立feat(computer-use)提交。不调用AI/云，不运行全量。报告写本plan scratch task-1-report.md。


Approved scope addendum: core/evolution/archive.py may include all normalized browser evidence references absent from the existing ordered path list, preserving old student/teacher order and deduplicating. Add regression: raw demonstration input/event tampering marks archive retrieval stale. Normalized event budget counts committed edits/clicks, not keystrokes; persist raw input immediately, flush pending input at stop and before other actions. Generic field_N_label/field_N_value and save_label parameter keys accepted; document exact interface for Task2.
