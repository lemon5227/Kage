import asyncio, json, os, sys, time
from pathlib import Path
from playwright.async_api import async_playwright
from core.computer_use.demonstration_service import BrowserDemonstrationService
ROOT=Path.cwd()
SCRATCH=ROOT/'.superpowers/sdd/browser-demonstration-2026-10-04'

async def worker_probe():
    root=SCRATCH/'final-review-worker-evidence'; root.mkdir(exist_ok=True)
    wrapper=root/'delayed-python'
    wrapper.write_text('#!'+str(ROOT/'.venv-computer-use/bin/python')+'\nimport os, runpy, sys, time\nsys.path.insert(0, os.getcwd())\nsys.argv=["task_bootstrap", *sys.argv[3:]]\nrunpy.run_module("core.computer_use.task_bootstrap", run_name="__main__")\ntime.sleep(30)\nos._exit(1)\n')
    wrapper.chmod(0o755)
    os.environ['KAGE_BROWSER_PYTHON']=str(wrapper)
    os.environ['KAGE_BROWSER_DEMONSTRATION_HEADLESS']='1'
    service=BrowserDemonstrationService(root, lambda: {})
    async def wait(run_id, predicate):
        for _ in range(500):
            job=service.get(run_id)
            if predicate(job): return job
            await asyncio.sleep(.02)
        raise AssertionError(job)
    try:
        job=await service.submit({'task_id':'demo_profile','source_kind':'automation'})
        run_id=job['run_id']; workspace=root/('run_'+run_id)
        ready=await wait(run_id, lambda j:j['status']=='recording')
        async with async_playwright() as p:
            browser=await p.chromium.connect_over_cdp(ready['automation_cdp_endpoint'])
            page=browser.contexts[0].pages[0]
            await page.get_by_label('Name', exact=True).fill('Kage Demo')
            await page.get_by_label('Email', exact=True).fill('demo@example.test')
            await page.get_by_role('button',name='Save profile',exact=True).click()
        await service.finish(run_id)
        job=await wait(run_id, lambda j: bool((j.get('result') or {}).get('candidate')))
        pid=json.loads((workspace/'worker-owner.json').read_text())['pid']
        os.kill(pid,0)
        print('PRE_SETTLEMENT',json.dumps({'run_id':run_id,'status':job['status'],'execution_status':job['execution_status'],'nested_task_status':job['result']['task_status'],'candidate_exposed':bool(job['result'].get('candidate')),'artifact_count':len(job['artifacts']),'manifest_readable':service.artifact(run_id,'candidate/manifest.json') is not None,'acceptance_exists':service._acceptance_path(run_id).exists(),'worker_alive':True}),flush=True)
    finally:
        await service.close()
        if 'pid' in locals():
            try: os.kill(pid,0)
            except ProcessLookupError: print('WORKER_CLEANUP leader gone',flush=True)
            else: raise AssertionError('worker survived cleanup')

async def ui_probe():
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True)
        try:
            page=await browser.new_page()
            selects=['task','source','reuse-task','history']
            ids=['start','finish','stop','replay']
            html=''.join(f'<select id="demonstration-{i}"><option value="">empty</option></select>' for i in selects)
            html+=''.join(f'<button id="demonstration-{i}">{i}</button>' for i in ids)
            html+=''.join(f'<div id="demonstration-{i}"></div>' for i in ['goal','reuse-goal','candidate','status','artifacts','error'])
            html+='<textarea id="demonstration-arguments"></textarea>'
            await page.set_content(html)
            await page.add_script_tag(path=str(ROOT/'kage-avatar/public/browser-demonstrations.js'))
            await page.evaluate('''() => {
              const old={run_id:'history-A',task_id:'demo_profile',operation:'demonstration',status:'incomplete',source_kind:'automation',executor:'automation'};
              window.posts=[]; window.waitingHistory=false;
              const request=(path,options={})=>{
                if(options.method==='POST'){window.posts.push(path); return new Promise(resolve=>window.releaseStart=()=>resolve({run_id:'new-B',task_id:'demo_profile',operation:'demonstration',status:'queued',source_kind:'automation',executor:'automation'}));}
                if(path.endsWith('/catalog'))return Promise.resolve({tasks:[{task_id:'demo_profile',family:'profile',title:'Profile',instruction:'Fill Name'}]});
                if(path.endsWith('/history-A')){window.waitingHistory=true;return new Promise(resolve=>window.releaseHistory=()=>resolve(old));}
                return Promise.resolve([old]);
              };
              window.KageBrowserDemonstrations.init({request,apiUrl:'/api'});
            }''')
            await page.wait_for_function("document.querySelector('#demonstration-task').options.length > 1")
            await page.locator('#demonstration-task').select_option('demo_profile')
            await page.locator('#demonstration-history').select_option('history-A')
            await page.wait_for_function('window.waitingHistory')
            await page.locator('#demonstration-start').click()
            await page.wait_for_function('window.posts.length===1')
            await page.evaluate('window.releaseHistory()')
            await page.wait_for_function("document.querySelector('#demonstration-status').textContent.includes('history-A')")
            await page.evaluate('window.releaseStart()')
            await page.wait_for_timeout(50)
            print('UI_HISTORY_START_RACE',json.dumps({'posts':await page.evaluate('window.posts'),'visible_status':await page.locator('#demonstration-status').inner_text(),'start_enabled':await page.locator('#demonstration-start').is_enabled(),'stop_enabled':await page.locator('#demonstration-stop').is_enabled()}),flush=True)
        finally: await browser.close()

async def main():
    await worker_probe()
    await ui_probe()
asyncio.run(main())
