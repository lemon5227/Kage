### Task 2: 持久示范session、隔离worker、复用API与Launcher

**Files:** Create core/computer_use/demonstration_service.py, demonstration_worker.py, core/routes/browser_demonstrations.py, kage-avatar/public/browser-demonstrations.js; modify task_service.py/task_bootstrap.py, core/routes/__init__.py, core/server.py, kage-avatar/public/launcher.html; tests/test_browser_demonstration_routes.py与已有相关回归。

**Consumes:** Task1 BrowserDemonstrationRecorder/compile_demonstration/demonstration_tasks，manifest task IDs；现有BrowserTaskService生命周期、BrowserSkillCatalog/ToolExecutor、checkpoint/Evaluator、ExperienceArchive/Journal。
**Interfaces (verbatim):**
```python
class BrowserDemonstrationService(BrowserTaskService):
    def __init__(self, run_root, config_loader, on_event=None): ...
    def catalog(self) -> dict: ...
    async def submit(self, payload: dict) -> dict: ...
    async def finish(self, run_id: str) -> dict | None: ...
    async def replay(self, run_id: str, payload: dict) -> dict: ...
    # get/list/stop/close/artifact retain signatures; adapt persisted result/status
```

BrowserTaskService.WORKER_MODULE默认task_worker；子类demonstration_worker，bootstrap可选第4argv模块名且只接受这两个。继承同一lane/worker、deadline、早期所有权/迟到句柄/kill逻辑，覆写示范任务定义、公共状态、partial结果、submit/replay。请求保留config={}供既有生命周期释放，不带任何模型配置/凭据；真实worker不使用ModelBroker。旧C5默认行为不变，保持已有20项生命周期覆盖。

public job有run_id/task_type=browser_demonstration、operation=demonstration或replay、task_id、source_kind、status、execution_status、event_count、check_available/check_passed、stop_reason/error、result/artifacts。状态queued/starting/recording/finalizing/verified/completed/incomplete/failed/stopped；示范verified必须check通过且候选成功，复用completed必须check通过。来源和执行者明确；有检查通过但候选失败显示failed+check_passed=true+candidate_error，不伪报学会。

submit payload严格task_id/source_kind（默认human_declared）；只允许demo_profile/demo_preferences；已有活动session返回409。非阻塞创建202；持久session.json公开元数据，status.json更新ready、event_count、automation CDP地址；worker单独启动resettable fixture与Playwright（human headed、automation可headless），监听finish.requested/stop.requested，900秒整体deadline。结束禁监听/flush、用既有CheckpointExecutor(settle_saves=True)等待实际保存、Evaluator独立检查、RunResult→archive→编译，写episode/feedback/candidate/parameters/result/索引后关Page。后台/预期只留审计，不进feedback。用户关窗口/挂起/不可用浏览器/编译失败都有具体错误，保留partial。止损标记优先于迟到文件与结果。

replay payload严格task_id/arguments；只允许已verified完整候选到相同family的reuse_profile/reuse_preferences，验证manifest/source hashes与参数schema，创建新run、operation=replay、executor=workflow_engine，不复用旧Page或旧checkpoint。参数由用户编辑，禁止从checker自动填值。现有工作流执行器真正操作freshPage，共享16primitives；保存/读回独立检查。零模型请求，与真实AI复用分表。

服务持久历史从session.json/result读取；重启遇活动旧run写stop.requested并显示stopped/service_restart，不重做用户动作。artifact限制本run已索引文件/包含路径，持久候选引用可重启读取，跨run访问拒绝。service singleton/lifespan close与原control应用兼容，环境KAGE_BROWSER_DEMONSTRATIONS_DIR默认~/.kage/browser-demonstrations、KAGE_BROWSER_PYTHON沿用；仅automation可发布CDP以操作实际worker Page。真人模式不启动远程调试。

```text
GET /api/browser/demonstrations/catalog
POST /api/browser/demonstrations             -> 202
GET /api/browser/demonstrations
GET /api/browser/demonstrations/{run_id}
POST .../{run_id}/finish                    -> current job, idempotent
POST .../{run_id}/stop                      -> stopped/current terminal
POST .../{run_id}/replay                    -> 202 new run
GET .../{run_id}/artifacts/{name:path}
```

路由静态catalog在动态run_id前，缺run404、输入422、状态/不支持/并发409。复用有界_notify_runtime事件桥；server对browser_demonstration也只发事件/日志、不启语音；Launcher在旧generic HTML渲染前分流该类型，新JS模块监听事件/轮询。相同generation/run绑定与终态锁，乱序旧响应不能让结束/取消/复用指错session。

卡片使用语义label/真实按钮：选择教学任务、公开目标；开始、结束并提取、取消；ready才提示操作独立窗口；显示来源、动作数、check/错误、候选digest、未晋级、可编辑JSON参数与新输入目标，复用按钮、独立状态/请求=0/费用来源/产物。默认不加载旧未晋级候选；模型文本/参数全用textContent或表单value。清楚区分“示范检查通过/候选已生成/复用检查通过”和“AI学会”。新模块不复制全套Launcher状态系统，复用最小公共事件接口。

- [ ] 先失败回归：TestClient control app→真实demo worker→automation CDP连接同一Page→填写/纠正/保存→finish→verified、episode+候选产物；replay参数改为公开新目标→真实freshPage POST/读回通过。无保存incomplete无bundle。真正操作Page，不能直接写events/结果文件假装录制。
```python
created = client.post('/api/browser/demonstrations', json={'task_id':'demo_profile','source_kind':'automation'})
assert created.status_code == 202
run_id = created.json()['run_id']
# wait recording, use returned automation CDP endpoint to operate the actual worker Page
finished = client.post(f'/api/browser/demonstrations/{run_id}/finish')
assert finished.status_code == 200
```
- [ ] 实现worker/session/routes；验double-start409、finish/stop幂等、启动/活动/窗口关闭清理真实PID、后续session可开始、重启读候选并复用、旧活动stop标记、迟到结果不能覆盖、越run产物404。核对旧C5生命周期不退化。
- [ ] 实现Launcher/new JS模块；真实Playwright点开始、ready/finish/取消、参数编辑、复用、失败、重载；注入延迟旧GET证明按钮绑当前run，终态不复活。普通通知与C5事件仍通过。无AI/云/TTS副作用。
- [ ] 聚焦`.venv-computer-use/bin/python -m pytest tests/test_browser_demonstration_routes.py tests/test_browser_demonstration.py tests/test_browser_task_service.py tests/test_browser_task_routes.py tests/test_server_helpers.py -q`，npm run build，git diff --check，独立feat(ui)提交，task-2-report记录红/绿/覆盖。最终全量/真实模型由controller在最终审查后运行，不在本任务重复。

### Controller delivery (after both reviewed tasks)

- [ ] 最终独立整包审查；一次全量pytest、frontend源码有新变更才复建；冻结实际模型小pilot后再推理，最多2个新reuse dev ×一次，无云/额外重试/重采样。保留automation来源，无真人来源冒认；若模型不用技能也照实记录。
- [ ] 主实验报告与两任务工程报告分开；记录商业可用路径、限制、失败/解决、源码/协议/模型/hash/资源/停止。全部scratch审查复制原始目录再清理该plan scratch，保留worktree；报告另提交，主仓库干净时FF。C4.5-DOM区分工程/自动化复验和真人示范验收，后续C1.2按队列。

Approved Task2 scope addendum: core/computer_use/episodes.py may narrowly classify explicit metadata.executor='workflow_engine' as source_kind='workflow_engine_replay', student.external_passed=None and genuine workflow_engine actor_segments, with actual workflow verified/incomplete failure_status rather than falling through student failure. Preserve old student/teacher/demo branches. Real replay episode tests must verify truthful source/status/segments; compiler still rejects non-demonstration sources. Record initial/final genuine DOM snapshots needed by archive. Exclude mutable status/finish/stop/result control files from published artifact hashes.
