
- 仅拥有的受控教学浏览器；单form文字字段/checkbox/保存按钮，profile/preferences两族。公开指令和实际可见DOM进入提取，隐藏checker/expected/后台文件不进入生成输入。
- 真人入口source_kind=human_declared；自动化测试/pilot=automation，DOM isTrusted不是真人认证。无人实际教学则真人学习验收保持待做。
- 示范最多64条归一化事件/900秒；工作流复用最多16 browser primitives/480秒。每服务最多一个活动session，重复创建409；创建/结束/取消POST只发一次。
- 原始前后DOM、事件顺序、修改/纠正、来源和hash永久保留；结束时停接收、flush、settle保存、独立检查、归档/提取，再关浏览器。未保存、取消、歧义、不支持、关闭窗口和崩溃不得生成可用候选。
- 编译所有被教学单form可编辑字段的最终可见标签/值和保存按钮，值/标签为参数；候选现有v2格式，含digest/参数schema/示例/来源hash/未晋级。不存节点IDs/坐标/端口、不自动晋级安装。
- 共用已有C5进程生命周期，bootstrap模块仅允许task_worker/demonstration_worker；保持旧服务默认、取消/启动/通知语义。示范没有模型请求，直接复用执行者为workflow_engine，费用0仅指本地API。
- 公开session元数据/结果可重启读取；旧活动session写stop.requested并标stopped/service_restart，不自动恢复。停止标记优先于迟到结果。
- 真实headed浏览器为human默认；automation才允许headless/CDP取证。工程通过真实worker Page操作，不用假事件数组冒充完整回归。事件/面板通知，无浏览器语音。
- 两任务各独立代码提交、任务审查，再最终审查/全量/build；报告另提交，本地主仓库干净时FF，不推送，不删除worktree。模型推理不与重测试并行。

