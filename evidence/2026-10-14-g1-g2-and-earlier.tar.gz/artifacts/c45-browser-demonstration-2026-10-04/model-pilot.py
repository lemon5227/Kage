"""Frozen two-run local skill consumption pilot; never rerun a submitted task."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys
import time

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
sys.path.insert(0, str(ROOT))
from core.computer_use.demonstration import demonstration_tasks
from core.computer_use.experiment import BrowserChainProvider
from core.computer_use.task_worker import RecordedProvider, _model_config
from core.evolution.budget import BudgetConfig, BudgetTracker
from core.evolution.contracts import Candidate, RunSpec
from core.evolution.journal import Journal
from core.evolution.mutator import bundle_digest
from core.evolution.runner import EvolutionRunner

def save(name, value):
    (P / name).write_text(json.dumps(value, ensure_ascii=False, indent=2))

def main():
    marker = P / 'model-submissions.json'
    if marker.exists():
        raise SystemExit('Model pilot already submitted. Inspect evidence; no rerun.')
    protocol = json.loads((P / 'protocol.json').read_text())
    captures = json.loads((P / 'capture-results.json').read_text())
    config = {'model': {'local_runtime': {'host': '127.0.0.1', 'port': 18082,
                'model_name': 'agents-a1-4b', 'timeout_sec': 120},
                'cloud_api': {}, 'hybrid': {'enabled': False}}}
    profiles, _ = _model_config(config, 'local')
    primary = profiles['primary']
    run_root = P / 'model-runs'
    journal = Journal(P / 'model-journal.sqlite')
    budget = BudgetTracker(BudgetConfig(max_api_calls=protocol['max_total_model_calls'],
        max_input_tokens_total=protocol['max_reserved_input_tokens'],
        max_output_tokens_total=protocol['max_reserved_output_tokens'],
        input_cost_per_million=0, output_cost_per_million=0), P / 'model-budget.sqlite')
    submissions, rows = [], []
    save(marker.name, submissions)
    for task_id in protocol['model_reuse']['tasks']:
        capture = next(item for item in captures if item['task_id'] == task_id.replace('reuse_', 'demo_'))
        job = capture.get('job')
        if not job or job['status'] != 'verified':
            rows.append({'task_id': task_id, 'status': 'blocked', 'reason': 'source demonstration not verified'})
            save('model-results.json', rows)
            continue
        # Candidate path below is bound to the service result, never a generated replacement.
        candidate = job['result']['candidate']
        bundle = candidate['bundle_path']
        digest = bundle_digest(Path(bundle))
        run_id = 'c45-' + task_id
        workspace = run_root / ('run_' + run_id)
        model = RecordedProvider(primary.provider, workspace / 'model-calls.jsonl', [])
        task = demonstration_tasks()[task_id]
        provider = BrowserChainProvider(model, task, model_label=primary.provider.model_name,
            provider_label=type(primary.provider).__name__, max_model_calls=6,
            external_completion=True, observation_format='compact-v2', max_loop_steps=5,
            browser_skill_bundle=bundle, skill_context_mode='preview')
        runner = EvolutionRunner(journal, budget, run_root, provider, step_isolation='fork')
        subject = Candidate('c45-demo-' + task_id, (), 'workflow', bundle, digest)
        submissions.append({'task_id': task_id, 'run_id': run_id, 'bundle_path': bundle,
                            'bundle_digest': digest, 'settings': provider.metadata()})
        save(marker.name, submissions)
        started = time.monotonic()
        result = runner.run(subject, task, RunSpec(run_id, subject.candidate_id, task_id,
                                                max_steps=1, timeout_s=480))
        rows.append({'task_id': task_id, 'seconds': round(time.monotonic() - started, 3),
                     'result': asdict(result)})
        save('model-results.json', rows)
        print(json.dumps(rows[-1], ensure_ascii=False), flush=True)

if __name__ == '__main__':
    main()
