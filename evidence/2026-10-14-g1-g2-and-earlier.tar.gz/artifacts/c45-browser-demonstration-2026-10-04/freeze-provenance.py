"""Bind the frozen pilot to reviewed source, drivers and actual local weights."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
WEIGHTS = Path('/Users/wenbo/.kage/models/agents-a1-4b/Agents-A1-4B-Q4_K_M.gguf')

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

if (P / 'capture-submissions.json').exists() or (P / 'model-submissions.json').exists():
    raise SystemExit('Pilot has submissions already; provenance is immutable.')
if (P / 'provenance.json').exists():
    raise SystemExit('Source provenance already frozen; do not overwrite.')
sources = subprocess.check_output(['git', 'ls-files', 'core', 'tests', 'eval',
    'kage-avatar/src', 'kage-avatar/public'], cwd=ROOT, text=True).splitlines()
weights_sha = sha(WEIGHTS)
if weights_sha != 'd93c393a9bd5139a4b5cfe24d31ef553c5a497bfb8afec178a354ecbf508f062':
    raise SystemExit('Local weights changed; do not silently change frozen model.')
value = {'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
    'git_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'source_hashes': {name: sha(ROOT / name) for name in sources},
    'protocol_sha256': sha(P / 'protocol.json'),
    'driver_hashes': {path.name: sha(path) for path in sorted(P.glob('*.py'))},
    'model': {'name': 'agents-a1-4b', 'path': str(WEIGHTS), 'sha256': weights_sha,
              'size_bytes': WEIGHTS.stat().st_size},
    'engine_version': subprocess.check_output(['/opt/homebrew/bin/llama-server', '--version'], text=True, stderr=subprocess.STDOUT),
    'cloud': False, 'human_demonstration': False,
    'scope': 'controlled automation teaching + deterministic reuse + local model integration pilot'}
(P / 'provenance.json').write_text(json.dumps(value, ensure_ascii=False, indent=2))
print(json.dumps({'sources': len(sources), 'model_sha256': weights_sha, 'git_revision': value['git_revision']}))
