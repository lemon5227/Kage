def choose(jobs, capacity):
    return [j['id'] for j in jobs]
