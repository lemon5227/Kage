def recover(error, history, checkpoints):
    # Find the most recent successful read_file call to infer file path and function name
    file_path = None
    function_name = None
    for row in reversed(history):
        if row.get('name') == 'read_file' and row.get('success'):
            args = row.get('arguments', {})
            if isinstance(args, str):
                import json
                try:
                    args = json.loads(args)
                except Exception:
                    continue
            file_path = args.get('path') or args.get('file_path')
            if file_path:
                # Try to infer function name from the file content in the result
                result = row.get('result', '')
                if isinstance(result, str):
                    import re
                    # Look for a function definition that matches the goal or common patterns
                    # First, try to find a function named in the error goal
                    goal = error.get('goal', '')
                    if goal:
                        # Extract possible function name from goal like 'fix choose(jobs, capacity)'
                        m = re.search(r'fix\s+(\w+)\s*\(', goal)
                        if m:
                            function_name = m.group(1)
                    if not function_name:
                        # Fallback: find the first function definition in the file content
                        m = re.search(r'def\s+(\w+)\s*\(', result)
                        if m:
                            function_name = m.group(1)
                break

    if not file_path:
        return {"action": "stop"}

    # Find a matching skill from available_skills
    skills = error.get('available_skills', [])
    for skill in skills:
        desc = skill.get('description', '').lower()
        # Match skills that repair Python functions, especially knapsack selection
        if 'repair' in desc and 'python' in desc and 'function' in desc:
            # Prefer skills that mention knapsack or selection if the goal does
            goal_lower = error.get('goal', '').lower()
            if ('knapsack' in desc or 'selection' in desc) and ('knapsack' in goal_lower or 'selection' in goal_lower):
                skill_id = skill.get('skill_id')
                digest = skill.get('digest')
                if skill_id and digest:
                    return {
                        "action": "switch_tool",
                        "tool_call": {
                            "name": "skill_call",
                            "arguments": {
                                "skill_id": skill_id,
                                "digest": digest,
                                "arguments": {
                                    "file_path": file_path,
                                    "function_name": function_name or "choose"
                                }
                            }
                        }
                    }
    return {"action": "stop"}