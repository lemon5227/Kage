"""Read-only audit of the frozen native pilot; never reruns models or desktop actions."""
from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
ROOT=P.parents[2]
def sha(path):
 d=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):d.update(block)
 return d.hexdigest()
def read(path):return json.loads(Path(path).read_text())
frozen=read(P/'freeze.json');results=read(P/'results.json');budget=read(P/'budget-final.json')
checks={};rows=[]
checks['source_hashes_match']=all(sha(ROOT/name)==digest for name,digest in frozen['source_hashes'].items())
checks['two_distinct_runs']=len(results)==2 and len({r['run_id'] for r in results})==2
for r in results:
 task=next(t for t in frozen['tasks'] if t['task_id']==r['run_id'])
 ws=Path(r['final_state_path']);chain=read(ws/'chain.json');completion=read(ws/'completion.json')
 model=[json.loads(x) for x in (ws/'model.jsonl').read_text().splitlines()]
 requests=[x for x in model if x['phase']=='request'];responses=[x for x in model if x['phase']=='response']
 tools=[json.loads(x) for x in (ws/'agent-tools.jsonl').read_text().splitlines()]
 text=(ws/task['document_name']).read_text();expected=task['expected']
 usage={k:sum(x['response']['usage'][k] for x in responses) for k in ['input_tokens','output_tokens']}
 checks[r['run_id']+'_calls_match']=len(requests)==len(responses)==chain['model_requests']==r['usage']['api_calls']
 checks[r['run_id']+'_usage_match']=all(v==r['usage'][k] for k,v in usage.items())
 checks[r['run_id']+'_temperature_zero']=all(x['request'].get('temperature')==0 for x in requests)
 checks[r['run_id']+'_output_cap']=all(x['request'].get('max_tokens')==300 for x in requests)
 checks[r['run_id']+'_limits']=len(requests)<=10 and chain['agent_actions']<=16 and chain['loop']['steps']<=8
 checks[r['run_id']+'_no_valid_save']=chain['agent_save_applied'] is False and completion['agent_save_applied'] is False
 checks[r['run_id']+'_unknown_preserved']=completion['status']=='unknown' and r['metadata']['completion']['status']=='step_limit'
 checks[r['run_id']+'_disk_difference_verified']=text!=expected and text==expected.rstrip('\n') and text.count('\\n')==0
 rows.append({'task_id':r['run_id'],'kernel_status':r['status'],'score':r['score'],'independent_completion':completion['status'],
              'stop_reason':chain['loop']['stop_reason'],'model_requests':len(requests),'agent_primitive_attempts':chain['agent_actions'],
              'tool_calls':len(tools),'usage':usage,'elapsed_s':r['elapsed_s'],'disk_sha256':sha(ws/task['document_name']),
              'missing_terminal_newline':text==expected.rstrip('\n'),'literal_backslash_n_count':text.count('\\n')})
checks['budget_usage_matches']=budget['total_api_calls']==sum(r['model_requests'] for r in rows) and all(budget['total_'+k]==sum(r['usage'][k] for r in rows) for k in ['input_tokens','output_tokens'])
checks['budget_settled']=budget['active_reservations']==0
checks['owned_service_stopped']=read(P/'service-cleanup.json')=={'owned_service':True,'owned_service_stopped':True}
report={'checks':checks,'passed_checks':sum(checks.values()),'total_checks':len(checks),'rows':rows,'results_sha256':sha(P/'results.json'),'freeze_sha256':sha(P/'freeze.json')}
(P/'audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'passed_checks':report['passed_checks'],'total_checks':report['total_checks'],'rows':rows},ensure_ascii=False))
assert all(checks.values()),checks
