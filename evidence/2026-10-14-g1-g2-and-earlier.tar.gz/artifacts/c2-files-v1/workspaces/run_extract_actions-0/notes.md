# Sprint
- [ ] Fix login [owner:Mia]
- [x] Deploy [owner:Noah]
- [ ] Write tests [owner:Leo]
- [ ] Discuss roadmap
