import os
import re

def run(arguments, context):
    file_path = arguments.get('file_path')
    function_name = arguments.get('function_name', 'choose')
    if not file_path:
        return {'success': False, 'error': 'file_path is required'}
    workspace = context.get('workspace_dir', '.')
    full_path = os.path.join(workspace, file_path)
    if not os.path.isfile(full_path):
        return {'success': False, 'error': f'File not found: {file_path}'}

    with open(full_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Build the corrected function definition
    new_func = f'''def {function_name}(jobs, capacity):
    if capacity < 0:
        raise ValueError("capacity must be nonnegative")
    for j in jobs:
        if j['weight'] <= 0:
            raise ValueError("job weight must be positive")

    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for j in jobs:
        w = j['weight']
        v = j['value']
        jid = j['id']
        for cap in range(capacity, w - 1, -1):
            prev = dp[cap - w]
            if prev is None:
                continue
            cand_val = prev[0] + v
            cand_ids = sorted(prev[1] + [jid])
            cur = dp[cap]
            if cur is None or cand_val > cur[0] or (cand_val == cur[0] and cand_ids < cur[1]):
                dp[cap] = (cand_val, cand_ids)

    best = (0, [])
    for cap in range(capacity + 1):
        cur = dp[cap]
        if cur is None:
            continue
        if cur[0] > best[0] or (cur[0] == best[0] and cur[1] < best[1]):
            best = cur
    return best[1]
'''

    # Replace the existing function definition with the corrected one
    pattern = re.compile(r'^def\s+' + re.escape(function_name) + r'\s*\(.*?\)\s*:.*?(?=^\S|\Z)', re.MULTILINE | re.DOTALL)
    if pattern.search(content):
        new_content = pattern.sub(new_func, content)
    else:
        # If function not found, append it
        new_content = content.rstrip() + '\n\n' + new_func

    with open(full_path, 'w', encoding='utf-8') as f:
        f.write(new_content)

    return {'success': True, 'file_path': file_path, 'function_name': function_name}
