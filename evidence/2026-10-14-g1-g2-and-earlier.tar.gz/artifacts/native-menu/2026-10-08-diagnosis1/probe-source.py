import asyncio,json,time,sys
from pathlib import Path
from core.computer_use.native_ax import MacOSAXDriver
from core.computer_use.native_model import NativeDocumentEnvironment,ScopedNativeAdapter
from scripts.experiments.native_lifecycle_diagnosis import unique
async def run():
 out=Path('artifacts/native-menu/2026-10-08-diagnosis1');out.mkdir(parents=True,exist_ok=False)
 doc=(out/'kage-menu-diagnosis1.txt').resolve();doc.write_text('Kage menu diagnosis.\nStatus: pending.\n')
 env=NativeDocumentEnvironment(doc,out);await env.setup()
 scope=ScopedNativeAdapter(env.adapter,'com.apple.TextEdit',doc.name,document_path=doc,max_actions=2)
 result=await scope.initial();obs=result['observation'];area=unique(obs,lambda t:t['role']=='AXTextArea')
 filled=await scope.act(obs['observation_id'],'fill',area['target_ref'],'Kage menu diagnosis.\nStatus: edited.\n')
 driver=env.adapter.driver;ax,kit,cf=driver._load();app=driver._windows[scope.allowed_ref][2];window=driver._windows[scope.allowed_ref][3]
 def read(element,name):
  ax.AXUIElementSetMessagingTimeout(element,.2)
  err,names=ax.AXUIElementCopyAttributeNames(element,None)
  if err:return {'discovery_error':int(err)}
  if name not in names:return {'unsupported':True}
  err,val=ax.AXUIElementCopyAttributeValue(element,name,None)
  return {'error':int(err)} if err else val
 def sample(stage):
  apps=kit.NSRunningApplication.runningApplicationsWithBundleIdentifier_('com.apple.TextEdit');front=kit.NSWorkspace.sharedWorkspace().frontmostApplication()
  main=read(app,'AXMainWindow');bar=read(app,'AXMenuBar');rows=[];errors=[]
  for bi,item in enumerate(read(bar,'AXChildren')):
   if bi<2:continue
   subs=read(item,'AXChildren')
   if isinstance(subs,dict):errors.append({'bar_index':bi,'children':subs});continue
   for sub in subs[:1]:
    kids=read(sub,'AXChildren')
    if isinstance(kids,dict):errors.append({'bar_index':bi,'submenu_children':kids});continue
    for child in kids[:100]:
     cmd=read(child,'AXMenuItemCmdChar')
     if isinstance(cmd,str) and cmd.lower() in ('s','w'):
      err,names=ax.AXUIElementCopyAttributeNames(child,None);ae,actions=ax.AXUIElementCopyActionNames(child,None)
      rows.append({'bar_index':bi,'command':cmd,'modifiers':read(child,'AXMenuItemCmdModifiers'),'enabled':read(child,'AXEnabled'),'role':read(child,'AXRole'),'title':read(child,'AXTitle'),'attribute_error':int(err),'attributes':list(names or []),'action_error':int(ae),'actions':list(actions or [])})
  entry={'stage':stage,'monotonic':time.monotonic(),'active':bool(apps[0].isActive()),'frontmost_bundle':str(front.bundleIdentifier()),'frontmost_pid':int(front.processIdentifier()),'owned_pid':int(apps[0].processIdentifier()),'main_owned':not isinstance(main,dict) and bool(cf.CFEqual(main,window)),'commands':rows,'errors':errors}
  with (out/'raw.jsonl').open('a') as f:f.write(json.dumps(entry)+'\n')
  print(json.dumps(entry),flush=True)
 sample('before_menu')
 fresh=await scope.initial();obs=fresh['observation'];menu=unique(obs,lambda t:t['role']=='AXMenuBarItem')
 opened=await scope.act(obs['observation_id'],'press',menu['target_ref'])
 (out/'menu-result.json').write_text(json.dumps(opened,indent=2));sample('immediate_after_menu')
 await asyncio.sleep(.5);sample('after_500ms')
 await asyncio.sleep(1.5);sample('after_2000ms')
 (out/'provenance.json').write_text(json.dumps({'actions':scope.actions,'model_requests':0,'cloud_calls':0,'document':str(doc),'waits':[.5,1.5]}))
asyncio.run(run())
