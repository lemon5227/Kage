"""Recompute frozen R3-a scores and evidence; run from the repository root."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from collections import Counter
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from core.evolution.runner import Evaluator
from core.evolution.mutator import bundle_digest
from scripts.experiments.browser_skill_diagnosis import summarize

p=Path(__file__).parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def lines(path): return [json.loads(x) for x in path.read_text().splitlines()]
c=json.loads((p/'config.json').read_text());rows=json.loads((p/'results.json').read_text())
tasks={t['task_id']:t for t in c['tasks']}
assert len(rows)==4 and {r['key'] for r in rows}=={t+'--'+a for t in tasks for a in c['arms']}
for name,digest in c['source_hashes'].items():
    data=subprocess.check_output(['git','show',c['git_revision']+':'+name],cwd=ROOT)
    assert hashlib.sha256(data).hexdigest()==digest,name
assert sha(ROOT/'eval/computer-use/browser-save-budget-dev.json')==c['suite_sha256']
assert bundle_digest(Path(c['candidate']['bundle_path']))==c['candidate']['digest']
assert len(set(c['prompt_hashes'].values()))==1
details=[];evidence_count=request_count=0;outcomes=Counter();caps=set()
for r in rows:
    task=tasks[r['task_id']];ws=Path(r['final_state_path']);cap=int(r['arm'].split('-')[1])
    score=Evaluator.score(task,ws)
    assert score==r['score'] and (r['status']=='passed')==(score==1)
    assert r['metadata']['max_loop_steps']==r['chain']['max_loop_steps']==cap
    for name,digest in r['evidence_hashes'].items():
        assert sha(ws/name)==digest,name
        evidence_count+=1
    requests=lines(p/(r['key']+'-local.jsonl'))
    assert len(requests)==r['chain']['model_calls']<=cap<=6
    request_count+=len(requests)
    assert all(x['request']['temperature']==0 for x in requests)
    caps.update(x['request']['max_tokens'] for x in requests)
    assert [x['response']['usage'] for x in requests]==r['chain']['call_usage']
    entries=lines(ws/'actor-tools.jsonl');outcomes.update(e['outcome'] for e in entries)
    snapshots={x['observation']['observation_id']:x['observation'] for x in lines(ws/'browser.jsonl') if x['phase']=='observe'}
    final=list(snapshots.values())[-1]
    form={f['name']:next(t['checked'] for t in final['targets'] if t['label']==f['label']) for f in task['fixture']['fields']}
    actions=[]
    for entry in entries:
        args=entry['arguments'];obs=snapshots.get(args.get('observation_id'),{})
        label=next((t['label'] for t in obs.get('targets',[]) if t['target_ref']==args.get('target_ref')),None)
        actions.append({'name':entry['name'],'operation':args.get('operation'),'label':label,'outcome':entry['outcome']})
    check=json.loads((ws/'browser-check.json').read_text())
    details.append({'key':r['key'],'status':r['status'],'score':score,'calls':len(requests),'max_loop_steps':cap,
        'stop':r['chain']['stop_reason'],'model_errors':r['chain']['model_errors'],
        'skill_search':r['skill_search'],'skill_call':r['skill_call'],'check':check,
        'final_form':form,'final_form_matches_goal':form==task['scoring_criteria']['expected']['record'],
        'actions':actions,'seconds':r['seconds']})
summary=summarize(rows,tuple(c['arms']),c['protocol'],expected_per_arm=2)
report=json.loads((p/'report.json').read_text())
assert report['arms']==summary['arms'] and report['complete']
assert report['local_usage_ledger']['total_api_calls']==request_count
audit={'runs':len(rows),'recomputed_passes':sum(r['status']=='passed' for r in rows),
    'source_hashes_verified':len(c['source_hashes']),'evidence_hashes_verified':evidence_count,
    'request_records_verified':request_count,'tool_outcomes':dict(outcomes),'request_output_caps':sorted(caps),
    'results_sha256':sha(p/'results.json'),'run_details':details}
(p/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
index={str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file() and f.name!='artifact-index.json' and not f.name.endswith(('-wal','-shm'))}
(p/'artifact-index.json').write_text(json.dumps(index,indent=2))
print(json.dumps({**{k:v for k,v in audit.items() if k!='run_details'},'indexed_files':len(index)},ensure_ascii=False))
