"""Recompute entry verdicts and usage from raw files, independent of UI status."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import sys

P = Path(__file__).parent
ROOT = P.parents[1]
sys.path.insert(0, str(ROOT))
from core.evolution.runner import Evaluator

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

provenance = load(P / 'provenance.json')
protocol = load(P / 'protocol.json')
assert sha(P / 'protocol.json') == provenance['protocol_sha256']
for name, digest in provenance['driver_hashes'].items():
    assert sha(P / name) == digest, name
for name, digest in provenance['source_hashes'].items():
    frozen = subprocess.check_output(['git', 'show', provenance['git_revision'] + ':' + name], cwd=ROOT)
    assert hashlib.sha256(frozen).hexdigest() == digest, name
tasks = {task['task_id']: task for task in load(ROOT / 'eval/computer-use/browser-learning-v2.json')['tasks']}
rows = load(P / 'results.json')
assert len(rows) == 2 and [row['task_id'] for row in rows] == protocol['tasks']
total = Counter()
details = []
hashes = 0
for row in rows:
    job = row['job']
    result = job['result']
    ws = P / 'runs' / ('run_' + row['run_id'])
    assert result == load(ws / 'result.json')
    assert result['executor'] == 'local' and result['model_name'] == 'agents-a1-4b'
    assert result['max_loop_steps'] == 5 and not result['teacher_used']
    assert result['workflow_digest'] is None and result['unpromoted']
    assert result['cost'] == {'amount_usd': 0, 'source': 'local_api_only'}
    assert result['reservation']['api_calls'] == 6
    trace_path = ws / 'model-calls.jsonl'
    trace = [json.loads(line) for line in trace_path.read_text().splitlines()] if trace_path.exists() else []
    requests = [item['request'] for item in trace if 'request' in item]
    responses = [item['response'] for item in trace if 'response' in item]
    assert len(responses) <= len(requests) <= result['usage']['api_calls'] <= 6
    # Preserve original local AgenticLoop/MeteredProvider default, confirmed in frozen source.
    assert all(request['temperature'] == 0.7 and request['max_tokens'] == 300 for request in requests)
    model_errors = [r['error'] for r in responses if r.get('error')]
    usage = {'api_calls': len(requests)}
    if result['usage_status'] == 'reported':
        assert len(requests) == len(responses) == result['usage']['api_calls']
        usage.update(input_tokens=sum(r['usage']['input_tokens'] for r in responses),
                     output_tokens=sum(r['usage']['output_tokens'] for r in responses))
        assert result['usage'] == usage
    else:
        usage['tokens_status'] = result['usage_status']
    total.update({key: value for key, value in usage.items() if isinstance(value, int)})
    assert all(item['matches'] for item in load(P / (row['task_id'] + '-artifact-fetch.json')))
    for item in result['artifacts']:
        assert sha(ws / item['name']) == item['sha256'], item['name']
        hashes += 1
    check = load(ws / 'browser-check.json') if (ws / 'browser-check.json').exists() else {}
    expected = tasks['preferences_dev']['scoring_criteria']['expected']
    if row['task_id'] == 'preferences_dev':
        score = Evaluator.score(tasks[row['task_id']], ws)
        assert result['check_available']
        if result['check_passed'] is not None:
            assert result['check_passed'] == (score == 1)
        assert (job['status'] == 'completed') == (score == 1 and result['check_passed'] is True)
    else:
        score = None
        assert not result['check_available'] and result['check_passed'] is None
        assert job['status'] in {'unknown', 'failed'}
        if job['status'] == 'failed':
            assert result.get('error') or result['stop_reason'] in {'timeout', 'worker_crashed', 'worker_launch_failed'}
    tool_path = ws / 'actor-tools.jsonl'
    tools = [json.loads(line) for line in tool_path.read_text().splitlines()] if tool_path.exists() else []
    details.append({'task_id': row['task_id'], 'run_id': row['run_id'], 'status': job['status'],
        'recomputed_score': score, 'check': check,
        'visible_saved_matches_dev_goal': all(check.get(key) == value for key, value in expected.items()),
        'usage': usage, 'request_temperatures': sorted({r['temperature'] for r in requests}), 'seconds': row['seconds'], 'stop_reason': result['stop_reason'], 'model_errors': model_errors,
        'tool_outcomes': dict(Counter(item['outcome'] for item in tools)),
        'prompt_sha256': hashlib.sha256(json.dumps(requests[0]['messages'][0], ensure_ascii=False, sort_keys=True).encode()).hexdigest() if requests else None})
assert total['api_calls'] <= protocol['max_total_calls']
audit = {'runs': len(rows), 'usage': dict(total), 'cloud_requests': 0,
         'source_hashes_verified': len(provenance['source_hashes']), 'artifact_hashes_verified': hashes,
         'results_sha256': sha(P / 'results.json'), 'audit_correction': load(P / 'audit-correction.json'), 'details': details}
(P / 'audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2))
index = {str(path.relative_to(P)): sha(path) for path in sorted(P.rglob('*'))
         if path.is_file() and '__pycache__' not in path.parts and path.name != 'artifact-index.json'
         and not path.name.endswith(('-wal', '-shm'))}
(P / 'artifact-index.json').write_text(json.dumps(index, ensure_ascii=False, indent=2))
print(json.dumps({key: value for key, value in audit.items() if key != 'details'}, ensure_ascii=False))
print('indexed_files=' + str(len(index)))
