"""Exactly one submission per frozen task; retain failures without rerunning."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import subprocess
import time
from urllib.request import Request, urlopen

P = Path(__file__).parent
ROOT = P.parents[1]
BASE = 'http://127.0.0.1:19085'

def save(name, value):
    (P / name).write_text(json.dumps(value, ensure_ascii=False, indent=2))

def request(path, payload=None):
    data = None if payload is None else json.dumps(payload).encode()
    with urlopen(Request(BASE + path, data=data, headers={'Content-Type': 'application/json'}), timeout=10) as response:
        return json.load(response)

if (P / 'submissions.json').exists():
    raise SystemExit('Frozen pilot was already submitted; inspect existing evidence, never append attempts.')
protocol = json.loads((P / 'protocol.json').read_text())
sources = ['core/computer_use/task_service.py', 'core/computer_use/task_worker.py',
    'core/computer_use/task_bootstrap.py',
    'core/routes/browser_tasks.py', 'core/server.py', 'core/background_worker.py',
    'core/computer_use/experiment.py', 'core/computer_use/teacher_takeover.py',
    'core/computer_use/browser.py', 'core/computer_use/context_pack.py',
    'core/evolution/runner.py', 'core/agentic_loop.py', 'core/model_provider.py',
    'core/model_broker.py', 'core/tool_executor.py', 'core/prompt_builder.py',
    'core/evolution/agent_provider.py', 'core/computer_use/task_environment.py',
    'kage-avatar/public/launcher.html',
    'eval/computer-use/browser-learning-v2.json']
save('provenance.json', {'started_at_utc': datetime.now(timezone.utc).isoformat(),
    'git_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'source_hashes': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources},
    'protocol_sha256': hashlib.sha256((P / 'protocol.json').read_bytes()).hexdigest(),
    'driver_hashes': {name: hashlib.sha256((P / name).read_bytes()).hexdigest()
                      for name in ('serve-pilot.py', 'run-pilot.py', 'recompute-audit.py')},
    'entry': 'production POST /api/browser/tasks', 'executor': 'local',
    'model': protocol['model'], 'model_sha256': protocol['model_sha256'],
    'cloud': False, 'workflow_bundle': None})
save('catalog.json', request('/api/browser/catalog'))
submissions, rows = [], []
save('submissions.json', submissions)
for task_id in protocol['tasks']:
    payload = {'task_id': task_id, 'executor': 'local', 'max_loop_steps': 5}
    started = time.monotonic()
    created = request('/api/browser/tasks', payload)
    submissions.append({'payload': payload, 'response': created})
    save('submissions.json', submissions)
    run_id = created['run_id']
    snapshots = [created]
    while True:
        job = request('/api/browser/tasks/' + run_id)
        snapshots.append(job)
        save(task_id + '-status.json', snapshots)
        if job['status'] not in {'queued', 'running'}:
            break
        if time.monotonic() - started > 500:
            raise RuntimeError('Service did not enforce its own deadline; preserve evidence and investigate.')
        time.sleep(1)
    # Follow every published artifact URL through the production route.
    fetched = []
    for item in (job.get('result') or {}).get('artifacts', []):
        with urlopen(BASE + item['url'], timeout=10) as response:
            digest = hashlib.sha256(response.read()).hexdigest()
        fetched.append({'name': item['name'], 'expected_sha256': item['sha256'],
                        'http_sha256': digest, 'matches': digest == item['sha256']})
    save(task_id + '-artifact-fetch.json', fetched)
    rows.append({'task_id': task_id, 'run_id': run_id, 'seconds': round(time.monotonic() - started, 3), 'job': job})
    save('results.json', rows)
    print(json.dumps({'task_id': task_id, 'status': job['status'], 'result': job.get('result', {}).get('usage'),
                      'seconds': rows[-1]['seconds']}, ensure_ascii=False), flush=True)
save('list.json', request('/api/browser/tasks'))
