### Spec Compliance

- ❌ Issues found. `core/computer_use/task_service.py:125` does not create a structured failed result or `result.json` if the selected Python cannot start. `core/computer_use/task_worker.py:163` can label a provider transport failure on an unchecked task `unknown` instead of an execution failure. `core/computer_use/task_worker.py:38` accepts an unconfigured local executor through ModelBroker's localhost defaults. The cleanup and credential issues below also conflict with the explicit process ownership and no-key-in-artifacts constraints.
- ⚠️ Cannot verify from this diff: live cloud billing and remote provider behavior; the reported tests intentionally used a scripted HTTP model. No API/UI routing is part of Task 1.

### Strengths

- `core/computer_use/task_service.py:62-85` restricts task IDs, executor values, loop counts, and payload fields, and blocks teacher use without a checker. `core/computer_use/task_worker.py:117-128` uses the existing runner in an isolated worker with the requested compact observation, request guards, and explicit skill bundle.
- `tests/test_browser_task_service.py:99-143` exercises real HTTP model calls, a separate worker, Chromium, POST/readback, and checked versus unchecked outcomes. The reported focused suite passed 11 tests with no warnings.

### Issues

#### Critical (Must Fix)

- None.

#### Important (Should Fix)

- `core/computer_use/task_service.py:125-128`, `core/computer_use/task_service.py:254`: startup cancellation is outside the tracked-process cleanup path. `close()` cancels `BackgroundWorker.run()` while `_process()` may still await `create_subprocess_exec`; until that await returns, `_processes` has no entry. A worker that has spawned or started Chromium in this window cannot be killed by the service's process-group cleanup. Track and await startup before cancelling the worker, and always kill the entire owned group on cancellation. The existing `BackgroundWorker.stop()` calls `_task.cancel()` (`core/background_worker.py:45-51`); the reported hung-worker test begins only after process registration.
- `core/computer_use/task_service.py:125-128`: an invalid `KAGE_BROWSER_PYTHON` raises before `_process()` enters its `try/finally`. `BackgroundWorker` records a failed lane job, but `get(run_id)['result']` is `None` and no `result.json` exists. This violates the required evidence and result fields for worker failures. Catch launch errors in the service, write a partial failure result, and cover this path with a focused test.
- `core/computer_use/task_worker.py:163-164`: `execution_failed` excludes provider responses that carry `ModelResponse.error`. The existing OpenAI-compatible provider returns such a response on `URLError` (`core/model_provider.py:214-225`), and the agent loop consumes its text without raising (`core/agentic_loop.py:304-312`). On `preferences_unchecked`, a failed HTTP model call can therefore produce `task_status='unknown'`, implying an attempted but unverified task instead of an execution failure. Treat recorded model errors as execution errors and leave the checker verdict unconfirmed.
- `core/computer_use/task_worker.py:38-64`: local execution never checks that `model.local_runtime` is configured. `ModelBroker` substitutes `127.0.0.1:8080` and `local-model` when absent (`core/model_broker.py:68-90`), so `submit({'task_id':'preferences_dev'})` accepts a configuration that `catalog()` calls unconfigured and may dispatch to an unrelated service. Reject missing local runtime settings before queueing.
- `core/computer_use/task_worker.py:79-101`: redaction applies only to `model-calls.jsonl`; the unredacted `ModelResponse` is returned to the browser loop. If a remote endpoint echoes its bearer token in assistant text or an error, the unchanged loop writes that text to `*-loop-result.json` (`core/computer_use/experiment.py:205-208`), and context packing can archive it in `context-evidence` (`core/computer_use/context_pack.py:13-17`). A remote model response that echoes its Authorization header reproduces the leak even though `model-calls.jsonl` is redacted. Sanitize response/error values before any downstream artifact writer receives them, or enforce redaction across every artifact sink.

#### Minor (Nice to Have)

- None.

### Assessment

**Task quality:** Needs fixes.

**Reasoning:** The real browser tests establish the normal checked, unchecked, and registered-worker cancellation paths. Launch failure, startup shutdown, provider error classification, and end-to-end secret handling remain material gaps in the requested service contract.
