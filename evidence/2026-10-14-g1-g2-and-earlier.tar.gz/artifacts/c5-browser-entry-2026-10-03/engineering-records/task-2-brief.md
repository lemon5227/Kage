### Task 2: API、Launcher与可信通知

**Files:** 创建core/routes/browser_tasks.py，注册core/routes/__init__.py与core/server.py；修改kage-avatar/public/launcher.html；测试tests/test_browser_task_routes.py（可含真实Launcher行为）与已有后台通知测试。

**Consumes:** Task1 BrowserTaskService接口与公共job/result。使用core.server._load_effective_config；全局惰性service，run_root=KAGE_BROWSER_RUNS_DIR或~/.kage/browser-runs，on_event在kage_server存在时调用其_notify_job_event。lifespan finally关闭service，不依赖是否启动重runtime。
**Produces:**
```text
GET /api/browser/catalog                  -> catalog
POST /api/browser/tasks                   -> 202 public_job
GET /api/browser/tasks                    -> list[public_job]
GET /api/browser/tasks/{run_id}            -> public_job / 404
POST /api/browser/tasks/{run_id}/stop      -> public_job / 404
GET /api/browser/tasks/{run_id}/artifacts/{name} -> FileResponse / 404
```
Payload/配置不支持返回422或409并提供短错误，不隐藏为成功；POST立即返回run_id、后台执行。复用现有APIRouter与kage:job；_background_completion_notification对browser_experiment按task_status表达通过/未通过/待确认/已停止，普通任务行为不改。

Launcher在Background Tasks附近新增“浏览器实验”卡片：选择公开任务、显示目标、执行器/实际模型、5/6步预算，显式可选workflow_bundle（默认空，显示未晋级）；开始按钮、运行ID/状态/stop_reason/请求tokens/费用/保守预留、截图/保存证据链接与停止按钮。仅普通文字/DOM构造渲染模型文本，不让它生成HTML。复用fetchJson，创建/停止POST只发一次，避免默认重试创造额外任务；完成/unknown等终态停止轮询，页面重连先GET list补齐。UI异步显示运行状态，不因模型超时冻结按钮。

- [ ] 先API回归控制模式：POST真实service+HTTP脚本模型，等待terminal后GET独立保存证据；未保存为failed而不是后台completed；artifact取该run，未知run/name=404；停止后status不被迟到事件覆盖。
```python
created = client.post('/api/browser/tasks', json={'task_id':'preferences_dev','max_loop_steps':5})
assert created.status_code == 202
assert created.json()['status'] in {'queued','running'}
```
- [ ] 用真实Playwright加载Launcher点击开始→检查实际POST/界面终态/证据链接；用无checker与失败结果验证文字没有任务成功；点击停止触发绑定run API；不写只检查源码含字符串的用例。
- [ ] 红灯后接route/service/lifespan、卡片与通知，聚焦API/界面/普通通知回归；然后一次全量pytest与kage-avatar npm run build，不与真实推理并行。独立提交feat(ui): expose checked browser experiment tasks。
- [ ] 冻结本次入口pilot：两个local任务preferences_dev和preferences_unchecked各一次，固定5步/6请求/480秒、无bundle/云；合计12请求/96000输入/4000输出预留。代码提交后启动自有Agents-A1-4B服务和隔离control HTTP应用，用户入口（真实Launcher或相同POST API）发起；保留任何终止结果，不复跑求成功。
- [ ] 报告两个run的实际执行者/请求、POST/读回、checked vs unknown、停止与费用、源码/提示/协议hash和证据；这只验入口集成，不是新能力分数。停止自有服务，报告/队列/master/index另提交，主仓库干净时FF；下一C4.5-DOM。
