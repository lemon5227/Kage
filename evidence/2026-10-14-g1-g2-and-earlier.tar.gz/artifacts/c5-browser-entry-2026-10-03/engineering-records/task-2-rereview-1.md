### Finding Verdicts

- **Late A GET can replace selected B and make Stop target A** — ADDRESSED. Selection is now separate from rendering; a poll captures run ID and generation and discards its response after selection changes (kage-avatar/public/launcher.html:1022,1071). Stop captures the selected run ID before sending its POST (kage-avatar/public/launcher.html:1143). The new real-Launcher regression delays A's GET until after B's POST, checks that B stays selected, and verifies Stop posts to B (tests/test_browser_task_routes.py:175).
- **Out-of-order poll or event can revive a terminal run** — ADDRESSED. Terminal status is latched for the selected run, older poll responses are discarded, and active events cannot re-enable polling or Stop after the terminal result (kage-avatar/public/launcher.html:1033,1071). The regression releases a delayed B poll and sends a late active event after Stop, then checks that B still shows stopped (tests/test_browser_task_routes.py:175).

### New Breakage in the Fix Diff

- None found.

### Out-of-Scope Observations

- None. The earlier note about pre-existing pytest/Vite warnings remains non-blocking and unchanged by this fix.

### Verdict

**Fix round:** All findings addressed, no new Critical/Important breakage. The fix report names the red regression (1 failed), focused green run (27 passed), and successful frontend build; these cover the amended code. No tests were rerun in this review.
