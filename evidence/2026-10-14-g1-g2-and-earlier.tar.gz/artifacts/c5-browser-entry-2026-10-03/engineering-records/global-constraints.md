
- 此包仅受控实验页面，不接用户已登录浏览器；不宣称任意网页/通用电脑能力。任务目录只暴露公开instruction，不接受自由指令配旧checker。
- local/cloud/local_teacher均为显式执行器；主执行者6请求保护、循环默认5/可选6；teacher独立6请求/5循环。使用实际ModelBroker/ModelProvider，禁止hybrid或缺配置时的静默执行者回退。
- compact-v2、原本地输出/历史；cloud沿用现有1024输出/12000 wire bytes与教师打包；每任务480秒整体界限，16 primitives/actor。未晋级技能不默认加载；workflow_bundle仅显式提供，返回digest和未晋级标志。
- 独立检查通过才task_status=completed；有checker未通过=failed；无checker=unknown；用户停止=stopped。BackgroundWorker.completed仅运行结束；通知与UI消费task_status。
- 日常配置不含cloud有效凭据时显式失败；凭据只经子进程stdin传递，不入命令行/公共config/日志/产物。价格未配置则云费用unknown；明确区分reported usage与保守预留，未知不写0。local API成本0，不含硬件电力。
- 长任务不阻塞HTTP/event loop；停止必须绑定run_id，杀自有worker及Playwright/Chromium后代，不杀外部模型服务。处理排队取消、启动竞态、运行中取消与shutdown；不让迟到结果覆盖stopped。
- 原始产物永久保留在活动worktree实验目录或用户~/.kage/browser-runs，公共artifact路由仅返回该run中已索引文件。每包代码/报告分开提交；不推远端，不删唯一证据，不与真实推理并跑重测试。

