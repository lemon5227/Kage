### Task 1: BrowserTaskService与隔离worker

**Files:** 创建core/computer_use/task_service.py、core/computer_use/task_worker.py；修改core/background_worker.py（取消后不覆盖）；测试tests/test_browser_task_service.py、tests/test_background_worker.py。

**Interfaces (verbatim):**
```python
class BrowserTaskService:
    def __init__(self, run_root, config_loader, on_event=None): ...
    def catalog(self) -> dict: ...
    async def submit(self, payload: dict) -> dict: ...
    def list(self) -> list[dict]: ...
    def get(self, run_id: str) -> dict | None: ...
    async def stop(self, run_id: str) -> dict | None: ...
    async def close(self): ...
    def artifact(self, run_id: str, name: str): ...  # Path or None
```
Service复用专用BackgroundLane/BackgroundWorker实例，实现单worker串行；不是另一套Agent循环或评分器。独立实例避免实验Page挤占普通音频/聊天任务。on_event为async(event, public_job)；公共job包含job_id=run_id、task_type=browser_experiment、input_text公开指令、status、execution_status、task_id、executor、max_loop_steps、result和error。status含queued/running/completed/failed/stopped/unknown，execution_status区分后台执行生命周期。

payload字段：task_id、executor（local/cloud/local_teacher，默认local）、max_loop_steps（5/6，默认5）、workflow_bundle（可省略的本地bundle路径）。拒绝未知字段/错误类型，避免自由指令改变验证目标。目录使用browser-learning-v2.json的profile_dev、preferences_dev；另preferences_unchecked为preferences_dev副本移除scoring_criteria，公开标无自动检查，external_completion=False。不改既有清单或成绩。无checker任务拒绝local_teacher，因为不能据此推断失败并自动消费教师预算；基础设施错误仍显示执行失败与目标未确认，不伪报成功。

catalog返回tasks（task_id,title,instruction,check_available）及executors（id,model_name,configured），不返回key；云需有效远端OpenAI-compatible配置，其他provider/loopback冒充cloud明确不支持。worker使用ModelBroker，覆盖本次broker角色与hybrid=false后核实际profile.mode；配置为运行时快照，不修改用户文件。

result至少包含task_status、check_available/check_passed、run_status、stop_reason、executor/model_name、max_loop_steps、usage与usage_status、reservation、cost（金额可null、source明确）、workflow_digest/unpromoted、artifacts（name,url,sha256）、final_text。停止/崩溃时保留已有请求、DOM、后台产物；部分usage不冒充完整账单。actor费用若未知则整体云费用unknown。

worker通过stdin接收私有配置，公共配置/实际请求响应可落盘但必须去key。执行EvolutionRunner(step_isolation='inline')，仅因它已在独立受管理子进程内；service以start_new_session启动并施加480秒整体deadline，超时/取消杀树并留明确状态。结果写result.json，普通返回与异常均有证据；model response/error原样保留。服务支持KAGE_BROWSER_PYTHON选择已有电脑实验Python（默认sys.executable），不自动安装依赖。

- [ ] 写失败回归：真实HTTP脚本模型→实际子进程→真实Page修改/POST/读回；成功与未保存失败；preferences_unchecked的模型说Done也只能unknown。
```python
job = await service.submit({'task_id':'preferences_dev','executor':'local'})
final = await wait_terminal(service, job['run_id'])
assert final['status'] == 'completed'
assert json.loads(service.artifact(job['run_id'], 'browser-check.json').read_text()) == {
    'record': {'email': True, 'sms': False, 'weekly': False},
    'posts': 1, 'readback_matches_backend': True}
```
- [ ] 对未保存模型：status=failed、check_passed=false、posts=0；无checker同样未保存不伪报failed/completed，status=unknown。
- [ ] 对挂起HTTP模型：等真实Chromium/worker已启动，停止run，所有自有PID退出；事件状态不可由迟到返回改成completed；排队取消不发模型请求；另一任务可继续。BackgroundWorker原普通任务回归仍通过。
- [ ] 运行红灯，再实现接口；局部命令`.venv-computer-use/bin/python -m pytest tests/test_browser_task_service.py tests/test_background_worker.py -q`。只允许脚本HTTP模型，不调用云/真实大模型。
- [ ] 自检配置/产物无key，服务shutdown可清理、错误有状态，git diff --check，独立提交feat(computer-use): add managed browser experiment task service。

