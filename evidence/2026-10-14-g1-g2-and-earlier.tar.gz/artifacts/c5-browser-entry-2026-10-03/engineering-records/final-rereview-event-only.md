- **Browser notification cancellation can leave an old playback worker that unloads newer speech** — **ADDRESSED** by removing that browser-to-audio path. `core/server.py:911-922` sends the job event, records browser task status, and returns for every `browser_experiment` before the speech call at `:931`. Its notification timeout or close therefore cannot create/cancel a browser speech worker. The supplied revert restores the pre-trial `core/speech_engine.py` source and removes the four trial tests. This is boundary avoidance under the controller-approved event/panel-only policy, not a claim that generic mixer ownership was repaired.
- **A stalled runtime notification can hold run start, stop, or close** — **ADDRESSED; remains fixed**. `core/routes/browser_tasks.py:52-59` still schedules delivery independently; `:38-44` still owns and bounds runtime delivery; `:80-87` still cancels owned tasks with a bounded cleanup wait. The remediation diff does not revert these changes.
- **An unconfirmed execution failure is presented as a negative independent check** — **ADDRESSED; remains fixed**. `core/server.py:1017-1020` retains the precise helper wording. The actual browser notification is now the job event and panel; `kage-avatar/public/launcher.html:1013-1017` retains the failed-check/unconfirmed-failure distinction, and `:1045-1058` retains explicit check/error fields rendered as text.

### New breakage in the fix diff

- None. The early return applies only to `browser_experiment`; ordinary background jobs continue through the original notification decision and `mouth_speak` at `core/server.py:923-931`. Browser job data still reaches the Launcher before the return. `docs/plans/browser-task-entry-2026-10-03.md:73` explicitly records the approved notification policy.

### Checks

- Read the supplied `e3cfc78..e1e9fff` fix package once, the latest policy/evidence appendix, and focused current lines for the three named findings. No broad review or Git diff derivation was performed.
- Reviewed `tests/test_server_helpers.py:234-273`: the actual `KageServer._notify_job_event` is called with a fake speech boundary; browser completion must send its job and log its status without changing speech revision/UI state or invoking speech; ordinary completion must still invoke speech. The implementation's unconditional browser-type return covers all browser event/status values, not only the completed case used in that regression.
- The report names RED **1 failed in 0.50s**, then GREEN **1 passed in 0.46s** for that regression. Saved covering output in `artifacts/c5-browser-entry-2026-10-03/event-only-tests.log` reports **67 passed, 1 existing pygame warning in 54.72s**. These are supplied test results; no test or suite was rerun in this re-review. No audio, TTS, AI/provider/network call, new agent, source edit, or Git mutation was used.

### Out-of-scope observations

- The shared-mixer/thread cleanup limitation remains in the pre-existing general speech implementation. The browser experiment path no longer exercises the newly introduced cancellation interaction, so this baseline limitation does not block C5 under the approved scope.

### Verdict

- **Fix round: All named findings addressed, no new Critical/Important breakage.** **Code review gate: clear** on `e1e9fff`. The parent retains the fresh full-suite gate, frozen two-run local pilot, reports/evidence migration, and main fast-forward.
