- **A stalled runtime notification bypasses the run deadline and can hang stop/shutdown** — **ADDRESSED**. `core/routes/browser_tasks.py:52-59` schedules delivery without awaiting runtime I/O or speech; both wrapper and delivery tasks are owned at `:24-40`. Delivery cancellation is requested after 5 seconds at `:41-44`; close cancels owned tasks and limits its cleanup wait to 0.25 seconds at `:80-87`. The existing stalled-notifier regression verifies actual scripted-worker progress plus bounded stop/close.
- **Infrastructure errors are announced as a failed independent check, including tasks with no checker** — **ADDRESSED**. `core/server.py:1007-1010` reserves failed-check wording for `check_available is True` and `check_passed is False`; otherwise a failed execution explicitly leaves the goal unconfirmed. `kage-avatar/public/launcher.html:1013-1017` applies the same distinction, and `:1045-1058` shows the verdict/error through `textContent`. The checked and unchecked worker-launch-error cases cover the actual Launcher.
- **Notification timeout/close must cancel current real playback and restore IDLE without harming newer speech or barge-in** — **NOT ADDRESSED**. `core/speech_engine.py:87-96` stops current playback and restores IDLE with revision guards, but cancelling `to_thread` does not join the playback worker. It publishes IDLE and returns while the old thread can still execute its unconditional global mixer cleanup. The supplied tests cover stop invocation and revision guards using `FakeMouth`; they do not model the real mouth's mixer ownership.

### New breakage in the fix diff

- **Important — Cancelled playback cleanup can unload a newer utterance.** `core/speech_engine.py:87-95` interacts with the unchanged `core/mouth.py:82-86`. A cancelled old playback can still be inside its `Clock.tick` when the handler stops the mixer, returns, and sets IDLE. A newer utterance then loads its file. When the old worker resumes, its `finally` unconditionally calls `pygame.mixer.music.unload()`, removing the newer file before the newer `play()` call. Speech revision guards do not cover this thread cleanup. The fix must either avoid imposing this browser notification cancellation on speech, or ensure the old worker finishes/owns cleanup before a newer playback can use the mixer.

### Checks

- Reviewed only the supplied `59dfe35..e3cfc78` fix package, the three named findings, requirements/global constraints, and the appended Task 2 fix evidence. Unchanged reads were confined to the concrete notification-to-speech and shared-mixer boundary.
- Confirmed the report names RED **2 failed, 2 passed**, then speech GREEN **4 passed**; the saved covering output reports **46 passed, 1 existing pygame warning in 35.66s**. The saved route/server output reports **32 passed in 27.83s**. These are supplied run results; no suite was rerun.
- Ran one in-memory no-audio reproduction against the actual `mouth_speak`, `KageMouth.play_audio_file`, and `stop_playback` methods, replacing pygame with a deterministic mock and using temporary empty files. Held old `Clock.tick`; cancelled old speech; started newer speech and held its `load` after setting the mixer file; released old cleanup; then released newer `play`. Exit 0; output: `Error playing audio: nothing loaded`; states `['SPEAKING', 'IDLE', 'SPEAKING', 'IDLE']`; failures `['new file unloaded by old cancelled worker']`. No TTS, audio device, AI/provider/network call, new agent, or Git mutation was used.

### Out-of-scope observations

- None.

### Verdict

- **Fix round: Findings remain open.** The first two findings are addressed. The speech cancellation ownership finding remains open, with one new **Important** race confirmed. **Merge gate: blocked on that race**; the parent still owns the fresh full gate, two actual local pilots, report migration, and main fast-forward.
