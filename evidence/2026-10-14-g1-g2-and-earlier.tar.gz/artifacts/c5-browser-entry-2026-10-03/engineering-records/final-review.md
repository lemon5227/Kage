# C5 whole-branch final architecture/code review

Reviewed range: `6bc671d..59dfe35`.

Requirements: `docs/plans/browser-task-entry-2026-10-03.md` and this package’s `global-constraints.md`. The whole supplied branch diff, Task 1/2 reports, and progress ledger were read. Unchanged boundary reads were limited to provider resolution, metering, browser execution/checking, job storage/worker behavior, and runtime notification transport.

## Strengths

- The implementation reuses the existing agent loop, browser fixture/checker, provider broker, and background lane instead of introducing alternate execution or grading paths. The experimental lane is independent of ordinary background work.
- Executor selection disables hybrid fallback, validates resolved provider modes, rejects unsupported cloud configuration and unchecked teacher takeover, and keeps secrets out of command-line arguments. Cloud wire/output limits wrap the actual provider, and teacher request/loop and primitive limits follow the existing execution path.
- Results distinguish the background lifecycle from checked task completion. A recovered historical model error does not erase an independently confirmed success. Unchecked ordinary completion remains unknown. Reservations are separate from provider-reported usage, and missing usage/prices are not silently presented as a zero cloud bill.
- Process ownership is explicit: fresh worker process groups, early bootstrap ownership records, stop tombstones, bounded startup handoff cleanup, and final group termination cover the relevant startup/cancellation races. The browser is newly launched inside this worker; the external model server is outside its ownership group.
- API initialization remains compatible with control mode and does not instantiate the heavy runtime. Artifact access requires both run-local containment and membership in the result index.
- Launcher create/stop requests use one attempt, and generation/run checks prevent old polling responses from selecting the wrong run. Terminal active-state revival is blocked. Browser model text is rendered with textContent and diverted away from the generic HTML background-job renderer.
- Tests exercise a real subprocess, HTTP scripted provider, Chromium, POST/readback, and Launcher behavior. The changes to ordinary BackgroundWorker behavior are narrowly scoped to preventing a cancelled job from being overwritten by a late return/error.

## Issues

### Critical (Must Fix)

None found.

### Important (Should Fix)

1. **A stalled runtime notification bypasses the run deadline and can hang stop/shutdown.**
   - Location: `core/routes/browser_tasks.py:25-29`; lifecycle consumers at `core/computer_use/task_service.py:130-132`, `:384`, and `:391-394`.
   - `_notify_runtime` catches raised exceptions but awaits `_notify_job_event` without any bound. The unchanged `BackgroundWorker.process_next` awaits its started event before calling `_process`, so the service’s 480-second handling has not started while the runtime websocket send is stalled. A stopped event is also awaited inline by `stop`; `close` awaits that same stop before cancelling the worker. A websocket/notification hang can therefore strand serial execution, keep a run running past its deadline, and prevent stop or application shutdown from returning. The runtime boundary includes a directly awaited websocket send and completion speech.
   - Focused reproduction, with no subprocess/model request: construct BrowserTaskService with the real `_notify_runtime` bridge and a runtime whose `_notify_job_event` awaits an unset asyncio.Event; shorten RUN_DEADLINE_SECONDS to .03; submit and wait .08. Observed `after_deadline: running startup_count: 0`. `wait_for(service.stop(run_id), .08)` then timed out on the stopped notification. Cleanup cancelled the worker successfully after the reproduction; no AI or cloud call occurred.
   - Fix: keep notification delivery off the critical execution/stop path, or give it an explicit short bounded wait with cancellation/error isolation. Ensure its ownership/cleanup cannot block close, and ensure the overall run deadline still covers pre-process notification waiting. Add a stalled-notifier regression covering continued job progress plus bounded stop/close; the existing notifier test only covers an immediate raised exception.

2. **Infrastructure errors are announced as a failed independent check, including tasks with no checker.**
   - Location: `core/server.py:1004-1013`, especially `:1009`; related presentation at `kage-avatar/public/launcher.html:1043-1052`.
   - The worker/service deliberately represent a launch/transport/timeout failure with task_status=failed and check_passed=None. The notification maps every failed status to “浏览器实验未通过检查。” without consulting check_available or check_passed. For preferences_unchecked this claims a failed check that does not exist; for a worker launch failure it claims a check outcome when the task was never evaluated. The Launcher likewise shows the generic failed label and does not expose the existing check verdict or error field, so it does not explicitly communicate the required unconfirmed objective.
   - Focused direct call to the actual `_background_completion_notification` with worker_launch_failed, check_passed=None, and each of check_available=True/False returned “浏览器实验未通过检查。” in both cases. No runtime/model initialization or network request was needed.
   - Fix: reserve “未通过检查” for an actual negative checker verdict. For execution failure with an unconfirmed verdict, state that execution failed and the goal remains unconfirmed; show that distinction in the browser card using the existing result fields. Preserve failed task_status for infrastructure errors. Add checked-unconfirmed and unchecked-error notification/UI cases while retaining confirmed-failure coverage.

### Minor (Nice to Have)

No new minor finding. Existing pygame/Vite warnings remain baseline limitations, not introduced blockers.

## Recommendations and validation boundary

Resolve the two focused findings and run the associated regressions before the final frozen-source gate. No package-wide suite or build was rerun during this review. The supplied evidence reports Task 1’s 20 focused passes, Task 2’s 27 focused passes and build success, and 939 full-suite passes before the final UI fix; the parent owns the fresh full gate on final source.

Live cloud pricing/provider behavior is not established by scripted tests and is not claimed here. The recorded bootstrap OS scheduling caveat is acknowledged: a child that has not been allowed to execute cannot publish ownership yet; the tombstone prevents subsequent dispatch and the late handle is reaped. This is not a new finding.

The actual two-run local pilot, audit/report migration, review archive, queue updates, and clean-main fast-forward are explicitly parent-owned pending work. They are not missing-code findings and do not change the review verdict on the implementation itself. No source, index, branch, or tracked report was changed in this review; only this requested scratch review was written.

## Assessment

**Ready to merge? With fixes.**

The core experiment execution and evidence architecture is sound, and the cancellation/UI review fixes are substantive. Notification delivery still crosses the lifecycle boundary without a bound, and the user-facing error wording loses the checker-unknown distinction; both are concrete contract violations that should be fixed before merging.
