### Spec Compliance

- ❌ Issues found: The Launcher can lose the selected run when an in-flight poll for an earlier run completes after a new POST. `browserRenderJob` always changes `_browserRunId` (kage-avatar/public/launcher.html:1018), and `browserPollStatus` does not check that its response still belongs to the selected run (kage-avatar/public/launcher.html:1055). Since Start remains available while a run is active (kage-avatar/public/launcher.html:1089), a late response can make Stop target the earlier run, violating the run-bound stop requirement.
- ✅ The route exposes the requested catalog, create, list, get, stop, and indexed artifact endpoints (core/routes/browser_tasks.py:52); the UI uses one POST attempt and text-only rendering (kage-avatar/public/launcher.html:1018, kage-avatar/public/launcher.html:1089). Browser events bypass the generic background-task HTML renderer (kage-avatar/public/launcher.html:1304). The service-derived public status distinguishes checked completion, failure, unknown, and stop; the notification branch consumes that status while ordinary notifications retain their prior branch (core/server.py:989, core/server.py:1001).
- ⚠️ The frozen two-run local-model pilot, report/index, and main fast-forward are explicitly root-owned follow-up work; they are outside this Task 2 code review.

### Strengths

- The service is initialized lazily under a lock and closed in lifespan `finally`, including control mode (core/routes/browser_tasks.py:36, core/server.py:481).
- Notification exceptions are contained at the service-to-runtime bridge, so a disconnected UI does not abort the browser worker (core/routes/browser_tasks.py:24).
- The new tests exercise the actual HTTP service, subprocess worker, scripted model, browser card, artifact GET, failure/unknown wording, and stop behavior (tests/test_browser_task_routes.py:42, tests/test_browser_task_routes.py:120).

### Issues

#### Critical (Must Fix)

- None.

#### Important (Should Fix)

- `kage-avatar/public/launcher.html:1018,1055,1089,1104`: A pending poll can overwrite the newly selected run after the user starts another experiment. Subsequent polling and Stop then use the old run ID. Capture the requested ID in each poll, ignore responses unless it still equals `_browserRunId`, and prevent concurrent/out-of-order polls from reviving a terminal run. Add a browser test that delays the first run's GET until after the second POST and verifies Stop uses the second run ID.

#### Minor (Nice to Have)

- `artifacts/c5-browser-entry-2026-10-03/full-tests.log`: The reported full suite passed with one pre-existing pygame `pkg_resources` deprecation warning; the frontend build also reported existing non-module script and chunk-size warnings (`artifacts/c5-browser-entry-2026-10-03/frontend-build.log`). The output is not pristine, though no new warning is attributed to this task.

### Assessment

**Task quality:** Needs fixes.

**Reasoning:** The API and status mapping match the requested entry behavior, and the focused integration tests are meaningful. The UI must guard asynchronous responses by run ID before its run-bound Stop action can be trusted.

**Focused boundary check:** Inspected `core/computer_use/task_service.py` public-job, catalog, event, stop, and artifact contracts to verify the changed API/UI/notification fields and route URLs; no broader codebase review or test rerun was performed.
