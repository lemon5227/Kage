### Finding Verdicts

- **Already spawned worker survives stop/timeout while startup withholds its handle** — ADDRESSED: `core/computer_use/task_bootstrap.py:10-26` atomically publishes its PID/PGID before imports or stdin processing and checks the stop tombstone; `core/computer_use/task_service.py:258-316` writes that tombstone, reads the ownership record, and terminates the process group before returning. Timeout and cancellation call this path at `core/computer_use/task_service.py:153-154` and `:370-375`. The changed tests assert the real child PID is gone *before* releasing the withheld handle (`tests/test_browser_task_service.py:431`, `:485`); `:508-545` checks a child created only after stop never dispatches.

### New Breakage in the Fix Diff

- None identified. A child that the OS has not scheduled cannot yet publish its PID within the bounded stop interval; `core/computer_use/task_bootstrap.py:15-26` blocks its later dispatch and the existing late-startup callback reaps a subsequently delivered handle. This is a practical scheduling limit, not the previously demonstrated already-running-worker leak.

### Out-of-Scope Observations

- None.

### Verdict

**Fix round:** All findings addressed, no new Critical/Important breakage. The appended report records 20 passing focused tests in 17.92 seconds, compilation success, and clean diff checks; no suite was rerun.
