"""Isolated production HTTP entry with an in-memory public local configuration."""
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
os.environ['KAGE_MODE'] = 'control'
os.environ['KAGE_BROWSER_RUNS_DIR'] = str(Path(__file__).parent / 'runs')
os.environ['KAGE_BROWSER_PYTHON'] = str(ROOT / '.venv-computer-use/bin/python')

import uvicorn
import core.server as server

CONFIG = {'model': {'local_runtime': {'host': '127.0.0.1', 'port': 18082,
    'model_name': 'agents-a1-4b', 'timeout_sec': 120}, 'cloud_api': {},
    'hybrid': {'enabled': False}}}
server._load_effective_config = lambda: CONFIG
uvicorn.run(server.app, host='127.0.0.1', port=19085, log_level='warning')
