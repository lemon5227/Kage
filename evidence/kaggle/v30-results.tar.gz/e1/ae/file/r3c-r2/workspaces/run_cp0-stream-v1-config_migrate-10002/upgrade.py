def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout."""
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported for upgrade")
    
    # Make a copy to avoid modifying the input
    result = {}
    
    # Handle key renames
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Move region and retries into network sub-dict
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    result["network"] = network
    
    # Drop keys with None values
    for key in list(cfg.keys()):
        if key not in result and cfg[key] is None:
            continue  # Skip None values
    
    # Set version to 2
    result["version"] = 2
    
    return result
