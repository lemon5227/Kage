import csv
import io


def normalize_table(text):
    """Clean an exported table with columns: id, email, city, name.

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "id" cell is empty.
    - Lower-case the "email" column.
    - Remove duplicate rows by "email", keeping the first occurrence.
    - Sort rows by "email" ascending as strings (stable).

    Returns cleaned CSV text with the same header.
    An empty string returns ''; a header-only input returns just the header line.
    """
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract and validate header
    header = [cell.strip() for cell in rows[0]]
    expected = ["id", "email", "city", "name"]
    if header != expected:
        return ""

    data = rows[1:]

    # Strip whitespace from every cell
    cleaned = []
    for row in data:
        stripped = [cell.strip() for cell in row]
        if len(stripped) != 4:
            continue
        cleaned.append(stripped)

    # Drop rows whose "id" cell is empty
    cleaned = [(r[0], r[1], r[2], r[3]) for r in cleaned if r[0] != ""]

    # Lower-case the "email" column
    cleaned = [(r[0], r[1].lower(), r[2], r[3]) for r in cleaned]

    # Remove duplicate rows by "email", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[1]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    # Sort rows by "email" ascending as strings (stable)
    deduped.sort(key=lambda r: r[1])

    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow([r[0] for r in deduped])
    writer.writerows(deduped)
    return out.getvalue()
