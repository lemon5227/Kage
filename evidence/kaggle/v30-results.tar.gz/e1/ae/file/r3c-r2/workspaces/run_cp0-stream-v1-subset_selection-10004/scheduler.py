def choose(items, capacity):
    """Select jobs under a capacity limit to maximize total value.
    
    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity. If several selections tie on total value, returns
    the lexicographically smallest sorted id list. An empty selection is
    allowed. Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    # Validate items and build a list of (id, weight, value) tuples
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        item_id = item["id"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item_id, weight, value))
    
    # Sort entries by id to ensure deterministic tie-breaking later
    entries.sort(key=lambda e: e[0])
    
    n = len(entries)
    if n == 0:
        return []
    
    # dp[w] = (max_value, sorted_id_list) for capacity w
    # We track both the max value and the actual selection to handle ties.
    # Using a tuple (value, id_tuple) where id_tuple is a frozen tuple of ids.
    # This allows lexicographic comparison when values tie.
    dp = [(0, ())] * (capacity + 1)
    
    for item_id, weight, value in entries:
        # Iterate capacity downward for 0/1 knapsack
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = prev_ids + (item_id,)
            # Choose the better option: higher value, or same value but
            # lexicographically smaller id list.
            if (cand_value > prev_value) or \
               (cand_value == prev_value and cand_ids < tuple(dp[w][1])):
                dp[w] = (cand_value, cand_ids)
    
    # The answer is the best value across all capacities, with tie-breaking.
    best_value, best_ids = max(dp, key=lambda pair: (pair[0], pair[1]))
    return list(best_ids)
