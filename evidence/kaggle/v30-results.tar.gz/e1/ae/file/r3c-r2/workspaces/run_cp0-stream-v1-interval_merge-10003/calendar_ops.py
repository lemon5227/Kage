def merge_slots(intervals):
    """Combine overlapping time ranges. Each interval is a dict {"start": s, "end": e} with integer values.
    Return merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged. Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping or touching intervals
    merged = []
    for interval in sorted_intervals:
        start = interval["start"]
        end = interval["end"]
        
        if not merged:
            merged.append(dict(interval))
        else:
            last_start = merged[-1]["start"]
            last_end = merged[-1]["end"]
            
            if start <= last_end:  # Overlapping or touching
                # Update the end of the last interval to be the maximum of the two ends
                if end > last_end:
                    merged[-1]["end"] = end
            else:
                merged.append(dict(interval))
    
    return merged
