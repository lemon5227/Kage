import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # Apply NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = "".join(c for c in normalized if ord(c) < 128)

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for c in lower:
        if c not in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev_char is not None:
                result.append("-")
        else:
            result.append(c)
        prev_char = c
    handle = "".join(result)

    # Strip leading and trailing "-"
    handle = handle.strip("-")

    # If longer than 23 characters, cut to 23 and then strip trailing "-"
    if len(handle) > 23:
        handle = handle[:23].strip("-")

    return handle
