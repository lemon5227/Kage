def coalesce(intervals):
    """Merge overlapping or touching intervals.
    
    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Touching intervals like [1,3] and [3,5]
    are merged. Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
        normalized.append((start, end))
    
    # Sort by start
    normalized.sort(key=lambda x: x[0])
    
    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start <= last_end + 1:  # Touching or overlapping
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])
    
    # Convert back to dicts and sort by start
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})
    
    return result
