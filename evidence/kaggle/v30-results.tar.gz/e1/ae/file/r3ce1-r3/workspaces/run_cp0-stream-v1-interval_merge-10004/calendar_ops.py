def merge_slots(intervals):
    """Merge overlapping intervals in a list of [start, end] pairs.

    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals sorted by start ascending.
    Touching intervals (e.g., [1,3] and [3,5]) are NOT merged.
    Raises ValueError if any interval has start > end.
    The input list is not modified.
    """
    # Validate all intervals first
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Invalid interval: {start} > {end}")

    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda pair: pair[0])

    merged = []
    for start, end in sorted_intervals:
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            # Only merge if there is a real overlap (end > last_end)
            if end > last_end:
                merged[-1][1] = end
            else:
                merged.append([start, end])

    return merged
