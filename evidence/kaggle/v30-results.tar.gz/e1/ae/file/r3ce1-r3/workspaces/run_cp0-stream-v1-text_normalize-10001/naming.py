import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters into base + combining marks
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for char in lower:
        if char not in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev_char is not None:
                result.append("_")
            prev_char = None
        else:
            result.append(char)
            prev_char = char

    slug = "".join(result)

    # Strip leading and trailing "_"
    return slug.strip("_")
