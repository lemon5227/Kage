def upgrade_config(cfg):
    """Upgrade old configuration dicts to v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    Output has "version": 2.
    Renames top-level keys:
      - "max_conn" -> "max_connections"
      - "dir" -> "directory"
      - "host" -> "hostname"
    Moves "cache_size" and "region" into a sub-dict "limits".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError(
            f"Expected configuration version 1, got {cfg.get('version')}"
        )

    # Make a copy to avoid modifying the input
    upgraded = dict(cfg)

    # Rename top-level keys
    if "max_conn" in upgraded:
        upgraded["max_connections"] = upgraded.pop("max_conn")
    if "dir" in upgraded:
        upgraded["directory"] = upgraded.pop("dir")
    if "host" in upgraded:
        upgraded["hostname"] = upgraded.pop("host")

    # Move cache_size and region into limits sub-dict
    limits = {}
    if "cache_size" in upgraded:
        limits["cache_size"] = upgraded.pop("cache_size")
    if "region" in upgraded:
        limits["region"] = upgraded.pop("region")
    upgraded["limits"] = limits

    # Handle timeout_ms conversion
    if "timeout_ms" in upgraded:
        upgraded["timeout_s"] = upgraded.pop("timeout_ms") / 1000.0

    # Drop keys whose value is None
    for key in list(upgraded.keys()):
        if upgraded[key] is None:
            del upgraded[key]

    return upgraded
