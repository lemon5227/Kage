import csv
import io


def clean_rows(text):
    """Clean CSV text with header row (columns: team, name, city, id, score).

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "score" cell is empty.
    - Remove duplicate rows by "score", keeping the first occurrence.
    - Sort rows by "name" ascending as strings (stable).

    Returns cleaned CSV text with same header.
    Empty string returns ''; header-only input returns just the header line.
    """
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ""

    # Ensure we have the expected columns
    expected_cols = ["team", "name", "city", "id", "score"]
    if len(header) != len(expected_cols):
        # If header doesn't match, just process what we have
        pass
    else:
        # Verify column names match exactly (case-sensitive)
        for col in expected_cols:
            if col not in header:
                # If a required column is missing, skip processing
                pass

    rows = []
    seen_scores = set()

    for row in reader:
        # Strip whitespace from each cell
        cleaned_row = [cell.strip() for cell in row]

        # Check if we have enough columns
        if len(cleaned_row) < 5:
            continue

        # Extract the score column (index 4)
        score = cleaned_row[4]

        # Drop rows whose "score" cell is empty
        if not score or score == "":
            continue

        # Remove duplicate rows by "score", keeping first occurrence
        if score in seen_scores:
            continue
        seen_scores.add(score)

        rows.append(cleaned_row)

    # Sort rows by "name" ascending as strings (stable)
    # The name column is at index 1
    rows.sort(key=lambda row: row[1])

    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in rows:
        writer.writerow(row)

    return output.getvalue()
