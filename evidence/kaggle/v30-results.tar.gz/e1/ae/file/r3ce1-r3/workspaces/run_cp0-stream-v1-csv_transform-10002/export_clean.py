import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: name, team, city, id, score).
    Output: Cleaned CSV text with the same header.

    Rules:
    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Remove duplicate rows by "score", keeping the first occurrence.
    - Sort rows by "id" ascending as strings (stable).
    """
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ""

    # Ensure we have the expected columns
    expected_cols = ["name", "team", "city", "id", "score"]
    if len(header) != len(expected_cols):
        # If header doesn't match, just process what we have
        pass
    else:
        # Map column names to indices
        col_idx = {col: i for i, col in enumerate(header)}
        name_idx = col_idx.get("name")
        id_idx = col_idx.get("id")
        score_idx = col_idx.get("score")
    else:
        # Fallback: assume standard order if header length matches but names differ
        # We'll still try to find the columns by position
        name_idx = 0
        team_idx = 1
        city_idx = 2
        id_idx = 3
        score_idx = 4

    rows = []
    seen_scores = set()

    for row in reader:
        # Strip whitespace from each cell
        cleaned_row = [cell.strip() for cell in row]

        # Skip if name is empty
        if name_idx is not None and cleaned_row[name_idx] == "":
            continue

        # Extract score for duplicate detection
        score = cleaned_row[score_idx] if score_idx is not None else None
        if score is not None and score in seen_scores:
            continue
        seen_scores.add(score)

        # Build the row with only the columns we need (name, team, city, id, score)
        # We keep all columns but ensure they're stripped
        new_row = cleaned_row[:len(expected_cols)] if expected_cols else cleaned_row
        rows.append(new_row)

    # Sort by "id" ascending as strings (stable)
    # We need to find the index of "id" column
    id_idx = col_idx.get("id") if col_idx else 3
    if id_idx is None:
        # Fallback: assume id is at index 3
        id_idx = 3

    # Sort rows by id (as strings) - stable sort
    # We need to handle the case where id might be missing or non-string
    def sort_key(row):
        idx = id_idx if id_idx is not None else 3
        val = row[idx] if idx < len(row) else ""
        return (val, row)  # Use tuple for stable sort

    rows.sort(key=sort_key)

    # Write output with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    if header:
        writer.writerow(header)
    for row in rows:
        writer.writerow(row)

    return output.getvalue()
