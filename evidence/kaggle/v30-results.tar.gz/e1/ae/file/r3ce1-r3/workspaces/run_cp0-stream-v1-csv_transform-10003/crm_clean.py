def tidy_csv(text):
    """Clean an exported CSV table with columns: name, city, score, team."""
    if text == "":
        return ""
    
    lines = text.splitlines()
    if not lines:
        return ""
    
    # Parse header
    header = [cell.strip() for cell in lines[0].split(",")]
    if len(header) != 4:
        return ""
    
    # Process data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = [cell.strip() for cell in line.split(",")]
        if len(cells) != 4:
            continue
        name, city, score, team = cells
        # Drop rows whose "name" cell is empty
        if not name:
            continue
        rows.append((name, city, score, team))
    
    # Remove duplicate rows by "name", keeping first occurrence
    seen = set()
    unique_rows = []
    for row in rows:
        if row[0] in seen:
            continue
        seen.add(row[0])
        unique_rows.append(row)
    
    # Sort rows by "city" ascending as strings (stable)
    unique_rows.sort(key=lambda r: r[1])
    
    # Write output with '\n' line endings
    if not unique_rows:
        return ""
    
    output_lines = [",".join(header)]
    for row in unique_rows:
        output_lines.append(",".join(row))
    return "\n".join(output_lines)
