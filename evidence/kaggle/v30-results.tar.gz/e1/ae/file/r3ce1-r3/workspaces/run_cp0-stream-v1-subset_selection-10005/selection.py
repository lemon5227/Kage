def allocate(items, capacity):
    """Select items to maximize total score while total size <= capacity.

    Each item is a dict with keys "id" (unique string), "size" (positive int),
    and "score" (non-negative int). Returns the sorted list of ids of selected
    items. If several selections tie on total score, returns the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("size must be positive")

    # Standard 0/1 knapsack DP over capacity.
    # dp[c] = (max_score, selected_ids) achievable with total size exactly c.
    # We track the best score for each capacity and reconstruct the selection.
    # To handle tie-breaking on lexicographically smallest sorted id list,
    # we store the actual selected ids along with the score.

    # Initialize dp[c] = (score, tuple of ids) for capacity c.
    # Use None to indicate unreachable capacity.
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for item in items:
        idx = item["id"]
        size = item["size"]
        score = item["score"]

        # Iterate capacities from high to low to avoid using the same item twice.
        for c in range(capacity, size - 1, -1):
            prev = dp[c - size]
            if prev is None:
                continue
            cand_score = prev[0] + score
            cand_ids = prev[1] + (idx,)

            cur = dp[c]
            if cur is None or cand_score > cur[0]:
                dp[c] = (cand_score, cand_ids)
            elif cand_score == cur[0]:
                # Tie: choose lexicographically smaller sorted id list.
                # Both are tuples of ids; compare them directly.
                if cand_ids < cur[1]:
                    dp[c] = (cand_score, cand_ids)

    # The answer is the best score achievable with total size <= capacity.
    best_score = None
    best_ids = None

    for c in range(capacity + 1):
        entry = dp[c]
        if entry is None:
            continue
        score, ids = entry
        if best_score is None or score > best_score:
            best_score = score
            best_ids = ids
        elif score == best_score:
            # Tie: choose lexicographically smaller sorted id list.
            if ids < best_ids:
                best_ids = ids

    return sorted(best_ids)
