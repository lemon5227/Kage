import csv
import io


def clean_rows(text):
    """Clean an exported table CSV text.

    Input: CSV text with header row (columns: id, team, score).
    Output: Cleaned CSV text with same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "score" cell is empty.
    3. Remove duplicate rows by "team", keeping first occurrence.
    4. Sort rows by "score" ascending as strings (stable).

    Returns empty string for empty input; header-only input returns just the header line.
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header and data rows
    header = rows[0]
    data_rows = rows[1:]

    # Strip whitespace from every cell in header and data rows
    header = [cell.strip() for cell in header]
    data_rows = [[cell.strip() for cell in row] for row in data_rows]

    # Drop rows whose "score" cell is empty
    score_index = header.index("score")
    cleaned_rows = []
    for row in data_rows:
        if len(row) <= score_index:
            continue  # Skip rows missing score column
        score = row[score_index]
        if score == "":
            continue  # Drop rows with empty score
        cleaned_rows.append(row)

    # Remove duplicate rows by "team", keeping first occurrence
    team_index = header.index("team")
    seen_teams = set()
    deduped_rows = []
    for row in cleaned_rows:
        if len(row) <= team_index:
            continue  # Skip rows missing team column
        team = row[team_index]
        if team in seen_teams:
            continue  # Skip duplicate
        seen_teams.add(team)
        deduped_rows.append(row)

    # Sort rows by "score" ascending as strings (stable)
    score_index = header.index("score")
    deduped_rows.sort(key=lambda row: row[score_index], stable=True)

    # Write output with '\n' line endings using csv module
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(deduped_rows)
    return output.getvalue()
