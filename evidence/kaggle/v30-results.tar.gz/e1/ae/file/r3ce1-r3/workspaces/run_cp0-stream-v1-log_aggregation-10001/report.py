def tally_events(lines):
    """Tally events from log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    
    Returns {name: count} per service for levels ERROR and WARN only,
    treating level names case-insensitively (upper-case keys), dropping malformed input lines.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # Check level is ERROR or WARN (case-insensitive)
        level = parts[1].upper()
        if level not in ('ERROR', 'WARN'):
            continue
        # Service is after the level, must be followed by colon
        service = parts[2]
        if not service.endswith(':'):
            continue
        # Extract service name (before the colon)
        service_name = service[:-1]
        if not service_name:
            continue
        counts[service_name] = counts.get(service_name, 0) + 1
    return counts
