def coalesce(intervals):
    """Merge overlapping intervals. Each interval is a dict {"start": s, "end": e} with integer values.
    
    Returns merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start value
    sorted_intervals = sorted(intervals, key=lambda i: i["start"])
    
    merged = []
    for interval in sorted_intervals:
        start = interval["start"]
        end = interval["end"]
        
        # If merged list is empty or current interval doesn't overlap/touch the last one, add it
        if not merged or merged[-1]["end"] < start - 1:
            merged.append(interval.copy())
        else:
            # Overlapping or touching intervals - extend the end if needed
            if end > merged[-1]["end"]:
                merged[-1]["end"] = end
    
    return merged
