import unicodedata


def to_key(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters into base + combining marks
    normalized = unicodedata.normalize("NFKD", text)

    # Keep only ASCII characters (0-127), drop non-ASCII
    ascii_only = [c for c in normalized if ord(c) < 128]

    # Lower-case
    ascii_only = [c.lower() for c in ascii_only]

    # Replace runs of non-alphanumeric with single underscore
    result = []
    prev_char = None
    for c in ascii_only:
        if not (c.isalpha() or c.isdigit()):
            if prev_char is not None:
                result.append("_")
        else:
            result.append(c)
        prev_char = c

    key = "".join(result)

    # Strip leading and trailing underscores
    return key.strip("_")
