def merge_slots(intervals):
    """Combine overlapping time ranges.

    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals in the same [start, end] list form,
    sorted by start ascending. Touching intervals like [1,3] and [3,5]
    are NOT merged; only real overlaps merge.

    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate all intervals first
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")

    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])

    # Merge overlapping intervals (strictly overlapping, not touching)
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start < last_end:  # Real overlap (strictly less than)
                # Extend the current interval if needed
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])

    return merged
