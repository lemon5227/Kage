def allocate(items, capacity):
    """Select jobs under a capacity limit to maximize total gain.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, returns the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")

    # DP: dp[c] = (max_gain, sorted_ids) for capacity c
    # We track the actual selection to reconstruct the lexicographically smallest
    # result when ties occur.
    # Initialize with (0, []) for capacity 0.
    dp = [(0, []) for _ in range(capacity + 1)]

    for item in items:
        idx = item["id"]
        cost = item["cost"]
        gain = item["gain"]
        # Iterate capacities downward to avoid using the same item twice
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            new_gain = prev_gain + gain
            new_ids = sorted(prev_ids + [idx])
            # Choose the better option: higher gain, or same gain but lexicographically smaller
            if new_gain > dp[c][0] or (new_gain == dp[c][0] and new_ids < dp[c][1]):
                dp[c] = (new_gain, new_ids)

    # The answer is the best result for any capacity up to the given capacity
    max_gain = 0
    best_ids = []
    for c in range(capacity + 1):
        gain, ids = dp[c]
        if gain > max_gain or (gain == max_gain and ids < best_ids):
            max_gain = gain
            best_ids = ids

    return best_ids
