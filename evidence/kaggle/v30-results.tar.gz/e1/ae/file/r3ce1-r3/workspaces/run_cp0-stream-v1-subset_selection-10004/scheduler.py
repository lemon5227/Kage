def choose(items, capacity):
    """Select jobs under a capacity limit to maximize total value.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity. If several selections tie on total value, returns
    the lexicographically smallest sorted id list. An empty selection is
    allowed. Raises ValueError if capacity is negative or any weight is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("weight must be positive")

    n = len(items)
    if n == 0:
        return []

    # DP: dp[w] = (max_value, chosen_ids) for capacity w
    # We track the actual chosen items to reconstruct the solution.
    # Initialize with (0, []) for capacity 0.
    dp = [(0, []) for _ in range(capacity + 1)]

    for i in range(n):
        item = items[i]
        weight = item["weight"]
        value = item["value"]
        id_ = item["id"]

        # Iterate backwards to avoid using the same item multiple times.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = prev_ids + [id_]
            if cand_value > dp[w][0]:
                dp[w] = (cand_value, cand_ids)

    # The best value is at capacity.
    best_value, best_ids = dp[capacity]

    # If there are multiple ways to achieve the same best value,
    # we need to return the lexicographically smallest sorted id list.
    # Since we built dp by considering items in order, we might have
    # multiple paths to the same value. We need to ensure we pick
    # the lexicographically smallest among all optimal selections.

    # Let's recompute to find all optimal selections and choose the
    # lexicographically smallest one.
    # We'll do a second pass: for each capacity w from 0 to capacity,
    # if dp[w][0] == best_value, we consider dp[w][1] as a candidate.
    # But note that dp[w][1] might not be the lexicographically smallest
    # among all selections with total weight <= capacity and value = best_value.

    # Actually, the DP state dp[w] gives the optimal value for exactly capacity w.
    # However, we want total weight <= capacity, so we should consider all w <= capacity.
    # And among those with dp[w][0] == best_value, we need the lexicographically smallest.

    # Let's find all w where dp[w][0] == best_value and pick the lexicographically smallest.
    candidates = []
    for w in range(capacity + 1):
        if dp[w][0] == best_value:
            candidates.append(dp[w][1])

    if not candidates:
        return []

    # Choose the lexicographically smallest sorted id list.
    # All candidates are already sorted (since we built them in order).
    best_candidate = min(candidates, key=lambda ids: tuple(ids))
    return best_candidate
