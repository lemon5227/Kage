import unicodedata


def make_handle(text):
    """Turn a title into a handle.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - If longer than 23 characters, cut to 23 and strip trailing "-".
    """
    if not isinstance(text, str):
        raise TypeError(f"text must be a string, not {type(text).__name__}")

    # NFKD normalization then drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = "".join(c for c in normalized if ord(c) < 128)

    # Lower-case
    ascii_only = ascii_only.lower()

    # Replace runs of non-alphanumeric with single "-"
    parts = []
    current = []
    for c in ascii_only:
        if c.isalnum():
            current.append(c)
        else:
            if current:
                parts.append("".join(current))
                current = []
            parts.append("-")
    if current:
        parts.append("".join(current))

    handle = "".join(parts)

    # Strip leading and trailing "-"
    while handle.startswith("-"):
        handle = handle[1:]
    while handle.endswith("-"):
        handle = handle[:-1]

    # If longer than 23, cut to 23 and strip trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        while handle.endswith("-"):
            handle = handle[:-1]

    return handle
