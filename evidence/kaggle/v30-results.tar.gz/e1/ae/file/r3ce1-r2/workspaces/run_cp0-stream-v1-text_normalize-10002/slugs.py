import re
import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters into base + combining marks
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    text = text.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This effectively replaces any sequence of non-alphanumeric characters with a single hyphen
    text = re.sub(r"[^a-z0-9]+", "-", text)

    # Strip leading and trailing "-"
    text = text.strip("-")

    return text
