import csv
import io


def clean_rows(text):
    """Clean CSV text with header row (columns: team, name, city, id, score).

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "score" cell is empty.
    - Remove duplicate rows by "score", keeping the first occurrence.
    - Sort rows by "name" ascending as strings (stable).
    Returns cleaned CSV text with the same header.
    Empty string returns ''; a header-only input returns just the header line.
    """
    if not text or not text.strip():
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    # Expect header row
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Strip whitespace from all cells in each row
    cleaned = []
    for row in data:
        stripped = [cell.strip() for cell in row]
        cleaned.append(stripped)

    # Drop rows whose "score" cell is empty
    score_idx = header.index("score") if "score" in header else -1
    if score_idx >= 0:
        cleaned = [row for row in cleaned if row[score_idx] != "" and row[score_idx] is not None]

    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped = []
    for row in cleaned:
        score = row[score_idx] if score_idx >= 0 else None
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped.append(row)

    # Sort rows by "name" ascending as strings (stable)
    name_idx = header.index("name") if "name" in header else -1
    if name_idx >= 0:
        deduped.sort(key=lambda row: row[name_idx])

    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
