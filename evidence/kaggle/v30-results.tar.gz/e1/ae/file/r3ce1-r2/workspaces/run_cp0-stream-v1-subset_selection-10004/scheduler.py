def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Return the sorted list of ids whose
    total value is as large as possible while total weight stays <= capacity.
    If several selections tie on total value, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("weight must be positive")

    # Use dynamic programming for the knapsack problem
    # dp[w] = (max_value, sorted_ids) for capacity w
    dp = [(0, [])] * (capacity + 1)

    for item in items:
        item_id = item["id"]
        weight = item["weight"]
        value = item["value"]

        # Iterate backwards to avoid using the same item multiple times
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            new_value = prev_value + value
            new_ids = sorted(prev_ids + [item_id])

            # Choose the better option (higher value, or lexicographically smaller if tied)
            if new_value > prev_value or (new_value == prev_value and new_ids < prev_ids):
                dp[w] = (new_value, new_ids)

    # The result is the best value for capacity <= capacity
    max_value, best_ids = dp[capacity]

    return best_ids
