def select_tasks(items, capacity):
    """Select parcels under a capacity limit to maximize total gain."""
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    # Validate items and filter out invalid ones
    valid_items = []
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        gain = item["gain"]
        if gain < 0:
            raise ValueError("gain must be non-negative")
        valid_items.append(item)
    
    # Sort items by gain/cost ratio (greedy approach for fractional knapsack-like problem)
    # But since we need integer selections, we should use dynamic programming or greedy with sorting
    # Actually, this is the classic 0/1 knapsack problem with cost as weight and gain as value
    
    # Use dynamic programming for 0/1 knapsack
    n = len(valid_items)
    if n == 0:
        return []
    
    # dp[i][c] = maximum gain using first i items with capacity c
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        cost = valid_items[i-1]["cost"]
        gain = valid_items[i-1]["gain"]
        for c in range(capacity + 1):
            # Don't include item i
            dp[i][c] = dp[i-1][c]
            if c >= cost:
                # Include item i
                dp[i][c] = max(dp[i][c], dp[i-1][c-cost] + gain)
    
    # Reconstruct the solution
    result = []
    c = capacity
    for i in range(n, 0, -1):
        if dp[i][c] != dp[i-1][c]:
            result.append(valid_items[i-1]["id"])
            c -= valid_items[i-1]["cost"]
    
    return sorted(result)
