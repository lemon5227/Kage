def summarize(lines):
    """Count WARN lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each service for levels WARN only to how many lines it has.
    Levels are case-insensitive (reported upper-case). Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # First two parts: timestamp and LEVEL
        level = parts[1].upper()
        # Service is after the colon following LEVEL
        if len(parts) < 3 or ':' not in parts[2]:
            continue
        service = parts[2].split(':')[0]
        if level != 'WARN':
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
