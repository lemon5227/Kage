import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters into base + combining marks
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    text = "".join(c for c in text if ord(c) < 128)

    # Lower-case
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_is_sep = False
    for c in text:
        is_sep = not (c.isalpha() or c.isdigit())
        if is_sep and not prev_is_sep:
            result.append("-")
        prev_is_sep = is_sep
    text = "".join(result)

    # Strip leading and trailing "-"
    return text.strip("-")
