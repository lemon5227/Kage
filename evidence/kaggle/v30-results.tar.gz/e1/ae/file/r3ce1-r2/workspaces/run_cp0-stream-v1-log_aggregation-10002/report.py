def digest_lines(lines):
    """Process log lines in format '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns a dict mapping level names (upper-case) to counts, dropping
    malformed input lines.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if not level.isalpha():
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
