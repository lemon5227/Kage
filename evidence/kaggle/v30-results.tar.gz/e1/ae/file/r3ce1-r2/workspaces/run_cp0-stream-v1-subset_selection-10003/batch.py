def pick_jobs(items, capacity):
    """Choose parcels to maximize total score within capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer (must be > 0)
      - "score": non-negative integer (>= 0)

    Returns a sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total
    score, return the lexicographically smallest sorted id list. An empty
    selection is allowed.

    Raises ValueError if capacity is negative or any item's size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # If no items, return empty list
    if not items:
        return []

    # Create a list of (id, size, score) tuples
    entries = [(item["id"], item["size"], item["score"]) for item in items]

    # Sort by score descending, then by id ascending for tie-breaking
    # This ensures that when we process items, higher scores come first,
    # and for equal scores, the lexicographically smaller id is considered
    # first. We'll use a greedy approach: sort by score desc, id asc,
    # then take items in order until capacity is exceeded.
    entries.sort(key=lambda e: (-e[2], e[0]))

    selected = []
    total_size = 0
    total_score = 0

    for item_id, size, score in entries:
        if total_size + size <= capacity:
            selected.append(item_id)
            total_size += size
            total_score += score

    return sorted(selected)
