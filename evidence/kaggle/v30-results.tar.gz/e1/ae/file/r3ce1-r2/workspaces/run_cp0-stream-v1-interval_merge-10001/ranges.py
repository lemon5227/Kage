def merge_slots(intervals):
    """Merge overlapping intervals. Each interval is a dict {"from": s, "to": e} with integer values.
    
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Convert to list of tuples for sorting and processing
    normalized = [(interval["from"], interval["to"]) for interval in intervals]
    
    # Sort by start time
    normalized.sort(key=lambda x: x[0])
    
    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start <= last_end:  # Overlapping or touching
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])
    
    # Convert back to dict format and sort by start
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})
    
    return result
