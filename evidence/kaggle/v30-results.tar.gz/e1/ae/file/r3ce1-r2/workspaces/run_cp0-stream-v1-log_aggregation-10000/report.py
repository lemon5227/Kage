def count_entries(lines):
    """Count occurrences of log levels in lines.

    Each line is expected to be: "<timestamp> <LEVEL> <service>: <message>"
    Returns a dict mapping each level (upper-case) to its count.
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service: ...
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if not level.isalpha():
            continue
        counts[level] = counts.get(level, 0) + 1
    return {k: v for k, v in counts.items() if v > 0}
