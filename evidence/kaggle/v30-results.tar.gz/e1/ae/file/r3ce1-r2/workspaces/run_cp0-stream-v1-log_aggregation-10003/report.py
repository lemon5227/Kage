def aggregate_log(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        service = parts[2]
        if service.startswith(':'):
            service = service[1:]
        if not service:
            continue
        if level not in ('ERROR', 'WARN'):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
