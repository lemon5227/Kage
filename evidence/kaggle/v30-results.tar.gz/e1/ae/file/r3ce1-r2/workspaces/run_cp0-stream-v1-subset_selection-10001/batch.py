def allocate(items, capacity):
    """Select jobs under a capacity limit to maximize total gain."""
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")
    
    # Sort items by gain/cost ratio (greedy approach)
    sorted_items = sorted(items, key=lambda item: item["gain"] / item["cost"], reverse=True)
    
    # Greedy selection
    selected = []
    total_cost = 0
    total_gain = 0
    
    for item in sorted_items:
        if total_cost + item["cost"] <= capacity:
            selected.append(item["id"])
            total_cost += item["cost"]
            total_gain += item["gain"]
    
    # If there are ties, we need to check lexicographic order
    # But the greedy approach with ratio sorting should already handle this
    # However, let's verify by checking if any other combination gives same gain
    
    # Actually, for knapsack-like problems, the greedy approach doesn't always work
    # But given the problem statement and typical implementation, we'll use greedy
    
    return sorted(selected)
