def allocate(items, capacity):
    """Select items to maximize total score while total size <= capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer
      - "score": non-negative integer

    Returns the sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total
    score, return the lexicographically smallest sorted id list. An empty
    selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # Standard 0/1 knapsack DP over capacity.
    # dp[c] = (max_score, chosen_ids) for capacity c.
    # We track the chosen ids to reconstruct the optimal selection.
    # To ensure lexicographically smallest id list among ties, we prefer
    # smaller ids when scores are equal.

    # Initialize: dp[0] = (0, [])
    # For each item, update dp in reverse capacity order.
    # When updating, if the new score is strictly greater, we take it.
    # If equal, we keep the one with lexicographically smaller id list.

    # We'll store tuples (score, chosen_ids) for each capacity.
    # Since we need to compare lexicographically when scores tie, we can
    # use a tuple (score, chosen_ids) and compare normally.

    # Initialize dp array with (-inf, []) for capacities 1..capacity,
    # and (0, []) for capacity 0.
    dp = [(float("-inf"), []) for _ in range(capacity + 1)]
    dp[0] = (0, [])

    for item in items:
        idx = item["id"]
        size = item["size"]
        score = item["score"]

        # Iterate capacities from capacity down to size.
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[c - size]
            new_score = prev_score + score
            new_ids = prev_ids + [idx]

            curr_score, curr_ids = dp[c]
            # Choose the better option: higher score, or if equal score,
            # lexicographically smaller id list.
            if new_score > curr_score or (new_score == curr_score and new_ids < curr_ids):
                dp[c] = (new_score, new_ids)

    best_score, best_ids = dp[capacity]
    return sorted(best_ids)
