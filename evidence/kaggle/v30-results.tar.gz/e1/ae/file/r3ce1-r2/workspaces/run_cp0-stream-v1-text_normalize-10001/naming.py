import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters into base + combining marks
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    text = text.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    import re
    text = re.sub(r"[^a-z0-9]+", "_", text)

    # Strip leading and trailing "_"
    text = text.strip("_")

    return text
