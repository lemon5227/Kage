import unicodedata


def make_handle(text):
    """Turn a title into a handle.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - If longer than 23 characters, cut to 23 and strip trailing "-".
    """
    if not isinstance(text, str):
        raise TypeError(f"text must be a string, not {type(text).__name__}")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = "".join(c for c in normalized if ord(c) < 128)

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_is_sep = False
    for c in lower:
        is_sep = not (c.isalpha() or c.isdigit())
        if is_sep and not prev_is_sep:
            result.append("-")
        elif not is_sep and prev_is_sep:
            # Skip consecutive separators
            continue
        prev_is_sep = is_sep
        result.append(c)

    handle = "".join(result)

    # Strip leading and trailing "-"
    while handle.startswith("-"):
        handle = handle[1:]
    while handle.endswith("-"):
        handle = handle[:-1]

    # If longer than 23 characters, cut to 23 and strip trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        while handle.endswith("-"):
            handle = handle[:-1]

    return handle
