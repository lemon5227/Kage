def select_tasks(items, capacity):
    """Select tasks to maximize total score within capacity.

    Each item is a dict with keys:
        - "id": unique string identifier
        - "size": positive integer (must be > 0)
        - "score": non-negative integer (>= 0)

    Returns a sorted list of task ids whose total score is maximized
    while total size stays <= capacity. If multiple selections tie on
    total score, returns the lexicographically smallest sorted id list.

    Raises ValueError if capacity is negative or any item has size <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    n = len(items)
    # dp[w] = (max_score, selected_ids) for capacity w
    # We track the actual selection to reconstruct the result.
    # Initialize with (0, []) for capacity 0.
    dp = [(0, []) for _ in range(capacity + 1)]

    for i in range(n):
        item = items[i]
        size = item["size"]
        score = item["score"]
        # Iterate backwards to avoid using the same item twice.
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[w - size]
            cand_score = prev_score + score
            cand_ids = prev_ids + [item["id"]]
            # Compare with current best at capacity w.
            if cand_score > prev_score:
                dp[w] = (cand_score, cand_ids)
            elif cand_score == prev_score and cand_ids < prev_ids:
                # Lexicographically smaller selection.
                dp[w] = (cand_score, cand_ids)

    # The answer is the best result among all capacities <= capacity.
    best_score = 0
    best_ids = []
    for w in range(capacity + 1):
        score, ids = dp[w]
        if score > best_score or (score == best_score and ids < best_ids):
            best_score = score
            best_ids = ids

    return sorted(best_ids)
