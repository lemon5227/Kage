def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout."""
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 configuration")

    result = {"version": 2}

    # Rename top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]

    # Move port and workers into storage sub-dict
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    result["storage"] = storage

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged, drop keys with None values
    for key, value in cfg.items():
        if key not in ("dir", "host", "port", "workers", "timeout_ms") and value is not None:
            result[key] = value

    return result
