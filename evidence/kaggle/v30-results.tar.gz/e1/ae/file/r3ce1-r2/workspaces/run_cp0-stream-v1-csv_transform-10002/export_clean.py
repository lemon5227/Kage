import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: name, team, city, id, score).
    Output: Cleaned CSV text with the same header.

    Rules:
    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Remove duplicate rows by "score", keeping the first occurrence.
    - Sort rows by "id" ascending as strings (stable).
    """
    # Handle empty input
    if not text or not text.strip():
        return ""

    # Parse CSV into a list of dicts
    reader = csv.DictReader(io.StringIO(text))
    rows = list(reader)

    # Strip whitespace from every cell
    for row in rows:
        for key in row:
            if row[key] is not None:
                row[key] = row[key].strip()

    # Drop rows whose "name" cell is empty
    rows = [row for row in rows if row.get("name", "") != ""]

    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped = []
    for row in rows:
        score = row["score"]
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped.append(row)

    # Sort rows by "id" ascending as strings (stable)
    deduped.sort(key=lambda row: row["id"])

    # Write output CSV with '\n' line endings
    output = io.StringIO()
    fieldnames = ["name", "team", "city", "id", "score"]
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(fieldnames)
    writer.writerows(deduped)

    return output.getvalue()
