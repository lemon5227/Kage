def merge_slots(intervals):
    """Merge overlapping intervals in a list of [start, end] pairs.
    
    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals sorted by start ascending.
    Touching intervals (e.g., [1,3] and [3,5]) are NOT merged.
    Raises ValueError if any interval has start > end.
    """
    # Validate all intervals first
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Invalid interval: {start}, {end}")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda pair: pair[0])
    
    # Merge overlapping intervals (strictly overlapping)
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start < last_end:  # Real overlap (strictly less than)
                # Merge by extending the end if needed
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])
    
    return merged
