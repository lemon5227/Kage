import csv
import io


def clean_rows(text):
    """Clean an exported table CSV text.

    Input: CSV text with header row (columns: id, team, score).
    Output: Cleaned CSV text with same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "score" cell is empty.
    3. Remove duplicate rows by "team", keeping first occurrence.
    4. Sort rows by "score" ascending as strings (stable).

    Returns:
        Cleaned CSV text, or '' if input is empty.
    """
    # Parse the CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ''

    # Extract header and data rows
    header = rows[0]
    data_rows = rows[1:]

    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)

    # Drop rows whose "score" cell is empty
    # The score column is at index 2 (id=0, team=1, score=2)
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) < 3 or row[2] == '':
            continue
        filtered_rows.append(row)

    # Remove duplicate rows by "team", keeping first occurrence
    seen_teams = set()
    unique_rows = []
    for row in filtered_rows:
        team = row[1]
        if team in seen_teams:
            continue
        seen_teams.add(team)
        unique_rows.append(row)

    # Sort rows by "score" ascending as strings (stable)
    # The score column is at index 2
    sorted_rows = sorted(unique_rows, key=lambda row: row[2])

    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in sorted_rows:
        writer.writerow(row)

    return output.getvalue()
