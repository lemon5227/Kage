import csv
import io


def tidy_csv(text):
    """Clean an exported CSV table with columns: name, city, score, team.

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Remove duplicate rows by "name", keeping the first occurrence.
    - Sort rows by "city" ascending as strings (stable).
    - Output uses '\n' line endings.

    Returns '' for empty input, and just the header line for header-only input.
    """
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    # Strip whitespace from each cell
    cleaned = []
    for row in rows:
        stripped = [cell.strip() for cell in row]
        cleaned.append(stripped)

    # Drop rows whose "name" cell is empty
    name_idx = 0  # first column is "name"
    filtered = []
    for row in cleaned:
        if len(row) <= name_idx:
            continue  # skip rows with insufficient columns
        if row[name_idx] == "":
            continue  # drop rows with empty name
        filtered.append(row)

    # Remove duplicate rows by "name", keeping first occurrence
    seen = set()
    deduped = []
    for row in filtered:
        key = row[name_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    # Sort rows by "city" ascending as strings (stable)
    city_idx = 1  # second column is "city"
    sorted_rows = sorted(deduped, key=lambda row: row[city_idx])

    # Write output with '\n' line endings
    writer = csv.writer(io.StringIO())
    writer.writerows(sorted_rows)
    return io.StringIO().read()

