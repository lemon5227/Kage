import csv
import io


def normalize_table(text):
    """Clean CSV text with header row (columns: score, id, email, name)."""
    if not text or not text.strip():
        return ""

    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header
    header = [cell.strip() for cell in rows[0]]
    if len(header) != 4 or header[0] != "score" or header[1] != "id" or header[2] != "email" or header[3] != "name":
        return ""

    # Process data rows (skip header)
    data_rows = rows[1:]

    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)

    # Drop rows whose "name" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) < 4 or not row[3]:
            continue
        filtered_rows.append(row)

    # Lower-case the "email" column (index 2)
    for row in filtered_rows:
        if len(row) > 2:
            row[2] = row[2].lower()

    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    deduped_rows = []
    for row in filtered_rows:
        name = row[3]
        if name in seen_names:
            continue
        seen_names.add(name)
        deduped_rows.append(row)

    # Sort rows by "email" ascending as strings (stable)
    deduped_rows.sort(key=lambda row: row[2])

    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
