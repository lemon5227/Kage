import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with header row (columns: name, team, city, id, score)
    Output: Cleaned CSV text with the same header
    
    Steps:
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "name" cell is empty
    - Remove duplicate rows by "score", keeping the first occurrence
    - Sort rows by "id" ascending as strings (stable)
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    header = next(reader)
    
    # Validate header columns
    expected_columns = ['name', 'team', 'city', 'id', 'score']
    if header != expected_columns:
        raise ValueError(f"Expected header {expected_columns}, got {header}")
    
    # Process rows
    rows = []
    seen_scores = set()
    
    for row in reader:
        # Strip whitespace from each cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip if name is empty
        if not cleaned_row[0]:
            continue
        
        # Remove duplicates by score (keep first occurrence)
        score = cleaned_row[4]
        if score in seen_scores:
            continue
        seen_scores.add(score)
        
        rows.append(cleaned_row)
    
    # Sort by id ascending as strings (stable sort)
    rows.sort(key=lambda row: row[3])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in rows:
        writer.writerow(row)
    
    return output.getvalue()
