import csv
import io


def clean_rows(text):
    """
    Clean CSV text with header row (columns: team, name, city, id, score).
    Returns cleaned CSV text with the same header.
    
    Operations in order:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "name" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Parse CSV
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Extract header
    header = lines[0].strip()
    if not header:
        return ''
    
    # Check if header matches expected columns
    expected_columns = ['team', 'name', 'city', 'id', 'score']
    if header != ','.join(expected_columns):
        # If header doesn't match, still process but use the given header
        pass
    
    # Parse data rows
    data_rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        # Split by comma and strip whitespace from each cell
        cells = [cell.strip() for cell in line.split(',')]
        if len(cells) < 5:
            continue
        data_rows.append(cells)
    
    # Step 1: Already stripped whitespace from each cell
    
    # Step 2: Drop rows whose "score" cell is empty
    filtered_rows = []
    for row in data_rows:
        score = row[4] if len(row) > 4 else ''
        if score != '':
            filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in filtered_rows:
        score = row[4] if len(row) > 4 else ''
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Step 4: Sort rows by "name" ascending as strings (stable)
    # Use stable sort - Python's sort is stable
    unique_rows.sort(key=lambda row: row[1] if len(row) > 1 else '')
    
    # Build output CSV
    output_lines = [header]
    for row in unique_rows:
        # Reconstruct the row, ensuring we have at least 5 columns
        cells = row[:5] if len(row) >= 5 else row + [''] * (5 - len(row))
        output_lines.append(','.join(cells))
    
    # Join with '\n' line endings
    return '\n'.join(output_lines)


if __name__ == '__main__':
    # Test examples
    test1 = "team,name,city,id,score\nA,B,C,D,10\nE,F,G,H,10"
    print("Test 1:", clean_rows(test1))
    
    test2 = "team,name,city,id,score\nX,Y,Z,W,"
    print("Test 2:", clean_rows(test2))
    
    test3 = ""
    print("Test 3:", clean_rows(test3))
