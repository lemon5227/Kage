def aggregate_log(lines):
    """Aggregate log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns {name: count} per service for levels ERROR, WARN only,
    treating level names case-insensitively (upper-case keys),
    dropping malformed input lines.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
            
        # Extract level (second part)
        level = parts[1].upper()
        
        # Check if level is ERROR or WARN
        if level not in ('ERROR', 'WARN'):
            continue
            
        # Extract service (third part, before the colon)
        service_part = parts[2]
        
        # Validate service format: should contain a colon
        if ':' not in service_part:
            continue
            
        service = service_part.split(':')[0]
        
        # Count this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
