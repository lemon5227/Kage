def summarize(lines):
    """
    Summarize log lines in format: <timestamp> <LEVEL> <service>: <message>
    Returns a dict mapping each service for levels WARN only to count.
    Levels are case-insensitive (reported upper-case).
    Skips malformed lines. Omit keys with zero count.
    """
    service_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 4 parts: timestamp, level, service, and message starts after colon
        if len(parts) < 4:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Check if level is WARN
        if level != 'WARN':
            continue
        
        # Extract service (third part, before the colon)
        # Format: <timestamp> <LEVEL> <service>: <message>
        # The service is the third token, but we need to ensure it's followed by a colon
        # parts[2] should be the service name
        service = parts[2]
        
        # Count this service
        service_counts[service] = service_counts.get(service, 0) + 1
    
    # Return only services with count > 0 (already handled by dict)
    return service_counts
