import csv
import io

def tidy_csv(text):
    """Clean an exported CSV table with header: name, city, score, team."""
    
    # Handle empty string input
    if not text or not text.strip():
        return ''
    
    # Split into lines and handle line endings
    lines = text.split('\n')
    
    # If only header row exists, return it as is
    if len(lines) == 1:
        return lines[0]
    
    # Parse the CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Check if there's a header row (first row)
    if not rows:
        return ''
    
    header = rows[0]
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "name" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if row[0] == '':
            continue
        filtered_rows.append(row)
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in filtered_rows:
        name = row[0]
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Sort rows by "city" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
