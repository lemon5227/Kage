def count_entries(lines):
    """Count entries by level in log lines.
    
    Each line looks like: "<timestamp> <LEVEL> <service>: <message>"
    Returns a dict mapping each level (case-insensitive, upper-case) to its count.
    Skips malformed lines and omits keys with zero count.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip malformed lines
        
        # Check if the second part is a valid level (non-empty)
        level = parts[1].upper()
        if not level:
            continue
        
        counts[level] = counts.get(level, 0) + 1
    
    # Omit keys with zero count (already handled by not adding them)
    return counts
