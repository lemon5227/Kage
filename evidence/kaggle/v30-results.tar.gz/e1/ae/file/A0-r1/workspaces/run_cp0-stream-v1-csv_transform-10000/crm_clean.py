import csv
import io


def normalize_table(text):
    """
    Process CSV text with header row (columns: score, id, email, name).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "name", keeping the first occurrence
    5. Sort rows by "email" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Check if first line is header
    header_line = lines[0]
    # Parse header
    try:
        reader = csv.reader(io.StringIO(header_line))
        header = next(reader)
    except Exception:
        return ''
    
    # Verify header columns: score, id, email, name
    expected_columns = ['score', 'id', 'email', 'name']
    if header != expected_columns:
        return ''
    
    # Parse data rows
    data_rows = []
    for line in lines[1:]:
        try:
            reader = csv.reader(io.StringIO(line))
            row = next(reader)
        except Exception:
            continue
        
        # Strip leading/trailing whitespace from every cell
        row = [cell.strip() for cell in row]
        
        # Skip if row doesn't have enough columns
        if len(row) < 4:
            continue
        
        score, id_val, email, name = row[0], row[1], row[2], row[3]
        
        # Drop rows whose "name" cell is empty
        if not name:
            continue
        
        # Lower-case the "email" column
        email = email.lower()
        
        data_rows.append({
            'score': score,
            'id': id_val,
            'email': email,
            'name': name
        })
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in data_rows:
        if row['name'] not in seen_names:
            seen_names.add(row['name'])
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x['email'])
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(['score', 'id', 'email', 'name'])
    
    for row in unique_rows:
        writer.writerow([row['score'], row['id'], row['email'], row['name']])
    
    return output.getvalue()


if __name__ == '__main__':
    # Test examples
    test1 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,another@example.com,Jane"
    print("Test 1:", normalize_table(test1))
    
    test2 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,test@example.com,Jane"
    print("Test 2:", normalize_table(test2))
    
    test3 = "score,id,email,name"
    print("Test 3:", normalize_table(test3))
    
    test4 = ""
    print("Test 4:", normalize_table(test4))
