from crm_clean import clean_rows

# Test 1: Basic functionality with duplicates
test1 = "team,name,city,id,score\nA,B,C,D,10\nE,F,G,H,10"
result1 = clean_rows(test1)
print("Test 1 (duplicates):")
print(result1)
print()

# Test 2: Header-only input
test2 = "team,name,city,id,score"
result2 = clean_rows(test2)
print("Test 2 (header only):")
print(result2)
print()

# Test 3: Empty input
test3 = ""
result3 = clean_rows(test3)
print("Test 3 (empty):")
print(repr(result3))
print()

# Test 4: Row with empty score
test4 = "team,name,city,id,score\nX,Y,Z,W,\nA,B,C,D,10"
result4 = clean_rows(test4)
print("Test 4 (empty score):")
print(result4)
print()

# Test 5: Whitespace stripping
test5 = " team , name , city , id , score \n A , B , C , D , 10 "
result5 = clean_rows(test5)
print("Test 5 (whitespace):")
print(result5)
