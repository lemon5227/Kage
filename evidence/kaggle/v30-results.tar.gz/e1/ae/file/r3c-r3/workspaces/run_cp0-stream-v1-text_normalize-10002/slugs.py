def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Expected string, got %s" % type(text).__name__)
    
    # Apply NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize('NFKD', text)
    ascii_only = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    prev_char = None
    for char in lower:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is not None:
                slug.append('-')
            prev_char = None
        else:
            slug.append(char)
            prev_char = char
    
    result = ''.join(slug)
    
    # Strip leading and trailing "-"
    return result.strip('-')
