def aggregate_log(lines):
    """Aggregate log strings into {name: count} per service for ERROR/WARN levels.
    
    Log format: "<timestamp> <LEVEL> <service>: <message>"
    - Only counts lines with ERROR or WARN (case-insensitive)
    - Drops malformed lines
    - Returns dict of service name -> count
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service:, message
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        # Service is after the level, followed by colon
        if len(parts) < 4 or parts[2].endswith(":"):
            service = parts[2][:-1]
        else:
            service = parts[2]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
