def summarize(lines):
    """Count WARN lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each service for levels WARN only to how many lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines.
    Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        parts = line.split(None, 3)  # split into at most 4 parts
        if len(parts) < 4:
            continue  # malformed line
        _, level, service, message = parts
        if level.upper() != "WARN":
            continue
        if not service:
            continue  # malformed line
        counts[service] = counts.get(service, 0) + 1
    return counts
