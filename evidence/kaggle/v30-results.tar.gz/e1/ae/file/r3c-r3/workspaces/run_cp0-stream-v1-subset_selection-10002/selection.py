def select_tasks(items, capacity):
    """Pick which jobs to take from a list of tasks.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Return the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without modifying the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("size must be positive")
        entries.append((item["id"], size, score))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_score, sorted_id_list) achievable with total_size <= c.
    best = [(0, []) for _ in range(capacity + 1)]

    for item_id, size, score in entries:
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = best[c - size]
            cand_score = prev_score + score
            cand_ids = sorted(prev_ids + [item_id])
            if cand_score > best[c][0]:
                best[c] = (cand_score, cand_ids)

    max_score, selected_ids = best[capacity]
    return selected_ids
