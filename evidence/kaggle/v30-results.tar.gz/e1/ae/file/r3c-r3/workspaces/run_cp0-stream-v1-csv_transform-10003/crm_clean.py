import csv
import io


def tidy_csv(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: name, city, score, team).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "name" cell is empty.
    3. Remove duplicate rows by "name", keeping the first occurrence.
    4. Sort rows by "city" ascending as strings (stable).

    Returns empty string for empty input; returns just the header line
    for a header-only input.
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header and data rows
    header = rows[0]
    data_rows = rows[1:]

    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)

    # Drop rows whose "name" cell is empty
    name_idx = header.index("name")
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) > name_idx and row[name_idx] == "":
            continue
        filtered_rows.append(row)

    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    deduped_rows = []
    for row in filtered_rows:
        name = row[name_idx] if len(row) > name_idx else ""
        if name in seen_names:
            continue
        seen_names.add(name)
        deduped_rows.append(row)

    # Sort rows by "city" ascending as strings (stable)
    city_idx = header.index("city")
    deduped_rows.sort(key=lambda row: row[city_idx] if len(row) > city_idx else "")

    # Write output with '\n' line endings using csv.writer
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
