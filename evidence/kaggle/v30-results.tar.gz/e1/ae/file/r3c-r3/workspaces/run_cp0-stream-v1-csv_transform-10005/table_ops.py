import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: id, email, city, name).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "id" cell is empty.
    3. Lower-case the "email" column.
    4. Remove duplicate rows by "email", keeping the first occurrence.
    5. Sort rows by "email" ascending as strings (stable).

    Returns:
        Cleaned CSV text with '\n' line endings.
        Empty string if input is empty or only header.
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header and data rows
    header = rows[0]
    data_rows = rows[1:]

    # Check if we have the expected columns
    expected_cols = ['id', 'email', 'city', 'name']
    if len(header) != len(expected_cols):
        # If header doesn't match, try to find the columns anyway
        # We'll use the first row as header and process accordingly
        pass

    # Process each data row
    processed_rows = []
    seen_emails = set()

    for row in data_rows:
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]

        # Check if "id" cell is empty (drop such rows)
        id_idx = header.index('id') if 'id' in header else 0
        if id_idx < len(cleaned_row) and cleaned_row[id_idx] == '':
            continue

        # Lower-case the "email" column
        email_idx = header.index('email') if 'email' in header else 1
        if email_idx < len(cleaned_row):
            cleaned_row[email_idx] = cleaned_row[email_idx].lower()

        # Remove duplicate rows by "email", keeping first occurrence
        email = cleaned_row[email_idx] if email_idx < len(cleaned_row) else ''
        if email in seen_emails:
            continue
        seen_emails.add(email)

        processed_rows.append(cleaned_row)

    # Sort rows by "email" ascending as strings (stable)
    email_idx = header.index('email') if 'email' in header else 1
    processed_rows.sort(key=lambda row: row[email_idx] if email_idx < len(row) else '')

    # Write output with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(processed_rows)

    return output.getvalue()
