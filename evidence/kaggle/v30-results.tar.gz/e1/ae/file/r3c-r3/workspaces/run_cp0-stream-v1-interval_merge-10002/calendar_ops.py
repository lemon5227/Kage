def coalesce(intervals):
    """Merge overlapping or touching intervals.
    
    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Raises ValueError if any interval has
    start > end. The input is not modified.
    """
    # Validate and extract intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                "invalid interval: start ({}) > end ({})".format(start, end)
            )
        normalized.append((start, end))
    
    # Sort by start, then by end
    normalized.sort(key=lambda pair: (pair[0], pair[1]))
    
    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1] + 1:
            # Touching or overlapping - merge them
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    
    # Convert back to dicts with "start" and "end" keys
    return [{"start": start, "end": end} for start, end in merged]
