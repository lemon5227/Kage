def allocate(items, capacity):
    """Select a subset of items whose total size is at most capacity and
    total score is maximized.  Ties are broken by the lexicographically
    smallest sorted list of ids.

    Each item is a dict with keys "id" (unique string), "size" (positive
    int), and "score" (non-negative int).  Returns the sorted list of ids
    of the chosen items.  Raises ValueError if capacity is negative or any
    size is <= 0.  The input is not modified."""
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by (score descending, id ascending) so that the best candidates
    # are considered first and lexicographic tie-breaking is handled
    # naturally by the stable sort order.
    entries.sort(key=lambda e: (-e[2], e[0]))

    # Greedy selection in order of decreasing score (and increasing id).
    chosen = []
    total_size = 0
    for item_id, size, score in entries:
        if total_size + size <= capacity:
            chosen.append(item_id)
            total_size += size

    return sorted(chosen)
