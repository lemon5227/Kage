def count_entries(lines):
    """Count occurrences of log levels in lines.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level (upper-case) to its count.
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service: ...
        if len(parts) < 3:
            continue
        level = parts[1]
        # Validate that the level part looks like a log level (alphanumeric)
        if not level.isalnum():
            continue
        counts[level.upper()] = counts.get(level.upper(), 0) + 1
    return {k: v for k, v in counts.items() if v > 0}
