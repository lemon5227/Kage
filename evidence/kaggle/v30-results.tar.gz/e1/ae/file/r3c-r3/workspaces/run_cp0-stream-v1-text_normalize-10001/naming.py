def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Expected string, got {}".format(type(text).__name__))
    
    # Apply NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize('NFKD', text)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    last_char_was_alnum = False
    for char in lower:
        if char.isalnum():
            last_char_was_alnum = True
            result.append(char)
        else:
            if last_char_was_alnum:
                result.append('_')
                last_char_was_alnum = False
    
    slug = ''.join(result)
    
    # Strip leading and trailing "_"
    return slug.strip('_')
