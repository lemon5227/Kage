def digest_lines(lines):
    """Count log lines by level.
    
    Each line is expected to be formatted as:
        <timestamp> <LEVEL> <service>: <message>
    
    Returns a dict mapping upper-case level names to their counts,
    dropping any malformed lines.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least 4 parts: timestamp, level, service:, message
        if len(parts) < 4:
            continue
        level = parts[1]
        # Verify that parts[2] contains ':' to ensure it's in the correct format
        if ':' not in parts[2]:
            continue
        # Count by level (case-insensitive, store as upper-case)
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
