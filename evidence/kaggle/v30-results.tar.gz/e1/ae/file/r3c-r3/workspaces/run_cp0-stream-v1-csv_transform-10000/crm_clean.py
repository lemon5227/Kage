import csv
import io


def normalize_table(text):
    """Clean CSV text with header row (columns: score, id, email, name).

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Lower-case the "email" column.
    - Remove duplicate rows by "name", keeping the first occurrence.
    - Sort rows by "email" ascending as strings (stable).

    Returns cleaned CSV text with the same header.
    An empty string returns ''; a header-only input returns just the header line.
    Output uses '\n' line endings via csv module.
    """
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header
    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Strip whitespace from every cell in all rows
    cleaned = []
    for row in data:
        stripped = [cell.strip() for cell in row]
        cleaned.append(stripped)

    # Drop rows whose "name" cell is empty
    name_idx = header.index("name")
    cleaned = [row for row in cleaned if row[name_idx] != ""]

    # Lower-case the "email" column
    email_idx = header.index("email")
    for row in cleaned:
        row[email_idx] = row[email_idx].lower()

    # Remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        name = row[name_idx]
        if name in seen:
            continue
        seen.add(name)
        deduped.append(row)

    # Sort rows by "email" ascending as strings (stable)
    deduped.sort(key=lambda row: row[email_idx])

    # Write output with '\n' line endings via csv module
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)
    return out.getvalue()
