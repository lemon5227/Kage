import csv
import io


def clean_rows(text):
    """Clean an exported table from CSV text.

    Input is CSV text with a header row (columns: id, team, score).
    Returns cleaned CSV text with the same header.

    Steps:
      1. Strip leading/trailing whitespace from every cell.
      2. Drop rows whose "score" cell is empty.
      3. Remove duplicate rows by "team", keeping the first occurrence.
      4. Sort rows by "score" ascending as strings (stable).

    Output is written with '\n' line endings.
    An empty string returns ''.
    A header-only input returns just the header line.
    """
    if not text:
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Strip whitespace from all cells in data rows
    cleaned = []
    for row in data:
        stripped = [cell.strip() for cell in row]
        cleaned.append(stripped)

    # Drop rows whose "score" cell is empty
    score_idx = header.index("score")
    cleaned = [row for row in cleaned if row[score_idx] != ""]

    # Remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        team = row[header.index("team")]
        if team in seen:
            continue
        seen.add(team)
        deduped.append(row)

    # Sort rows by "score" ascending as strings (stable)
    score_idx = header.index("score")
    deduped.sort(key=lambda row: row[score_idx])

    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
