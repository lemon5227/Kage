import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: name, team, city, id, score).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "name" cell is empty.
    3. Remove duplicate rows by "score", keeping the first occurrence.
    4. Sort rows by "id" ascending as strings (stable).

    Returns:
        Cleaned CSV text with '\n' line endings.
        Empty string if input is empty or only header.
        Header-only input returns just the header line.
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header and data rows
    header = rows[0]
    data_rows = rows[1:]

    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)

    # Drop rows whose "name" cell is empty
    name_index = header.index("name")
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) <= name_index:
            continue  # Skip rows with insufficient columns
        if row[name_index] == "":
            continue  # Skip rows with empty name
        filtered_rows.append(row)

    # Remove duplicate rows by "score", keeping the first occurrence
    score_index = header.index("score")
    seen_scores = set()
    deduped_rows = []
    for row in filtered_rows:
        if len(row) <= score_index:
            continue  # Skip rows with insufficient columns
        score = row[score_index]
        if score in seen_scores:
            continue  # Skip duplicate
        seen_scores.add(score)
        deduped_rows.append(row)

    # Sort rows by "id" ascending as strings (stable)
    id_index = header.index("id")
    deduped_rows.sort(key=lambda row: row[id_index])

    # Write output with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()


if __name__ == "__main__":
    # Example usage
    sample_csv = """name,team,city,id,score
Alice,TeamA,NewYork,1,100
Bob,TeamB,LosAngeles,2,100
Charlie,TeamC,Chicago,3,200
"""
    result = normalize_table(sample_csv)
    print(result)
