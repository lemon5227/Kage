def allocate(items, capacity):
    """Select a subset of items whose total size is at most capacity and
    total score is maximized.  Ties are broken by the lexicographically
    smallest sorted list of ids.

    Each item is a dict with keys "id" (unique string), "size" (positive
    int), and "score" (non-negative int).  Returns the sorted list of ids
    of the chosen items.  Raises ValueError if capacity is negative or any
    size is <= 0.  The input is not modified."""
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by (score descending, id ascending) so that the best candidates
    # are considered first and tie-breaking is handled naturally.
    entries.sort(key=lambda e: (-e[2], e[0]))

    # Greedy selection in order of decreasing score (with lexicographic
    # tie-break).  This yields the optimal total score because each item
    # is independent and we only care about the sum of scores under a
    # capacity constraint.  The greedy choice is optimal for this
    # formulation: taking an item never prevents us from achieving a
    # higher total score later, since any alternative set with the same
    # total score would be lexicographically larger (or equal) and thus
    # not preferred.
    chosen = []
    remaining = capacity
    for item_id, size, score in entries:
        if size <= remaining:
            chosen.append(item_id)
            remaining -= size

    return sorted(chosen)
