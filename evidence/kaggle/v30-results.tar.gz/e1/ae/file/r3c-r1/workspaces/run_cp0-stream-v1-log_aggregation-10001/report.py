def tally_events(lines):
    """Tally log events by service for ERROR and WARN levels only.
    
    Each line is formatted as: "<timestamp> <LEVEL> <service>: <message>"
    Returns a dict mapping service name (upper-case) to count.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # split into timestamp, level, service:, message
        if len(parts) < 3:
            continue
        _, level, service_part = parts[0], parts[1], parts[2]
        # Validate level is ERROR or WARN (case-insensitive)
        if level.upper() not in ("ERROR", "WARN"):
            continue
        # Extract service name from "service: message" format
        if not service_part.endswith(":"):
            continue
        service_name = service_part[:-1]
        if not service_name:
            continue
        counts[service_name.upper()] = counts.get(service_name.upper(), 0) + 1
    return counts
