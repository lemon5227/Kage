import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: id, email, city, name).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "id" cell is empty.
    3. Lower-case the "email" column.
    4. Remove duplicate rows by "email", keeping the first occurrence.
    5. Sort rows by "email" ascending as strings (stable).

    Returns:
        Cleaned CSV text with '\n' line endings.
        Empty string if input is empty or only header.
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header and data rows
    header = rows[0]
    data_rows = rows[1:]

    # Check if we have the expected columns
    expected_cols = ['id', 'email', 'city', 'name']
    if len(header) != len(expected_cols):
        # If header doesn't match, try to find the email column
        email_idx = None
        for i, col in enumerate(header):
            if col.lower() == 'email':
                email_idx = i
                break
        if email_idx is None:
            return ""
    else:
        email_idx = 1

    # Process rows
    processed_rows = []
    seen_emails = set()

    for row in data_rows:
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]

        # Check if "id" cell is empty (drop such rows)
        id_idx = 0 if len(expected_cols) == 4 else None
        if id_idx is not None and cleaned_row[id_idx] == "":
            continue

        # Lower-case the "email" column
        email_val = cleaned_row[email_idx].lower() if email_idx is not None else ""

        # Remove duplicate rows by "email", keeping first occurrence
        if email_val in seen_emails:
            continue
        seen_emails.add(email_val)

        # Add the processed row with lowercased email
        processed_rows.append((email_val, cleaned_row))

    # Sort rows by "email" ascending as strings (stable)
    processed_rows.sort(key=lambda x: x[0])

    # Reconstruct CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    if header:
        writer.writerow(header)
    for email_val, row in processed_rows:
        writer.writerow(row)

    return output.getvalue()
