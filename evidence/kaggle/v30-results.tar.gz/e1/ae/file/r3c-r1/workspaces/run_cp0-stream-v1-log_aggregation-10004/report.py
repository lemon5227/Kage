import re

_LINE_PATTERN = re.compile(r'^\S+\s+(\S+)\s+\S+:\s')

def digest_lines(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Lines that do not match the format are ignored.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        match = _LINE_PATTERN.match(line.strip())
        if not match:
            continue
        level = match.group(1).upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
