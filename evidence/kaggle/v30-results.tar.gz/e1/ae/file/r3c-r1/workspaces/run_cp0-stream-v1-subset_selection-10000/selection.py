def select_tasks(items, capacity):
    """Select parcels under a capacity limit to maximize total gain.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")

    # Handle empty items list
    if not items:
        return []

    # Create a list of (id, cost, gain) tuples
    parcels = [(item["id"], item["cost"], item["gain"]) for item in items]

    # Sort by id to ensure deterministic ordering for tie-breaking
    parcels.sort(key=lambda x: x[0])

    # Use dynamic programming for the 0/1 knapsack problem
    # dp[c] = (max_gain, selected_ids) for capacity c
    # We track the selected items to handle tie-breaking on lexicographic order
    
    # Initialize dp array where dp[c] = (gain, tuple of ids)
    dp = [(0, ()) for _ in range(capacity + 1)]

    for cost, gain, item_id in parcels:
        # Iterate backwards to avoid using the same item multiple times
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            new_gain = prev_gain + gain
            new_ids = prev_ids + (item_id,)
            
            # Compare with current dp[c] - prefer higher gain, then lexicographically smaller ids
            if new_gain > dp[c][0]:
                dp[c] = (new_gain, new_ids)
            elif new_gain == dp[c][0]:
                # Tie on gain: choose lexicographically smaller sorted id list
                if sorted(new_ids) < sorted(dp[c][1]):
                    dp[c] = (new_gain, new_ids)

    # The answer is the best result across all capacities <= capacity
    max_gain = 0
    best_ids = ()
    
    for c in range(capacity + 1):
        gain, ids = dp[c]
        if gain > max_gain:
            max_gain = gain
            best_ids = ids
        elif gain == max_gain:
            if sorted(ids) < sorted(best_ids):
                best_ids = ids

    return sorted(best_ids)
