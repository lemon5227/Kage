def aggregate_log(lines):
    """Aggregate log strings into {name: count} for ERROR and WARN levels only.
    
    Each line is formatted as "<timestamp> <LEVEL> <service>: <message>".
    Only counts lines with ERROR or WARN (case-insensitive).
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # split into at most 4 parts
        if len(parts) < 3:
            continue
        # parts[0] = timestamp, parts[1] = level, parts[2] = service: ...
        level = parts[1].upper()
        service = parts[2] if len(parts) > 2 else ""
        if service.startswith(":"):
            service = service[1:]
        if not service:
            continue
        if level not in ("ERROR", "WARN"):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
