import unicodedata


def label_id(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters; non-ASCII are dropped.
    normalized = unicodedata.normalize("NFKD", text)
    # Keep only ASCII characters (a-z, 0-9).
    ascii_only = "".join(c for c in normalized if c.isascii())
    # Lower-case.
    ascii_only = ascii_only.lower()
    # Replace every run of non-alphanumeric characters with a single "-".
    runs = []
    current_run = []
    for c in ascii_only:
        if c.isalnum():
            current_run.append(c)
        else:
            if current_run:
                runs.append("".join(current_run))
                current_run = []
            runs.append("-")
    if current_run:
        runs.append("".join(current_run))

    slug = "".join(runs)
    # Strip leading and trailing "-".
    while slug.startswith("-"):
        slug = slug[1:]
    while slug.endswith("-"):
        slug = slug[:-1]
    return slug
