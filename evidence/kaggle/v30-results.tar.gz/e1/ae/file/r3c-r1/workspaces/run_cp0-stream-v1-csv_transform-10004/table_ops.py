import csv
import io


def clean_rows(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: id, team, score).
    Output: Cleaned CSV text with the same header.

    Rules:
      - Strip leading/trailing whitespace from every cell.
      - Drop rows whose "score" cell is empty.
      - Remove duplicate rows by "team", keeping the first occurrence.
      - Sort rows by "score" ascending as strings (stable).
    """
    # Parse CSV into a list of dicts
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Strip whitespace from every cell in every row
    cleaned = []
    for row in data:
        cleaned_row = [cell.strip() for cell in row]
        cleaned.append(cleaned_row)

    # Drop rows whose "score" cell is empty
    score_idx = header.index("score")
    filtered = []
    for row in cleaned:
        if len(row) <= score_idx:
            continue
        if row[score_idx] == "":
            continue
        filtered.append(row)

    # Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    deduped = []
    for row in filtered:
        team = row[header.index("team")]
        if team in seen_teams:
            continue
        seen_teams.add(team)
        deduped.append(row)

    # Sort rows by "score" ascending as strings (stable)
    score_idx = header.index("score")
    deduped.sort(key=lambda row: row[score_idx])

    # Write output with '\n' line endings using csv.writer
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)
    return out.getvalue()
