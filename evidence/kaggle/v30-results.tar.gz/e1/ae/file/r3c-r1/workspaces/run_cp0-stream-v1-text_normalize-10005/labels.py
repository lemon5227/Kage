import unicodedata


def to_key(text):
    """Normalize labels into identifiers.

    Apply NFKD normalization, drop non-ASCII characters, lower-case,
    replace every run of characters outside [a-z0-9] with a single "_",
    and strip leading and trailing "_".
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_is_alnum = False
    for ch in lower:
        if ch.isalnum():
            if not prev_is_alnum:
                result.append(ch)
            prev_is_alnum = True
        else:
            if result and not prev_is_alnum:
                result.append("_")
            result.append(ch)
            prev_is_alnum = False

    # Strip leading and trailing "_"
    while result and result[-1] == "_":
        result.pop()
    while result and result[0] == "_":
        result.pop(0)

    return "".join(result) if result else ""
