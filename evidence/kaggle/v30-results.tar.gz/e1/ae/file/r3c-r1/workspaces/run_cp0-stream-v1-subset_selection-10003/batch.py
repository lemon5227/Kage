def pick_jobs(items, capacity):
    """Choose parcels to maximize total score within capacity."""
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    # Validate items and collect data
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("size must be positive")
        entries.append((item["id"], size, score))
    
    # Sort by score descending, then by id ascending for tie-breaking
    entries.sort(key=lambda e: (-e[2], e[0]))
    
    # Greedy selection by score (since all items can be taken independently)
    selected = []
    total_size = 0
    for item_id, size, score in entries:
        if total_size + size <= capacity:
            selected.append(item_id)
            total_size += size
    
    return sorted(selected)
