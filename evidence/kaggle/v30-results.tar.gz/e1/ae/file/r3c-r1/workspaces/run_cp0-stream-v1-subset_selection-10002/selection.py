def select_tasks(items, capacity):
    """Pick a subset of items whose total size <= capacity and total score is maximized.
    
    Items are dicts with keys: "id" (unique string), "size" (positive int), "score" (non-negative int).
    Returns the sorted list of ids of the selected items.
    If multiple selections tie on total score, return the lexicographically smallest sorted id list.
    An empty selection is allowed.
    
    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        if "size" not in item or "score" not in item or "id" not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if not isinstance(item["size"], int) or item["size"] <= 0:
            raise ValueError("size must be a positive integer")
        if not isinstance(item["score"], int) or item["score"] < 0:
            raise ValueError("score must be a non-negative integer")
    
    # 0/1 knapsack DP: dp[w] = (max_score, selected_ids) for capacity w
    # We track the selection to handle lexicographic tie-breaking.
    # Initialize dp[0] = (0, []) and dp[w] = (-inf, None) for w > 0.
    NEG_INF = float('-inf')
    dp = [NEG_INF] * (capacity + 1)
    parent = [None] * (capacity + 1)  # parent[w] = (prev_w, item_id) or None
    
    for item in items:
        idx = id(item)  # use object identity to ensure uniqueness for each iteration
        item_id = item["id"]
        size = item["size"]
        score = item["score"]
        
        # Iterate w from capacity down to size
        for w in range(capacity, size - 1, -1):
            if dp[w - size] + score > dp[w]:
                dp[w] = dp[w - size] + score
                parent[w] = (w - size, item_id)
    
    # Reconstruct the selection from the DP table
    selected_ids = []
    w = capacity
    while w is not None and parent[w] is not None:
        prev_w, item_id = parent[w]
        selected_ids.append(item_id)
        w = prev_w
    
    # Sort the selected ids lexicographically
    selected_ids.sort()
    
    return selected_ids
