def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Return the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity.  If several selections tie on total value, return
    the lexicographically smallest sorted id list.  An empty selection is
    allowed.  Raise ValueError if capacity is negative or any weight is <= 0.
    Do not modify the input.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant fields without mutating the input dicts.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # Sort by value descending, then by weight ascending for tie-breaking.
    entries.sort(key=lambda e: (e[2], -e[1]))

    # Greedy selection by value density.
    selected = []
    remaining = capacity
    for item_id, weight, value in entries:
        if weight <= remaining:
            selected.append(item_id)
            remaining -= weight

    return sorted(selected)
