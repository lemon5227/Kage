def coalesce(intervals):
    """Combine overlapping or touching time ranges.
    
    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals sorted by start ascending.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate and copy intervals without modifying input
    validated = []
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
        validated.append(interval)
    
    # Sort by start time
    sorted_intervals = sorted(validated, key=lambda x: x[0])
    
    # Merge overlapping or touching intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append(interval)
        else:
            last_start, last_end = merged[-1]
            if start <= last_end + 1:  # Overlapping or touching (start == last_end + 1 means touching)
                # Merge by extending the end if needed
                merged[-1] = [last_start, max(last_end, end)]
            else:
                merged.append(interval)
    
    return merged
