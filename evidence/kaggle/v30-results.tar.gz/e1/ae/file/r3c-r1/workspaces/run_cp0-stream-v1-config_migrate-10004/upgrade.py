def migrate(cfg):
    """Migrate a v1 config dict to v2."""
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1")
    
    # Make a copy to avoid modifying the input
    new_cfg = {}
    new_cfg["version"] = 2
    
    # Track which keys we've processed
    processed = set()
    
    # Handle special key renames and transformations
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
        processed.add("pwd_file")
    
    if "user" in cfg:
        new_cfg["username"] = cfg["user"]
        processed.add("user")
    
    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
        processed.add("cache_size")
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
        processed.add("workers")
    
    # Add network sub-dict (always present, possibly empty)
    new_cfg["network"] = network
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
        processed.add("timeout_ms")
    
    # Keep other keys unchanged, but drop keys with None value
    for key in cfg:
        if key not in processed and cfg[key] is not None:
            new_cfg[key] = cfg[key]
    
    return new_cfg
