import csv
import io


def clean_rows(text):
    """Clean CSV text with header row (columns: team, name, city, id, score).

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "score" cell is empty.
    - Remove duplicate rows by "score", keeping the first occurrence.
    - Sort rows by "name" ascending as strings (stable).
    Returns cleaned CSV text with the same header.
    An empty string returns ''; a header-only input returns just the header line.
    """
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ""

    # Ensure we have the expected columns
    expected_cols = ["team", "name", "city", "id", "score"]
    if len(header) != len(expected_cols):
        # If header doesn't match, just process what we have
        pass
    else:
        # Verify column names match exactly (case-sensitive)
        for col in expected_cols:
            if col not in header:
                # If a required column is missing, skip processing
                pass

    rows = list(reader)

    # Strip whitespace from every cell in every row
    cleaned_rows = []
    for row in rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)

    # Drop rows whose "score" cell is empty
    score_idx = expected_cols.index("score") if "score" in expected_cols else -1
    if score_idx >= 0:
        cleaned_rows = [row for row in cleaned_rows if row[score_idx] != ""]

    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in cleaned_rows:
        if score_idx >= 0:
            score = row[score_idx]
        else:
            score = None
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped_rows.append(row)

    # Sort rows by "name" ascending as strings (stable)
    name_idx = expected_cols.index("name") if "name" in expected_cols else -1
    if name_idx >= 0:
        deduped_rows.sort(key=lambda row: row[name_idx])
    else:
        # If no name column, sort by first column as fallback
        deduped_rows.sort(key=lambda row: row[0] if row else "")

    # Write output with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    if header:
        writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
