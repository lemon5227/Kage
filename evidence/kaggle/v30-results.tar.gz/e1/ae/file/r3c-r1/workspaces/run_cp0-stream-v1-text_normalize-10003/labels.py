def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("Expected string, got {}".format(type(text).__name__))
    
    # Apply NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize('NFKD', text)
    ascii_only = ''.join(c for c in normalized if ord(c) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for char in lower:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is not None:
                result.append('-')
            prev_char = None
        else:
            result.append(char)
            prev_char = char
    
    # Strip leading and trailing "-"
    handle = ''.join(result).strip('-')
    
    return handle
