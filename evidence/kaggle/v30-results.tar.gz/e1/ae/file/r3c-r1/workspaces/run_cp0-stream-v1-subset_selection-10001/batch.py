def allocate(items, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    # Validate and copy items without modifying input
    validated_items = []
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        gain = item["gain"]
        validated_items.append(item)
    
    # Sort by gain descending, then by id ascending for tie-breaking
    sorted_items = sorted(validated_items, key=lambda x: (-x["gain"], x["id"]))
    
    # Greedy selection: iterate through sorted items and add if capacity allows
    selected_ids = []
    total_cost = 0
    
    for item in sorted_items:
        if total_cost + item["cost"] <= capacity:
            selected_ids.append(item["id"])
            total_cost += item["cost"]
    
    return selected_ids
