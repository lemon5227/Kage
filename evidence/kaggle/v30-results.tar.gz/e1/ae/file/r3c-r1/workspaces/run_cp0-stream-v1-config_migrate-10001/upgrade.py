def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Raise ValueError unless version is 1
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")
    
    # Create a new dict without modifying the input
    result = {"version": 2}
    
    # Rename top-level keys
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    
    # Move "port" and "retries" into a sub-dict "storage"
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "retries" in cfg:
        storage["retries"] = cfg["retries"]
    result["storage"] = storage
    
    # Handle "timeout_ms" - convert to "timeout_s" if exists
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged and drop keys whose value is None
    for key, value in cfg.items():
        if key not in ["host", "max_conn", "pwd_file", "port", "retries", "timeout_ms"]:
            if value is not None:
                result[key] = value
    
    return result
