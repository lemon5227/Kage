def digest_lines(lines):
    """Process log lines in format "<timestamp> <LEVEL> <service>: <message>".
    
    Returns a dict mapping level name (uppercase) to count of occurrences.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, LEVEL, service:, message
        if len(parts) < 3:
            continue
        level = parts[1]
        # Validate that the third part starts with "service:"
        if len(parts) < 3 or not parts[2].startswith("service:"):
            continue
        # Count this line for the given level
        counts[level.upper()] = counts.get(level.upper(), 0) + 1
    return counts
