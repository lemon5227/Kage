import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: name, team, city, id, score).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "name" cell is empty.
    3. Remove duplicate rows by "score", keeping the first occurrence.
    4. Sort rows by "id" ascending as strings (stable).

    Returns empty string for empty input; returns just the header line
    for a header-only input.
    """
    # Parse CSV text into a list of rows (each row is a list of cells)
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # The first row is the header
    header = rows[0]
    # Ensure we have the expected columns
    expected_cols = ["name", "team", "city", "id", "score"]
    if len(header) != len(expected_cols):
        # If header doesn't match, just use what we have
        pass

    data_rows = rows[1:]

    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)

    # Step 2: Drop rows whose "name" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) > 0 and row[0] == "":
            continue
        filtered_rows.append(row)

    # Step 3: Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in filtered_rows:
        if len(row) < 5:
            continue
        score = row[4]
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped_rows.append(row)

    # Step 4: Sort rows by "id" ascending as strings (stable)
    # The id is at index 3
    def sort_key(row):
        return row[3] if len(row) > 3 else ""

    deduped_rows.sort(key=sort_key, stable=True)

    # Write output with '\n' line endings using csv.writer
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
