def tidy_csv(text):
    """Clean an exported CSV table with columns: name, city, score, team."""
    if text == "":
        return ""
    
    lines = text.splitlines()
    if not lines:
        return ""
    
    # Parse header
    header = [cell.strip() for cell in lines[0].split(",")]
    if len(header) != 4:
        return ""
    
    # Validate column names
    expected = ["name", "city", "score", "team"]
    if header != expected:
        return ""
    
    # Process data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = [cell.strip() for cell in line.split(",")]
        if len(cells) != 4:
            continue
        name, city, score, team = cells
        if name == "":
            continue
        rows.append((name, city, score, team))
    
    # Remove duplicates by name, keeping first occurrence
    seen = set()
    unique_rows = []
    for row in rows:
        if row[0] in seen:
            continue
        seen.add(row[0])
        unique_rows.append(row)
    
    # Sort by city ascending (stable sort)
    unique_rows.sort(key=lambda r: r[1])
    
    # Build output CSV
    output_lines = [",".join(header)]
    for row in unique_rows:
        output_lines.append(",".join(str(cell) for cell in row))
    
    return "\n".join(output_lines)
