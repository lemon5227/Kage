import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize('NFKD', text)
    ascii_only = ''.join(c for c in normalized if ord(c) < 128)

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_is_alnum = False
    for c in ascii_only:
        if c.isalnum():
            prev_is_alnum = True
            result.append(c)
        else:
            if not prev_is_alnum:
                result.append('-')
                prev_is_alnum = False

    handle = ''.join(result)

    # strip leading and trailing "-"
    handle = handle.strip('-')

    # if longer than 23 characters, cut to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        if handle.endswith('-'):
            handle = handle[:-1]

    return handle
