def merge_slots(intervals):
    """Merge overlapping intervals. Each interval is a dict {"from": s, "to": e}.
    
    Touching intervals like [1,3] and [3,5] are merged. Raises ValueError if
    any interval has start > end. Returns merged intervals sorted by start.
    The input is not modified.
    """
    # Validate and convert intervals to a list of (start, end) tuples
    normalized = []
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(
                "invalid interval: start ({}) > end ({})".format(start, end)
            )
        normalized.append((start, end))
    
    # Sort by start time
    normalized.sort(key=lambda pair: pair[0])
    
    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1] + 1:
            # Touching or overlapping - extend the end if needed
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    
    # Convert back to dict format
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})
    
    return result
