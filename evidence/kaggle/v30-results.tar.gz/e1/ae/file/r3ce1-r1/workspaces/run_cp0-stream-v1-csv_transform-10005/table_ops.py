import csv
import io


def normalize_table(text):
    """Clean an exported table.

    Input is CSV text with a header row (columns: id, email, city, name).
    Returns cleaned CSV text with the same header.

    Processing steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "id" cell is empty.
    3. Lower-case the "email" column.
    4. Remove duplicate rows by "email", keeping the first occurrence.
    5. Sort rows by "email" ascending as strings (stable).

    Edge cases:
    - Empty string returns ''.
    - Header-only input returns just the header line.
    """
    if text == "":
        return ""

    # Parse CSV into a list of lists
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header
    header = [cell.strip() for cell in rows[0]]
    # Ensure we have the expected columns
    expected_cols = ["id", "email", "city", "name"]
    if len(header) != len(expected_cols):
        # If header doesn't match, just use what we have
        pass

    # Process data rows (skip header)
    data_rows = rows[1:]

    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)

    # Step 2: Drop rows whose "id" cell is empty
    # Find the index of "id" column
    id_idx = header.index("id") if "id" in header else None
    if id_idx is not None:
        cleaned_rows = [row for row in cleaned_rows if row[id_idx] != "" and row[id_idx] is not None]

    # Step 3: Lower-case the "email" column
    email_idx = header.index("email") if "email" in header else None
    if email_idx is not None:
        for row in cleaned_rows:
            if len(row) > email_idx:
                row[email_idx] = row[email_idx].lower()

    # Step 4: Remove duplicate rows by "email", keeping the first occurrence
    seen_emails = set()
    deduped_rows = []
    for row in cleaned_rows:
        if email_idx is not None and len(row) > email_idx:
            email = row[email_idx]
            if email in seen_emails:
                continue
            seen_emails.add(email)
            deduped_rows.append(row)

    # Step 5: Sort rows by "email" ascending as strings (stable)
    if email_idx is not None and len(deduped_rows) > 0:
        deduped_rows.sort(key=lambda row: row[email_idx] if len(row) > email_idx else "")

    # Reconstruct CSV output with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
