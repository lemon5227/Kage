import csv
import io


def clean_rows(text):
    """Clean an exported table CSV text.

    Input: CSV text with header row (columns: id, team, score).
    Output: Cleaned CSV text with same header.

    Cleaning steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "score" cell is empty.
    3. Remove duplicate rows by "team", keeping first occurrence.
    4. Sort rows by "score" ascending as strings (stable).

    Returns empty string for empty input; header-only input returns just the header line.
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header and data rows
    header = rows[0]
    data_rows = rows[1:]

    # Strip whitespace from every cell in every row
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)

    # Drop rows whose "score" cell is empty
    score_index = header.index("score")
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) <= score_index:
            continue  # Skip rows without a score column
        score = row[score_index]
        if score == "":
            continue  # Drop rows with empty score
        filtered_rows.append(row)

    # Remove duplicate rows by "team", keeping first occurrence
    team_seen = set()
    deduped_rows = []
    for row in filtered_rows:
        team = row[header.index("team")]
        if team in team_seen:
            continue  # Skip duplicate
        team_seen.add(team)
        deduped_rows.append(row)

    # Sort rows by "score" ascending as strings (stable)
    score_index = header.index("score")
    deduped_rows.sort(key=lambda row: (row[score_index], row[header.index("team")]))

    # Write output CSV with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
