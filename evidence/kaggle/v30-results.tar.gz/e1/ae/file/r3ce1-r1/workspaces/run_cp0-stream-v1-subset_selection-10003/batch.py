def pick_jobs(items, capacity):
    """Choose parcels to maximize total score within capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer (must be > 0)
      - "score": non-negative integer (>= 0)

    Returns a sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total
    score, return the lexicographically smallest sorted id list. An empty
    selection is allowed.

    Raises ValueError if capacity is negative or any item has size <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # Sort items by score descending, then by id ascending for tie-breaking
    # This ensures we consider higher-scoring items first and handles ties
    sorted_items = sorted(
        items,
        key=lambda item: (-item["score"], item["id"])
    )

    # Greedy selection: pick items in order until capacity is exceeded
    selected = []
    total_size = 0
    total_score = 0

    for item in sorted_items:
        size = item["size"]
        score = item["score"]

        if total_size + size <= capacity:
            selected.append(item["id"])
            total_size += size
            total_score += score

    return sorted(selected)
