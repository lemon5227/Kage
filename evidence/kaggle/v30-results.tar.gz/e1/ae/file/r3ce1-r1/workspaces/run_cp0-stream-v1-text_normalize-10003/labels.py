import re
import unicodedata


def make_handle(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks.
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII).
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case.
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-".
    # This is equivalent to replacing any sequence of non-alphanumeric chars
    # with a single hyphen, then stripping leading/trailing hyphens.
    slug = re.sub(r"[^a-z0-9]+", "-", lower)
    slug = slug.strip("-")

    return slug
