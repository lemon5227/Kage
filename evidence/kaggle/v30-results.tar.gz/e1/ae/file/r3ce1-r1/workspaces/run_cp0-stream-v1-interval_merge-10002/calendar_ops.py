def coalesce(intervals):
    """Merge overlapping or touching intervals.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same keys, sorted by start ascending.
    Raises ValueError if any interval has start > end.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Invalid interval: start ({start}) > end ({end})")
        normalized.append((start, end))

    # Sort by start, then by end for deterministic merging
    normalized.sort(key=lambda x: (x[0], x[1]))

    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching - extend the current interval
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))

    # Convert back to dict format
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})

    return result
