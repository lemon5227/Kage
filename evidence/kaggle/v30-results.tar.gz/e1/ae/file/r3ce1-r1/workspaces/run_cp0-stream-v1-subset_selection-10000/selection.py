def select_tasks(items, capacity):
    """Select parcels under a capacity limit to maximize total gain."""
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    # Validate and normalize items
    normalized = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        normalized.append((item["id"], cost, gain))
    
    # 0/1 knapsack using dynamic programming
    # dp[i][w] = maximum gain using first i items with capacity w
    dp = [[0] * (capacity + 1) for _ in range(len(normalized) + 1)]
    
    for i in range(1, len(normalized) + 1):
        item_id, cost, gain = normalized[i - 1]
        for w in range(capacity + 1):
            # Don't include this item
            dp[i][w] = dp[i - 1][w]
            # Include this item if capacity allows
            if cost <= w:
                dp[i][w] = max(dp[i][w], dp[i - 1][w - cost] + gain)
    
    # Reconstruct the solution
    selected = []
    w = capacity
    for i in range(len(normalized), 0, -1):
        if dp[i][w] != dp[i - 1][w]:
            item_id, cost, gain = normalized[i - 1]
            selected.append(item_id)
            w -= cost
    
    return sorted(selected)
