def allocate(items, capacity):
    """Select jobs under a capacity limit to maximize total gain.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, returns the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")

    n = len(items)
    # dp[c] = (max_gain, selected_ids) for capacity c
    # We'll track the actual selection to reconstruct the result.
    # Initialize with (0, []) for capacity 0.
    dp = [(0, []) for _ in range(capacity + 1)]

    for i in range(n):
        item = items[i]
        cost = item["cost"]
        gain = item["gain"]
        # Iterate capacities from high to low (like knapsack)
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            new_gain = prev_gain + gain
            new_ids = prev_ids + [item["id"]]
            if new_gain > dp[c][0]:
                dp[c] = (new_gain, new_ids)

    # Find the best capacity (max gain) and reconstruct the selection
    max_gain = 0
    best_ids = []
    for c in range(capacity + 1):
        if dp[c][0] > max_gain:
            max_gain = dp[c][0]
            best_ids = dp[c][1]

    # Sort the ids lexicographically (they are already in order of selection,
    # but we need to sort them for the final result)
    return sorted(best_ids)
