import re

def digest_lines(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level is case-insensitive and must be upper-cased.
    Lines that do not match the pattern are ignored.
    Returns a plain dict of counts.
    """
    pattern = re.compile(r'^\S+\s+(\S+)\s+\S+:\s')
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        match = pattern.match(line)
        if not match:
            continue
        level = match.group(1).upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
