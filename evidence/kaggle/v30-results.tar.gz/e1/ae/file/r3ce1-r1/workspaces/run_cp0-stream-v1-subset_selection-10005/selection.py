def allocate(items, capacity):
    """Select items to maximize total score while total size <= capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer
      - "score": non-negative integer

    Returns the sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total
    score, return the lexicographically smallest sorted id list. An empty
    selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # Standard 0/1 knapsack DP over capacity.
    # dp[c] = (max_score, chosen_ids) for capacity c.
    # We track the chosen ids to reconstruct the optimal selection.
    # Initialize with (score=0, ids=[]) for capacity 0.
    best = [None] * (capacity + 1)
    best[0] = (0, [])

    for item in items:
        idx = item["id"]
        size = item["size"]
        score = item["score"]
        # Iterate capacities from high to low to avoid reusing the same item.
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = best[c - size]
            cand_score = prev_score + score
            cand_ids = prev_ids + [idx]
            if (cand_score, cand_ids) > best[c]:
                best[c] = (cand_score, cand_ids)

    # The optimal selection is the one with maximum score at capacity <= capacity.
    max_score = None
    best_ids = None
    for c in range(capacity + 1):
        score, ids = best[c]
        if max_score is None or score > max_score:
            max_score = score
            best_ids = ids
        elif score == max_score and (best_ids is None or ids < best_ids):
            best_ids = ids

    return sorted(best_ids)
