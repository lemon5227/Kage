def merge_slots(intervals):
    """Combine overlapping time ranges.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Touching intervals like [1,3] and [3,5]
    are merged. Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                "Interval has start > end: {}".format(interval)
            )
        normalized.append((start, end))

    # Sort by start time
    normalized.sort(key=lambda pair: pair[0])

    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start <= last_end + 1:
                # Overlapping or touching intervals are merged
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])

    # Convert back to dict format and sort by start
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})

    return result
