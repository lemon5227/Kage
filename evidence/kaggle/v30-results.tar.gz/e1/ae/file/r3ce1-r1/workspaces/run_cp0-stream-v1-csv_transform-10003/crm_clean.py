import csv
import io


def tidy_csv(text):
    """Clean an exported CSV table.

    Input: CSV text with a header row (columns: name, city, score, team).
    Output: Cleaned CSV text with the same header.

    Rules:
    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Remove duplicate rows by "name", keeping the first occurrence.
    - Sort rows by "city" ascending as strings (stable).
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header
    header = [cell.strip() for cell in rows[0]]
    data_rows = rows[1:]

    # Strip whitespace from all cells in data rows
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)

    # Drop rows whose "name" cell is empty
    name_idx = header.index("name")
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) <= name_idx:
            continue  # skip rows missing the name column
        if not row[name_idx]:
            continue  # skip rows with empty name
        filtered_rows.append(row)

    # Remove duplicate rows by "name", keeping first occurrence
    seen_names = set()
    deduped_rows = []
    for row in filtered_rows:
        name = row[name_idx]
        if name in seen_names:
            continue
        seen_names.add(name)
        deduped_rows.append(row)

    # Sort rows by "city" ascending as strings (stable)
    city_idx = header.index("city")
    deduped_rows.sort(key=lambda row: row[city_idx])

    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
