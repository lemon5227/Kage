def merge_slots(intervals):
    """Merge overlapping intervals in a list of [start, end] pairs.
    
    Intervals are merged only if they truly overlap (i.e., one interval's
    start is less than the other's end). Touching intervals like [1,3] and
    [3,5] are NOT merged.
    
    Raises ValueError if any interval has start > end.
    Returns a new list of merged intervals sorted by start.
    """
    # Validate all intervals first
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Invalid interval: {start}, {end}")
    
    # Sort by start time first
    sorted_intervals = sorted(intervals, key=lambda pair: pair[0])
    
    merged = []
    for start, end in sorted_intervals:
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            # Only merge if there is a true overlap (start < last_end)
            if start < last_end:
                # Extend the end if needed
                if end > last_end:
                    merged[-1][1] = end
            else:
                merged.append([start, end])
    
    return merged
