import csv
import io


def clean_rows(text):
    """Clean CSV text with header row (columns: team, name, city, id, score).

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "score" cell is empty.
    - Remove duplicate rows by "score", keeping the first occurrence.
    - Sort rows by "name" ascending as strings (stable).
    Returns cleaned CSV text with the same header.
    Empty string returns ''; header-only input returns just the header line.
    """
    if not text or not text.strip():
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header
    header = [cell.strip() for cell in rows[0]]
    data_rows = rows[1:]

    # Strip whitespace from all cells in all rows
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)

    # Drop rows whose "score" cell is empty
    score_index = header.index("score") if "score" in header else -1
    if score_index >= 0:
        cleaned_rows = [row for row in cleaned_rows if row[score_index] != ""]

    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in cleaned_rows:
        score = row[score_index] if score_index >= 0 else None
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped_rows.append(row)

    # Sort rows by "name" ascending as strings (stable)
    name_index = header.index("name") if "name" in header else -1
    if name_index >= 0:
        deduped_rows.sort(key=lambda row: row[name_index])

    # Reconstruct CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
