def digest_lines(lines):
    """Process log lines in format '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns a dict mapping level name (uppercase) to count of occurrences.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if not level.isalpha():
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
