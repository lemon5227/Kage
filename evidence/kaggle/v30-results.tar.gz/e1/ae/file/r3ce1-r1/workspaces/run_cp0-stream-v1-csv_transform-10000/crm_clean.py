import csv
import io


def normalize_table(text):
    """Normalize CSV text with columns: score, id, email, name.

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Lower-case the "email" column.
    - Remove duplicate rows by "name", keeping the first occurrence.
    - Sort rows by "email" ascending as strings (stable).

    Returns empty string for empty input, and just the header line
    for header-only input.
    """
    if not text or not text.strip():
        return ""

    # Parse CSV into a list of dicts
    reader = csv.reader(io.StringIO(text))
    rows = []
    for row in reader:
        # Strip whitespace from each cell
        cleaned = [cell.strip() for cell in row]
        rows.append(cleaned)

    if not rows:
        return ""

    # Extract header and data
    header = rows[0]
    data = rows[1:]

    # Drop rows whose "name" cell is empty
    name_idx = header.index("name")
    data = [row for row in data if row[name_idx] != ""]

    # Lower-case the "email" column
    email_idx = header.index("email")
    for row in data:
        row[email_idx] = row[email_idx].lower()

    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    deduped = []
    for row in data:
        name = row[name_idx]
        if name in seen_names:
            continue
        seen_names.add(name)
        deduped.append(row)

    # Sort rows by "email" ascending as strings (stable)
    deduped.sort(key=lambda row: row[email_idx])

    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()
