def tally_events(lines):
    """Tally log events per service for ERROR and WARN levels only.
    
    Log format: "<timestamp> <LEVEL> <service>: <message>"
    - Counts occurrences per service for levels ERROR and WARN (case-insensitive).
    - Drops malformed lines.
    - Returns dict with upper-case keys.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # Format: timestamp level service: message
        # We need at least: timestamp, level, service (with colon)
        # The service part includes the colon and message
        # Let's parse more carefully
        # parts[0] = timestamp
        # parts[1] = level
        # parts[2] should start with service name followed by colon
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        # Find the service part - it's the first token after level that contains a colon
        # Actually format is: "<timestamp> <LEVEL> <service>: <message>"
        # So after splitting by space, we have: [timestamp, LEVEL, service:, message...]
        # But service: might be split if there are spaces in service name? Unlikely.
        # Let's assume standard format: parts[2] is "service:" or "service: message"
        # We need to find the service name before the colon
        # Better approach: look for the first occurrence of ":" after level
        # But simpler: parts[2] might be "service:" if no space in service name
        # Let's check if parts[2] contains a colon
        service_part = parts[2] if len(parts) > 2 else ""
        if not service_part:
            continue
        # Find the colon position in service_part
        colon_idx = service_part.find(":")
        if colon_idx == -1:
            # No colon found, malformed line
            continue
        service_name = service_part[:colon_idx]
        if not service_name:
            continue
        counts[service_name] = counts.get(service_name, 0) + 1
    return counts
