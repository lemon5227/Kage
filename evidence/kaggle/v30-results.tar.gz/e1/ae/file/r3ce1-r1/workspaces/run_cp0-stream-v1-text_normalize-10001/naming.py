import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters into base + combining marks
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    text = "".join(c for c in text if ord(c) < 128)

    # Lower-case
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we need to group consecutive non-alphanumeric characters and replace each group with one underscore
    parts = []
    current = []
    for c in text:
        if c.isalnum():
            current.append(c)
        else:
            if current:
                parts.append("".join(current))
                current = []
            # Skip non-alphanumeric characters (they don't get added to parts)
    if current:
        parts.append("".join(current))

    # Join with underscores, but ensure we don't have consecutive underscores
    result = "_".join(parts)

    # Strip leading and trailing "_"
    return result.strip("_")
