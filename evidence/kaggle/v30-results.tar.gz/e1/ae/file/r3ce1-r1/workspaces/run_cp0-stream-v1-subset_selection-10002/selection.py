def select_tasks(items, capacity):
    """Select a subset of tasks to maximize total score within capacity."""
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    # Validate items and build list of (id, size, score)
    entries = []
    for item in items:
        item_id = item["id"]
        size = item["size"]
        score = item["score"]
        
        if not isinstance(item_id, str):
            raise ValueError("item id must be a string")
        if not isinstance(size, int) or size <= 0:
            raise ValueError("item size must be a positive integer")
        if not isinstance(score, int) or score < 0:
            raise ValueError("item score must be a non-negative integer")
        
        entries.append((item_id, size, score))
    
    # Sort by score descending, then by id ascending for tie-breaking
    entries.sort(key=lambda e: (-e[2], e[0]))
    
    # Greedy selection: take items in order until capacity is exceeded
    selected = []
    total_size = 0
    for item_id, size, score in entries:
        if total_size + size <= capacity:
            selected.append(item_id)
            total_size += size
    
    return sorted(selected)
