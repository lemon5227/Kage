def upgrade_config(cfg):
    """Upgrade old configuration dicts to v2 layout."""
    # Check version - only upgrade if version is 1
    if cfg.get("version") != 1:
        raise ValueError(f"Expected version 1, got {cfg.get('version')}")

    # Create new dict with v2 layout
    new_cfg = {"version": 2}

    # Handle top-level keys
    if "max_conn" in cfg:
        new_cfg["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        new_cfg["directory"] = cfg["dir"]
    if "host" in cfg:
        new_cfg["hostname"] = cfg["host"]

    # Handle cache_size and region - move into limits sub-dict
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    new_cfg["limits"] = limits

    # Handle timeout_ms - convert to timeout_s if present
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged
    for key, value in cfg.items():
        if key not in ("max_conn", "dir", "host", "cache_size", "region", "timeout_ms", "version"):
            # Only keep keys with non-None values
            if value is not None:
                new_cfg[key] = value

    return new_cfg
