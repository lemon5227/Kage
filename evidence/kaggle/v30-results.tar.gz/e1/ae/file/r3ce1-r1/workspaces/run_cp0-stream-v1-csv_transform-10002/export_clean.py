import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: name, team, city, id, score).
    Output: Cleaned CSV text with the same header.

    Rules:
    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Remove duplicate rows by "score", keeping the first occurrence.
    - Sort rows by "id" ascending as strings (stable).
    """
    # Handle empty input
    if not text or not text.strip():
        return ""

    # Parse CSV into a list of dicts
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    # If there's no data, return just the header (or empty string)
    if not rows:
        return ""

    # Extract header row
    header = [cell.strip() for cell in rows[0]]
    # Ensure we have the expected columns
    expected_cols = ["name", "team", "city", "id", "score"]
    if len(header) != len(expected_cols):
        # If header doesn't match, just return what we have
        pass

    # Process data rows (skip header)
    data_rows = []
    for row in rows[1:]:
        # Strip whitespace from each cell
        cleaned_row = [cell.strip() for cell in row]
        if len(cleaned_row) != len(header):
            continue  # Skip malformed rows

        # Map to column names
        cell_dict = dict(zip(header, cleaned_row))

        # Drop rows whose "name" cell is empty
        if not cell_dict.get("name"):
            continue

        data_rows.append(cell_dict)

    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in data_rows:
        score = row["score"]
        if score in seen_scores:
            continue
        seen_scores.add(score)
        unique_rows.append(row)

    # Sort rows by "id" ascending as strings (stable)
    unique_rows.sort(key=lambda r: r["id"])

    # Write output CSV with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow([row[col] for col in header])

    return output.getvalue()
