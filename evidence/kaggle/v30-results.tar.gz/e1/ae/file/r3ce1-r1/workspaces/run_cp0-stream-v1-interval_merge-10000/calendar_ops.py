def coalesce(intervals):
    """Combine overlapping time ranges into merged intervals.

    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals sorted by start ascending.
    Touching intervals like [1,3] and [3,5] are merged.
    Raises ValueError if any interval has start > end.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
        normalized.append([start, end])

    # Sort by start time
    normalized.sort(key=lambda x: x[0])

    # Merge overlapping or touching intervals
    merged = []
    for interval in normalized:
        if not merged:
            merged.append(interval)
        else:
            last_start, last_end = merged[-1]
            current_start, current_end = interval
            if current_start <= last_end + 1:
                # Overlapping or touching intervals - merge them
                merged[-1][1] = max(last_end, current_end)
            else:
                merged.append(interval)

    return merged
