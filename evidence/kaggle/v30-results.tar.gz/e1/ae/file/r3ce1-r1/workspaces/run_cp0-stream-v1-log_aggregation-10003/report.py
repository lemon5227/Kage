def aggregate_log(lines):
    """Aggregate log strings into {name: count} per service for ERROR and WARN only.
    
    Log format: "<timestamp> <LEVEL> <service>: <message>"
    - Only counts lines with LEVEL ERROR or WARN (case-insensitive).
    - Keys are upper-case level names.
    - Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # parts[0] = timestamp, parts[1] = LEVEL, parts[2] = service (before colon)
        level = parts[1].upper()
        service = parts[2]
        # Check if service contains a colon; take the part before colon as the service name
        if ':' in service:
            service = service.split(':')[0]
        else:
            # If no colon, the whole service string is used
            pass
        if level not in ('ERROR', 'WARN'):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
