def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Raise ValueError unless version is 1
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")

    # Create new dict with version 2
    result = {"version": 2}

    # Rename top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]

    # Move region and retries into network sub-dict
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    result["network"] = network

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key not in ["dir", "pwd_file", "max_conn", "region", "retries", "timeout_ms"]:
            if value is not None:
                result[key] = value

    return result
