import unicodedata


def to_key(text):
    """Normalize text into a label identifier.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case the result.
    - Replace every run of characters outside [a-z0-9] with a single "_".
    - Strip leading and trailing "_".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    normalized = unicodedata.normalize("NFKD", text)
    # Drop non-ASCII characters (keep only ASCII after NFKD)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    parts = []
    current = ""
    for ch in lower:
        if ch.isalnum():
            current += ch
        else:
            if current:
                parts.append(current)
                current = ""
            # Use a single underscore for any run of non-alnum chars
            parts.append("_")
    if current:
        parts.append(current)

    result = "".join(parts)

    # Strip leading and trailing "_"
    return result.strip("_")
