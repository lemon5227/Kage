def count_entries(lines):
    """Count lines by log level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (report them upper-case).
    Skip malformed lines. Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        _timestamp, level, rest = parts[0], parts[1], " ".join(parts[2:])
        if not rest.startswith(":"):
            continue
        # The service name is everything between the colon and the first space,
        # but we only need to validate that the format is at least
        # "<timestamp> <LEVEL> <service>:" so we check that there's a third token.
        if len(parts) < 3:
            continue
        _service = parts[2]
        if not _service.endswith(":"):
            continue
        level = _service[:-1].upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
