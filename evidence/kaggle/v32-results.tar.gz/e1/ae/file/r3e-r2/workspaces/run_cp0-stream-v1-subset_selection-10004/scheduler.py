def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity.  Ties on total value are broken by the
    lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and normalize items without mutating the input.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_value, chosen_ids) for capacity c.
    # We track the chosen ids so we can reconstruct the solution.
    prev = [(0, []) for _ in range(capacity + 1)]
    for idx in range(len(entries)):
        item_id, weight, value = entries[idx]
        for c in range(capacity, weight - 1, -1):
            prev_c = prev[c - weight][1]
            cand_ids = prev_c + [item_id]
            if prev[c][0] < value + prev_c[0]:
                prev[c] = (value + prev_c[0], cand_ids)
            elif value + prev_c[0] == prev[c][0]:
                # Tie on total value: prefer lexicographically smallest sorted id list.
                if sorted(cand_ids) < sorted(prev[c][1]):
                    prev[c] = (value + prev_c[0], cand_ids)

    # The optimal value is at capacity, and we need the lexicographically
    # smallest sorted id list among all selections that achieve it.
    best_value = prev[capacity][0]
    best_ids = prev[capacity][1]

    # Check all capacities for equal or better value, then pick the
    # lexicographically smallest sorted id list.
    for c in range(capacity + 1):
        val, ids = prev[c]
        if val > best_value:
            best_value = val
            best_ids = ids
        elif val == best_value:
            if sorted(ids) < sorted(best_ids):
                best_ids = ids

    return sorted(best_ids)
