def allocate(items, capacity):
    """Select a subset of items whose total cost is at most capacity
    and total gain is maximized. Ties on total gain are broken by
    choosing the lexicographically smallest sorted list of ids.

    Each item is a dict with a unique string "id", a positive integer
    "cost" and a non-negative integer "gain". The input is not modified.

    Raises ValueError if capacity is negative or any cost is <= 0.
    Returns the sorted list of selected ids (empty list is allowed).
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    n = len(entries)
    if n == 0:
        return []

    # Sort by id so that we can reason about tie-breaking consistently.
    entries.sort(key=lambda e: e[0])

    # dp[w] = best (gain, selected_id_tuple) achievable with cost exactly w.
    # We track the chosen id tuple to resolve ties lexicographically.
    # Initialize with (gain=0, ids=[]) for cost 0.
    dp = [(0, [])] * (capacity + 1)

    for idx in range(n):
        item_id, cost, gain = entries[idx]
        # Iterate costs descending so each item is used at most once.
        for w in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[w - cost]
            cand_gain = prev_gain + gain
            cand_ids = prev_ids + [item_id]
            if cand_gain > dp[w][0]:
                dp[w] = (cand_gain, cand_ids)
            elif cand_gain == dp[w][0] and cand_ids < dp[w][1]:
                # Tie on gain: prefer lexicographically smaller id list.
                dp[w] = (cand_gain, cand_ids)

    # Find the best total gain across all feasible costs.
    best_gain = 0
    best_ids = []
    for w in range(capacity + 1):
        gain, ids = dp[w]
        if gain > best_gain or (gain == best_gain and ids < best_ids):
            best_gain = gain
            best_ids = ids

    return best_ids
