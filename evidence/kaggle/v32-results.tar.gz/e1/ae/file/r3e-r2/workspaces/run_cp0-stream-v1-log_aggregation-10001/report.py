def tally_events(lines):
    """Tally log lines by service for ERROR and WARN levels only.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    - Level names are matched case-insensitively; only ERROR and WARN are counted.
    - Malformed lines are dropped.
    - Returns a dict mapping service name (upper-case key) to the number of events.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service (with colon), message
        if len(parts) < 4:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service_token = parts[2]
        if not service_token.endswith(":"):
            continue
        service = service_token[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
