import unicodedata


def slugify(text):
    """Build a URL slug from text.

    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces every run of characters outside [a-z0-9] with a single "-",
    and strips leading and trailing "-". Non-string input raises TypeError.
    """
    if not isinstance(text, str):
        raise TypeError("Expected string, got %s" % type(text).__name__)

    # NFKD normalization + drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    current = ""
    for ch in ascii_only:
        if ch.isalnum():
            current += ch
        else:
            if current:
                segments.append(current)
                current = ""
            # non-alnum runs become a single "-"
            if ch not in "-":
                segments.append("-")
    if current:
        segments.append(current)

    result = "".join(segments)

    # strip leading and trailing "-"
    return result.strip("-")
