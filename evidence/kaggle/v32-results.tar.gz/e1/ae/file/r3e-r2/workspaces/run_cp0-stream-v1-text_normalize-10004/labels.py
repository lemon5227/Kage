import unicodedata


def label_id(text):
    """Build a URL slug from text.

    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    and replaces every run of characters outside [a-z0-9] with a single "-".
    Leading and trailing "-" are stripped.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters
    ascii_only = ""
    for ch in normalized:
        if ord(ch) < 128:
            ascii_only += ch

    # lower-case
    ascii_only = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    prev_is_alnum = False
    for ch in ascii_only:
        is_alnum = ch.isalnum()
        if not is_alnum:
            if not prev_is_alnum:
                slug.append("-")
        prev_is_alnum = is_alnum

    result = "".join(slug)

    # Strip leading and trailing "-"
    return result.strip("-")
