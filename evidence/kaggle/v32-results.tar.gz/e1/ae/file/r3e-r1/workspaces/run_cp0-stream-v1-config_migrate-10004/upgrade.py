def migrate(cfg):
    """Migrate a v1 config dict to v2.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys: "pwd_file" -> "password_file", "user" -> "username".
    Moves "cache_size" and "workers" into a sub-dict "network" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1, got {}".format(cfg.get("version")))

    # Make a copy so we don't modify the input
    result = dict(cfg)
    result["version"] = 2

    # Rename top-level keys
    if "pwd_file" in result:
        result["password_file"] = result.pop("pwd_file")
    if "user" in result:
        result["username"] = result.pop("user")

    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in result:
        network["cache_size"] = result.pop("cache_size")
    if "workers" in result:
        network["workers"] = result.pop("workers")
    result["network"] = network

    # Handle timeout_ms -> timeout_s conversion
    if "timeout_ms" in result:
        result["timeout_s"] = result["timeout_ms"] / 1000.0
        result.pop("timeout_ms", None)

    # Drop keys whose value is None
    for key in list(result.keys()):
        if result[key] is None:
            del result[key]

    return result
