def pick_jobs(items, capacity):
    """Choose a subset of items maximizing total score within capacity.

    Each item is a dict with a unique string "id", a positive integer
    "size" and a non-negative integer "score". Returns the sorted list of
    ids whose total score is as large as possible while total size stays
    <= capacity. Ties on total score are broken by choosing the
    lexicographically smallest sorted id list. An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # Copy the list of ids so we don't mutate the input
    chosen = []
    total_size = 0
    total_score = 0

    # Sort items by (score, id) to handle tie-breaking correctly
    sorted_items = sorted(items, key=lambda item: (item["score"], item["id"]))

    for item in sorted_items:
        item_id = item["id"]
        size = item["size"]
        score = item["score"]

        if total_size + size <= capacity:
            chosen.append(item_id)
            total_size += size
            total_score += score

    return chosen
