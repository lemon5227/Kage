import unicodedata


def slugify(text):
    """Turn a title into a handle.

    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces every run of characters outside [a-z0-9] with a single "_",
    and strips leading and trailing "_".
    """
    if not isinstance(text, str):
        raise TypeError("Expected string, got %r" % type(text))

    # NFKD normalization + drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    parts = ascii_only.split("_")
    cleaned_parts = []
    for part in parts:
        if part.strip() == "":
            continue
        cleaned_parts.append(part)
    result = "_".join(cleaned_parts)

    # strip leading and trailing "_"
    return result.strip("_")
