import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "score" cell is empty
    score_idx = header.index("score") if "score" in header else None
    if score_idx is not None:
        cleaned = [row for row in cleaned if len(row) > score_idx and row[score_idx] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    if score_idx is not None:
        seen = set()
        deduped = []
        for row in cleaned:
            key = row[score_idx] if len(row) > score_idx else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(row)
        cleaned = deduped

    # sort rows by "name" ascending as strings (stable)
    name_idx = header.index("name") if "name" in header else None
    if name_idx is not None:
        cleaned.sort(key=lambda row: row[name_idx] if len(row) > name_idx else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
