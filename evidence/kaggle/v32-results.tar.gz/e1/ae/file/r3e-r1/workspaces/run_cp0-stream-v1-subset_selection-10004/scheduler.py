def choose(items, capacity):
    """Select a subset of items whose total weight is at most capacity and total value is maximized.

    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Returns the sorted list of ids of the
    chosen items. Ties on total value are broken by choosing the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    n = len(entries)
    if n == 0:
        return []

    # Sort by id so that we can reason about lexicographic tie-breaking.
    entries.sort(key=lambda e: e[0])

    # dp[w] = best (value, chosen_ids) achievable with weight exactly <= w.
    # We track the chosen ids to resolve ties lexicographically.
    # Using a dict keyed by weight for the best value, plus the id list.
    NEG = None
    dp = [None] * (capacity + 1)  # dp[w] = (value, tuple_of_ids) or None
    dp[0] = (0, ())

    for idx in range(n):
        item_id, weight, value = entries[idx]
        # Iterate weights descending for 0/1 knapsack.
        for w in range(capacity, weight - 1, -1):
            prev = dp[w - weight]
            if prev is None:
                continue
            cand_value = prev[0] + value
            cand_ids = prev[1] + (item_id,)
            cur = dp[w]
            if cur is None or cand_value > cur[0]:
                dp[w] = (cand_value, cand_ids)
            elif cand_value == cur[0] and cand_ids < cur[1]:
                dp[w] = (cand_value, cand_ids)

    # Find the best value across all capacities, then the lexicographically
    # smallest id list among those achieving that value.
    best_value = None
    best_ids = None
    for w in range(capacity + 1):
        entry = dp[w]
        if entry is None:
            continue
        value, ids = entry
        if best_value is None or value > best_value:
            best_value = value
            best_ids = ids
        elif value == best_value and (best_ids is None or ids < best_ids):
            best_ids = ids

    return list(best_ids) if best_ids is not None else []
