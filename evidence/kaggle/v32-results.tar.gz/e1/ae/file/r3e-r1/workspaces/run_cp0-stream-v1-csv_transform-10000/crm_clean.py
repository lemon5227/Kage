import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name")
    cleaned = [r for r in cleaned if name_idx < len(r) and r[name_idx] != ""]

    # lower-case the "email" column
    email_idx = header.index("email")
    for r in cleaned:
        if email_idx < len(r):
            r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[name_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    # sort rows by "email" ascending as strings (stable)
    email_idx = header.index("email")
    deduped.sort(key=lambda r: r[email_idx] if email_idx < len(r) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        input_text = "\n".join(sys.argv[1:])
    else:
        input_text = ""

    result = normalize_table(input_text)
    print(result)
