import unicodedata


def slugify(text):
    """Build a URL slug from text.

    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces every run of characters outside [a-z0-9] with a single "-",
    and strips leading and trailing "-". Non-string input raises TypeError.
    """
    if not isinstance(text, str):
        raise TypeError("Expected string, got %s" % type(text).__name__)

    # NFKD normalization separates characters into base + combining marks
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    text = "".join(c for c in text if ord(c) < 128)

    # Lowercase
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    current = []
    for c in text:
        if c.isalnum():
            current.append(c)
        else:
            if current:
                segments.append("".join(current))
                current = []
            segments.append("-")
    if current:
        segments.append("".join(current))

    text = "".join(segments)

    # Strip leading and trailing "-"
    while text.startswith("-"):
        text = text[1:]
    while text.endswith("-"):
        text = text[:-1]

    return text
