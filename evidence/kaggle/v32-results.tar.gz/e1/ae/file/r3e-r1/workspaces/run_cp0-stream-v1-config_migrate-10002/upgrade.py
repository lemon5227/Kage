def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError(
            "upgrade_config requires cfg['version'] == 1, "
            f"got {cfg.get('version')}"
        )

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process keys in the order they appear in the original dict
    for key in cfg:
        value = cfg[key]

        # Drop keys whose value is None
        if value is None:
            continue

        # Rename top-level keys
        if key == "dir":
            result["directory"] = value
        elif key == "pwd_file":
            result["password_file"] = value
        elif key == "max_conn":
            result["max_connections"] = value
        else:
            result[key] = value

    # Move "region" and "retries" into a sub-dict "network"
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    result["network"] = network

    # Handle "timeout_ms" -> "timeout_s" conversion
    if "timeout_ms" in cfg:
        timeout_ms = cfg["timeout_ms"]
        result["timeout_s"] = float(timeout_ms) / 1000.0

    return result
