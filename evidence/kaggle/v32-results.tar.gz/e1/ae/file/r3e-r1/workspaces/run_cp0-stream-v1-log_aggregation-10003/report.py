def aggregate_log(lines):
    """Aggregate log lines into {name: count} for ERROR and WARN levels only.

    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"

    Level names are matched case-insensitively and only ERROR/WARN are counted.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service = parts[2]
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
