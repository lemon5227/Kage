def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys "user" -> "username", "dir" -> "directory".
    Moves "cache_size" and "retries" into a sub-dict "limits".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError(
            "config_v2.py: only version 1 configurations are supported; "
            f"got version {cfg.get('version')}"
        )

    # Work on a copy so the input is never modified.
    out = {}
    out["version"] = 2

    # Process top-level keys in a deterministic order.
    for key in sorted(cfg.keys()):
        value = cfg[key]

        # Drop keys whose value is None.
        if value is None:
            continue

        if key == "user":
            out["username"] = value
        elif key == "dir":
            out["directory"] = value
        elif key == "cache_size":
            out["limits"] = {}
            out["limits"]["cache_size"] = value
        elif key == "retries":
            out["limits"] = {}
            out["limits"]["retries"] = value
        elif key == "timeout_ms":
            out["timeout_s"] = float(value) / 1000.0
        else:
            out[key] = value

    return out
