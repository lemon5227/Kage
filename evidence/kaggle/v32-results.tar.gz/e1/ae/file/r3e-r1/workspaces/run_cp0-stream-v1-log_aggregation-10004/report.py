def digest_lines(lines):
    """Count log lines per level.

    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # The third token must be "<service>:" (service followed by colon)
        if not parts[2].endswith(":"):
            continue
        level = parts[1].upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
