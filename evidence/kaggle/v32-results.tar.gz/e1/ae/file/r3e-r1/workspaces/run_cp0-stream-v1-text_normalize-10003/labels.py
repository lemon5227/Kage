import unicodedata


def make_handle(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization + drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = "".join(c for c in normalized if ord(c) < 128)

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    current = ""
    for c in ascii_only:
        if c.isalnum():
            current += c
        else:
            if current:
                segments.append(current)
                current = ""
            segments.append("-")
    if current:
        segments.append(current)

    handle = "".join(segments)

    # strip leading and trailing "-"
    return handle.strip("-")
