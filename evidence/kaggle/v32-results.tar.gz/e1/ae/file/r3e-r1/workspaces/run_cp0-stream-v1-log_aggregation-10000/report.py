def count_entries(lines):
    """Count lines by level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (report them upper-case).
    Skip malformed lines. Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        _timestamp, level, rest = parts[0], parts[1], " ".join(parts[2:])
        if not rest.startswith(":"):
            continue
        # level must be non-empty and not just whitespace
        if not level.strip():
            continue
        level_upper = level.upper()
        counts[level_upper] = counts.get(level_upper, 0) + 1
    return counts
