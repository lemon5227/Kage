def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "max_conn" -> "max_connections"
      "dir" -> "directory"
      "host" -> "hostname"
    Moves "cache_size" and "region" into a sub-dict "limits".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError(
            "upgrade_config requires configuration with version 1, "
            f"got version {cfg.get('version')}"
        )

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process top-level keys in order of precedence
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]

    # Move cache_size and region into limits
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    result["limits"] = limits

    # Handle timeout_ms -> timeout_s conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Copy remaining keys that are not None
    for key, value in cfg.items():
        if key in ("max_conn", "dir", "host", "cache_size", "region", "timeout_ms"):
            continue
        if value is None:
            continue
        result[key] = value

    return result
