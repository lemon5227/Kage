import unicodedata


def to_key(text):
    """Normalize text into a label identifier.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case the result.
    - Replace every run of characters outside [a-z0-9] with a single "_".
    - Strip leading and trailing "_".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization then drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    parts = []
    current = ""
    for ch in ascii_only:
        if ch.isalnum():
            current += ch
        else:
            if current:
                parts.append(current)
                current = ""
            # use a single underscore for any run of non-alnum chars
            parts.append("_")
    if current:
        parts.append(current)

    result = "".join(parts)

    # strip leading and trailing "_"
    return result.strip("_")