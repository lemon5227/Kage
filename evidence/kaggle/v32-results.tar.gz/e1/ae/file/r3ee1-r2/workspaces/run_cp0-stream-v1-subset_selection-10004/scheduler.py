def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity. Ties on total value are broken by the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # 0/1 knapsack over sorted ids (by id for deterministic tie-breaking).
    # We track the best total value and the corresponding sorted id list.
    # Since we need the lexicographically smallest id list among ties,
    # we iterate over all subsets in order of increasing id sequence.
    n = len(entries)
    if n == 0:
        return []

    # Sort entries by id so that we can generate subsets in lexicographic order.
    entries.sort(key=lambda e: e[0])

    best_value = 0
    best_ids = []

    # Iterate over all subsets of indices, in order that yields increasing
    # lexicographic sequences of ids (because entries are sorted by id).
    # This guarantees that when we find a tie on value, the first (smallest)
    # subset is kept.
    for mask in range(1 << n):
        current_value = 0
        current_weight = 0
        chosen_ids = []
        for i in range(n):
            if mask & (1 << i):
                idx = entries[i][1]
                weight = entries[i][2]
                value = entries[i][3]
                current_weight += weight
                current_value += value
                chosen_ids.append(entries[i][0])

        if current_weight > capacity:
            continue

        # Check if this subset is better (or equal value but lexicographically smaller).
        if current_value > best_value:
            best_value = current_value
            best_ids = sorted(chosen_ids)
        elif current_value == best_value and len(chosen_ids) == len(best_ids):
            # Tie on value: keep the lexicographically smallest sorted id list.
            if sorted(chosen_ids) < best_ids:
                best_ids = sorted(chosen_ids)

    return best_ids
