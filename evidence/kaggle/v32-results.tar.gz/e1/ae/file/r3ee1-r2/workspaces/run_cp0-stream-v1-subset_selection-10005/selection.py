def allocate(items, capacity):
    """Select a subset of items whose total size is <= capacity and total score is maximized.
    
    Each item is a dict with a unique string "id", a positive integer "size" and a non-negative integer "score".
    Returns the sorted list of ids of the selected items. If several selections tie on total score,
    returns the lexicographically smallest sorted id list. An empty selection is allowed.
    
    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")
    
    # 0/1 knapsack via dynamic programming
    # dp[w] = best (score, chosen_ids) achievable with total size exactly w
    # We track the chosen ids to resolve ties lexicographically.
    # Initialize: dp[0] = (0, [])
    # For each item, we update dp in reverse order of capacity.
    
    # Use a dict mapping total_size -> (score, sorted_id_list)
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])
    
    for item in items:
        item_id = item["id"]
        size = item["size"]
        score = item["score"]
        
        # Iterate capacity descending to avoid reusing the same item multiple times
        for w in range(capacity, size - 1, -1):
            if dp[w - size] is not None:
                prev_score, prev_ids = dp[w - size]
                new_score = prev_score + score
                new_ids = sorted(prev_ids + [item_id])
                
                # Check if this gives a better score, or same score but lexicographically smaller
                if dp[w] is None or new_score > dp[w][0]:
                    dp[w] = (new_score, new_ids)
                elif new_score == dp[w][0] and new_ids < dp[w][1]:
                    dp[w] = (new_score, new_ids)
    
    # Find the best score among all capacities <= capacity
    best_score = 0
    best_ids = []
    
    for w in range(capacity + 1):
        if dp[w] is not None:
            score, ids = dp[w]
            if score > best_score or (score == best_score and ids < best_ids):
                best_score = score
                best_ids = ids
    
    return best_ids
