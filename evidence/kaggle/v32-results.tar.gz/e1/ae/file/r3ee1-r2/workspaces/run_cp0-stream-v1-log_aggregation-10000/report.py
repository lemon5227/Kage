def count_entries(lines):
    """Count log entries by level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (reported upper-case). Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service: (with message optional)
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        # Validate that the level is a non-empty string of letters
        if not level.isalpha():
            continue
        # Check that part 2 is a service name followed by a colon
        # e.g. "auth: user logged in" -> parts[2] = "auth:"
        if len(parts) < 3:
            continue
        service_part = parts[2]
        if not service_part.endswith(":"):
            continue
        # Skip malformed lines (e.g. missing service or invalid format)
        # We've already validated level, so this line is considered valid.
        counts[level] = counts.get(level, 0) + 1
    return counts
