def tally_events(lines):
    """Tally log lines by service for ERROR and WARN levels only.
    
    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"
    
    Only counts lines with level ERROR or WARN (case-insensitive).
    Returns a dict mapping service name to occurrence count.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service (with colon)
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        # The service is the third token followed by a colon
        # e.g. "2024-01-01T12:00:00Z ERROR auth-service: login failed"
        # parts[2] would be "auth-service:" including the colon
        if len(parts) < 3 or not parts[2].endswith(":"):
            continue
        service = parts[2].rstrip(":")
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
