import unicodedata


def to_key(text):
    """Normalize labels into identifiers.

    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces every run of characters outside [a-z0-9] with a single "_",
    and strips leading and trailing "_". Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lowercase
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for char in lower:
        if not char.isalnum():
            if prev_char is not None:
                result.append("_")
            prev_char = None
        else:
            if prev_char is None or prev_char != char:
                result.append(char)
            prev_char = char

    return "".join(result).strip("_")
