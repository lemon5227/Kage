import unicodedata


def make_handle(text):
    """Turn a title into a handle.

    Apply NFKD normalization and drop non-ASCII characters; lower-case;
    replace every run of characters outside [a-z0-9] with a single "-";
    strip leading and trailing "-". If the result is longer than 23
    characters, cut it to 23 and then strip a trailing "-".
    Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    normalized = unicodedata.normalize("NFKD", text)
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")
    # Lower-case
    ascii_only = ascii_only.lower()
    # Replace every run of characters outside [a-z0-9] with a single "-"
    parts = []
    current = ""
    for ch in ascii_only:
        if ch.isalnum():
            current += ch
        else:
            if current:
                parts.append(current)
                current = ""
            parts.append("-")
    if current:
        parts.append(current)

    handle = "".join(parts)
    # Strip leading and trailing "-"
    handle = handle.strip("-")
    # If longer than 23 characters, cut to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.rstrip("-")

    return handle
