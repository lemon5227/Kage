def select_tasks(items, capacity):
    """Pick which jobs to take.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by score descending, then by id ascending for tie-breaking.
    entries.sort(key=lambda e: (-e[2], e[0]))

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = best (score, chosen_ids) achievable with total size <= w.
    # We track the chosen ids to resolve ties lexicographically.
    # Using a dict keyed by size for the best score at that size, plus the id list.
    # Initialize with zero size having score 0 and empty id list.
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for idx in range(n):
        item_id, size, score = entries[idx]
        # Iterate capacities descending so each item is used at most once.
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[w - size]
            cand_score = prev_score + score
            cand_ids = sorted(prev_ids + [item_id])
            if dp[w] is None or cand_score > dp[w][0]:
                dp[w] = (cand_score, cand_ids)
            elif cand_score == dp[w][0] and cand_ids < dp[w][1]:
                dp[w] = (cand_score, cand_ids)

    # The answer is the best score across all capacities, with lexicographically
    # smallest id list among those achieving that score.
    best_score = None
    best_ids = None
    for w in range(capacity + 1):
        entry = dp[w]
        if entry is None:
            continue
        score, ids = entry
        if best_score is None or score > best_score:
            best_score = score
            best_ids = ids
        elif score == best_score and (best_ids is None or ids < best_ids):
            best_ids = ids

    return best_ids if best_ids is not None else []
