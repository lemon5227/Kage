def digest_lines(lines):
    """Process log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    
    Returns a dict mapping level name (upper-case) to count.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, LEVEL, service: message
        if len(parts) < 3:
            continue
        level = parts[1]
        # Validate level format: must be alphabetic (e.g., DEBUG, INFO, WARN, ERROR)
        if not level.isalpha():
            continue
        # Count occurrences (case-insensitive, store as upper-case key)
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
