def merge_slots(intervals):
    """Merge overlapping intervals.

    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals as [start, end] lists, sorted by start ascending.
    Touching intervals (e.g. [1, 3] and [3, 5]) are NOT merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate all intervals first
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Invalid interval: start ({start}) > end ({end})")

    # Sort by start time (and end time for stability)
    sorted_intervals = sorted(intervals, key=lambda pair: (pair[0], pair[1]))

    merged = []
    current_start, current_end = sorted_intervals[0]

    for next_start, next_end in sorted_intervals[1:]:
        # Only merge if there is a real overlap (current_end > next_start)
        # Touching intervals (current_end == next_start) do NOT merge
        if current_end > next_start:
            # Merge by extending the end if needed
            current_end = max(current_end, next_end)
        else:
            # No overlap, push the current interval and start a new one
            merged.append([current_start, current_end])
            current_start, current_end = next_start, next_end

    # Append the last interval
    merged.append([current_start, current_end])

    return merged
