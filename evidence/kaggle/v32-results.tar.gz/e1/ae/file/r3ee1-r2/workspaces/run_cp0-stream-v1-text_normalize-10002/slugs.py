import unicodedata


def slugify(text):
    """Build a URL slug from text.

    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces every run of characters outside [a-z0-9] with a single "-",
    and strips leading and trailing "-". Non-string input raises TypeError.
    """
    if not isinstance(text, str):
        raise TypeError("Expected string, got %s" % type(text).__name__)

    # NFKD normalization separates characters into base + combining marks
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lowercase
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    prev_char_is_alnum = False
    for ch in lower:
        if ch.isalnum():
            if not prev_char_is_alnum:
                slug.append(ch)
            prev_char_is_alnum = True
        else:
            if not slug or slug[-1].isalnum():
                slug.append("-")
            prev_char_is_alnum = False

    result = "".join(slug)

    # Strip leading and trailing "-"
    return result.strip("-")
