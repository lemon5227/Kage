import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "score" cell is empty
    score_idx = header.index("score") if "score" in header else None
    if score_idx is not None:
        cleaned = [r for r in cleaned if score_idx < len(r) and r[score_idx] != ""]

    # remove duplicate rows by "team", keeping the first occurrence
    team_idx = header.index("team") if "team" in header else None
    if team_idx is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            key = r[team_idx] if team_idx < len(r) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(r)
        cleaned = deduped

    # sort rows by "score" ascending as strings (stable)
    score_idx = header.index("score") if "score" in header else None
    if score_idx is not None:
        cleaned.sort(key=lambda r: r[score_idx] if score_idx < len(r) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in cleaned:
        writer.writerow(row)

    return out.getvalue()
