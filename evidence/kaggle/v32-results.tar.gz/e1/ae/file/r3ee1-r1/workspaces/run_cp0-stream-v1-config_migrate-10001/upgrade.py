def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "host" -> "hostname"
      "max_conn" -> "max_connections"
      "pwd_file" -> "password_file"
    Moves "port" and "retries" into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate input version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            "convert_settings() requires cfg with version == 1, "
            f"got version={version}"
        )

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process each key in the input dict
    for key, value in cfg.items():
        if value is None:
            # Drop keys whose value is None
            continue

        if key == "host":
            result["hostname"] = value
        elif key == "max_conn":
            result["max_connections"] = value
        elif key == "pwd_file":
            result["password_file"] = value
        elif key == "port":
            # Move into storage sub-dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["port"] = value
        elif key == "retries":
            # Move into storage sub-dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["retries"] = value
        elif key == "timeout_ms":
            # Convert milliseconds to seconds (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value

    return result
