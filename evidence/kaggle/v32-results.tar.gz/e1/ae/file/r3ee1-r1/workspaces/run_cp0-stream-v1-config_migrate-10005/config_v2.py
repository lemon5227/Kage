def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys: "user" -> "username", "dir" -> "directory".
    Moves "cache_size" and "retries" into a sub-dict "limits" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1, got " + str(cfg.get("version")))

    # Start with a copy to avoid modifying the input
    result = {}
    result["version"] = 2

    # Process keys in order of precedence
    # First handle special keys that need transformation
    if "user" in cfg:
        result["username"] = cfg["user"]
    if "dir" in cfg:
        result["directory"] = cfg["dir"]

    # Move cache_size and retries into limits
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "retries" in cfg:
        limits["retries"] = cfg["retries"]
    result["limits"] = limits

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Process remaining keys, dropping None values
    for key, value in cfg.items():
        if key in ["user", "dir", "cache_size", "retries", "timeout_ms"]:
            continue  # Already handled above
        if value is None:
            continue  # Drop None values
        result[key] = value

    return result
