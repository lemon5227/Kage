def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            "upgrade_config requires cfg['version'] == 1, "
            f"got {version!r}"
        )

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process each key in the input dict
    for key in list(cfg.keys()):
        value = cfg[key]

        # Skip keys with None values
        if value is None:
            continue

        # Handle specific key renames and transformations
        if key == "dir":
            result["directory"] = value
        elif key == "pwd_file":
            result["password_file"] = value
        elif key == "max_conn":
            result["max_connections"] = value
        elif key == "region":
            # Move region into network sub-dict
            if "network" not in result:
                result["network"] = {}
            result["network"]["region"] = value
        elif key == "retries":
            # Move retries into network sub-dict
            if "network" not in result:
                result["network"] = {}
            result["network"]["retries"] = value
        elif key == "timeout_ms":
            # Convert timeout_ms to timeout_s (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value

    return result
