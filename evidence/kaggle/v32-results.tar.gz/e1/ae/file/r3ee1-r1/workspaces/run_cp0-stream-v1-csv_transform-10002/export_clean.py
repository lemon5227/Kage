import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if len(rows) == 0:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name")
    cleaned = [row for row in cleaned if len(row) > name_idx and row[name_idx] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    score_idx = header.index("score")
    seen = set()
    deduped = []
    for row in cleaned:
        key = row[score_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    # sort rows by "id" ascending as strings (stable)
    id_idx = header.index("id")
    deduped.sort(key=lambda row: row[id_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()


if __name__ == "__main__":
    # Example usage
    sample_text = "name,team,city,id,score\nAlice,TeamA,NewYork,1,100\nBob,TeamB,LosAngeles,2,100\nCharlie,TeamC,Chicago,3,200"
    result = normalize_table(sample_text)
    print(result)
