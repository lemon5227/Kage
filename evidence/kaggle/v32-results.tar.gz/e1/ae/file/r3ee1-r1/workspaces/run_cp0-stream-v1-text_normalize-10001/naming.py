import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    runs = []
    prev = None
    for ch in ascii_only:
        if ch not in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev is None or prev != "_":
                runs.append("_")
                prev = "_"
        else:
            prev = ch

    result = ""
    for ch in ascii_only:
        if ch not in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev is None or prev != "_":
                result += "_"
                prev = "_"
        else:
            result += ch
            prev = ch

    # strip leading and trailing "_"
    return result.strip("_")
