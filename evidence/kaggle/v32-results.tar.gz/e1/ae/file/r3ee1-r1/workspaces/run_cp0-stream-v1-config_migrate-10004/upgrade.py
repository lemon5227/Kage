def migrate(cfg):
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Only v1 configs can be migrated")

    # Copy the config to avoid modifying input
    result = {}
    result["version"] = 2

    # Rename top-level keys
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    if "user" in cfg:
        result["username"] = cfg["user"]

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    result["network"] = network

    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key in ["pwd_file", "user", "timeout_ms", "cache_size", "workers"]:
            continue  # already handled above
        if value is None:
            continue  # drop keys with None value
        if key not in result:
            result[key] = value

    return result
