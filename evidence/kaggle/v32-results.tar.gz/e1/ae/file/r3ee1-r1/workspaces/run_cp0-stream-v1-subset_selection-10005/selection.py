def allocate(items, capacity):
    """Select a subset of items maximizing total score within capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    Ties on total score are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by (score descending, id ascending) so that higher scores come first
    # and ties are broken by the lexicographically smallest id.
    entries.sort(key=lambda e: (-e[2], e[0]))

    # Classic 0/1 knapsack DP over capacity.
    # dp[c] = best (score, id_list) achievable with total size exactly c.
    # We track the chosen ids to resolve ties lexicographically.
    dp = [(0, []) for _ in range(capacity + 1)]

    for item_id, size, score in entries:
        # Iterate capacity downward so each item is used at most once.
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[c - size]
            cand_score = prev_score + score
            cand_ids = prev_ids + [item_id]
            cur_score, cur_ids = dp[c]
            if cand_score > cur_score:
                dp[c] = (cand_score, cand_ids)
            elif cand_score == cur_score and cand_ids < cur_ids:
                # Tie on score: prefer lexicographically smaller id list.
                dp[c] = (cand_score, cand_ids)

    # Find the best score among all capacities <= capacity.
    best_score = 0
    best_ids = []
    for c in range(capacity + 1):
        score, ids = dp[c]
        if score > best_score or (score == best_score and ids < best_ids):
            best_score = score
            best_ids = ids

    return sorted(best_ids)
