def count_entries(lines):
    """Count occurrences of log levels in lines.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (reported upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service: (with message optional)
        if len(parts) < 3:
            continue
        timestamp = parts[0]
        level = parts[1].upper()
        # Validate timestamp format (basic check)
        try:
            int(timestamp)
        except ValueError:
            continue
        # Check for service: pattern after level
        if len(parts) < 4 or not parts[2].endswith(':'):
            continue
        # Count this line
        counts[level] = counts.get(level, 0) + 1
    return counts
