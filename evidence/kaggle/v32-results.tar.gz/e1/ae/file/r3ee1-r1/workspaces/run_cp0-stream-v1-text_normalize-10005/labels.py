import unicodedata


def to_key(text):
    """Normalize labels into identifiers.

    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces every run of characters outside [a-z0-9] with a single "_",
    and strips leading and trailing "_". Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lowercase
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for ch in lower:
        if not ch.isalnum():
            if prev_char is not None and prev_char not in "0123456789":
                # Only insert "_" if the previous character was a letter (a-z)
                # This ensures we don't duplicate underscores when numbers are adjacent
                result.append("_")
        else:
            prev_char = ch
    return "".join(result).strip("_")
