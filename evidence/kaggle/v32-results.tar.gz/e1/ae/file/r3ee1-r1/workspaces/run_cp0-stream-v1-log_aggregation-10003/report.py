def aggregate_log(lines):
    """Aggregate log lines into {service_name: count} for ERROR and WARN levels.
    
    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"
    
    Only counts lines with level ERROR or WARN (case-insensitive).
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service:
        if len(parts) < 3:
            continue
        
        level = parts[1].upper()
        service = parts[2]
        
        # Check if service contains a colon (e.g., "service:")
        if not service.endswith(':'):
            continue
        
        service_name = service[:-1]
        
        # Only count ERROR and WARN levels
        if level not in ('ERROR', 'WARN'):
            continue
        
        counts[service_name] = counts.get(service_name, 0) + 1
    
    return counts
