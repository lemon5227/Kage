def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity. Ties on total value are broken by returning the
    lexicographically smallest sorted id list. An empty selection is
    allowed. Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # Sort by id so that we can reason about tie-breaking consistently.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = best (value, chosen_ids) achievable with weight exactly w.
    # We track the chosen ids to resolve ties lexicographically.
    # Initialize with (0, []) for weight 0.
    dp = [(0, [])] * (capacity + 1)

    for idx in range(n):
        item_id, weight, value = entries[idx]
        # Iterate weights descending so each item is used at most once.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = prev_ids + [item_id]
            if cand_value > dp[w][0]:
                dp[w] = (cand_value, cand_ids)
            elif cand_value == dp[w][0]:
                # Tie on value: prefer lexicographically smallest sorted id list.
                if sorted(cand_ids) < sorted(dp[w][1]):
                    dp[w] = (cand_value, cand_ids)

    # Find the maximum value across all weights <= capacity.
    best_value = 0
    best_ids = []
    for w in range(capacity + 1):
        value, ids = dp[w]
        if value > best_value:
            best_value = value
            best_ids = ids
        elif value == best_value:
            if sorted(ids) < sorted(best_ids):
                best_ids = ids

    return best_ids
