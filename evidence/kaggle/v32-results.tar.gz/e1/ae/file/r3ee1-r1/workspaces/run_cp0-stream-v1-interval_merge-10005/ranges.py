def merge_slots(intervals):
    """Combine overlapping time ranges.

    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals as [start, end] lists, sorted by start ascending.
    Touching intervals (e.g. [1,3] and [3,5]) are NOT merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    normalized = []
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        normalized.append([start, end])

    # Sort by start time, then by end time for deterministic ordering.
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    merged = []
    for interval in normalized:
        start, end = interval[0], interval[1]
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1][0], merged[-1][1]
            # Only merge if there is a real overlap (end > last_end).
            # Touching intervals (end == last_end) are NOT merged.
            if end > last_end:
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])

    return merged
