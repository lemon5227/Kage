import unicodedata


def slugify(text):
    """Build a URL slug from text.

    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces every run of characters outside [a-z0-9] with a single "-",
    and strips leading and trailing "-". Non-string input raises TypeError.
    """
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization decomposes characters; diacritics become separate
    # components which will be dropped by the next step.
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (anything outside the ASCII range).
    text = "".join(ch for ch in text if ord(ch) < 128)

    # Lowercase.
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-".
    normalized = []
    prev_char = None
    for ch in text:
        if ch.isalnum():
            normalized.append(ch)
        else:
            if prev_char is not None:
                # Start of a new run of non-alphanumeric chars.
                normalized.append("-")
            prev_char = ch

    text = "".join(normalized)

    # Strip leading and trailing "-".
    text = text.strip("-")

    return text
