def allocate(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without modifying the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # Sort by gain descending, then by cost ascending for tie-breaking.
    entries.sort(key=lambda e: (e[2], -e[1]))

    # Greedy selection by gain, tracking total cost and the chosen ids.
    chosen = []
    total_cost = 0
    for item_id, cost, gain in entries:
        if total_cost + cost <= capacity:
            chosen.append(item_id)
            total_cost += cost

    return sorted(chosen)
