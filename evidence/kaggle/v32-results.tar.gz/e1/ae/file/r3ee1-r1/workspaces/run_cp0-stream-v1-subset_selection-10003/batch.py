def pick_jobs(items, capacity):
    """Choose parcels to maximize total score while total size stays <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible. If several selections tie on total
    score, return the lexicographically smallest sorted id list. An empty
    selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # Sort items by score descending, then by id ascending for tie-breaking
    # This ordering ensures that when we iterate, we consider higher scores first,
    # and among equal scores, the lexicographically smaller id comes first.
    sorted_items = sorted(
        items,
        key=lambda item: (-item["score"], item["id"])
    )

    # Greedy selection: iterate through sorted items and pick each if it fits
    chosen = []
    remaining_capacity = capacity

    for item in sorted_items:
        if remaining_capacity >= item["size"]:
            chosen.append(item["id"])
            remaining_capacity -= item["size"]

    return sorted(chosen)
