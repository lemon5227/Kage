import unicodedata


def make_handle(text):
    """Turn a title into a handle.

    Apply NFKD normalization, drop non-ASCII characters, lower-case,
    replace every run of characters outside [a-z0-9] with a single "-",
    strip leading and trailing "-", and if longer than 23 characters,
    cut to 23 and then strip a trailing "-".
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    normalized = unicodedata.normalize("NFKD", text)
    # Drop non-ASCII characters
    ascii_only = "".join(c for c in normalized if ord(c) < 128)
    # Lower-case
    ascii_only = ascii_only.lower()
    # Replace every run of characters outside [a-z0-9] with a single "-"
    parts = []
    current = ""
    for c in ascii_only:
        if c.isalnum():
            current += c
        else:
            if current:
                parts.append(current)
                current = ""
            parts.append("-")
    if current:
        parts.append(current)

    handle = "".join(parts)
    # Strip leading and trailing "-"
    handle = handle.strip("-")
    # If longer than 23 characters, cut to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.rstrip("-")

    return handle
