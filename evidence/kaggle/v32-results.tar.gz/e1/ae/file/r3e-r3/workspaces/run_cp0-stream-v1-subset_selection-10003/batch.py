def pick_jobs(items, capacity):
    """Choose a subset of items maximizing total score within capacity.

    Each item is a dict with a unique string "id", a positive integer
    "size" and a non-negative integer "score". Returns the sorted list of
    ids whose total score is as large as possible while total size stays
    <= capacity. Ties on total score are broken by the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    n = len(entries)
    if n == 0:
        return []

    # Sort by id so that we can reason about lexicographic tie-breaking.
    entries.sort(key=lambda e: e[0])

    # dp[c] = best (score, chosen_ids) achievable with capacity exactly c,
    # plus the chosen ids for tie-breaking. We track the chosen ids to
    # resolve ties lexicographically.
    # Using a dict keyed by capacity, storing (score, tuple_of_ids).
    # Initialize with (0, ()) for capacity 0.
    dp = [(0, ())]  # index 0 -> (score, ids)
    # We'll grow the list as needed.

    for idx in range(n):
        item_id, size, score = entries[idx]
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[c - size]
            cand_score = prev_score + score
            cand_ids = prev_ids + (item_id,)
            # Check if this candidate is better: higher score, or same score
            # but lexicographically smaller id list.
            if c < len(dp):
                cur_score, cur_ids = dp[c]
                if cand_score > cur_score or (
                    cand_score == cur_score and cand_ids < cur_ids
                ):
                    dp[c] = (cand_score, cand_ids)
            else:
                # Capacity c is beyond what we've tracked; store it.
                dp.append((cand_score, cand_ids))

    # Find the best score across all capacities <= capacity.
    best_score = 0
    best_ids = ()
    for c in range(capacity + 1):
        if c < len(dp):
            score, ids = dp[c]
            if score > best_score or (
                score == best_score and ids < best_ids
            ):
                best_score = score
                best_ids = ids

    return list(best_ids)
