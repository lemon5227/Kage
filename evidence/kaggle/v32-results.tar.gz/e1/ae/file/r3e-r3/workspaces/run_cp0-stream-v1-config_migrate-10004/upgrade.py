def migrate(cfg):
    """Migrate a v1 config dict to v2.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys: "pwd_file" -> "password_file", "user" -> "username".
    Moves "cache_size" and "workers" into a sub-dict "network" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1, got {}".format(cfg.get("version")))

    # Make a copy so we don't modify the input
    result = {}
    result["version"] = 2

    # Process each key in the original config
    for key, value in cfg.items():
        if value is None:
            # Drop keys whose value is None
            continue

        if key == "pwd_file":
            result["password_file"] = value
        elif key == "user":
            result["username"] = value
        elif key == "cache_size":
            # Move into network sub-dict
            if "network" not in result:
                result["network"] = {}
            result["network"]["cache_size"] = value
        elif key == "workers":
            # Move into network sub-dict
            if "network" not in result:
                result["network"] = {}
            result["network"]["workers"] = value
        elif key == "timeout_ms":
            # Convert to timeout_s (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value

    return result
