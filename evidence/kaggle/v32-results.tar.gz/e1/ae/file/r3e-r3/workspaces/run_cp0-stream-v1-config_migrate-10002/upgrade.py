def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Renames top-level keys:
      "dir" -> "directory"
      "pwd_file" -> "password_file"
      "max_conn" -> "max_connections"
    Moves "region" and "retries" into a sub-dict "network".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError(
            "upgrade_config requires cfg['version'] == 1; "
            f"got version {cfg.get('version')}"
        )

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process each key in the original dict
    for key, value in cfg.items():
        if value is None:
            continue  # drop keys with None value

        if key == "dir":
            result["directory"] = value
        elif key == "pwd_file":
            result["password_file"] = value
        elif key == "max_conn":
            result["max_connections"] = value
        elif key == "region":
            # Move into network sub-dict
            network = result.get("network", {})
            network["region"] = value
            result["network"] = network
        elif key == "retries":
            # Move into network sub-dict
            network = result.get("network", {})
            network["retries"] = value
            result["network"] = network
        elif key == "timeout_ms":
            # Convert milliseconds to seconds (float)
            result["timeout_s"] = float(value) / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value

    return result
