def allocate(items, capacity):
    """Select a subset of items whose total cost is at most capacity
    and total gain is maximized.  Ties on total gain are broken by
    choosing the lexicographically smallest sorted list of ids.

    Each item is a dict with a unique string "id", a positive integer
    "cost" and a non-negative integer "gain".  The input is not modified.

    Raises ValueError if capacity is negative or any cost is <= 0.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    n = len(entries)
    if n == 0:
        return []

    # Sort by id so that we can reason about lexicographic tie-breaking.
    entries.sort(key=lambda e: e[0])

    # dp[c] = best (gain, chosen_ids) achievable with cost exactly c,
    # plus the total cost used.  We track the chosen ids to resolve ties.
    # Using a dict keyed by cost for the best gain, and storing the id list.
    NEG = None
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for idx in range(n):
        item_id, cost, gain = entries[idx]
        # Iterate costs descending so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev = dp[c - cost]
            if prev is None:
                continue
            cand_gain = prev[0] + gain
            cand_ids = prev[1] + [item_id]
            cur = dp[c]
            if cur is None or cand_gain > cur[0]:
                dp[c] = (cand_gain, cand_ids)
            elif cand_gain == cur[0] and cand_ids < cur[1]:
                dp[c] = (cand_gain, cand_ids)

    # Find the best gain across all feasible total costs.
    best_gain = None
    best_ids = None
    for c in range(capacity + 1):
        entry = dp[c]
        if entry is None:
            continue
        gain, ids = entry
        if best_gain is None or gain > best_gain:
            best_gain = gain
            best_ids = ids
        elif gain == best_gain and (best_ids is None or ids < best_ids):
            best_ids = ids

    return best_ids if best_ids is not None else []
