def count_entries(lines):
    """Count lines by log level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (reported upper-case). Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if not level.isalpha():
            continue
        # Validate that the third token is "<service>:" (service followed by a colon).
        service_token = parts[2]
        if not service_token.endswith(":"):
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
