def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Rename top-level keys "user" -> "username", "dir" -> "directory".
    Move "cache_size" and "retries" into a sub-dict "limits" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keep other keys unchanged and drop keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")

    result = {"version": 2}

    # Rename top-level keys
    if "user" in cfg:
        result["username"] = cfg["user"]
    if "dir" in cfg:
        result["directory"] = cfg["dir"]

    # Move cache_size and retries into limits
    result["limits"] = {}
    if "cache_size" in cfg:
        result["limits"]["cache_size"] = cfg["cache_size"]
    if "retries" in cfg:
        result["limits"]["retries"] = cfg["retries"]

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged, drop None values
    for key, value in cfg.items():
        if key in ("user", "dir", "cache_size", "retries", "timeout_ms"):
            continue
        if value is None:
            continue
        result[key] = value

    return result
