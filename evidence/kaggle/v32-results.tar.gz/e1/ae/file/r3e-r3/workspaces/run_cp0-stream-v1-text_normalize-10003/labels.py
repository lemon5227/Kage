import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    current = ""
    for ch in ascii_only:
        if ch.isalnum():
            current += ch
        else:
            if current:
                segments.append(current)
                current = ""
            # non-alphanumeric runs become a single "-"
            if not current and not segments:
                # first run of non-alphanumerics -> "-"
                pass
    if current:
        segments.append(current)

    handle = "-".join(segments)

    # strip leading and trailing "-"
    handle = handle.strip("-")

    return handle
