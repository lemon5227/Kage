def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity. Ties on total value are broken by the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = best (value, chosen_ids) achievable with total weight exactly w.
    # We track the chosen ids so we can reconstruct the solution.
    # Initialize with impossible states (None) except dp[0] = (0, []).
    NEG = None
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for idx in range(n):
        item_id, weight, value = entries[idx]
        # Iterate weights descending so each item is used at most once.
        for w in range(capacity, weight - 1, -1):
            prev = dp[w - weight]
            if prev is None:
                continue
            cand_value = prev[0] + value
            cand_ids = list(prev[1]) + [item_id]
            cur = dp[w]
            if cur is None or cand_value > cur[0]:
                dp[w] = (cand_value, cand_ids)
            elif cand_value == cur[0]:
                # Tie on value: prefer lexicographically smallest sorted id list.
                if sorted(cand_ids) < sorted(cur[1]):
                    dp[w] = (cand_value, cand_ids)

    # Find the best value among all reachable weights.
    best_value = 0
    best_ids = []
    for w in range(capacity + 1):
        entry = dp[w]
        if entry is None:
            continue
        value, ids = entry
        if value > best_value:
            best_value = value
            best_ids = ids
        elif value == best_value:
            if sorted(ids) < sorted(best_ids):
                best_ids = ids

    return sorted(best_ids)
