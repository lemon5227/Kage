def select_tasks(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")

    # 0/1 knapsack via dynamic programming
    # dp[c] = best (gain, sorted_id_list) achievable with total cost exactly c
    # We track the best gain for each possible cost, and among ties we keep
    # the lexicographically smallest sorted id list.
    dp = [None] * (capacity + 1)  # dp[c] = (gain, tuple_of_ids) or None
    dp[0] = (0, ())

    for item in items:
        item_id = item["id"]
        cost = item["cost"]
        gain = item["gain"]

        # Iterate costs descending to avoid reusing the same item multiple times
        for c in range(capacity, cost - 1, -1):
            prev = dp[c - cost]
            if prev is None:
                continue
            new_gain = prev[0] + gain
            new_ids = prev[1] + (item_id,)
            # Compare with existing dp[c]: prefer larger gain, then smaller id list
            if dp[c] is None or new_gain > dp[c][0] or (new_gain == dp[c][0] and new_ids < dp[c][1]):
                dp[c] = (new_gain, new_ids)

    # Find the best overall: maximum gain among all costs <= capacity
    best_gain = 0
    best_ids = ()
    for c in range(capacity + 1):
        entry = dp[c]
        if entry is None:
            continue
        gain, ids = entry
        if gain > best_gain or (gain == best_gain and ids < best_ids):
            best_gain = gain
            best_ids = ids

    return sorted(best_ids)
