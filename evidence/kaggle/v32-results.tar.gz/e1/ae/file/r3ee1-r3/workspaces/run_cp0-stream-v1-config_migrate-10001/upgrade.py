def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output always has "version": 2.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            "Expected configuration version 1, got %r" % version
        )

    # Start with a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process keys in order, preserving their original values
    for key in cfg:
        value = cfg[key]

        # Skip None values
        if value is None:
            continue

        # Handle special key transformations
        if key == "host":
            result["hostname"] = value
        elif key == "max_conn":
            result["max_connections"] = value
        elif key == "pwd_file":
            result["password_file"] = value
        elif key == "port":
            # Move port into storage sub-dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["port"] = value
        elif key == "retries":
            # Move retries into storage sub-dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["retries"] = value
        elif key == "timeout_ms":
            # Convert timeout_ms to timeout_s (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value

    return result
