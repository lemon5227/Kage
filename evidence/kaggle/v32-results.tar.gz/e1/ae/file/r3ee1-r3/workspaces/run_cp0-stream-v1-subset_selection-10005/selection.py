def allocate(items, capacity):
    """Select a subset of items whose total size is <= capacity and total score is maximized.
    
    Each item is a dict with a unique string "id", a positive integer "size" and a non-negative integer "score".
    Returns the sorted list of ids of the selected items. If several selections tie on total score,
    returns the lexicographically smallest sorted id list. An empty selection is allowed.
    
    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")
    
    # 0/1 knapsack via DP over capacity
    # dp[c] = best (score, sorted_id_list) achievable with total size exactly c
    # We track the best score for each capacity, and among ties the lex-smallest id list.
    # Initialize dp[0] = (0, []) and dp[c] = None for c > 0.
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])
    
    for item in items:
        idx = item["id"]
        size = item["size"]
        score = item["score"]
        # Iterate capacities downward so each item is used at most once per capacity
        for c in range(capacity, size - 1, -1):
            prev = dp[c - size]
            if prev is None:
                continue
            cand_score = prev[0] + score
            cand_ids = sorted(prev[1] + [idx])
            cur = dp[c]
            if cur is None or cand_score > cur[0] or (cand_score == cur[0] and cand_ids < cur[1]):
                dp[c] = (cand_score, cand_ids)
    
    # Find the best score across all capacities <= capacity
    best_score = 0
    best_ids = []
    for c in range(capacity + 1):
        entry = dp[c]
        if entry is None:
            continue
        score, ids = entry
        if score > best_score or (score == best_score and ids < best_ids):
            best_score = score
            best_ids = ids
    
    return best_ids
