def migrate(cfg):
    """Migrate a v1 config dict to v2.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1, got %r" % cfg.get("version"))

    # Work on a copy to avoid modifying the input
    result = {}
    result["version"] = 2

    # Process keys
    for key in list(cfg.keys()):
        value = cfg[key]

        # Drop keys with None values
        if value is None:
            continue

        # Handle specific key transformations
        if key == "pwd_file":
            result["password_file"] = value
        elif key == "user":
            result["username"] = value
        elif key == "cache_size":
            # Move into network sub-dict
            if "network" not in result:
                result["network"] = {}
            result["network"]["cache_size"] = value
        elif key == "workers":
            # Move into network sub-dict
            if "network" not in result:
                result["network"] = {}
            result["network"]["workers"] = value
        elif key == "timeout_ms":
            # Convert to timeout_s (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value

    return result
