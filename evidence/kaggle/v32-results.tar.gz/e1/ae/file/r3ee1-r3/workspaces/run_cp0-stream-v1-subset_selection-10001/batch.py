def allocate(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")

    # Handle empty items list
    if not items:
        return []

    # Create a list of (id, cost, gain) tuples
    entries = []
    for item in items:
        entry = (item["id"], item["cost"], item["gain"])
        entries.append(entry)

    # Sort by gain descending, then by id ascending for tie-breaking
    # This ensures we consider higher gain items first, and for equal gains,
    # we prefer lexicographically smaller ids.
    entries.sort(key=lambda e: (-e[2], e[0]))

    # Greedy selection: iterate through sorted entries and select if capacity allows
    selected = []
    total_cost = 0
    total_gain = 0

    for entry in entries:
        item_id, cost, gain = entry
        if total_cost + cost <= capacity:
            selected.append(item_id)
            total_cost += cost
            total_gain += gain

    return sorted(selected)
