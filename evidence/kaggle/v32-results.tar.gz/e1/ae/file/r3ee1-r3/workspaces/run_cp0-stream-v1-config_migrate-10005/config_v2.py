def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys: "user" -> "username", "dir" -> "directory".
    Moves "cache_size" and "retries" into a sub-dict "limits" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1, got " + str(cfg.get("version")))

    # Start with a fresh dict to avoid mutating the input
    result = {}

    # Copy over existing keys that are not None
    for key, value in cfg.items():
        if value is None:
            continue  # drop keys with None values

        if key == "user":
            result["username"] = value
        elif key == "dir":
            result["directory"] = value
        elif key == "cache_size":
            # Move into limits sub-dict
            if "limits" not in result:
                result["limits"] = {}
            result["limits"]["cache_size"] = value
        elif key == "retries":
            # Move into limits sub-dict
            if "limits" not in result:
                result["limits"] = {}
            result["limits"]["retries"] = value
        elif key == "timeout_ms":
            # Convert milliseconds to seconds (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value

    # Ensure version is set to 2 in the output
    result["version"] = 2

    return result
