import unicodedata


def slugify(text):
    """Build a URL slug from text.

    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces every run of characters outside [a-z0-9] with a single "-",
    and strips leading and trailing "-". Non-string input raises TypeError.
    """
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization decomposes characters; diacritics become separate
    # components that will be filtered out below.
    normalized = unicodedata.normalize("NFKD", text)

    # Keep only ASCII characters (a-z, A-Z, 0-9) and drop non-ASCII.
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lowercase the string.
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-".
    # This is equivalent to splitting on non-alphanumeric runs and joining
    # with a single hyphen.
    parts = [part for part in lower.split() if part]
    slug = "-".join(parts)

    # Strip leading and trailing hyphens.
    slug = slug.strip("-")

    return slug
