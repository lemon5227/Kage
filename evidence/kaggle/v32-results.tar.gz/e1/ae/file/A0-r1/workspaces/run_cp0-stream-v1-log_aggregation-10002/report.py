def digest_lines(lines):
    result = {}
    for line in lines:
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        # Check if service part contains colon
        if ':' not in parts[2]:
            continue
        result[level] = result.get(level, 0) + 1
    return result
