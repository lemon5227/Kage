def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per service for levels ERROR, WARN only, case-insensitively (uppercase keys),
    dropping malformed input lines."""
    result = {}
    for line in lines:
        # Strip whitespace and check if line is empty
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service (with colon)
        if len(parts) < 3:
            continue
        
        # Extract level and service
        level = parts[1].upper()
        # The service is in parts[2] but it should be followed by a colon
        # Format: <timestamp> <LEVEL> <service>: <message>
        # So parts[2] should be the service name, and we need to check for colon
        if len(parts) < 3 or ':' not in parts[2]:
            continue
        
        service = parts[2].split(':')[0]
        
        # Only count ERROR and WARN levels
        if level in ('ERROR', 'WARN'):
            result[service] = result.get(service, 0) + 1
    
    return result
