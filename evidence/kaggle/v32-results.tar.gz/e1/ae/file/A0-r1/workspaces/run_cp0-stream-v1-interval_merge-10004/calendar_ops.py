def merge_slots(intervals):
    # Check for invalid intervals where start > end
    for start, end in intervals:
        if start > end:
            raise ValueError("Interval start must not be greater than end")
    
    # Sort intervals by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    merged = []
    current_start, current_end = sorted_intervals[0]
    
    for next_start, next_end in sorted_intervals[1:]:
        # Only merge if there is an overlap (next_start < current_end)
        # Touching intervals (next_start == current_end) do not merge
        if next_start < current_end:
            # Merge by updating current_end to the maximum
            current_end = max(current_end, next_end)
        else:
            # No overlap, push current interval and start new one
            merged.append([current_start, current_end])
            current_start, current_end = next_start, next_end
    
    # Add the last interval
    merged.append([current_start, current_end])
    
    return merged
