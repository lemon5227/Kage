import csv
import io

def normalize_table(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with header row (columns: id, email, city, name)
    Output: Cleaned CSV text with the same header
    
    Processing steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "id" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "email", keeping the first occurrence
    5. Sort rows by "email" ascending as strings (stable)
    
    Returns: Empty string if input is empty; header-only input returns just the header line.
    """
    # Parse the CSV text
    lines = text.strip().split('\n')
    
    if not lines:
        return ''
    
    # Check if it's header-only
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    if len(header) != 4 or header[0] != 'id' or header[1] != 'email' or header[2] != 'city' or header[3] != 'name':
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) != 4:
            continue
        
        id_val, email_val, city_val, name_val = cells
        
        # Strip leading/trailing whitespace from every cell
        id_val = id_val.strip()
        email_val = email_val.strip()
        city_val = city_val.strip()
        name_val = name_val.strip()
        
        # Drop rows whose "id" cell is empty
        if not id_val:
            continue
        
        # Lower-case the "email" column
        email_val = email_val.lower()
        
        rows.append({
            'id': id_val,
            'email': email_val,
            'city': city_val,
            'name': name_val
        })
    
    # Remove duplicate rows by "email", keeping the first occurrence
    seen_emails = set()
    unique_rows = []
    for row in rows:
        if row['email'] not in seen_emails:
            seen_emails.add(row['email'])
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    unique_rows.sort(key=lambda r: r['email'])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(['id', 'email', 'city', 'name'])
    for row in unique_rows:
        writer.writerow([row['id'], row['email'], row['city'], row['name']])
    
    return output.getvalue()
