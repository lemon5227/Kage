import csv
import io


def tidy_csv(text):
    """Clean an exported CSV table with header: name, city, score, team."""
    # Parse the input text into lines
    lines = text.strip().split('\n')
    
    # Handle empty or header-only input
    if not lines:
        return ''
    
    # Extract header
    header = lines[0].strip()
    
    # Check if it's just a header (no data rows)
    if len(lines) == 1:
        return header
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        # Strip leading/trailing whitespace from the entire line
        line = line.strip()
        if not line:
            continue
        
        # Split by comma, but handle potential quoted fields
        # Use csv reader for proper parsing
        try:
            reader = csv.reader(io.StringIO(line))
            row = next(reader)
        except Exception:
            continue
        
        # Strip whitespace from each cell
        row = [cell.strip() for cell in row]
        
        # Skip rows where name is empty
        if not row[0]:
            continue
        
        rows.append(row)
    
    # Remove duplicate rows by name, keeping first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        name = row[0]
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Sort by city (column 1) ascending as strings, stable sort
    unique_rows.sort(key=lambda row: row[1])
    
    # Build output CSV text with \n line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header.split(','))
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
