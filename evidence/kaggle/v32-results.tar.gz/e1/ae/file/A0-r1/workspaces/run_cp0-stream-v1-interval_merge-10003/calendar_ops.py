def merge_slots(intervals):
    """
    Combines overlapping time ranges. Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort intervals by start time
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping or touching intervals
    merged = []
    for interval in sorted_intervals:
        start = interval["start"]
        end = interval["end"]
        
        if not merged:
            merged.append({"start": start, "end": end})
        else:
            last = merged[-1]
            # If intervals overlap or touch (end == start), merge them
            if end >= last["end"]:
                # Update the end of the last interval to the maximum end
                last["end"] = max(last["end"], end)
            else:
                # No overlap, add this interval as a new one
                merged.append({"start": start, "end": end})
    
    return merged
