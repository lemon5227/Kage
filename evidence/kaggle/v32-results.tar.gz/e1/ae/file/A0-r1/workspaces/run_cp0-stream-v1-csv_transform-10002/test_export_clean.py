#!/usr/bin/env python3
"""Test export_clean.py"""

from export_clean import normalize_table

# Test 1: Basic functionality
test1 = "name,team,city,id,score\nAlice,TeamA,City1,1,A\nBob,TeamB,City2,2,B"
result1 = normalize_table(test1)
print("Test 1 - Basic:")
print(result1)
print()

# Test 2: Empty input
test2 = ""
result2 = normalize_table(test2)
print("Test 2 - Empty input:")
print(repr(result2))
print()

# Test 3: Header only
test3 = "name,team,city,id,score"
result3 = normalize_table(test3)
print("Test 3 - Header only:")
print(repr(result3))
print()

# Test 4: Duplicate score (keep first)
test4 = "name,team,city,id,score\nAlice,TeamA,City1,1,A\nBob,TeamB,City2,1,B"
result4 = normalize_table(test4)
print("Test 4 - Duplicate score:")
print(result4)
print()

# Test 5: Whitespace stripping
test5 = " name , team , city , id , score \n Alice , TeamA , City1 , 1 , A \n Bob , TeamB , City2 , 2 , B "
result5 = normalize_table(test5)
print("Test 5 - Whitespace stripping:")
print(result5)
print()

# Test 6: Sort by id ascending (stable)
test6 = "name,team,city,id,score\nAlice,TeamA,City1,2,A\nBob,TeamB,City2,1,B\nCharlie,TeamC,City3,3,C"
result6 = normalize_table(test6)
print("Test 6 - Sort by id:")
print(result6)
