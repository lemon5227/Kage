import unicodedata


def slugify(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("Expected string, got {}".format(type(text).__name__))

    # NFKD normalization + drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    current = []
    for ch in ascii_only:
        if ch.isalnum():  # [a-z0-9] after lower-casing
            current.append(ch)
        else:
            if current:
                segments.append("".join(current))
                current = []
            # non-alnum runs become a single "-"
            segments.append("-")

    if current:
        segments.append("".join(current))

    # strip leading and trailing "-"
    slug = "".join(segments).strip("-")

    return slug
