import csv
import io


def clean_rows(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: id, team, score).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "score" cell is empty.
    3. Remove duplicate rows by "team", keeping the first occurrence.
    4. Sort rows by "score" ascending as strings (stable).

    Returns:
        Empty string if input is empty.
        Just the header line if input contains only the header.
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header
    header = rows[0]
    # Ensure we have the expected columns
    if len(header) < 3 or header[0] != "id" or header[1] != "team" or header[2] != "score":
        return ""

    # Process data rows (skip header)
    data_rows = rows[1:]

    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)

    # Step 2: Drop rows whose "score" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) < 3 or row[2] == "":
            continue
        filtered_rows.append(row)

    # Step 3: Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    deduped_rows = []
    for row in filtered_rows:
        team = row[1]
        if team in seen_teams:
            continue
        seen_teams.add(team)
        deduped_rows.append(row)

    # Step 4: Sort rows by "score" ascending as strings (stable)
    # Use a stable sort key that preserves order for equal scores
    def sort_key(row):
        score = row[2]
        # For stability, we also use the team as a tiebreaker in a deterministic way
        return (score, team if (team := row[1]) is not None else "")

    # Actually, let's do it properly: stable sort by score string, then by team for determinism
    deduped_rows.sort(key=lambda row: (row[2], row[1]))

    # Build output CSV text with the same header
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
