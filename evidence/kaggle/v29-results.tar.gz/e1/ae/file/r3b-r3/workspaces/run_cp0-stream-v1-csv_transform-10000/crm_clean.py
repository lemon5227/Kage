import csv
import io


def normalize_table(text):
    """Clean CSV text with header row (columns: score, id, email, name).

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Lower-case the "email" column.
    - Remove duplicate rows by "name", keeping the first occurrence.
    - Sort rows by "email" ascending as strings (stable).

    Returns cleaned CSV text with the same header.
    Empty string returns ''; a header-only input returns just the header line.
    Output uses '\n' line endings via csv module.
    """
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Parse header
    header = [cell.strip() for cell in rows[0]]
    # Ensure we have the expected columns
    expected = ["score", "id", "email", "name"]
    if len(header) != len(expected):
        # If header doesn't match, just use what we have
        pass
    else:
        # Map columns by name
        col_idx = {name: i for i, name in enumerate(header)}
    else:
        col_idx = {name: i for i, name in enumerate(header)}

    data = []
    for row in rows[1:]:
        cells = [cell.strip() for cell in row] if row else []
        # Ensure we have enough cells
        while len(cells) < len(expected):
            cells.append("")
        # Extract fields by index
        score = cells[col_idx.get("score", 0)] if "score" in col_idx else ""
        id_val = cells[col_idx.get("id", 0)] if "id" in col_idx else ""
        email = cells[col_idx.get("email", 0)] if "email" in col_idx else ""
        name = cells[col_idx.get("name", 0)] if "name" in col_idx else ""

        # Drop rows whose "name" cell is empty
        if not name:
            continue

        # Lower-case the "email" column
        if email:
            email = email.lower()

        data.append((score, id_val, email, name))

    # Remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    unique_data = []
    for item in data:
        if item[3] in seen:
            continue
        seen.add(item[3])
        unique_data.append(item)

    # Sort rows by "email" ascending as strings (stable)
    unique_data.sort(key=lambda x: x[2])

    # Write output using csv module with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    # Write header
    writer.writerow(header)
    # Write data rows
    for score, id_val, email, name in unique_data:
        writer.writerow([score, id_val, email, name])

    return out.getvalue()
