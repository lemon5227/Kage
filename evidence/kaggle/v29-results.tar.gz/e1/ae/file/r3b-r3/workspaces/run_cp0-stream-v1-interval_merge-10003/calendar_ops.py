def merge_slots(intervals):
    """Combine overlapping time ranges in intervals.
    
    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Touching intervals like [1,3] and [3,5]
    are merged. Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate all intervals first
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping or touching intervals
    merged = []
    for interval in sorted_intervals:
        start = interval["start"]
        end = interval["end"]
        
        if not merged:
            merged.append({"start": start, "end": end})
        else:
            last = merged[-1]
            # Touching or overlapping intervals should be merged
            if start <= last["end"]:
                # Merge by updating the end time
                last["end"] = max(last["end"], end)
            else:
                merged.append({"start": start, "end": end})
    
    return merged
