def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize('NFKD', text)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single underscore
    result = []
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is not None:
                result.append('_')
            prev_char = None
        else:
            result.append(char)
            prev_char = char
    
    slug = ''.join(result)
    
    # Strip leading and trailing underscores
    return slug.strip('_')
