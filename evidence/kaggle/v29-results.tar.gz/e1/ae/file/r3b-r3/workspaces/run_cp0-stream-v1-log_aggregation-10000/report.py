def count_entries(lines):
    """Count occurrences of log levels in lines.
    
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (reported upper-case). Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service:
        if len(parts) < 3:
            continue
        level = parts[1]
        # Validate that the level part looks like a log level (non-empty, no colons)
        if not level or ':' in level:
            continue
        # Count this level
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
