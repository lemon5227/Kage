def select_tasks(items, capacity):
    """Select a subset of items maximizing total score with total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and normalize items
    normalized = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        normalized.append((item["id"], size, score))

    # 0/1 knapsack DP over capacity
    # dp[c] = (max_score, sorted_ids) for capacity c
    # We track the actual selection to handle tie-breaking.
    # Use a list of tuples: (score, tuple_of_ids) for each capacity.
    # Initialize dp[0] = (0, ()) and -inf for others to indicate unreachable.
    NEG_INF = None  # marker for unreachable
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for item_id, size, score in normalized:
        # Iterate capacity descending for 0/1 knapsack
        for c in range(capacity, size - 1, -1):
            prev = dp[c - size]
            if prev is None:
                continue
            cand_score = prev[0] + score
            cand_ids = prev[1] + (item_id,)
            cur = dp[c]
            # Compare: higher score wins; if tie, lexicographically smaller ids wins
            if cur is None or cand_score > cur[0] or (cand_score == cur[0] and cand_ids < cur[1]):
                dp[c] = (cand_score, cand_ids)

    # The answer is the best among all capacities <= capacity
    best_score = None
    best_ids = None
    for c in range(capacity + 1):
        entry = dp[c]
        if entry is None:
            continue
        score, ids = entry
        if best_score is None or score > best_score or (score == best_score and ids < best_ids):
            best_score = score
            best_ids = ids

    return list(best_ids)
