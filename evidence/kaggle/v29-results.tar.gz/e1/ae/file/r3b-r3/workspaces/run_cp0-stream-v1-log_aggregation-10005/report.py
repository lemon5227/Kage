def summarize(lines):
    """Count WARN lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each service for levels WARN only to how many lines it has.
    Levels are case-insensitive (reported upper-case). Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        service = parts[2]
        # Only count WARN lines
        if level != "WARN":
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
