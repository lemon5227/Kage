import csv
import io


def tidy_csv(text):
    """Clean an exported table with columns: name, city, score, team.

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Remove duplicate rows by "name", keeping the first occurrence.
    - Sort rows by "city" ascending as strings (stable).
    - Output uses '\\n' line endings.

    Returns '' for empty input, and just the header line for a header-only input.
    """
    # Parse CSV text into a list of dicts
    reader = csv.reader(io.StringIO(text))
    rows = []
    for row in reader:
        # Strip whitespace from each cell
        cleaned = [cell.strip() for cell in row]
        rows.append(cleaned)

    if not rows:
        return ""

    # Extract header (first row)
    header = rows[0]
    data = rows[1:]

    # Drop rows whose "name" cell is empty
    name_idx = 0  # first column is "name"
    data = [r for r in data if r[name_idx] != ""]

    # Remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for r in data:
        name = r[name_idx]
        if name in seen:
            continue
        seen.add(name)
        deduped.append(r)

    # Sort rows by "city" ascending as strings (stable)
    city_idx = 1  # second column is "city"
    deduped.sort(key=lambda r: r[city_idx])

    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(header)
    for r in deduped:
        writer.writerow(r)
    return out.getvalue()
