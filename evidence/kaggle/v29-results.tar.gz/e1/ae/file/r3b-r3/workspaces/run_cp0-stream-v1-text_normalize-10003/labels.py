def make_handle(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case the result.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters, then filter to ASCII only.
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case.
    lower = ascii_only.lower()

    # Replace runs of non-alphanumeric characters with a single "-".
    # We need to handle the case where there are consecutive non-alnum chars.
    result = []
    current_run = []
    for ch in lower:
        if ch.isalnum():
            current_run.append(ch)
        else:
            if current_run:
                result.append("".join(current_run))
                current_run = []
            # Non-alnum char starts a new run - we'll add "-" later
            # Actually, we need to replace the run with "-", not keep it
            # Let's track runs of non-alnum separately
    # This approach is getting complex. Let's do it properly:
    
    # Build the slug by processing character by character
    slug_parts = []
    in_run = False
    for ch in lower:
        if ch.isalnum():
            if not in_run:
                slug_parts.append(ch)
                in_run = True
            # else continue adding to current part
        else:
            if in_run:
                # We're in a non-alnum run, add the separator
                slug_parts.append("-")
                in_run = False
            # else start a new run
    
    # Strip leading and trailing "-"
    while slug_parts and slug_parts[0] == "-":
        slug_parts.pop(0)
    while slug_parts and slug_parts[-1] == "-":
        slug_parts.pop(-1)
    
    return "".join(slug_parts) if slug_parts else ""
