import unicodedata


def to_key(text):
    """Normalize labels into identifiers.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "_".
    - Strip leading and trailing "_".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks.
    normalized = unicodedata.normalize("NFKD", text)

    # Keep only ASCII characters (0-127), dropping non-ASCII.
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case.
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_".
    # This handles punctuation, spaces, digits (already kept), etc.
    # We'll use regex to find sequences of non-alphanumeric chars and replace with "_".
    import re
    normalized = re.sub(r"[^a-z0-9]+", "_", lower)

    # Strip leading and trailing "_".
    return normalized.strip("_")
