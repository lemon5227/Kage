def aggregate_log(lines):
    """Aggregate log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    
    Returns {name: count} per service for levels ERROR, WARN only,
    treating level names case-insensitively (upper-case keys), dropping
    malformed input lines.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # Split into at most 4 parts
        if len(parts) < 3:
            continue
        # Format: [timestamp] [LEVEL] [service]: [message]
        level = parts[1].upper() if parts[1] else ""
        service = parts[2] if len(parts) > 2 else ""
        if not service or not level:
            continue
        if level not in ("ERROR", "WARN"):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
