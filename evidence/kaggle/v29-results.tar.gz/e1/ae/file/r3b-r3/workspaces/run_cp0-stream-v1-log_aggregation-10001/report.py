def tally_events(lines):
    """Tally ERROR and WARN log entries per service.
    
    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"
    
    Only counts entries with level ERROR or WARN (case-insensitive).
    Returns a dict mapping service name (uppercase) to count.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # split into timestamp, level, service:, message
        if len(parts) < 3:
            continue
        _, level, service_part = parts[0], parts[1], parts[2]
        # The service name is everything before the first colon in service_part
        if ':' in service_part:
            service_name = service_part.split(':', 1)[0]
        else:
            service_name = service_part
        level_upper = level.upper()
        if level_upper not in ('ERROR', 'WARN'):
            continue
        # Normalize service name to uppercase for the key
        key = service_name.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
