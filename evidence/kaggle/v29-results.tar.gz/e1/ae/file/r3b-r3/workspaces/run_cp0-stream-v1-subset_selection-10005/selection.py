def allocate(items, capacity):
    """Select a subset of items maximizing total score within capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer
      - "score": non-negative integer

    Returns the sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total
    score, return the lexicographically smallest sorted id list. An empty
    selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # DP over capacity: dp[c] = (max_score, sorted_id_list) for capacity c
    # We track the best (score, id_list) achievable at each capacity.
    # Initialize with (0, []) at capacity 0.
    dp = [(0, [])] * (capacity + 1)

    for item in items:
        idx = item["id"]
        size = item["size"]
        score = item["score"]

        # Iterate capacities downward to avoid using the same item twice
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[c - size]
            cand_score = prev_score + score
            cand_ids = sorted(prev_ids + [idx])

            # Compare: prefer higher score; if tie, lexicographically smaller id list
            if (cand_score, cand_ids) > (dp[c][0], dp[c][1]):
                dp[c] = (cand_score, cand_ids)

    best_score, best_ids = dp[capacity]
    return best_ids
