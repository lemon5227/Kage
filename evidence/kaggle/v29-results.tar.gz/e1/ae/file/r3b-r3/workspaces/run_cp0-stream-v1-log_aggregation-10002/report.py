def digest_lines(lines):
    """Process log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    
    Returns a dict {name: count} per level, treating level names case-insensitively
    (upper-case keys), dropping malformed input lines.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Format: <timestamp> <LEVEL> <service>: <message>
        # At minimum we need timestamp, level, and service (with colon)
        if len(parts) < 3:
            continue
        timestamp = parts[0]
        level = parts[1].upper()  # case-insensitive, upper-case key
        # Check if service is present with colon
        if len(parts) >= 3 and not parts[2].endswith(':'):
            # Malformed: need service followed by colon
            continue
        # If we have at least 3 parts and part[2] ends with ':', then service is parts[2] without colon
        if len(parts) >= 3 and parts[2].endswith(':'):
            service = parts[2][:len(parts[2])-1]
        else:
            # Only timestamp and level provided, no service - malformed
            continue
        
        # Count this level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
