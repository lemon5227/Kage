def pick_jobs(items, capacity):
    """Choose parcels to maximize total score while total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # 0/1 knapsack: dp[w] = (max_score, chosen_ids) for capacity w
    # We track the chosen items to reconstruct the solution.
    # dp[w] = (score, tuple of ids)
    dp = [(0, ()) for _ in range(capacity + 1)]

    for item in items:
        idx = item["id"]
        size = item["size"]
        score = item["score"]

        # Iterate capacity descending to avoid using the same item twice
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[w - size]
            cand_score = prev_score + score
            cand_ids = prev_ids + (idx,)
            if cand_score > dp[w][0]:
                dp[w] = (cand_score, cand_ids)

    # Find the best score among all capacities <= capacity
    best_score = 0
    best_ids = ()
    for w in range(capacity + 1):
        score, ids = dp[w]
        if score > best_score:
            best_score = score
            best_ids = ids

    # Tie-breaker: lexicographically smallest sorted id list
    # Since we always pick the first occurrence of a better score,
    # and we iterate w from 0 to capacity, we need to check ties.
    # Actually, we should re-check for ties at the best_score.
    for w in range(capacity + 1):
        score, ids = dp[w]
        if score == best_score:
            # Compare lexicographically; keep the smaller one
            if ids < best_ids:
                best_ids = ids

    return sorted(best_ids)
