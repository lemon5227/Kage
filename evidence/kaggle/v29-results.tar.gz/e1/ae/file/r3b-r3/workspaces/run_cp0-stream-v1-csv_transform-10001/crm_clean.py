import csv
import io


def clean_rows(text):
    """Clean CSV text with header row (columns: team, name, city, id, score).

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "score" cell is empty.
    - Remove duplicate rows by "score", keeping the first occurrence.
    - Sort rows by "name" ascending as strings (stable).
    Returns cleaned CSV text with the same header.
    Empty string returns ''; a header-only input returns just the header line.
    Output uses '\n' line endings.
    """
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ""

    # Validate header columns
    expected_cols = ["team", "name", "city", "id", "score"]
    if len(header) != len(expected_cols):
        return ""

    # Check that header matches expected columns (order matters)
    if [col.lower() for col in header] != [col.lower() for col in expected_cols]:
        return ""

    rows = []
    seen_scores = set()

    for row in reader:
        if len(row) != len(expected_cols):
            continue

        # Strip whitespace from each cell
        cleaned = [cell.strip() for cell in row]

        # Drop rows whose "score" cell is empty
        score = cleaned[4]
        if score == "":
            continue

        # Remove duplicate rows by "score", keeping the first occurrence
        if score in seen_scores:
            continue
        seen_scores.add(score)

        rows.append(cleaned)

    # Sort rows by "name" ascending as strings (stable)
    rows.sort(key=lambda r: r[1])

    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(rows)
    return out.getvalue()
