def migrate(cfg):
    """Migrate a v1 config dict to v2 format."""
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 config")

    # Create a new dict without modifying the input
    result = {"version": 2}

    # Process keys
    for key, value in cfg.items():
        if key == "pwd_file":
            result["password_file"] = value
        elif key == "user":
            result["username"] = value
        elif key == "cache_size":
            if "network" not in result:
                result["network"] = {}
            result["network"]["cache_size"] = value
        elif key == "workers":
            if "network" not in result:
                result["network"] = {}
            result["network"]["workers"] = value
        elif key == "timeout_ms":
            if value is not None:
                result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged, but drop None values
            if value is not None:
                result[key] = value

    return result
