import unicodedata


def to_key(text):
    """Normalize labels into identifiers.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case the result.
    - Replace every run of characters outside [a-z0-9] with a single "_".
    - Strip leading and trailing "_".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks.
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII).
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case.
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_".
    result = []
    prev_char_is_alnum = False
    for char in lower:
        if char.isalnum():
            if not prev_char_is_alnum:
                result.append(char)
            prev_char_is_alnum = True
        else:
            if result and not prev_char_is_alnum:
                # Start of a run of non-alphanumeric chars.
                result.append("_")
                prev_char_is_alnum = False
    # Strip leading and trailing "_".
    while result and result[0] == "_":
        result.pop(0)
    while result and result[-1] == "_":
        result.pop()
    return "".join(result)
