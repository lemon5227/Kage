def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")

    # Create a new dict for the output
    result = {"version": 2}

    # Process top-level keys
    # Rename "dir" -> "directory", "host" -> "hostname"
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]

    # Move "port" and "workers" into a sub-dict "storage"
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    result["storage"] = storage

    # Handle "timeout_ms" -> "timeout_s"
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged, but drop keys whose value is None
    for key, value in cfg.items():
        if key not in ["dir", "host", "port", "workers", "timeout_ms", "version"]:
            if value is not None:
                result[key] = value

    return result
