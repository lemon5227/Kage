def pick_jobs(items, capacity):
    """Choose parcels to maximize total score within capacity."""
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    # Validate items and build list of (size, score, id)
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        item_id = item["id"]
        
        if not isinstance(item_id, str):
            raise ValueError("item id must be a string")
        if not isinstance(size, int) or size <= 0:
            raise ValueError("item size must be a positive integer")
        if not isinstance(score, int) or score < 0:
            raise ValueError("item score must be a non-negative integer")
        
        entries.append((size, score, item_id))
    
    # Sort by score descending, then by id ascending for tie-breaking
    entries.sort(key=lambda e: (-e[1], e[2]))
    
    # Greedy selection: take items in order until capacity is exceeded
    total_size = 0
    selected = []
    for size, score, item_id in entries:
        if total_size + size <= capacity:
            total_size += size
            selected.append(item_id)
    
    return sorted(selected)
