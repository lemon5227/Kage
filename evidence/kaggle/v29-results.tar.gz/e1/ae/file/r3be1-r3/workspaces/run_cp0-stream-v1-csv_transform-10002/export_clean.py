import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: name, team, city, id, score).
    Output: Cleaned CSV text with the same header.

    Rules:
    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Remove duplicate rows by "score", keeping the first occurrence.
    - Sort rows by "id" ascending as strings (stable).
    - Use '\n' line endings.

    Returns:
        Empty string if input is empty.
        Header-only input returns just the header line.
    """
    # Parse CSV text into a list of rows (each row is a list of cells)
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header and data rows
    header = rows[0]
    data_rows = rows[1:]

    # Strip leading/trailing whitespace from every cell in header and data
    cleaned_header = [cell.strip() for cell in header]
    cleaned_data = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        if not stripped_row:
            continue
        cleaned_data.append(stripped_row)

    # Drop rows whose "name" cell is empty (index 0)
    filtered_data = []
    for row in cleaned_data:
        if not row[0]:
            continue
        filtered_data.append(row)

    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_data = []
    for row in filtered_data:
        score = row[4]
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped_data.append(row)

    # Sort rows by "id" ascending as strings (stable)
    sorted_data = sorted(deduped_data, key=lambda row: row[3])

    # Write output CSV with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(cleaned_header)
    for row in sorted_data:
        writer.writerow(row)

    return output.getvalue()
