import csv
import io


def tidy_csv(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: name, city, score, team).
    Output: Cleaned CSV text with the same header.

    Rules:
    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Remove duplicate rows by "name", keeping the first occurrence.
    - Sort rows by "city" ascending as strings (stable).
    - Write output with '\n' line endings.

    Returns:
        Empty string if input is empty.
        Header-only input returns just the header line.
    """
    # Parse CSV text into a list of dicts
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header
    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Strip whitespace from all cells in all rows
    cleaned_rows = []
    for row in data:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)

    # Drop rows whose "name" cell is empty
    name_index = header.index("name")
    filtered_rows = []
    for row in cleaned_rows:
        if not row[name_index]:
            continue
        filtered_rows.append(row)

    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    deduped_rows = []
    for row in filtered_rows:
        name = row[name_index]
        if name in seen_names:
            continue
        seen_names.add(name)
        deduped_rows.append(row)

    # Sort rows by "city" ascending as strings (stable)
    city_index = header.index("city")
    deduped_rows.sort(key=lambda row: row[city_index])

    # Write output with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
