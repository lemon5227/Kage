import unicodedata


def slugify(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters; non-ASCII are dropped.
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case.
    ascii_only = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-".
    parts = []
    current = []
    for ch in ascii_only:
        if ch.isalnum():
            current.append(ch)
        else:
            if current:
                parts.append("".join(current))
                current = []
            # Use a single hyphen for each run of non-alphanumeric chars.
            parts.append("-")
    if current:
        parts.append("".join(current))

    slug = "-".join(parts)
    return slug.strip("-")
