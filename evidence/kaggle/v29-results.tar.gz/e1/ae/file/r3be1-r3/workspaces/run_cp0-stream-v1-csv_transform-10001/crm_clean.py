import csv
import io


def clean_rows(text):
    """Clean CSV text with header row (columns: team, name, city, id, score).

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "score" cell is empty.
    - Remove duplicate rows by "score", keeping the first occurrence.
    - Sort rows by "name" ascending as strings (stable).
    - Output with '\n' line endings.

    Returns empty string for empty input; returns just the header line
    for a header-only input.
    """
    # Parse CSV text into list of dicts
    reader = csv.reader(io.StringIO(text))
    rows = []
    for row in reader:
        cells = [cell.strip() for cell in row]
        rows.append(dict(zip(row, cells)))

    # Drop rows whose "score" cell is empty
    filtered = [r for r in rows if r["score"] != ""]

    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped = []
    for r in filtered:
        score = r["score"]
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped.append(r)

    # Sort rows by "name" ascending as strings (stable)
    sorted_rows = sorted(deduped, key=lambda r: r["name"])

    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    if sorted_rows:
        writer.writerow(sorted_rows[0].keys())
        for r in sorted_rows[1:]:
            writer.writerow([r[key] for key in sorted_rows[0].keys()])
    return out.getvalue()
