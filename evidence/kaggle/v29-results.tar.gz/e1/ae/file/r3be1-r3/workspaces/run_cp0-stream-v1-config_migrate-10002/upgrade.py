def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            f"Expected version 1, got {version!r} (type {type(version).__name__})"
        )

    # Start with a fresh dict to avoid mutating the input
    new_cfg = {"version": 2}

    # Process top-level keys
    for key in ["dir", "pwd_file", "max_conn"]:
        if key in cfg:
            new_key = {
                "dir": "directory",
                "pwd_file": "password_file",
                "max_conn": "max_connections",
            }[key]
            new_cfg[new_key] = cfg[key]

    # Handle network sub-dict
    network = {}
    for key in ["region", "retries"]:
        if key in cfg:
            network[key] = cfg[key]
    new_cfg["network"] = network

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        timeout_ms = cfg["timeout_ms"]
        if not isinstance(timeout_ms, (int, float)):
            raise ValueError(
                f"timeout_ms must be a number, got {type(timeout_ms).__name__}"
            )
        new_cfg["timeout_s"] = float(timeout_ms) / 1000.0

    # Drop keys with None values
    for key in list(new_cfg.keys()):
        if new_cfg[key] is None:
            del new_cfg[key]

    return new_cfg
