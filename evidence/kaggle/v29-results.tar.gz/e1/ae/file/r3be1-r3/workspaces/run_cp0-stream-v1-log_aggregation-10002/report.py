def digest_lines(lines):
    """Parse log strings in format '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per level (case-insensitive, upper-case keys),
    dropping malformed input lines."""
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # Format: <timestamp> <LEVEL> <service>: <message>
        # We need at least timestamp, level, and service (with colon)
        # The service part must contain a colon to separate it from message
        # Let's parse more carefully
        # First, check if there's a colon in the line after the first two parts
        # Actually, the format is: <timestamp> <LEVEL> <service>: <message>
        # So we need at least 3 tokens, and the third token must end with ':'
        # But wait, the service could have colons? No, it's likely just alphanumeric.
        # Let's check if parts[2] ends with ':'
        if len(parts) < 3:
            continue
        # Check if the third part has a colon
        if not parts[2].endswith(':'):
            continue
        # Now extract level from parts[1]
        level = parts[1].upper()
        # Count occurrences
        counts[level] = counts.get(level, 0) + 1
    return counts
