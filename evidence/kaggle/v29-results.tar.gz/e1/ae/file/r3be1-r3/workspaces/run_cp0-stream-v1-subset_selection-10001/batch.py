def allocate(items, capacity):
    """Select jobs under a capacity limit to maximize total gain.

    Each item is a dict with a unique string "id", a positive integer
    "cost" and a non-negative integer "gain". Returns the sorted list of
    ids whose total gain is as large as possible while total cost stays
    <= capacity. If several selections tie on total gain, returns the
    lexicographically smallest sorted id list. An empty selection is
    allowed. Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")

    # Use dynamic programming (knapsack-style) to find the optimal selection.
    # dp[c] = (max_gain, sorted_ids) for total cost exactly c.
    # We'll track which items were selected to reconstruct the solution.
    # Since we need lexicographically smallest sorted id list among ties,
    # we'll store the best gain and the set of ids that achieve it.

    # Initialize: dp[c] = (gain, frozenset of ids) for cost c.
    # We use a dictionary to map cost -> (gain, frozenset of ids).
    # Start with cost 0 having gain 0 and empty set.
    dp = {(0): (0, frozenset())}

    for item in items:
        item_id = item["id"]
        cost = item["cost"]
        gain = item["gain"]

        # Iterate through costs in descending order to avoid using the same
        # item multiple times in one selection (0/1 knapsack).
        new_dp = dict(dp)
        for c in sorted(dp.keys(), reverse=True):
            if c + cost <= capacity:
                prev_gain, prev_ids = dp[c]
                new_gain = prev_gain + gain
                new_ids = prev_ids | {item_id}
                # Update if we find a better gain, or same gain but
                # lexicographically smaller sorted id list.
                if c + cost in new_dp:
                    existing_gain, existing_ids = new_dp[c + cost]
                    if (new_gain > existing_gain) or \
                       (new_gain == existing_gain and
                        sorted(new_ids) < sorted(existing_ids)):
                        new_dp[c + cost] = (new_gain, new_ids)
                else:
                    new_dp[c + cost] = (new_gain, new_ids)

        dp = new_dp

    # Find the maximum gain among all costs <= capacity.
    max_gain = None
    best_ids = None
    for c in range(capacity + 1):
        if c in dp:
            gain, ids = dp[c]
            if max_gain is None or gain > max_gain or \
               (gain == max_gain and (best_ids is None or sorted(ids) < sorted(best_ids))):
                max_gain = gain
                best_ids = ids

    if max_gain is None:
        return []

    # Return the sorted list of ids.
    return sorted(best_ids)
