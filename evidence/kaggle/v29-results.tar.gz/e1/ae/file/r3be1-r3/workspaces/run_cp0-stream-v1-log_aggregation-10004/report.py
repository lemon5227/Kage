def digest_lines(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Lines that do not match the format are ignored.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # Check format: timestamp level service: message
        # First two parts are timestamp and level
        level = parts[1].upper()
        # Verify the rest matches the pattern
        # After level, we should have "service:" followed by message
        if len(parts) < 3:
            continue
        # Check that part[2] starts with a service name followed by colon
        service_part = parts[2]
        if not service_part.startswith(':'):
            continue
        # Extract the service name (before the colon)
        service_name = service_part.split(':')[0]
        # Verify service_name is non-empty
        if not service_name:
            continue
        # Count this line
        counts[level] = counts.get(level, 0) + 1
    return counts
