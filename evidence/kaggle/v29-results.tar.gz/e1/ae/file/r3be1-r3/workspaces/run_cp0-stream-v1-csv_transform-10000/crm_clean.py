import csv
import io


def normalize_table(text):
    """Clean CSV text with header row (columns: score, id, email, name).

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Lower-case the "email" column.
    - Remove duplicate rows by "name", keeping the first occurrence.
    - Sort rows by "email" ascending as strings (stable).

    Returns cleaned CSV text with the same header.
    Empty string returns ''; header-only input returns just the header line.
    """
    if not text or not text.strip():
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # First row is header
    header = [cell.strip() for cell in rows[0]]
    # Ensure columns are score, id, email, name
    expected_cols = ["score", "id", "email", "name"]
    if len(header) != len(expected_cols):
        return ""

    data = []
    seen_names = set()

    for row in rows[1:]:
        if len(row) != len(header):
            continue

        cells = [cell.strip() for cell in row]
        score, id_val, email, name = cells[:4]

        # Drop rows whose "name" cell is empty
        if not name:
            continue

        # Lower-case the "email" column
        email = email.lower()

        # Remove duplicate rows by "name", keeping first occurrence
        if name in seen_names:
            continue
        seen_names.add(name)

        data.append((score, id_val, email, name))

    # Sort rows by "email" ascending as strings (stable)
    data.sort(key=lambda r: r[2])

    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in data:
        writer.writerow(row)

    return out.getvalue()
