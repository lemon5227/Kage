def choose(items, capacity):
    """Select jobs under a capacity limit to maximize total value.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity. If several selections tie on total value, returns
    the lexicographically smallest sorted id list. An empty selection is
    allowed. Raises ValueError if capacity is negative or any weight is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("weight must be positive")

    # Handle empty items list
    if not items:
        return []

    # Use dynamic programming for 0/1 knapsack
    # dp[w] = (max_value, sorted_ids) for capacity w
    # We'll track the best value and lexicographically smallest id list
    
    # Initialize: dp[0] = (0, [])
    # For each item, we update dp table from capacity down to weight
    
    # We need to track both value and the actual ids for tie-breaking
    # Let's use a different approach: dp[w] = (max_value, best_ids)
    
    # Initialize dp array where dp[w] = (value, tuple_of_ids)
    # Start with dp[0] = (0, ()) and others as (-1, None)
    
    dp = [(0, ())] + [(-1, None)] * capacity
    
    for item in items:
        weight = item["weight"]
        value = item["value"]
        item_id = item["id"]
        
        # Iterate backwards through capacities
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            new_value = prev_value + value
            new_ids = prev_ids + (item_id,)
            
            # Compare: if new_value > dp[w][0], update
            # If equal, choose lexicographically smaller tuple of ids
            current_value, current_ids = dp[w]
            if new_value > current_value or (new_value == current_value and new_ids < current_ids):
                dp[w] = (new_value, new_ids)
    
    # The answer is the best value among all capacities <= capacity
    max_value = 0
    best_ids = ()
    
    for w in range(capacity + 1):
        value, ids = dp[w]
        if value > max_value or (value == max_value and ids < best_ids):
            max_value = value
            best_ids = ids
    
    return list(best_ids)
