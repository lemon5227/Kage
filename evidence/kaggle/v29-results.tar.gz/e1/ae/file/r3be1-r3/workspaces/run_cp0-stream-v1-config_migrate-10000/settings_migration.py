def upgrade_config(cfg):
    """Upgrade old configuration dicts to v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    Output always has "version": 2.
    Renames top-level keys:
      - "max_conn" -> "max_connections"
      - "dir" -> "directory"
      - "host" -> "hostname"
    Moves "cache_size" and "region" into a sub-dict "limits".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError(
            "upgrade_config requires configuration with version 1; "
            f"got version {cfg.get('version')}"
        )

    # Make a copy to avoid modifying the input
    new_cfg = {}
    new_cfg["version"] = 2

    # Process top-level keys
    for key in list(cfg.keys()):
        value = cfg[key]

        # Skip None values
        if value is None:
            continue

        # Handle special key renames and transformations
        if key == "max_conn":
            new_cfg["max_connections"] = value
        elif key == "dir":
            new_cfg["directory"] = value
        elif key == "host":
            new_cfg["hostname"] = value
        elif key == "cache_size":
            # Move into limits sub-dict
            if "limits" not in new_cfg:
                new_cfg["limits"] = {}
            new_cfg["limits"]["cache_size"] = value
        elif key == "region":
            # Move into limits sub-dict
            if "limits" not in new_cfg:
                new_cfg["limits"] = {}
            new_cfg["limits"]["region"] = value
        elif key == "timeout_ms":
            # Convert to timeout_s (float)
            new_cfg["timeout_s"] = float(value) / 1000.0
        else:
            # Keep other keys unchanged
            new_cfg[key] = value

    return new_cfg
