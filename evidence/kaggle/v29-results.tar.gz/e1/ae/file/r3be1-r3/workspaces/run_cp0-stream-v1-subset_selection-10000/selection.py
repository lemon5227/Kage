def select_tasks(items, capacity):
    """Select parcels under a capacity limit to maximize total gain.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")
    
    # dp[c] = (max_gain, selected_ids) for total cost exactly c
    # Initialize with empty selection at cost 0
    dp = [(0, [])]  # (gain, list of ids)
    
    # Process each item in order
    for item in items:
        item_id = item["id"]
        cost = item["cost"]
        gain = item["gain"]
        
        # Create a copy of dp to avoid using the same item multiple times
        # We need to iterate over capacities from high to low to avoid
        # using the same item twice in one iteration (like unbounded knapsack)
        # But we're building new_dp from the old dp, so we can do it in any order
        
        new_dp = [list(dp)]  # Start with current best options
        
        # For each capacity level we can afford, try adding this item
        for c in range(len(dp)):
            current_gain, current_ids = dp[c]
            if c + cost <= capacity:
                new_gain = current_gain + gain
                new_ids = current_ids + [item_id]
                
                # Check if this gives a better result at capacity c+cost
                idx = c + cost
                existing_gain, existing_ids = dp[idx]
                if new_gain > existing_gain or \
                   (new_gain == existing_gain and sorted(new_ids) < sorted(existing_ids)):
                    dp[idx] = (new_gain, new_ids)
        
        # Update dp with the new options
        dp = new_dp
    
    # The answer is the best result at capacity <= capacity limit
    max_gain = 0
    best_ids = []
    
    for c in range(capacity + 1):
        gain, ids = dp[c]
        if gain > max_gain or (gain == max_gain and sorted(ids) < sorted(best_ids)):
            max_gain = gain
            best_ids = ids
    
    return sorted(best_ids)
