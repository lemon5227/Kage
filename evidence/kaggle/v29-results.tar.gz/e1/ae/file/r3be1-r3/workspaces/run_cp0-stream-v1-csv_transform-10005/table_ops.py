import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: id, email, city, name).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "id" cell is empty.
    3. Lower-case the "email" column.
    4. Remove duplicate rows by "email", keeping the first occurrence.
    5. Sort rows by "email" ascending as strings (stable).

    Returns:
        Empty string if input is empty.
        Header line only if input contains only header.
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header row
    header = [cell.strip() for cell in rows[0]]
    data_rows = rows[1:]

    # If only header row exists, return just the header line
    if len(data_rows) == 0:
        return "\n".join(header) + "\n"

    # Process data rows
    processed_rows = []
    seen_emails = set()

    for row in data_rows:
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]

        # Check if "id" cell is empty (drop such rows)
        id_index = header.index("id")
        if id_index >= len(cleaned_row) or cleaned_row[id_index] == "":
            continue

        # Lower-case the "email" column
        email_index = header.index("email")
        if email_index >= len(cleaned_row):
            continue
        cleaned_row[email_index] = cleaned_row[email_index].lower()

        # Remove duplicate rows by "email", keeping first occurrence
        email = cleaned_row[email_index]
        if email in seen_emails:
            continue
        seen_emails.add(email)

        processed_rows.append(cleaned_row)

    # Sort rows by "email" ascending as strings (stable)
    email_index = header.index("email")
    processed_rows.sort(key=lambda row: row[email_index])

    # Write output with '\n' line endings using csv module
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(processed_rows)

    return output.getvalue()
