import unicodedata


def make_handle(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case the result.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters into base + combining marks.
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII).
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case.
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-".
    result = []
    prev_char_is_alnum = False
    for ch in lower:
        if ch.isalnum():
            if not prev_char_is_alnum:
                result.append(ch)
            prev_char_is_alnum = True
        else:
            if not result or result[-1].isalnum():
                result.append("-")
            prev_char_is_alnum = False

    # Strip leading and trailing "-".
    while result and result[0] == "-":
        result.pop(0)
    while result and result[-1] == "-":
        result.pop()

    return "".join(result)
