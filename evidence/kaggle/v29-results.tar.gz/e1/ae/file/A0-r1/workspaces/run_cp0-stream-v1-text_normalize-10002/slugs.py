import unicodedata

def slugify(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = ''
    previous_char = None
    for char in lower_text:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            slug += char
        else:
            if previous_char is None or not char.isalnum():
                slug += '-'
                previous_char = char
    
    # Strip leading and trailing "-"
    slug = slug.strip('-')
    
    return slug
