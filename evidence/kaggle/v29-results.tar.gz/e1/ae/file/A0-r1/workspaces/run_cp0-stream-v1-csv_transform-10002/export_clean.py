import csv
import io

def normalize_table(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with header row (columns: name, team, city, id, score)
    Output: Cleaned CSV text with the same header
    
    Rules:
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "name" cell is empty
    - Remove duplicate rows by "score", keeping the first occurrence
    - Sort rows by "id" ascending as strings (stable)
    """
    # Parse CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = []
    for row in rows[1:]:
        # Strip whitespace from all cells
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip if name is empty
        if not cleaned_row[0]:
            continue
        
        data_rows.append(cleaned_row)
    
    # Remove duplicates by score (keeping first occurrence)
    seen_scores = set()
    unique_rows = []
    for row in data_rows:
        score = row[-1]  # last column is score
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort by id ascending as strings (stable sort)
    # We need to keep the original order for equal ids, so use a stable sort
    # Python's sort is stable, so we can sort by id only
    unique_rows.sort(key=lambda row: row[3])  # id is at index 3
    
    # Build output CSV text
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
