import re

def digest_lines(lines):
    """Count log lines per level.
    Line format: <timestamp> <LEVEL> <service>: <message>
    Level case may vary and must be upper-cased.
    Ignore lines that do not match.
    Returns a plain dict of counts.
    """
    counts = {}
    # Pattern: timestamp (single word) level service: message
    pattern = r'^\s*(\S+)\s+(\S+)\s+(\S+):\s*.*$'
    for line in lines:
        if not line.strip():
            continue
        match = re.match(pattern, line.strip())
        if match:
            level = match.group(2).upper()
            counts[level] = counts.get(level, 0) + 1
    return counts
