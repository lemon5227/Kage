def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per service for levels ERROR, WARN only, case-insensitive (upper-case keys).
    Drops malformed input lines."""
    result = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Malformed line (needs at least timestamp, level, service)
            continue
        
        # Extract timestamp, level, service, and message
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, store as uppercase
        service = parts[2]
        
        # Only process ERROR and WARN levels
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Increment count for this service
        result[service] = result.get(service, 0) + 1
    
    return result
