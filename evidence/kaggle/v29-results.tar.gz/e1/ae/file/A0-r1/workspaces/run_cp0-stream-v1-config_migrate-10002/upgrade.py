def upgrade_config(cfg):
    # Raise ValueError if version is not 1
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1 for upgrade")
    
    # Create a new dict for the upgraded configuration
    upgraded = {"version": 2}
    
    # Process top-level keys
    # Rename keys
    if "dir" in cfg:
        upgraded["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        upgraded["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        upgraded["max_connections"] = cfg["max_conn"]
    
    # Move region and retries into network sub-dict
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    upgraded["network"] = network
    
    # Handle timeout_ms
    if "timeout_ms" in cfg:
        upgraded["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["dir", "pwd_file", "max_conn", "region", "retries", "timeout_ms"]:
            # Skip keys with None value
            if value is not None:
                # Check if key should be renamed or moved
                if key == "dir":
                    continue  # already handled
                elif key == "pwd_file":
                    continue  # already handled
                elif key == "max_conn":
                    continue  # already handled
                elif key in ["region", "retries"]:
                    continue  # already moved to network
                elif key == "timeout_ms":
                    continue  # already handled
                else:
                    upgraded[key] = value
    
    return upgraded
