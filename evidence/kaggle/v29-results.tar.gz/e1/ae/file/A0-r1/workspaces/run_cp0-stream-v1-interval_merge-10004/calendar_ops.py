def merge_slots(intervals):
    # Check for invalid intervals first
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Interval {start}, {end} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last = merged[-1]
            # Only merge if there's a real overlap (end > last_end)
            if end > last[1]:
                # Merge by updating the last interval's end
                last[1] = end
            else:
                # No overlap, add new interval
                merged.append([start, end])
    
    return merged
