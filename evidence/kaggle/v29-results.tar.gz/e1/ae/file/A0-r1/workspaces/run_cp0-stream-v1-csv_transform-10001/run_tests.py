from crm_clean import clean_rows

# Test 1: Basic functionality with duplicates
test1 = "team,name,city,id,score\nA,B,C,D,10\nE,F,G,H,10"
result1 = clean_rows(test1)
print("Test 1 (duplicates):")
print(result1)
print()

# Test 2: Single row
test2 = "team,name,city,id,score\nA,B,C,D,10"
result2 = clean_rows(test2)
print("Test 2 (single row):")
print(result2)
print()

# Test 3: Empty input
test3 = ""
result3 = clean_rows(test3)
print("Test 3 (empty):")
print(repr(result3))
print()

# Test 4: Header only
test4 = "team,name,city,id,score"
result4 = clean_rows(test4)
print("Test 4 (header only):")
print(result4)
print()

# Test 5: Whitespace stripping
test5 = " team , name , city , id , score \n A , B , C , D , 10 "
result5 = clean_rows(test5)
print("Test 5 (whitespace):")
print(result5)
print()

# Test 6: Rows with empty score should be dropped
test6 = "team,name,city,id,score\nA,B,C,D,10\nE,F,G,H,\nI,J,K,L,20"
result6 = clean_rows(test6)
print("Test 6 (empty score):")
print(result6)
