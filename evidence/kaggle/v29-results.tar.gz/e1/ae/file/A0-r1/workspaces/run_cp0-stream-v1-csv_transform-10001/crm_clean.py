import csv
import io


def clean_rows(text):
    """
    Clean CSV text with header row (columns: team, name, city, id, score).
    
    Returns cleaned CSV text with the same header.
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "name" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Check if there's a header row
    if not rows:
        return ''
    
    header = rows[0]
    # Validate header columns
    expected_columns = ['team', 'name', 'city', 'id', 'score']
    if len(header) != len(expected_columns):
        return ''
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        if len(row) != len(expected_columns):
            continue
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Step 2: Drop rows whose "score" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if not row[4]:  # score is at index 4
            continue
        filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in filtered_rows:
        score = row[4]
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Step 4: Sort rows by "name" ascending as strings (stable)
    # Use a stable sort - Python's sorted is stable
    sorted_rows = sorted(unique_rows, key=lambda row: row[1])
    
    # Build output CSV
    output = []
    output.append(','.join(header))
    for row in sorted_rows:
        output.append(','.join(row))
    
    return '\n'.join(output)


if __name__ == '__main__':
    # Test examples
    test1 = "team,name,city,id,score\nA,B,C,D,10\nE,F,G,H,10"
    print("Test 1:", clean_rows(test1))
    
    test2 = "team,name,city,id,score\nA,B,C,D,10"
    print("Test 2:", clean_rows(test2))
    
    test3 = ""
    print("Test 3:", clean_rows(test3))
    
    test4 = "team,name,city,id,score"
    print("Test 4:", clean_rows(test4))
