def pick_jobs(items, capacity):
    """Choose parcels to maximize total score within capacity."""
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    # Validate items and check for positive sizes
    validated_items = []
    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")
        validated_items.append(item)
    
    # Sort by score/size ratio (descending), then by id for tie-breaking
    # This ensures we get maximum score while handling ties correctly
    sorted_items = sorted(
        validated_items,
        key=lambda item: (-item["score"] / item["size"], item["id"])
    )
    
    # Greedy selection
    selected = []
    total_size = 0
    total_score = 0
    
    for item in sorted_items:
        if total_size + item["size"] <= capacity:
            selected.append(item["id"])
            total_size += item["size"]
            total_score += item["score"]
    
    return sorted(selected)
