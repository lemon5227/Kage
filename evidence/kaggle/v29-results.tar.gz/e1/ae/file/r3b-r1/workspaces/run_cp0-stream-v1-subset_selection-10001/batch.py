def allocate(items, capacity):
    """Select jobs under a capacity limit to maximize total gain.
    
    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.
    
    Raises ValueError if capacity is negative or any cost is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")
    
    # This is a 0/1 knapsack problem with maximization of gain under cost constraint.
    # We'll use dynamic programming to find the maximum gain for each capacity level.
    # dp[c] = maximum gain achievable with total cost exactly c (or at most c)
    
    # Initialize dp array where dp[c] represents the maximum gain achievable
    # with total cost <= c. We'll track which items were selected.
    dp = [0] * (capacity + 1)
    parent = [[None] * (capacity + 1) for _ in range(len(items))]
    
    # Process each item
    for i, item in enumerate(items):
        id_ = item["id"]
        cost = item["cost"]
        gain = item["gain"]
        
        # Iterate through capacities from high to low for 0/1 knapsack
        for c in range(capacity, cost - 1, -1):
            # Option 1: Don't include this item
            value_without = dp[c]
            
            # Option 2: Include this item (if we have enough capacity)
            value_with = dp[c - cost] + gain
            
            if value_with > value_without:
                dp[c] = value_with
                parent[i][c] = (i, c - cost)  # Record that item i was selected
    
    # Find the maximum gain and the lexicographically smallest id list
    max_gain = dp[capacity]
    
    # Reconstruct the selection by backtracking from capacity
    selected_ids = []
    c = capacity
    for i in range(len(items) - 1, -1, -1):
        if parent[i][c] is not None:
            item_idx, prev_c = parent[i][c]
            selected_ids.append(items[item_idx]["id"])
            c = prev_c
    
    # Sort the ids lexicographically and return
    return sorted(selected_ids)
