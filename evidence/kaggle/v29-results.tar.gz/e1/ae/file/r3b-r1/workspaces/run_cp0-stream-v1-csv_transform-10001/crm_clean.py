import csv
import io


def clean_rows(text):
    """Clean CSV text with header row (columns: team, name, city, id, score).

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "score" cell is empty.
    - Remove duplicate rows by "score", keeping the first occurrence.
    - Sort rows by "name" ascending as strings (stable).
    Returns cleaned CSV text with the same header.
    Empty string returns ''; a header-only input returns just the header line.
    Output uses '\n' line endings via csv module.
    """
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ""

    # Validate header columns
    expected_cols = ["team", "name", "city", "id", "score"]
    if len(header) != len(expected_cols):
        return ""

    rows_data = []
    seen_scores = set()

    for row in reader:
        if len(row) != len(expected_cols):
            continue

        # Strip whitespace from each cell
        cleaned = [cell.strip() for cell in row]

        # Drop rows whose "score" cell is empty
        score = cleaned[4]
        if score == "":
            continue

        # Remove duplicate rows by "score", keeping first occurrence
        if score in seen_scores:
            continue
        seen_scores.add(score)

        rows_data.append(cleaned)

    # Sort rows by "name" ascending as strings (stable)
    rows_data.sort(key=lambda r: r[1])

    # Write output with '\n' line endings via csv module
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(rows_data)
    return out.getvalue()
