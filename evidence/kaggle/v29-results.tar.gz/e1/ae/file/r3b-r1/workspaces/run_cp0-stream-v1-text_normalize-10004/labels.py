import unicodedata


def label_id(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks.
    normalized = unicodedata.normalize("NFKD", text)

    # Keep only ASCII characters (0-127). This drops non-ASCII.
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case.
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-".
    # We'll use regex to find sequences of non-alphanumeric chars and replace them.
    import re
    slug = re.sub(r"[^a-z0-9]+", "-", lower)

    # Strip leading and trailing "-".
    slug = slug.strip("-")

    return slug
