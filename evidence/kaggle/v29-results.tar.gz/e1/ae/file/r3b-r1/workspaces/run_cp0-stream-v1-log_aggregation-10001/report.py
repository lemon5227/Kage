def tally_events(lines):
    """Tally ERROR and WARN log lines per service.
    
    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"
    
    Only levels ERROR and WARN (case-insensitive) are counted.
    Malformed lines are dropped.
    Returns {service_name: count} with uppercase keys.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # split into timestamp, level, service:, message
        if len(parts) < 3:
            continue
        _, level, service_part = parts[0], parts[1], parts[2]
        # The service name is everything after the colon in service_part
        if ':' in service_part:
            service_name = service_part.split(':', 1)[1].strip()
        else:
            service_name = service_part.strip()
        
        level_upper = level.upper()
        if level_upper not in ('ERROR', 'WARN'):
            continue
        
        counts[service_name] = counts.get(service_name, 0) + 1
    return counts
