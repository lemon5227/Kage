import unicodedata


def slugify(text):
    """Turn a title into a handle.

    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces every run of characters outside [a-z0-9] with a single "_",
    and strips leading and trailing "_". Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("Expected string, got {}".format(type(text).__name__))

    # NFKD normalization decomposes characters into base + combining marks
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char_is_alnum = False
    for char in lower:
        if char.isalnum():
            if not prev_char_is_alnum:
                result.append(char)
            prev_char_is_alnum = True
        else:
            if result and not prev_char_is_alnum:
                # Start of a run of non-alphanumeric chars - add separator
                result.append("_")
                prev_char_is_alnum = False
    return "".join(result).strip("_")
