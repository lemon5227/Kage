import csv
import io


def tidy_csv(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: name, city, score, team).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "name" cell is empty.
    3. Remove duplicate rows by "name", keeping the first occurrence.
    4. Sort rows by "city" ascending as strings (stable).

    Returns:
        Empty string if input is empty.
        Just the header line if input contains only the header.
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # The first row is the header
    header = rows[0]
    # Ensure we have the expected columns
    expected_cols = ["name", "city", "score", "team"]
    if len(header) != len(expected_cols):
        raise ValueError(
            f"Expected {len(expected_cols)} columns, got {len(header)}"
        )

    # Process data rows (starting from index 1)
    data_rows = rows[1:]

    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        if len(row) != len(expected_cols):
            continue  # Skip malformed rows
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)

    # Step 2: Drop rows whose "name" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if not row[0]:  # name is at index 0
            continue
        filtered_rows.append(row)

    # Step 3: Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    deduped_rows = []
    for row in filtered_rows:
        name = row[0]
        if name in seen_names:
            continue
        seen_names.add(name)
        deduped_rows.append(row)

    # Step 4: Sort rows by "city" ascending as strings (stable)
    # city is at index 1
    deduped_rows.sort(key=lambda row: row[1])

    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
