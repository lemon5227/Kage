def digest_lines(lines):
    """Process log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    
    Returns a dict {name: count} per level, treating level names case-insensitively
    (upper-case keys), dropping malformed input lines.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Format: <timestamp> <LEVEL> <service>: <message>
        # At minimum we need timestamp, level, and service (with colon)
        if len(parts) < 3:
            continue
        timestamp = parts[0]
        level = parts[1].upper()
        # Check that service part starts with a colon after the level
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # So after level, we expect something like "service:" or "service: message"
        # We need to find the service name before the colon
        rest = " ".join(parts[2:])
        if not rest.startswith(":"):
            continue
        # Find the service name (everything before the first colon)
        colon_idx = rest.find(":")
        if colon_idx == -1:
            continue
        service = rest[:colon_idx]
        if not service.strip():
            continue
        # Count by level
        key = level
        counts[key] = counts.get(key, 0) + 1
    return counts
