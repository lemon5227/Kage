import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: id, email, city, name).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "id" cell is empty.
    3. Lower-case the "email" column.
    4. Remove duplicate rows by "email", keeping the first occurrence.
    5. Sort rows by "email" ascending as strings (stable).

    Returns:
        Empty string if input is empty.
        Header line only if input has no data rows.
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = rows[0]
    data_rows = rows[1:]

    if not data_rows:
        # Header-only input returns just the header line
        return "\n".join(header) + "\n" if header else ""

    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)

    # Step 2: Drop rows whose "id" cell is empty
    id_index = header.index("id")
    filtered_rows = []
    for row in cleaned_rows:
        if id_index >= len(row) or row[id_index] == "":
            continue
        filtered_rows.append(row)

    # Step 3: Lower-case the "email" column
    email_index = header.index("email")
    for row in filtered_rows:
        if email_index < len(row):
            row[email_index] = row[email_index].lower()

    # Step 4: Remove duplicate rows by "email", keeping the first occurrence
    seen_emails = set()
    deduped_rows = []
    for row in filtered_rows:
        email = row[email_index] if email_index < len(row) else ""
        if email in seen_emails:
            continue
        seen_emails.add(email)
        deduped_rows.append(row)

    # Step 5: Sort rows by "email" ascending as strings (stable)
    def sort_key(row):
        email = row[email_index] if email_index < len(row) else ""
        return email

    deduped_rows.sort(key=sort_key, stable=True)

    # Write output with '\n' line endings using csv module
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
