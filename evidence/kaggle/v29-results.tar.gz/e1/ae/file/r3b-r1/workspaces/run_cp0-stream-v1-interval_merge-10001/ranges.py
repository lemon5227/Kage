def merge_slots(intervals):
    """Merge overlapping intervals. Each interval is a dict {"from": s, "to": e}.
    
    Touching intervals like [1,3] and [3,5] are merged. Raises ValueError if
    any interval has start > end. Returns merged intervals sorted by start.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        from_val = interval["from"]
        to_val = interval["to"]
        if from_val > to_val:
            raise ValueError(
                "Interval has start > end: from=%r, to=%r" % (from_val, to_val)
            )
        normalized.append((from_val, to_val))
    
    # Sort by start time
    normalized.sort(key=lambda pair: pair[0])
    
    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching - extend the end if needed
            merged[-1] = (start, max(merged[-1][1], end))
        else:
            merged.append((start, end))
    
    # Convert back to dict format
    return [{"from": start, "to": end} for start, end in merged]
