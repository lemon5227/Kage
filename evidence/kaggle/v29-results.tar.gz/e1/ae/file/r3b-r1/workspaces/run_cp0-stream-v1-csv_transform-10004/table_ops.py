import csv
import io


def clean_rows(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: id, team, score).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "score" cell is empty.
    3. Remove duplicate rows by "team", keeping the first occurrence.
    4. Sort rows by "score" ascending as strings (stable).

    Returns:
        Empty string if input is empty.
        Just the header line if input contains only the header.
    """
    # Parse CSV text into a list of rows (including header)
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = rows[0]
    data_rows = rows[1:]

    if not data_rows:
        return "\n".join(header) + "\n" if header else ""

    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)

    # Step 2: Drop rows whose "score" cell is empty
    score_index = header.index("score")
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) <= score_index:
            continue  # Skip rows without a score column
        if row[score_index] == "":
            continue  # Skip rows with empty score
        filtered_rows.append(row)

    # Step 3: Remove duplicate rows by "team", keeping the first occurrence
    team_index = header.index("team")
    seen_teams = set()
    deduped_rows = []
    for row in filtered_rows:
        if len(row) <= team_index:
            continue  # Skip rows without a team column
        team = row[team_index]
        if team in seen_teams:
            continue  # Skip duplicate
        seen_teams.add(team)
        deduped_rows.append(row)

    # Step 4: Sort rows by "score" ascending as strings (stable)
    def sort_key(row):
        score = row[score_index] if len(row) > score_index else ""
        return (score, row)

    deduped_rows.sort(key=sort_key)

    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
