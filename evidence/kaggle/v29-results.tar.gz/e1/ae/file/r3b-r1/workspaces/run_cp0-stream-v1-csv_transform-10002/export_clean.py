import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: name, team, city, id, score).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "name" cell is empty.
    3. Remove duplicate rows by "score", keeping the first occurrence.
    4. Sort rows by "id" ascending as strings (stable).

    Returns:
        Empty string if input is empty.
        Header-only input returns just the header line.
    """
    # Parse CSV text into a list of dictionaries
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # The first row is the header
    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Strip leading/trailing whitespace from every cell in all rows
    cleaned_rows = []
    for row in data:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)

    # Drop rows whose "name" cell is empty
    name_index = header.index("name")
    filtered_rows = []
    for row in cleaned_rows:
        if not row[name_index]:
            continue
        filtered_rows.append(row)

    # Remove duplicate rows by "score", keeping the first occurrence
    score_index = header.index("score")
    seen_scores = set()
    deduped_rows = []
    for row in filtered_rows:
        score = row[score_index]
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped_rows.append(row)

    # Sort rows by "id" ascending as strings (stable)
    id_index = header.index("id")
    deduped_rows.sort(key=lambda row: row[id_index])

    # Write output with '\n' line endings using csv module
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
