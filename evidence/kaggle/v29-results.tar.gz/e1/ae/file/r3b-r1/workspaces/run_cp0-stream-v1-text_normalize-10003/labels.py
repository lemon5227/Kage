def make_handle(text):
    """Build a URL slug from text.

    - Apply unicodedata NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters, then drop non-ASCII
    normalized = unicodedata.normalize('NFKD', text)
    ascii_only = normalized.encode('ascii', 'ignore').decode('ascii')

    # Lower-case
    lower = ascii_only.lower()

    # Replace runs of non-alphanumeric with a single "-"
    slug = []
    prev_is_alnum = False
    for ch in lower:
        if ch.isalnum():
            if not prev_is_alnum:
                slug.append("-")
            slug.append(ch)
            prev_is_alnum = True
        else:
            if prev_is_alnum:
                slug.append("-")
            prev_is_alnum = False

    result = "".join(slug)

    # Strip leading and trailing "-"
    while result.startswith("-"):
        result = result[1:]
    while result.endswith("-"):
        result = result[:-1]

    return result
