def select_tasks(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")
    
    # If no items, return empty list
    if not items:
        return []
    
    # Create a list of (id, gain, cost) tuples
    parcels = [(item["id"], item["gain"], item["cost"]) for item in items]
    
    # Sort by gain descending, then by id ascending for tie-breaking
    parcels.sort(key=lambda x: (-x[1], x[0]))
    
    # Greedy selection: take items in order until capacity is exceeded
    selected = []
    total_cost = 0
    
    for item_id, gain, cost in parcels:
        if total_cost + cost <= capacity:
            selected.append(item_id)
            total_cost += cost
    
    return sorted(selected)
