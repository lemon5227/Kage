def allocate(items, capacity):
    """Select a subset of items maximizing total score within capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer
      - "score": non-negative integer

    Returns the sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total
    score, return the lexicographically smallest sorted id list. An empty
    selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        if "size" not in item or "score" not in item:
            raise ValueError("each item must have 'size' and 'score' keys")
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")
        if not isinstance(size, int) or not isinstance(item["score"], int):
            raise ValueError("item size and score must be integers")

    # 0/1 knapsack DP: dp[w] = (max_score, chosen_ids) for capacity w
    # We track the chosen items to reconstruct the solution.
    # Initialize dp[0] = (0, []) and dp[w] = (-inf, None) for w > 0.
    NEG_INF = None  # sentinel for unreachable states
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    # We'll process items one by one. For each item, we update dp in reverse
    # to avoid using the same item multiple times.
    for item in items:
        idx = item["id"]
        size = item["size"]
        score = item["score"]
        # Iterate capacities from capacity down to size
        for w in range(capacity, size - 1, -1):
            if dp[w - size] is not None:
                cand_score = dp[w - size][0] + score
                cand_ids = dp[w - size][1] + [idx]
                cur_score, cur_ids = dp[w]
                # Prefer higher score; if tie, lexicographically smaller id list
                if (cand_score, cand_ids) > (cur_score, cur_ids):
                    dp[w] = (cand_score, cand_ids)

    # The optimal value is at dp[capacity], but we need the best among all
    # capacities <= capacity. So we scan for the maximum score.
    best_score = None
    best_ids = None
    for w in range(capacity + 1):
        val = dp[w]
        if val is None:
            continue
        score, ids = val
        if best_score is None or (score, ids) > (best_score, best_ids):
            best_score = score
            best_ids = ids

    return sorted(best_ids)
