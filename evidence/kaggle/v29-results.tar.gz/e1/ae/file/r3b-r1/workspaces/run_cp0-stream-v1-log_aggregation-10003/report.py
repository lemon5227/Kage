def aggregate_log(lines):
    """Aggregate log strings into {service: count} for ERROR and WARN levels only.
    
    Each line is formatted as "<timestamp> <LEVEL> <service>: <message>".
    Level names are matched case-insensitively; keys in result are uppercase.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # split into timestamp, level, service, message
        if len(parts) < 3:
            continue
        _, level, service = parts[:3]
        if service.startswith(':'):
            service = service[1:]
        if not service:
            continue
        level_upper = level.upper()
        if level_upper not in ('ERROR', 'WARN'):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
