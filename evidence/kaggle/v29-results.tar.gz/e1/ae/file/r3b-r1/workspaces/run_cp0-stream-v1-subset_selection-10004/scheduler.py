def choose(items, capacity):
    """Select jobs under a capacity limit.
    
    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Returns the sorted list of ids whose
    total value is as large as possible while total weight stays <= capacity.
    If several selections tie on total value, return the lexicographically
    smallest sorted id list. An empty selection is allowed.
    
    Raises ValueError if capacity is negative or any weight is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("weight must be positive")
    
    if not items:
        return []
    
    # Create a list of (id, weight, value) tuples
    entries = [(item["id"], item["weight"], item["value"]) for item in items]
    
    # Dynamic programming: dp[w] = (max_value, sorted_ids) for capacity w
    # We need to track which items were selected to reconstruct the solution
    # Use a dictionary to store the best value for each weight, and track choices
    
    # dp[w] = (max_value, set of selected ids) - but sets are not order-preserving
    # Better: dp[w] = (max_value, tuple of sorted ids)
    
    # Initialize dp[0] = (0, ()) and dp[w] = (-inf, ()) for w > 0
    NEG_INF = None  # Represents impossible
    
    # We'll use a list where dp[w] = (value, tuple_of_ids)
    # But we need to handle the case where multiple selections give same value
    # and choose lexicographically smallest
    
    # Let's use a different approach: dp[w] = max value achievable with weight <= w
    # and track the selection that gives this value
    
    # Actually, we need to find the exact weight that gives max value
    # and then reconstruct the selection
    
    # Standard knapsack DP: dp[w] = max value using a subset of items with total weight exactly w
    # But we want weight <= capacity, so we can compute for all weights up to capacity
    
    # Initialize dp[0] = 0, others = -1 (impossible)
    dp = [0] + [-1] * capacity
    
    # parent[w] = (item_id, previous_weight) to reconstruct solution
    parent = [None] * (capacity + 1)
    
    for item_id, weight, value in entries:
        # Iterate backwards through capacities
        for w in range(capacity, weight - 1, -1):
            if dp[w - weight] != -1 and dp[w - weight] + value > dp[w]:
                dp[w] = dp[w - weight] + value
                parent[w] = (item_id, w - weight)
    
    # Find the maximum value achievable with weight <= capacity
    max_value = 0
    best_weight = 0
    for w in range(capacity + 1):
        if dp[w] > max_value:
            max_value = dp[w]
            best_weight = w
    
    # Reconstruct the selection
    selected_ids = []
    w = best_weight
    while w > 0:
        if parent[w] is not None:
            item_id, prev_w = parent[w]
            selected_ids.append(item_id)
            w = prev_w
        else:
            break
    
    # Return sorted list of ids
    return sorted(selected_ids)
