import unicodedata


def to_key(text):
    """Normalize labels into identifiers.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "_".
    - Strip leading and trailing "_".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks.
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII).
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case.
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_".
    # This is equivalent to: collapse any sequence of non-alphanumeric chars to one underscore.
    parts = []
    current = []
    for ch in lower:
        if ch.isalnum():
            current.append(ch)
        else:
            if current:
                parts.append("".join(current))
                current = []
            # Insert a single underscore for the run of non-alphanumerics.
            parts.append("_")
    if current:
        parts.append("".join(current))

    key = "".join(parts)

    # Strip leading and trailing "_".
    return key.strip("_")
