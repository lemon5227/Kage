import unicodedata


def slugify(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters; non-ASCII are dropped.
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case.
    ascii_only = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-".
    runs = []
    current_run = []
    for ch in ascii_only:
        if ch.isalnum():
            current_run.append(ch)
        else:
            if current_run:
                runs.append("".join(current_run))
                current_run = []
            runs.append("-")
    if current_run:
        runs.append("".join(current_run))

    slug = "".join(runs)

    # Strip leading and trailing "-".
    while slug.startswith("-"):
        slug = slug[1:]
    while slug.endswith("-"):
        slug = slug[:-1]

    return slug
