def digest_lines(lines):
    """Process log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    
    Returns a dictionary mapping level names (upper-case) to their counts.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        # Check format: <timestamp> <LEVEL> <service>: <message>
        # The service part should contain a colon followed by message
        # So we need at least 4 parts to have "service:" and message
        # Or the service could be in parts[2] and then there's a colon in it
        # Let's check if parts[2] contains a colon
        if len(parts) < 4:
            # Check if parts[2] has a colon (e.g., "service:")
            if ':' not in parts[2]:
                continue
        level = parts[1]
        # Count the level (case-insensitive, store as upper-case)
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
