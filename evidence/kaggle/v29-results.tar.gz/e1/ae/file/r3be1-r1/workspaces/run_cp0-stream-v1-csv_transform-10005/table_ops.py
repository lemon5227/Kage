import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: id, email, city, name).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "id" cell is empty.
    3. Lower-case the "email" column.
    4. Remove duplicate rows by "email", keeping the first occurrence.
    5. Sort rows by "email" ascending as strings (stable).

    Returns:
        Empty string if input is empty.
        Header-only input returns just the header line.
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header row
    header = [cell.strip() for cell in rows[0]]
    data_rows = rows[1:]

    # Process each row: strip whitespace from all cells
    processed_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        processed_rows.append(stripped_row)

    # Drop rows whose "id" cell is empty
    id_index = header.index("id")
    cleaned_rows = []
    for row in processed_rows:
        if not row[id_index]:
            continue
        cleaned_rows.append(row)

    # Lower-case the "email" column
    email_index = header.index("email")
    for row in cleaned_rows:
        row[email_index] = row[email_index].lower()

    # Remove duplicate rows by "email", keeping the first occurrence
    seen_emails = set()
    deduped_rows = []
    for row in cleaned_rows:
        email = row[email_index]
        if email in seen_emails:
            continue
        seen_emails.add(email)
        deduped_rows.append(row)

    # Sort rows by "email" ascending as strings (stable)
    deduped_rows.sort(key=lambda row: row[email_index])

    # Write output CSV with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
