def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")

    # Create a new dict without modifying the input
    result = {"version": 2}

    # Process top-level keys
    # Rename "dir" -> "directory", "host" -> "hostname"
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]

    # Move "port" and "workers" into a sub-dict "storage"
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    result["storage"] = storage

    # Handle "timeout_ms" -> "timeout_s"
    if "timeout_ms" in cfg:
        timeout_ms = cfg["timeout_ms"]
        if timeout_ms is None:
            # Drop keys with None value
            continue
        result["timeout_s"] = float(timeout_ms / 1000)

    # Keep other keys unchanged, but drop keys whose value is None
    for key, value in cfg.items():
        if key in ("version", "dir", "host", "port", "workers", "timeout_ms"):
            continue  # Already handled above
        if value is None:
            continue  # Drop keys with None value
        if key not in result:
            result[key] = value

    return result
