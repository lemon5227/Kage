def select_tasks(items, capacity):
    """Select a subset of items whose total size is at most capacity and total score is maximized.

    Each item is a dict with keys:
      - "id": a unique string identifier
      - "size": a positive integer
      - "score": a non-negative integer

    Returns the sorted list of ids of the selected items. If several selections tie on total score,
    return the lexicographically smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("size must be positive")

    # DP over capacity, tracking the best score and the lexicographically smallest id list among ties.
    # dp[c] = (best_score, best_id_list) for capacity c.
    # We process items one by one, updating the table in reverse order of capacity to avoid using the same item twice.

    # Initialize dp[0] = (0, []) and all other entries as (-1, None).
    dp = [(None,) * (capacity + 1)]
    for c in range(capacity + 1):
        dp[c] = (0 if c == 0 else -1, [] if c == 0 else None)

    # Process each item.
    for item in items:
        idx = item["id"]
        size = item["size"]
        score = item["score"]

        # Iterate capacities from capacity down to size.
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[c - size]
            if prev_score is None:
                continue

            cand_score = prev_score + score
            cand_ids = sorted([idx] + prev_ids)

            cur_score, cur_ids = dp[c]
            # Compare: prefer higher score; if equal, prefer lexicographically smaller id list.
            if (cand_score > cur_score) or (cand_score == cur_score and cand_ids < cur_ids):
                dp[c] = (cand_score, cand_ids)

    # The best total score is dp[capacity].
    best_score, best_ids = dp[capacity]
    return best_ids
