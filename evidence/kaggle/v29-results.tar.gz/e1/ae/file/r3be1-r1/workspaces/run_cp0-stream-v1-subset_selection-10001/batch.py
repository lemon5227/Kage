def allocate(items, capacity):
    """Select jobs under a capacity limit to maximize total gain.
    
    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, returns the lexicographically
    smallest sorted id list. An empty selection is allowed.
    
    Raises ValueError if capacity is negative or any cost is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")
    
    # Handle empty items list
    if not items:
        return []
    
    # Use dynamic programming for the knapsack problem
    # dp[i][c] = (max_gain, selected_ids) for first i items with capacity c
    # We need to track which items were selected to handle tie-breaking
    
    n = len(items)
    
    # dp[c] will store (max_gain, sorted_ids) for capacity c
    # Initialize with (0, []) for capacity 0
    dp = [(0, []) for _ in range(capacity + 1)]
    
    for i in range(n):
        item = items[i]
        cost = item["cost"]
        gain = item["gain"]
        item_id = item["id"]
        
        # Iterate backwards to avoid using the same item multiple times
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            new_gain = prev_gain + gain
            new_ids = sorted(prev_ids + [item_id])
            
            # Compare with current value at dp[c]
            if new_gain > dp[c][0]:
                dp[c] = (new_gain, new_ids)
            elif new_gain == dp[c][0]:
                # Tie-breaking: choose lexicographically smallest sorted id list
                if new_ids < dp[c][1]:
                    dp[c] = (new_gain, new_ids)
    
    # The result is the best selection for capacity <= capacity
    # We need to find the maximum gain among all capacities from 0 to capacity
    max_gain = 0
    best_ids = []
    
    for c in range(capacity + 1):
        gain, ids = dp[c]
        if gain > max_gain:
            max_gain = gain
            best_ids = ids
        elif gain == max_gain:
            if ids < best_ids:
                best_ids = ids
    
    return best_ids
