def tally_events(lines):
    """Tally log events by service for ERROR and WARN levels.

    Each line is expected to be formatted as:
        <timestamp> <LEVEL> <service>: <message>

    Only lines with ERROR or WARN (case-insensitive) are counted.
    Malformed lines are dropped. Returns a dict mapping service name to count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        service = parts[2]
        if service.startswith(':'):
            service = service[1:]
        if not service:
            continue
        if level not in ('ERROR', 'WARN'):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
