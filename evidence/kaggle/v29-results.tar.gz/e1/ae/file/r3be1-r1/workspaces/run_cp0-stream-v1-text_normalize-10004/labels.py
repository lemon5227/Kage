import unicodedata


def label_id(text):
    """Build a URL slug from text.

    - Apply NFKD normalization to unicode characters.
    - Drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters into base + combining marks
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    prev_char = None
    for char in lower:
        if char not in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev_char is not None:
                slug.append("-")
        else:
            slug.append(char)
        prev_char = char

    result = "".join(slug)

    # Strip leading and trailing "-"
    return result.strip("-")
