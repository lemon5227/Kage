import unicodedata


def make_handle(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case the result.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters into base + combining marks.
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII).
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case.
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-".
    # This is equivalent to: split on non-alphanumeric runs, then join with "-".
    parts = [part for part in lower.split() if part]
    handle = "-".join(parts)

    # Strip leading and trailing "-".
    handle = handle.strip("-")

    return handle
