def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            f"Expected version 1, got {version!r} (type {type(version).__name__})"
        )

    # Start with a fresh dict containing the required version field
    result = {"version": 2}

    # Process top-level keys
    for key in ["dir", "pwd_file", "max_conn"]:
        if key in cfg:
            new_key = {
                "dir": "directory",
                "pwd_file": "password_file",
                "max_conn": "max_connections"
            }[key]
            result[new_key] = cfg[key]

    # Handle network sub-dict
    network_keys = ["region", "retries"]
    if "network" in cfg:
        network = cfg["network"]
        if isinstance(network, dict):
            result["network"] = {}
            for nk in network_keys:
                if nk in network:
                    result["network"][nk] = network[nk]
        else:
            # If network is not a dict, keep it as-is but ensure it's present
            result["network"] = network

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        timeout_ms = cfg["timeout_ms"]
        if isinstance(timeout_ms, (int, float)):
            result["timeout_s"] = float(timeout_ms) / 1000.0
        else:
            raise ValueError(
                f"timeout_ms must be a number, got {type(timeout_ms).__name__}"
            )

    # Drop keys with None values (already handled by not including them)
    # Any other keys are kept unchanged
    for key in cfg:
        if key not in ["dir", "pwd_file", "max_conn", "network", "timeout_ms"]:
            if key not in result:
                result[key] = cfg[key]

    return result
