import csv
import io


def normalize_table(text):
    """Normalize CSV text with header row (columns: score, id, email, name).

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Lower-case the "email" column.
    - Remove duplicate rows by "name", keeping the first occurrence.
    - Sort rows by "email" ascending as strings (stable).

    Returns cleaned CSV text with the same header.
    Empty string returns ''; header-only input returns just the header line.
    Output uses '\n' line endings.
    """
    if not text:
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header
    header = [cell.strip() for cell in rows[0]]
    # Ensure we have the expected columns
    expected_cols = ["score", "id", "email", "name"]
    if len(header) != len(expected_cols):
        # If header doesn't match, use what we have but still process
        pass

    # Process data rows
    data_rows = []
    seen_names = set()

    for row in rows[1:]:
        # Strip whitespace from all cells
        cleaned_row = [cell.strip() for cell in row]

        # Check if "name" is empty (index 3)
        if len(cleaned_row) > 3 and cleaned_row[3] == "":
            continue

        # Lower-case the "email" column (index 2)
        if len(cleaned_row) > 2:
            cleaned_row[2] = cleaned_row[2].lower()

        # Remove duplicates by "name", keeping first occurrence
        name = cleaned_row[3] if len(cleaned_row) > 3 else ""
        if name in seen_names:
            continue
        seen_names.add(name)

        data_rows.append(cleaned_row)

    # Sort rows by "email" ascending as strings (stable)
    # Use index 2 for email sorting
    data_rows.sort(key=lambda row: row[2] if len(row) > 2 else "")

    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in data_rows:
        writer.writerow(row)

    return output.getvalue()
