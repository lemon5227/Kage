import unicodedata


def make_handle(text):
    """Turn a title into a handle.

    Apply NFKD normalization, drop non-ASCII characters, lower-case,
    replace every run of characters outside [a-z0-9] with a single "-",
    strip leading and trailing "-", and if longer than 23 characters,
    cut to 23 and then strip a trailing "-".

    Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters
    ascii_only = "".join(c for c in normalized if ord(c) < 128)

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for c in lower:
        if c not in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev_char is not None:
                result.append("-")
            prev_char = None
        else:
            result.append(c)
            prev_char = c
    handle = "".join(result)

    # Strip leading and trailing "-"
    handle = handle.strip("-")

    # If longer than 23 characters, cut to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.rstrip("-")

    return handle
