import unicodedata


def to_key(text):
    """Normalize labels into identifiers.

    Apply NFKD normalization, drop non-ASCII characters, lower-case,
    replace every run of characters outside [a-z0-9] with a single "_",
    and strip leading and trailing "_". Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for char in lower:
        if char not in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev_char is not None:
                # End of a run of non-alphanumeric chars
                result.append("_")
            prev_char = None
        else:
            # Start of an alphanumeric run - keep the first char
            if prev_char is None or prev_char != char:
                result.append(char)
            prev_char = char

    return "".join(result).strip("_")
