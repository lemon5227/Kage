def aggregate_log(lines):
    """Aggregate log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    
    Returns {name: count} per service for levels ERROR and WARN only,
    treating level names case-insensitively (upper-case keys), dropping malformed input lines.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # Format: <timestamp> <LEVEL> <service>: <message>
        # timestamp is first part, level is second, service is third (before colon)
        level = parts[1].upper()
        service = parts[2]
        if ':' not in service:
            continue
        name, _ = service.split(':', 1)
        if level not in ('ERROR', 'WARN'):
            continue
        counts[name] = counts.get(name, 0) + 1
    return counts
