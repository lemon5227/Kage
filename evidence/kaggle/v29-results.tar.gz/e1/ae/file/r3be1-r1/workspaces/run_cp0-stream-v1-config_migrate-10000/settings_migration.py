def upgrade_config(cfg):
    """Upgrade old configuration dicts to v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    Output has "version": 2.
    Renames top-level keys:
      - "max_conn" -> "max_connections"
      - "dir" -> "directory"
      - "host" -> "hostname"
    Moves "cache_size" and "region" into a sub-dict "limits".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Make a copy to avoid modifying the input
    result = {}
    version = cfg.get("version")
    if version != 1:
        raise ValueError("Expected configuration version 1, got %r" % version)

    result["version"] = 2

    # Process top-level keys
    for key in ["max_conn", "dir", "host"]:
        if key in cfg:
            new_key = {
                "max_conn": "max_connections",
                "dir": "directory",
                "host": "hostname"
            }[key]
            value = cfg[key]
            if value is None:
                continue  # drop keys with None value
            result[new_key] = value

    # Move cache_size and region into limits
    limits = {}
    for key in ["cache_size", "region"]:
        if key in cfg:
            value = cfg[key]
            if value is None:
                continue  # drop keys with None value
            limits[key] = value
    result["limits"] = limits

    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        value = cfg["timeout_ms"]
        if value is None:
            continue  # drop keys with None value
        result["timeout_s"] = float(value) / 1000.0

    return result
