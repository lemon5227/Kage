def pick_jobs(items, capacity):
    """Choose parcels to maximize total score within capacity.

    Each item is a dict with a unique string "id", a positive integer
    "size" and a non-negative integer "score".  Returns the sorted list
    of ids whose total score is as large as possible while total size
    stays <= capacity.  If several selections tie on total score, return
    the lexicographically smallest sorted id list.  An empty selection
    is allowed.  Raises ValueError if capacity is negative or any size
    is <= 0.  The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # Sort items by score descending, then by id ascending for tie-breaking
    # This ensures we consider higher scores first and handles lexicographic
    # ordering when scores are equal.
    sorted_items = sorted(
        items,
        key=lambda item: (-item["score"], item["id"])
    )

    # Greedy selection: iterate through sorted items and pick those that fit
    total_size = 0
    selected_ids = []

    for item in sorted_items:
        size = item["size"]
        score = item["score"]

        if total_size + size <= capacity:
            total_size += size
            selected_ids.append(item["id"])

    return sorted(selected_ids)
