def count_entries(lines):
    """Count lines by level in log format: "<timestamp> <LEVEL> <service>: <message>"

    Returns a dict mapping each level to its count. Levels are case-insensitive
    and reported upper-case. Malformed lines are skipped. Keys with zero count
    are omitted.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed line
        level = parts[1].upper()
        if not level.isalpha():
            continue  # invalid level
        counts[level] = counts.get(level, 0) + 1
    return counts
