def allocate(items, capacity):
    """Select parcels to maximize total score within capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer (must be > 0)
      - "score": non-negative integer

    Returns the sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total
    score, return the lexicographically smallest sorted id list. An empty
    selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # Standard 0/1 knapsack DP over capacity.
    # dp[c] = (max_score, chosen_ids) for capacity c.
    # We track the best score and lexicographically smallest id list.
    best = [None] * (capacity + 1)
    for c in range(capacity + 1):
        best[c] = (0, [])

    for item in items:
        idx = item["id"]
        size = item["size"]
        score = item["score"]
        # Iterate capacity descending to avoid reusing the same item.
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = best[c - size]
            cand_score = prev_score + score
            cand_ids = sorted(prev_ids + [idx])
            cur_best = best[c]
            if cand_score > cur_best[0]:
                best[c] = (cand_score, cand_ids)
            elif cand_score == cur_best[0] and cand_ids < cur_best[1]:
                best[c] = (cand_score, cand_ids)

    return best[capacity][1]
