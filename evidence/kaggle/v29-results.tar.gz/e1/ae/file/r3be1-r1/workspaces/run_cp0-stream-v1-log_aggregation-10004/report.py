import re

def digest_lines(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased; ignore lines that do not match.
    Returns a plain dict of counts.
    """
    counts = {}
    pattern = re.compile(r'^\S+\s+(\S+)\s+\S+:\s')
    
    for line in lines:
        if not isinstance(line, str):
            continue
        match = pattern.match(line.strip())
        if not match:
            continue
        level = match.group(1).upper()
        counts[level] = counts.get(level, 0) + 1
    
    return counts
