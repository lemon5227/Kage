def select_tasks(items, capacity):
    """Select a subset of items maximizing total score within capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer (weight)
      - "score": non-negative integer (value)

    Returns the sorted list of ids whose total score is maximal
    while total size stays <= capacity. Ties on total score are
    broken by returning the lexicographically smallest sorted id list.

    An empty selection is allowed. Raises ValueError if capacity is
    negative or any item size is <= 0. The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy relevant data without modifying the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = (max_score, sorted_id_list) for capacity w.
    # We track the best (score, id_tuple) achievable at each weight.
    # Initialize with (-inf, empty) to indicate unreachable.
    NEG_INF = None
    dp = [(NEG_INF, []) for _ in range(capacity + 1)]
    dp[0] = (0, [])

    for idx in range(n):
        item_id, size, score = entries[idx]
        # Iterate capacities descending to avoid using the same item twice.
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[w - size]
            if prev_score is NEG_INF:
                continue
            cand_score = prev_score + score
            cand_ids = sorted(prev_ids + [item_id])
            cur_score, cur_ids = dp[w]
            if cand_score > cur_score or (cand_score == cur_score and cand_ids < cur_ids):
                dp[w] = (cand_score, cand_ids)

    best_score, best_ids = dp[capacity]
    if best_score is NEG_INF:
        return []
    return best_ids
