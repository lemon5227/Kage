def choose(items, capacity):
    """Select jobs under a capacity limit to maximize total value.
    
    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Returns the sorted list of ids whose
    total value is as large as possible while total weight stays <= capacity.
    If several selections tie on total value, return the lexicographically
    smallest sorted id list. An empty selection is allowed.
    
    Raises ValueError if capacity is negative or any weight is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("weight must be positive")
    
    if not items:
        return []
    
    # Create a list of (id, weight, value) tuples
    entries = [(item["id"], item["weight"], item["value"]) for item in items]
    
    # Dynamic programming: dp[w] = (max_value, sorted_ids) for capacity w
    # We'll track which items were selected to reconstruct the solution
    dp = [None] * (capacity + 1)
    dp[0] = ([], 0)  # capacity 0: no items selected, value 0
    
    # Process each item in order
    for item_id, weight, value in entries:
        # Iterate backwards to avoid using the same item multiple times
        for w in range(capacity, weight - 1, -1):
            if dp[w - weight] is not None and dp[w - weight][1] + value > dp[w][1]:
                # Found a better value at capacity w
                prev_ids, prev_value = dp[w - weight]
                dp[w] = (sorted(prev_ids + [item_id]), prev_value + value)
    
    # The result is the best value at capacity <= capacity
    best_value = 0
    best_ids = []
    for w in range(capacity + 1):
        if dp[w] is not None and dp[w][1] > best_value:
            best_value = dp[w][1]
            best_ids = dp[w][0]
    
    return best_ids
