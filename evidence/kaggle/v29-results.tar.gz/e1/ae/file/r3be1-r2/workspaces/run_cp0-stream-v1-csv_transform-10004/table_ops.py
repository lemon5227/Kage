import csv
import io


def clean_rows(text):
    """Clean an exported table from CSV text.

    Input: CSV text with a header row (columns: id, team, score).
    Output: Cleaned CSV text with the same header.

    Steps:
    1. Strip leading/trailing whitespace from every cell.
    2. Drop rows whose "score" cell is empty.
    3. Remove duplicate rows by "team", keeping the first occurrence.
    4. Sort rows by "score" ascending as strings (stable).

    Returns:
        Empty string if input is empty.
        Header-only input returns just the header line.
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header row
    header = rows[0]
    # Ensure we have the expected columns
    expected_cols = ["id", "team", "score"]
    if len(header) != len(expected_cols):
        raise ValueError(
            f"Expected header {expected_cols}, got {header}"
        )

    # Process data rows (skip header)
    data_rows = rows[1:]

    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        new_row = [cell.strip() for cell in row]
        cleaned_rows.append(new_row)

    # Step 2: Drop rows whose "score" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) < 3:
            continue
        score = row[2]
        if not score:
            continue
        filtered_rows.append(row)

    # Step 3: Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    deduped_rows = []
    for row in filtered_rows:
        team = row[1]
        if team in seen_teams:
            continue
        seen_teams.add(team)
        deduped_rows.append(row)

    # Step 4: Sort rows by "score" ascending as strings (stable)
    # Use a stable sort key that preserves order for equal scores
    def sort_key(row):
        return (row[2], row[0], row[1])

    sorted_rows = sorted(deduped_rows, key=sort_key)

    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(header)
    for row in sorted_rows:
        writer.writerow(row)

    return output.getvalue()
