import unicodedata


def label_id(text):
    """Build a URL slug from text.

    - Apply NFKD normalization to decompose characters.
    - Drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization decomposes characters into base + combining marks
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    prev_char_is_alnum = False
    for char in lower:
        if char.isalnum():  # a-z and 0-9
            if not prev_char_is_alnum:
                slug.append(char)
            prev_char_is_alnum = True
        else:
            if not prev_char_is_alnum:
                slug.append("-")
                prev_char_is_alnum = False
            else:
                # Skip consecutive non-alnum characters
                pass

    result = "".join(slug)

    # Strip leading and trailing "-"
    while result.startswith("-"):
        result = result[1:]
    while result.endswith("-"):
        result = result[:-1]

    return result
