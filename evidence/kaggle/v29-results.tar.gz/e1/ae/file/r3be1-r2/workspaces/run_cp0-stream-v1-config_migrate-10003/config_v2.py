def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.
    
    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    Output has "version": 2.
    Renames top-level keys: "dir" -> "directory", "host" -> "hostname".
    Moves "port" and "workers" into a sub-dict "storage" (always present).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")
    
    # Create new dict without modifying input
    result = {"version": 2}
    
    # Process top-level keys
    for key, value in list(cfg.items()):
        # Skip None values
        if value is None:
            continue
            
        if key == "dir":
            result["directory"] = value
        elif key == "host":
            result["hostname"] = value
        elif key == "port":
            # Move to storage sub-dict
            storage = result.setdefault("storage", {})
            storage["port"] = value
        elif key == "workers":
            storage = result.setdefault("storage", {})
            storage["workers"] = value
        elif key == "timeout_ms":
            # Convert milliseconds to seconds (float)
            result["timeout_s"] = float(value) / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value
    
    return result
