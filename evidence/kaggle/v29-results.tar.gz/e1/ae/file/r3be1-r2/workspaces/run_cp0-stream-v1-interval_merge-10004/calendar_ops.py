def merge_slots(intervals):
    """Merge overlapping intervals in a list of [start, end] pairs.

    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals in the same [start, end] list form,
    sorted by start ascending. Touching intervals like [1,3] and [3,5]
    are NOT merged; only real overlaps merge.

    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate all intervals first
    for start, end in intervals:
        if start > end:
            raise ValueError(
                "Invalid interval: start ({}) > end ({})".format(start, end)
            )

    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda pair: pair[0])

    merged = []
    for start, end in sorted_intervals:
        if merged and start < merged[-1][1]:
            # Real overlap: merge by extending the end if needed
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    return merged
