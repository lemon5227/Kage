def aggregate_log(lines):
    """Aggregate log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    
    Returns a dict mapping service names to counts for ERROR and WARN levels only.
    Level names are compared case-insensitively; keys in the result are upper-case.
    Malformed input lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # Format: <timestamp> <LEVEL> <service>: <message>
        # Timestamp is the first part (could be any string)
        level = parts[1].upper()
        service = parts[2]
        # Check if service contains a colon (e.g., "service-name: message")
        # We need to extract the service name before the colon
        if ':' in service:
            service = service.split(':')[0]
        # Only count ERROR and WARN levels
        if level not in ('ERROR', 'WARN'):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
