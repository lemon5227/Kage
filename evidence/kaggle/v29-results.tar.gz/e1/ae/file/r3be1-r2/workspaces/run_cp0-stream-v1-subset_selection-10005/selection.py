def allocate(items, capacity):
    """Select items to maximize total score while total size <= capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer
      - "score": non-negative integer

    Returns the sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total
    score, return the lexicographically smallest sorted id list. An empty
    selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # Use dynamic programming to find the maximum score for each capacity.
    # dp[c] = (max_score, chosen_ids) for capacity c.
    # We'll track the best selection for each capacity, and then backtrack.
    # Since we need lexicographically smallest sorted id list on ties,
    # we'll store both the score and the selection, and compare accordingly.

    # Initialize dp[0] = (0, []) and dp[c] = (-inf, None) for c > 0.
    # We'll use a list of tuples: (score, sorted_ids).
    # For efficiency, we can compute iteratively over items.

    # dp[c] = best (score, sorted_ids) achievable with capacity <= c.
    # Actually, we need to track the exact capacity used to ensure we don't
    # exceed capacity. Let's use a list where dp[c] is the best selection
    # for exactly capacity c, and then take the best among all c <= capacity.

    # Initialize with no items selected.
    # We'll use a list of (score, sorted_ids) for each capacity from 0 to capacity.
    # Start with dp[0] = (0, []), and dp[c] = None for c > 0.
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for item in items:
        item_id = item["id"]
        size = item["size"]
        score = item["score"]

        # Iterate capacities from capacity down to size.
        for c in range(capacity, size - 1, -1):
            if dp[c] is None:
                continue
            prev_score, prev_ids = dp[c - size]
            new_score = prev_score + score
            new_ids = sorted(prev_ids + [item_id])

            # Compare with current dp[c]. If new_score is greater, update.
            # If equal, choose lexicographically smaller sorted id list.
            if dp[c] is None or new_score > dp[c][0] or (new_score == dp[c][0] and new_ids < dp[c][1]):
                dp[c] = (new_score, new_ids)

    # Find the best selection among all capacities <= capacity.
    best_score = None
    best_ids = None

    for c in range(capacity + 1):
        if dp[c] is None:
            continue
        score, ids = dp[c]
        if best_score is None or score > best_score or (score == best_score and ids < best_ids):
            best_score = score
            best_ids = ids

    return best_ids
