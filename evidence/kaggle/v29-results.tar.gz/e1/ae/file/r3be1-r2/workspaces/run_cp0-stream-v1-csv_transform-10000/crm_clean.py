import csv
import io


def normalize_table(text):
    """Clean CSV text with header row (columns: score, id, email, name).

    - Strip leading/trailing whitespace from every cell.
    - Drop rows whose "name" cell is empty.
    - Lower-case the "email" column.
    - Remove duplicate rows by "name", keeping the first occurrence.
    - Sort rows by "email" ascending as strings (stable).

    Returns cleaned CSV text with the same header.
    Empty string returns ''; header-only input returns just the header line.
    Output uses '\n' line endings.
    """
    if not text:
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Extract header
    header = [cell.strip() for cell in rows[0]]
    # Ensure we have the expected columns
    expected_cols = ["score", "id", "email", "name"]
    if len(header) != len(expected_cols):
        # If header doesn't match, just use what we have
        pass

    # Process data rows
    data_rows = []
    seen_names = set()

    for row in rows[1:]:
        # Strip whitespace from all cells
        cleaned_row = [cell.strip() for cell in row]

        # Check if "name" is empty (drop such rows)
        name_idx = header.index("name") if "name" in header else -1
        if name_idx >= 0 and not cleaned_row[name_idx]:
            continue

        # Lower-case the "email" column
        email_idx = header.index("email") if "email" in header else -1
        if email_idx >= 0:
            cleaned_row[email_idx] = cleaned_row[email_idx].lower()

        # Remove duplicates by "name", keeping first occurrence
        name_val = cleaned_row[name_idx] if name_idx >= 0 else ""
        if name_val in seen_names:
            continue
        seen_names.add(name_val)

        data_rows.append(cleaned_row)

    # Sort rows by "email" ascending as strings (stable)
    email_idx = header.index("email") if "email" in header else -1
    if email_idx >= 0:
        data_rows.sort(key=lambda row: row[email_idx], stable=True)
    else:
        # If no email column, sort by name or keep original order
        name_idx = header.index("name") if "name" in header else -1
        if name_idx >= 0:
            data_rows.sort(key=lambda row: row[name_idx], stable=True)

    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in data_rows:
        writer.writerow(row)

    return output.getvalue()
