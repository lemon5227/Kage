def select_tasks(items, capacity):
    """Select parcels under a capacity limit to maximize total gain.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    validated_items = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        item_id = item["id"]
        
        if cost <= 0:
            raise ValueError("cost must be positive")
        
        validated_items.append({
            "id": item_id,
            "cost": cost,
            "gain": gain
        })
    
    # Dynamic programming for 0/1 knapsack
    # dp[w] = (max_gain, selected_ids) for capacity w
    # We'll track which items were selected to ensure lexicographic ordering
    
    n = len(validated_items)
    # dp[w] = maximum gain achievable with capacity w
    dp = [0] * (capacity + 1)
    # parent[w] = index of last item added to achieve dp[w]
    parent = [-1] * (capacity + 1)
    
    for i in range(n):
        cost = validated_items[i]["cost"]
        gain = validated_items[i]["gain"]
        # Iterate backwards to avoid using the same item twice
        for w in range(capacity, cost - 1, -1):
            if dp[w - cost] + gain > dp[w]:
                dp[w] = dp[w - cost] + gain
                parent[w] = i
    
    # Reconstruct the solution
    selected_indices = []
    w = capacity
    for i in range(n - 1, -1, -1):
        if parent[w] == i:
            selected_indices.append(i)
            w -= validated_items[i]["cost"]
    
    # Sort indices by item id (lexicographically smallest)
    selected_ids = [validated_items[idx]["id"] for idx in selected_indices]
    selected_ids.sort()
    
    return selected_ids
