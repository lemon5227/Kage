def choose(items, capacity):
    """Select jobs under a capacity limit to maximize total value.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity. If several selections tie on total value, returns
    the lexicographically smallest sorted id list. An empty selection is
    allowed. Raises ValueError if capacity is negative or any weight is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("weight must be positive")

    # Dynamic programming: dp[w] = (max_value, selected_ids) for capacity w
    # We track the actual selection to handle tie-breaking correctly.
    # Initialize with empty selection at capacity 0.
    dp = [(0, []) for _ in range(capacity + 1)]

    for item in items:
        item_id = item["id"]
        weight = item["weight"]
        value = item["value"]

        # Iterate backwards to avoid using the same item multiple times
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            new_value = prev_value + value
            new_ids = prev_ids + [item_id]

            # Compare: prefer higher value, then lexicographically smaller id list
            if new_value > prev_value or (new_value == prev_value and new_ids < prev_ids):
                dp[w] = (new_value, new_ids)

    # The answer is the best result for all capacities up to capacity
    max_value = 0
    best_ids = []
    for w in range(capacity + 1):
        value, ids = dp[w]
        if value > max_value or (value == max_value and ids < best_ids):
            max_value = value
            best_ids = ids

    return sorted(best_ids)
