def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            f"Expected version 1, got {version!r} (type {type(version).__name__})"
        )

    # Start with a copy to avoid mutating the input
    result = {"version": 2}

    # Process top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        timeout_ms = cfg["timeout_ms"]
        if not isinstance(timeout_ms, (int, float)):
            raise ValueError(
                f"timeout_ms must be a number, got {type(timeout_ms).__name__}"
            )
        result["timeout_s"] = float(timeout_ms) / 1000.0

    # Build network sub-dict
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        retries = cfg["retries"]
        if not isinstance(retries, (int, float)):
            raise ValueError(
                f"retries must be a number, got {type(retries).__name__}"
            )
        network["retries"] = float(retries)
    result["network"] = network

    # Drop keys whose value is None
    for key in list(result.keys()):
        if result[key] is None:
            del result[key]

    return result
