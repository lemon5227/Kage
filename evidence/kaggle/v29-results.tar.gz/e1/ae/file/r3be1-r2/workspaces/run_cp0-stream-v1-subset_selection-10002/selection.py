def select_tasks(items, capacity):
    """Select a subset of items whose total size is at most capacity and
    total score is maximized.  If several selections tie on total score,
    return the lexicographically smallest sorted id list.

    Each item is a dict with a unique string "id", a positive integer
    "size" and a non-negative integer "score".  An empty selection is
    allowed.  Raise ValueError if capacity is negative or any size is <= 0.
    Do not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("size must be positive")

    # DP over capacity, tracking the best (score, sorted_ids) for each capacity.
    # We use a list of (score, tuple_of_ids) where ids are sorted.
    # Initialize with (0, ()) for capacity 0.
    best = [(0, ())]  # (score, sorted_ids) for capacity 0

    # Process items one by one.
    for item in items:
        item_id = item["id"]
        size = item["size"]
        score = item["score"]

        # We need to consider adding this item to previous capacities.
        # We'll iterate over capacities from capacity down to size.
        # best[c] is the best (score, sorted_ids) for capacity c using items processed so far.
        # We'll create a new list for the next state.
        new_best = []
        for cap in range(capacity + 1):
            # Copy the previous best for this capacity.
            prev_score, prev_ids = best[cap]

            # Try adding the item if we have enough remaining capacity.
            if cap >= size:
                # Compute the new sorted id list.
                new_ids = tuple(sorted([item_id] + list(prev_ids)))
                new_score = prev_score + score

                # Compare with existing best for this capacity.
                # We want to maximize score, and break ties by lexicographically smallest sorted ids.
                if (new_score, new_ids) > (prev_score, prev_ids):
                    prev_score, prev_ids = new_score, new_ids

            new_best.append((prev_score, prev_ids))

        best = new_best

    # The answer is the best result for capacity exactly equal to the given capacity.
    final_score, final_ids = best[capacity]
    return list(final_ids)
