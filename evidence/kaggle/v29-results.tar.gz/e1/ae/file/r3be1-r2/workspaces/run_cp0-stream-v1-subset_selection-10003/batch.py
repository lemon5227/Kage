def pick_jobs(items, capacity):
    """Choose parcels to maximize total score within capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer (must be > 0)
      - "score": non-negative integer (>= 0)

    Returns the sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total
    score, return the lexicographically smallest sorted id list. An empty
    selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # Use dynamic programming for the 0/1 knapsack problem.
    # dp[w] = (max_score, chosen_ids) for capacity w.
    # We track the best score and the lexicographically smallest id list
    # among those achieving that score.
    # Initialize with zero capacity: score 0, empty list.
    dp = [(0, [])] * (capacity + 1)

    for item in items:
        idx = item["id"]
        size = item["size"]
        score = item["score"]

        # Iterate capacities from high to low to avoid using the same item twice.
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[w - size]
            cand_score = prev_score + score
            cand_ids = sorted(prev_ids + [idx])

            # Compare with current dp[w]: prefer higher score, then lexicographically smaller ids.
            if cand_score > prev_score or (cand_score == prev_score and cand_ids < prev_ids):
                dp[w] = (cand_score, cand_ids)

    # The answer is the best result among all capacities up to capacity.
    best_score, best_ids = max(dp, key=lambda pair: (pair[0], tuple(pair[1])))
    return best_ids
