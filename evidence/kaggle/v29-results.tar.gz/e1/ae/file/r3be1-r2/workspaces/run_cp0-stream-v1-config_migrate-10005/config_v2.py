def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.
    
    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    Output has "version": 2.
    Renames top-level keys: "user" -> "username", "dir" -> "directory".
    Moves "cache_size" and "retries" into a sub-dict "limits".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")
    
    # Create a new dict to avoid modifying the input
    result = {"version": 2}
    
    # Process top-level keys
    for key in list(cfg.keys()):
        value = cfg[key]
        
        # Skip keys with None values
        if value is None:
            continue
        
        # Handle specific key transformations
        if key == "user":
            result["username"] = value
        elif key == "dir":
            result["directory"] = value
        elif key == "cache_size":
            # Move into limits sub-dict
            if "limits" not in result:
                result["limits"] = {}
            result["limits"]["cache_size"] = value
        elif key == "retries":
            # Move into limits sub-dict
            if "limits" not in result:
                result["limits"] = {}
            result["limits"]["retries"] = value
        elif key == "timeout_ms":
            # Convert to timeout_s (float)
            result["timeout_s"] = float(value) / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value
    
    return result
