def merge_slots(intervals):
    """Merge overlapping intervals. Each interval is a dict {"from": s, "to": e} with integer values.
    
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] are merged.
    Raises ValueError if any interval has start > end.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        from_val = interval["from"]
        to_val = interval["to"]
        if from_val > to_val:
            raise ValueError(f"Interval {interval} has start > end")
        normalized.append((from_val, to_val))
    
    # Sort by start value
    normalized.sort(key=lambda x: x[0])
    
    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1] + 1:
            # Touching or overlapping - merge them
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    
    # Convert back to dict format
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})
    
    return result
