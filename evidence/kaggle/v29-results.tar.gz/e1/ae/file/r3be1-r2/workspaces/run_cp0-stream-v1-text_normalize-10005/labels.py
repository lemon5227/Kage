import unicodedata


def to_key(text):
    """Normalize labels into identifiers.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case the result.
    - Replace every run of characters outside [a-z0-9] with a single "_".
    - Strip leading and trailing "_".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks.
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII).
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case.
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_".
    result = []
    prev_char = None
    for ch in lower:
        if ch not in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev_char is not None:
                # End of a run of non-alphanumeric chars.
                result.append("_")
            prev_char = None
        else:
            if prev_char is None or prev_char != "_":
                # Start of a new alphanumeric run.
                result.append(ch)
            prev_char = ch

    return "".join(result).strip("_")
