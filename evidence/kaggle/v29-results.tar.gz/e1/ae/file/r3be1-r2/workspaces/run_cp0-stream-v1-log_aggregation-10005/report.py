def summarize(lines):
    """Count WARN lines per service.

    Each line is expected to be: "<timestamp> <LEVEL> <service>: <message>"
    Only lines with LEVEL == WARN (case-insensitive) are counted.
    Malformed lines are skipped.
    Returns a dict mapping service name to count, omitting zero counts.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # First two tokens: timestamp and LEVEL
        level = parts[1].upper()
        # Service is after the colon following LEVEL
        # Format: "<timestamp> <LEVEL> <service>: <message>"
        # So parts[2] should be the service name before the colon
        if len(parts) < 3 or parts[2].endswith(':'):
            continue
        service = parts[2]
        if level != "WARN":
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
