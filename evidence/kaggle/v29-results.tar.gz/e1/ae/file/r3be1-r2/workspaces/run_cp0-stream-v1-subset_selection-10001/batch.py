def allocate(items, capacity):
    """Select jobs under a capacity limit to maximize total gain.

    Each item is a dict with a unique string "id", a positive integer
    "cost" and a non-negative integer "gain". Returns the sorted list of
    ids whose total gain is as large as possible while total cost stays
    <= capacity. If several selections tie on total gain, returns the
    lexicographically smallest sorted id list. An empty selection is
    allowed. Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")

    # Use dynamic programming (0/1 knapsack) to find the maximum gain
    # dp[c] = (max_gain, sorted_ids) for capacity c
    # We'll track both the gain and the selection to handle tie-breaking

    # Initialize: dp[c] = (gain, tuple of ids) for each capacity from 0 to capacity
    # dp[0] = (0, ()) - zero gain with empty selection
    dp = [(0, ())] * (capacity + 1)

    for item in items:
        item_id = item["id"]
        cost = item["cost"]
        gain = item["gain"]

        # Iterate backwards to avoid using the same item multiple times
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            new_gain = prev_gain + gain
            new_ids = sorted(prev_ids + [item_id])

            # Compare with current dp[c]
            if new_gain > prev_gain:
                dp[c] = (new_gain, new_ids)
            elif new_gain == prev_gain:
                # Tie-breaking: choose lexicographically smallest sorted id list
                if new_ids < prev_ids:
                    dp[c] = (new_gain, new_ids)

    # The answer is at dp[capacity]
    return dp[capacity][1]
