def spin_board(grid, turns):
    """Rotate a grid of rows 90 degrees clockwise `turns` times.

    Negative turns rotate counter-clockwise; only turns % 4 matters.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    """
    if not isinstance(grid, (list, tuple)):
        raise ValueError("grid must be a list of rows")

    rows = list(grid)
    if not rows:
        return []

    widths = {len(row) for row in rows}
    if len(widths) > 1:
        raise ValueError("all rows must have the same length")

    width = widths.pop()
    if width == 0:
        return [[] for _ in rows]

    n = turns % 4
    if n == 0:
        return [list(row) for row in rows]

    result = [list(row) for row in rows]
    for _ in range(n):
        # 90 degrees clockwise: new[r][c] = old[height-1-c][r]
        height = len(result)
        result = [
            [result[height - 1 - c][r] for c in range(height)]
            for r in range(len(result[0]))
        ]
    return result
