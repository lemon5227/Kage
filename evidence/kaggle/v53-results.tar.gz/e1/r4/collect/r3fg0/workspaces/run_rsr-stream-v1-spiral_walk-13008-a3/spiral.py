def spiral_order(matrix):
    """Return the elements of a matrix in clockwise spiral order.

    The matrix is a list of equally long lists. Traversal starts at the
    top-left corner, goes right along the top row, down the right column,
    left along the bottom row, up the left column, and continues inwards
    until every element has been visited exactly once.

    Returns [] for an empty matrix or a matrix whose rows are empty.
    Raises ValueError if the rows differ in length.
    """
    if not matrix:
        return []

    # Check all rows have the same length
    lengths = [len(row) for row in matrix]
    if len(set(lengths)) > 1:
        raise ValueError("matrix rows must all have the same length")

    width = lengths[0]
    if width == 0:
        return []

    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, width - 1

    while top <= bottom and left <= right:
        # top row, left -> right
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1

        # right column, top -> bottom
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1

        if top <= bottom:
            # bottom row, right -> left
            for col in range(right, left - 1, -1):
                result.append(matrix[bottom][col])
            bottom -= 1

        if left <= right:
            # left column, bottom -> top
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][left])
            left += 1

    return result
