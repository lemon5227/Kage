def turn_grid(grid, turns):
    """Rotate a grid (list of equal-length rows) counter-clockwise by `turns` * 90 degrees.

    Negative turns rotate clockwise; only turns % 4 matters.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    """
    # Normalize to 0-3 range for clarity
    n = turns % 4

    # Counter-clockwise rotation: 90° CCW = 270° clockwise, or equivalently 3 rotations clockwise
    # So we perform (4 - n) clockwise rotations if n != 0
    if n == 0:
        return [] if not grid else [list(row) for row in grid]

    # For 90° CCW, we can rotate clockwise 3 times (or directly compute the transpose with reversed order)
    # Direct approach: 90° CCW = transpose then reverse rows
    result = []
    if not grid:
        return result

    width = len(grid[0])
    for row in grid:
        if len(row) != width:
            raise ValueError("All rows must have the same length")

    # Perform 3 clockwise rotations (each 90° CW)
    # First rotation: transpose then reverse each row (or zip(*grid[::-1]))
    # Let's do it step by step for clarity
    temp = grid[:]
    for _ in range(3):
        # 90° clockwise: first column (bottom-up) becomes first row
        temp = [list(col) for col in zip(*temp[::-1])]
    return temp
