def parse_duration(text):
    """Convert a duration text to the total number of whole minutes.

    A duration is one or more parts, each a non-negative integer followed by a
    unit (d, h, m, s). Spaces between parts are allowed and ignored. Units must
    appear from largest to smallest and each at most once.

    Returns the sum of all parts converted to minutes (seconds are dropped).
    Raises ValueError for empty text, missing number, unknown unit, repeated unit,
    or units in the wrong order.
    """
    if not isinstance(text, str):
        raise ValueError("duration text must be a string")

    # Units and their values in minutes
    _VALUES = {"d": 1440, "h": 60, "m": 1, "s": 0}
    _ORDER = ["d", "h", "m", "s"]

    total_minutes = 0
    seen = []  # units seen so far, in order of appearance
    i = 0
    n = len(text)
    found_part = False

    while i < n:
        ch = text[i]

        if ch.isspace():
            i += 1
            continue

        # Parse the number.
        start = i
        while i < n and text[i].isdigit():
            i += 1
        if i == start:
            raise ValueError("missing number at position %d" % start)
        number = int(text[start:i])

        # Skip spaces between number and unit.
        while i < n and text[i].isspace():
            i += 1

        # Parse the unit.
        if i >= n:
            raise ValueError("missing unit at position %d" % i)
        unit = text[i]
        if unit not in _VALUES:
            raise ValueError("unknown unit %r" % unit)
        i += 1

        if unit in seen:
            raise ValueError("repeated unit %r" % unit)
        if seen and _ORDER.index(unit) < _ORDER.index(seen[-1]):
            raise ValueError("units out of order: %r after %r" % (unit, seen[-1]))

        seen.append(unit)
        total_minutes += number * _VALUES[unit]
        found_part = True

    if not found_part:
        raise ValueError("empty duration text")

    return total_minutes
