def turn_grid(grid, turns):
    """Rotate a grid (list of equal-length rows) counter-clockwise by `turns` * 90 degrees.

    Positive turns rotate counter-clockwise; negative turns rotate clockwise.
    Only turns % 4 matters. Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    An empty grid or a grid of empty rows is returned unchanged as a new list.
    """
    rows = [list(row) for row in grid]

    if not rows:
        return []

    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("All rows must have the same length")

    if width == 0:
        return [[] for _ in rows]

    n = turns % 4
    # Counter-clockwise rotation: first row (left-to-right) becomes last column (top-to-bottom)
    result = rows
    for _ in range(n):
        # 90 degrees counter-clockwise: first row becomes last column
        result = [list(col) for col in zip(*result)]
    return result
