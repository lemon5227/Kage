def spiral_order(matrix):
    if not matrix or not matrix[0]:
        return []
    
    # Check that all lines are of equal length
    line_lengths = [len(row) for row in matrix]
    if not all(length == line_lengths[0] for length in line_lengths):
        raise ValueError("Matrix lines must be of equal length")
    
    n = len(matrix)
    m = len(matrix[0])
    
    # Track boundaries: top, bottom, left, right
    top = 0
    bottom = n - 1
    left = 0
    right = m - 1
    
    result = []
    
    while top <= bottom and left <= right:
        # Move right along the top row
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1
        
        # Move down along the right column
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1
        
        # Check if there's still a row to process
        if top > bottom:
            break
            
        # Move left along the bottom row
        for col in range(right, left - 1, -1):
            result.append(matrix[bottom][col])
        bottom -= 1
        
        # Check if there's still a column to process
        if left > right:
            break
    
    return result
