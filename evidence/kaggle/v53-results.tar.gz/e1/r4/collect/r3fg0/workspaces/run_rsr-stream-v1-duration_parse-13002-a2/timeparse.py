"""Convert duration texts such as '1d2h' or '90m15s' to minutes."""

_UNITS = {"d": 1440, "h": 60, "m": 1, "s": 0}
_ORDER = ["d", "h", "m", "s"]


def to_seconds(text):
    """Return the total number of whole minutes described by ``text`` as an int.

    A duration is one or more parts, each a non-negative integer followed by a
    unit (d, h, m, s). Spaces between parts are allowed and ignored. Units must
    appear from largest to smallest and each at most once.

    Raises ValueError for empty text, a missing number, an unknown unit, a
    repeated unit or units in the wrong order.
    """
    if not isinstance(text, str):
        raise ValueError("duration text must be a string")

    total_minutes = 0
    seen = []  # units seen so far, in order of appearance
    i = 0
    n = len(text)
    found_part = False

    while i < n:
        ch = text[i]

        if ch.isspace():
            i += 1
            continue

        # Parse the number.
        start = i
        while i < n and text[i].isdigit():
            i += 1
        if i == start:
            raise ValueError("missing number at position %d" % start)
        number = int(text[start:i])

        # Skip spaces between number and unit.
        while i < n and text[i].isspace():
            i += 1

        # Parse the unit.
        if i >= n:
            raise ValueError("missing unit at position %d" % i)
        unit = text[i]
        if unit not in _UNITS:
            raise ValueError("unknown unit %r" % unit)
        i += 1

        if unit in seen:
            raise ValueError("repeated unit %r" % unit)
        if seen and _ORDER.index(unit) < _ORDER.index(seen[-1]):
            raise ValueError("units out of order: %r after %r" % (unit, seen[-1]))

        seen.append(unit)
        total_minutes += number * _UNITS[unit]
        found_part = True

    if not found_part:
        raise ValueError("empty duration text")

    return total_minutes
