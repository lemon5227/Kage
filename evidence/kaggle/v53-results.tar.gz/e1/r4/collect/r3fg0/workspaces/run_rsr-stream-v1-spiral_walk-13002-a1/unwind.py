def spiral_order(matrix):
    if not matrix or not matrix[0]:
        return []
    
    # Check all lines have the same length
    row_len = len(matrix[0])
    for row in matrix:
        if len(row) != row_len:
            raise ValueError("Matrix lines differ in length")
    
    top = 0
    bottom = len(matrix) - 1
    left = 0
    right = len(matrix[0]) - 1
    
    result = []
    
    while top <= bottom and left <= right:
        # Move from left to right along the top row
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1
        
        # Move from top to bottom along the right column
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1
        
        # Check if there's still a row to process
        if top > bottom:
            break
            
        # Move from right to left along the bottom row
        for col in range(right, left - 1, -1):
            result.append(matrix[bottom][col])
        bottom -= 1
        
        # Check if there's still a column to process
        if left > right:
            break
        
        # Move from bottom to top along the left column
        for row in range(bottom, top - 1, -1):
            result.append(matrix[row][left])
        left += 1
    
    return result
