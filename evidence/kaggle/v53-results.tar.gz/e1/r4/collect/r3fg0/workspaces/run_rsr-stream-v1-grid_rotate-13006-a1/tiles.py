def turn_grid(grid, turns):
    """Rotate a grid of rows counter-clockwise by 90 degrees, `turns` times.

    Only ``turns % 4`` matters; negative values rotate clockwise.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if the rows have different lengths.
    """
    # Handle empty grid or grid with no rows
    if not grid:
        return []

    # Convert rows to lists for mutability
    rows = [list(row) for row in grid]

    # Check all rows have the same length
    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("all rows must have the same length")

    # Handle empty rows case
    if width == 0:
        return [[] for _ in rows]

    # Calculate effective rotations (mod 4)
    n = turns % 4

    # Perform counter-clockwise rotation n times
    for _ in range(n):
        # Counter-clockwise: first column (bottom to top) becomes first row.
        # Transpose and reverse each row
        rows = [list(col) for col in zip(*rows)][::-1]

    return rows
