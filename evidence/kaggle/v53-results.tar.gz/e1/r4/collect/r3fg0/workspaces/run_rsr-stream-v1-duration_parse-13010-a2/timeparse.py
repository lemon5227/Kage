import re

_UNITS = {"d": 86400, "h": 3600, "m": 60, "s": 1}
_ORDER = ["d", "h", "m", "s"]
_PART_RE = re.compile(r"(\d+)([A-Za-z])")


def parse_duration(text):
    """Convert a duration text like "1d2h" or "90m15s" to total seconds (int).

    Spaces between parts are allowed and ignored ("1h 30m").
    The units must appear from largest to smallest and each at most once.
    Raises ValueError for an empty text, a missing number, an unknown unit,
    a repeated unit or units in the wrong order.
    """
    if not isinstance(text, str):
        raise ValueError("duration must be a string")
    if text == "":
        raise ValueError("empty duration")

    # Split by spaces and remove empty parts
    parts = [p for p in text.split() if p]

    total = 0
    last_index = -1
    seen = set()

    for part in parts:
        match = _PART_RE.match(part)
        if not match:
            raise ValueError("invalid format in %r" % part)

        number, unit = match.group(1), match.group(2)
        if not number.isdigit():
            raise ValueError("missing number in %r" % part)

        if unit not in _UNITS:
            raise ValueError("unknown unit %r" % unit)

        if unit in seen:
            raise ValueError("repeated unit %r" % unit)

        index = _ORDER.index(unit)
        if index <= last_index:
            raise ValueError("units must be in order d, h, m, s")

        seen.add(unit)
        last_index = index
        total += int(number) * _UNITS[unit]

    return total
