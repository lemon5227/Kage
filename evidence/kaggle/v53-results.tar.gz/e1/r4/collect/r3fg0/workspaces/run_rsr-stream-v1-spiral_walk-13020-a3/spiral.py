def spiral_order(matrix):
    """Return the elements of matrix in spiral order.

    The traversal starts at the top-left corner and proceeds inwards in a
    counter-clockwise spiral: first down the left edge, then to the right
    along the bottom line, then up the right edge, and finally to the left
    along the top line, repeating until every element has been visited once.

    The matrix is a list of lists, all of which must have the same length.
    An empty matrix or a matrix whose rows are empty returns [].
    If the rows have different lengths, raises ValueError.
    """
    if not matrix:
        return []

    # Validate that all rows have the same length
    row_lengths = [len(row) for row in matrix]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("all rows must have the same length")

    if not row_lengths[0]:
        return []

    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1

    while top <= bottom and left <= right:
        # down the left edge
        for r in range(top, bottom + 1):
            result.append(matrix[r][left])
        left += 1

        # right along the bottom line
        if top <= bottom:
            for c in range(left, right + 1):
                result.append(matrix[bottom][c])
            bottom -= 1

        # up the right edge
        if left <= right:
            for r in range(bottom, top - 1, -1):
                result.append(matrix[r][right])
            right -= 1

        # left along the top line
        if top <= bottom:
            for c in range(right, left - 1, -1):
                result.append(matrix[top][c])
            top += 1

    return result
