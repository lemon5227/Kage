def spin_board(grid, turns):
    """Rotate a grid of rows 90 degrees counter-clockwise `turns` times.

    Positive turns rotate counter-clockwise; only turns % 4 matters.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    """
    if not isinstance(grid, (list, tuple)):
        raise ValueError("grid must be a list of rows")

    rows = list(grid)
    if not rows:
        return []

    widths = {len(row) for row in rows}
    if len(widths) > 1:
        raise ValueError("all rows must have the same length")

    width = widths.pop()
    if width == 0:
        return [[] for _ in rows]

    n = turns % 4
    if n == 0:
        return [list(row) for row in rows]

    # 90 degrees counter-clockwise: new[r][c] = old[c][height-1-r]
    height = len(rows)
    result = [[0] * height for _ in range(width)]
    for r in range(height):
        for c in range(width):
            result[c][height - 1 - r] = rows[r][c]
    return result
