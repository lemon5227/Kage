def rotate(grid, turns):
    """Rotate a grid (list of equal-length rows) clockwise by `turns` * 90 degrees.

    Negative turns rotate counter-clockwise; only turns % 4 matters.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    """
    rows = [list(row) for row in grid]

    if not rows:
        return []

    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("All rows must have the same length")

    if width == 0:
        return [[] for _ in rows]

    n = turns % 4
    if n == 0:
        return rows

    result = rows
    for _ in range(n):
        # 90 degrees clockwise: first column (bottom-up) becomes first row
        result = [list(col) for col in zip(*result[::-1])]
    return result


def rotate_tiles(grid, turns):
    """Rotate a grid counter-clockwise by `turns` * 90 degrees.

    The grid is a list of rows (lists) of equal length.
    Rotate it by 90 degrees counter-clockwise, `turns` times; `turns` is any integer,
    negative turns rotate the other way and only `turns` modulo 4 matters.
    Return a new list of lists and do not modify the input.
    An empty grid ([]) or a grid of empty rows is returned unchanged as a new list.
    Raise ValueError if the rows have different lengths.
    """
    # Reuse the same logic as rotate, but interpret turns as counter-clockwise.
    # Counter-clockwise rotation by 90° is equivalent to clockwise rotation by -90°.
    # So we compute the effective clockwise rotation amount as (4 - (turns % 4)) % 4.
    rows = [list(row) for row in grid]

    if not rows:
        return []

    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("All rows must have the same length")

    if width == 0:
        return [[] for _ in rows]

    # Convert counter-clockwise turns to clockwise turns.
    # A counter-clockwise rotation by 90° is a clockwise rotation by -90°.
    # In modulo 4 arithmetic: effective_clockwise = (4 - (turns % 4)) % 4
    n = (4 - (turns % 4)) % 4

    if n == 0:
        return rows

    result = rows
    for _ in range(n):
        # 90 degrees clockwise: first column (bottom-up) becomes first row
        result = [list(col) for col in zip(*result[::-1])]
    return result
