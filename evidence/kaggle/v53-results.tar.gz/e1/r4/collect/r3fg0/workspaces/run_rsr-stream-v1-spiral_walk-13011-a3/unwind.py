def walk_spiral(matrix):
    if not matrix:
        return []
    
    # Check all lines are equally long
    lengths = [len(row) for row in matrix]
    if not all(l == lengths[0] for l in lengths):
        raise ValueError("Matrix rows have different lengths")
    
    n = len(matrix)
    m = len(matrix[0])
    
    # Track boundaries: top, bottom, left, right
    top = 0
    bottom = n - 1
    left = 0
    right = m - 1
    
    result = []
    
    while top <= bottom and left <= right:
        # Move down the left edge (top to bottom)
        for row in range(top, bottom + 1):
            result.append(matrix[row][left])
        
        # Move right along the bottom line (left to right)
        if top <= bottom:
            for col in range(left, right + 1):
                result.append(matrix[bottom][col])
        
        # Move up the right edge (bottom to top) - but only if we haven't already processed this column
        if left < right and top <= bottom:
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][right])
        
        # Move left along the top line (right to left) - but only if we haven't already processed this row
        if left < right and top <= bottom:
            for col in range(right, left - 1, -1):
                result.append(matrix[top][col])
        
        # Shrink the boundaries
        top += 1
        bottom -= 1
        left += 1
        right -= 1
    
    return result
