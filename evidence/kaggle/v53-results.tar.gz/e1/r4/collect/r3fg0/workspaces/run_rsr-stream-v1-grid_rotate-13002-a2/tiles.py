def spin_board(grid, turns):
    """Rotate a grid counter-clockwise by 90 degrees, `turns` times.

    Only ``turns % 4`` matters; negative values rotate clockwise.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if the rows have different lengths.
    """
    # Convert rows to lists to ensure mutability
    rows = [list(row) for row in grid]

    if not rows:
        return []

    # Find the width from the first row
    width = len(rows[0])
    
    # Check all rows have the same length
    for row in rows:
        if len(row) != width:
            raise ValueError("all rows must have the same length")

    # Handle empty grid case
    if width == 0:
        return [[] for _ in rows]

    # Perform counter-clockwise rotation `turns` times
    n = turns % 4
    for _ in range(n):
        # Counter-clockwise rotation: first column (bottom to top) becomes first row.
        # This is equivalent to: transpose then reverse each row
        rows = [list(col) for col in zip(*rows)][::-1]

    return rows
