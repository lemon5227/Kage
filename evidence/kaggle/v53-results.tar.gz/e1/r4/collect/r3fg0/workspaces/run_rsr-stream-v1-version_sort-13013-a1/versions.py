def sorted_tags(versions):
    """Sort version strings (dot-separated non-negative integers) newest first.

    Rules:
      - Compare parts as integers so "1.10" > "1.9".
      - A shorter version that is a prefix of a longer one is older,
        so "1.2" comes before "1.2.0".
      - Equal versions are ordered by their string, in the same direction.
      - Raise ValueError for an empty string or any non-numeric part.
    """
    # Validate and normalize each version string.
    def validate_version(version):
        parts = version.split('.')
        for i, part in enumerate(parts):
            if not part.isdigit():
                raise ValueError(f"non-numeric part in version {version!r} at index {i}")
        return parts

    # Normalize: pad with zeros so that shorter versions are treated as older.
    def normalize(version):
        parts = validate_version(version)
        # The number of parts is the "length" of the version.
        # We'll compare tuples of (int_parts, -length) to handle prefix rule.
        return parts

    normalized = []
    for v in versions:
        if not v:
            raise ValueError("empty string in versions list")
        parts = validate_version(v)
        normalized.append((parts, len(parts)))

    # Sort: newest first (descending).
    # Compare by integer parts descending, then by length descending.
    def compare_key(key):
        int_parts = [int(p) for p in key[0]]
        return int_parts[::-1], -key[1]

    normalized.sort(key=compare_key, reverse=True)

    return [v for v, _ in normalized]
