def unwind(matrix):
    """Unwind a matrix in clockwise spiral order.

    Starts at the top-left corner, moves right along the top line, then down
    the right edge, left along the bottom line, and up the left edge,
    proceeding inwards until every element is visited exactly once.

    Returns a flat list of the visited elements.
    Raises ValueError if the rows have differing lengths.
    """
    if not matrix:
        return []

    # Check that all rows have the same length
    row_lengths = [len(row) for row in matrix]
    first_len = row_lengths[0] if row_lengths else 0
    if any(length != first_len for length in row_lengths):
        raise ValueError("matrix rows must all have the same length")

    # Handle empty matrix or matrix with empty lines
    if first_len == 0:
        return []

    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, first_len - 1

    while top <= bottom and left <= right:
        # right along the top line
        for c in range(left, right + 1):
            result.append(matrix[top][c])
        top += 1

        # down the right edge
        if top <= bottom:
            for r in range(top, bottom + 1):
                result.append(matrix[r][right])
            right -= 1

        # left along the bottom line
        if left <= right:
            for c in range(right, left - 1, -1):
                result.append(matrix[bottom][c])
            bottom -= 1

        # up the left edge
        if top <= bottom:
            for r in range(bottom, top - 1, -1):
                result.append(matrix[r][left])
            left += 1

    return result
