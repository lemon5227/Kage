def turn_grid(grid, turns):
    """Rotate a grid (list of equal-length rows) counter-clockwise by `turns` * 90 degrees.

    Positive turns rotate counter-clockwise; only turns % 4 matters.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    """
    # Normalize turns to 0-3 (counter-clockwise rotations)
    n = turns % 4

    # Convert rows to lists for mutability
    rows = [list(row) for row in grid]

    if not rows:
        return []

    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("All rows must have the same length")

    if width == 0:
        return [[] for _ in rows]

    # Counter-clockwise rotation: first column (top-down) becomes first row
    # After n rotations (each 90° CCW), the result is the same as
    # rotating clockwise by (4 - n) % 4 degrees.
    # Clockwise rotation formula: [list(col) for col in zip(*result[::-1])]
    # For CCW, we can use: [list(row) for row in zip(*grid)] but applied n times.

    result = rows
    for _ in range(n):
        # 90 degrees counter-clockwise: first column (top-down) becomes first row
        result = [list(col) for col in zip(*result)]

    return result
