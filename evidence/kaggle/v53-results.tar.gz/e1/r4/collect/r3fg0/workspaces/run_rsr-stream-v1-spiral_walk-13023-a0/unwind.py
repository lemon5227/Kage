def walk_spiral(matrix):
    """Unwind a matrix in spiral order, clockwise from top-left."""
    if not matrix or not matrix[0]:
        return []

    # Check that all rows have the same length
    row_len = len(matrix[0])
    for row in matrix:
        if len(row) != row_len:
            raise ValueError("All rows must have the same length")

    n = row_len
    result = []

    top, bottom = 0, len(matrix) - 1
    left, right = 0, n - 1

    while top <= bottom and left <= right:
        # Traverse top row from left to right
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1

        # Traverse right column from top to bottom
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1

        # Traverse bottom row from right to left
        if top <= bottom:
            for col in range(right, left - 1, -1):
                result.append(matrix[bottom][col])
            bottom -= 1

        # Traverse left column from bottom to top
        if left <= right:
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][left])
            left += 1

    return result
