import re

_UNITS = {"d": 86400, "h": 3600, "m": 60, "s": 1}
_ORDER = ["d", "h", "m", "s"]
_PART_RE = re.compile(r"(\d+)([A-Za-z])")


def parse_duration(text):
    """Convert a duration text like "1d2h" or "90m15s" to total seconds (int).

    Raises ValueError for spaces, empty text, missing number, unknown unit,
    repeated unit, or units not in largest-to-smallest order.
    """
    if not isinstance(text, str):
        raise ValueError("duration must be a string")
    if text == "":
        raise ValueError("empty duration")
    if any(ch.isspace() for ch in text):
        raise ValueError("duration must not contain spaces")

    total = 0
    pos = 0
    last_index = -1
    seen = set()

    while pos < len(text):
        match = _PART_RE.match(text, pos)
        if not match:
            # Either a missing number or an unknown/invalid unit.
            if text[pos].isdigit():
                raise ValueError("missing unit at position %d" % pos)
            raise ValueError("missing number at position %d" % pos)

        number, unit = match.group(1), match.group(2)
        if unit not in _UNITS:
            raise ValueError("unknown unit %r" % unit)
        if unit in seen:
            raise ValueError("repeated unit %r" % unit)

        index = _ORDER.index(unit)
        if index <= last_index:
            raise ValueError("units must be in order d, h, m, s")

        seen.add(unit)
        last_index = index
        total += int(number) * _UNITS[unit]
        pos = match.end()

    return total


def to_seconds(text):
    """Convert a duration text to a number.

    A duration is one or more parts written as a non-negative integer followed by a unit:
    d (days), h (hours), m (minutes), s (seconds). For example "1d2h" or "90m15s".
    Return the total number of whole minutes (leftover seconds are dropped) as an int.

    The text must not contain spaces; raise ValueError if it does.
    The units must appear from largest to smallest and each at most once.
    Raise ValueError for an empty text, a missing number, an unknown unit,
    a repeated unit or units in the wrong order.
    """
    # Reuse the same parsing logic
    total_seconds = parse_duration(text)
    return total_seconds // 60
