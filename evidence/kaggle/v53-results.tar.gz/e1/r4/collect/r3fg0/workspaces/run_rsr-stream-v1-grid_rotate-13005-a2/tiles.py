def rotate_tiles(grid, turns):
    """Rotate a grid (list of equal-length rows) counter-clockwise by `turns` * 90 degrees.

    Negative turns rotate clockwise; only turns % 4 matters.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    """
    # Convert rows to lists for mutability
    rows = [list(row) for row in grid]

    if not rows:
        return []

    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("All rows must have the same length")

    # Counter-clockwise rotation: equivalent to 3 clockwise rotations (or -1 mod 4)
    n = turns % 4
    if n == 0:
        return [list(row) for row in rows]

    # Perform n counter-clockwise rotations
    result = rows
    for _ in range(n):
        # Counter-clockwise: first column (top-down) becomes first row
        result = [list(col) for col in zip(*result)]

    return result
