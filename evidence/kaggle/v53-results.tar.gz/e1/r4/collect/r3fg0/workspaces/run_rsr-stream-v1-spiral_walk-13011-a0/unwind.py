def walk_spiral(matrix):
    """Return the elements of a matrix in counter-clockwise spiral order.

    The matrix is a list of equally long lists. Traversal starts at the
    top-left corner and moves inward in a counter-clockwise spiral:
    first down the left edge, then right along the bottom row, up the right
    edge, left along the top row, and continues until every element has been
    visited exactly once.

    Returns [] for an empty matrix or a matrix whose rows are empty.
    Raises ValueError if the rows differ in length.
    """
    if not matrix:
        return []

    lengths = {len(row) for row in matrix}
    if len(lengths) > 1:
        raise ValueError("matrix rows must all have the same length")

    width = lengths.pop()
    if width == 0:
        return []

    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, width - 1

    while top <= bottom and left <= right:
        # down the left edge
        for row in range(top, bottom + 1):
            result.append(matrix[row][left])
        left += 1

        # right along the bottom row
        if left > right:
            break
        for col in range(left, right + 1):
            result.append(matrix[bottom][col])
        bottom -= 1

        # up the right edge
        if top > bottom:
            break
        for row in range(bottom, top - 1, -1):
            result.append(matrix[row][right])
        right -= 1

        # left along the top row
        if left > right:
            break
        for col in range(right, left - 1, -1):
            result.append(matrix[top][col])
        top += 1

    return result
