def rotate(grid, turns):
    """Rotate a grid (list of equal-length rows) clockwise by `turns` * 90 degrees.

    Negative turns rotate counter-clockwise; only turns % 4 matters.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    """
    rows = [list(row) for row in grid]

    if not rows:
        return []

    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("All rows must have the same length")

    if width == 0:
        return [[] for _ in rows]

    n = turns % 4
    if n == 0:
        return rows

    result = rows
    for _ in range(n):
        # 90 degrees clockwise: first column (bottom-up) becomes first row
        result = [list(col) for col in zip(*result[::-1])]
    return result


def rotate_tiles(grid, turns):
    """Rotate a grid counter-clockwise by `turns` * 90 degrees.

    The grid is a list of rows (lists) of equal length.
    Rotate it by 90 degrees counter-clockwise, `turns` times; `turns` is any integer,
    negative turns rotate the other way and only `turns` modulo 4 matters.
    Return a new list of lists and do not modify the input.
    An empty grid ([]) or a grid of empty rows is returned unchanged as a new list.
    Raise ValueError if the rows have different lengths.
    """
    # Reuse the same logic but rotate counter-clockwise instead of clockwise.
    # Counter-clockwise rotation by 90 degrees is equivalent to clockwise rotation by -90 degrees,
    # which is the same as 3 clockwise rotations (or 1 counter-clockwise rotation).
    # We can compute the effective number of clockwise rotations:
    #   clockwise_rotations = (-turns) % 4
    # Then apply the existing clockwise rotation logic.
    rows = [list(row) for row in grid]

    if not rows:
        return []

    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("All rows must have the same length")

    if width == 0:
        return [[] for _ in rows]

    # Effective clockwise rotations for counter-clockwise `turns`
    clockwise_rotations = (-turns) % 4
    if clockwise_rotations == 0:
        return rows

    result = rows
    for _ in range(clockwise_rotations):
        # 90 degrees clockwise: first column (bottom-up) becomes first row
        result = [list(col) for col in zip(*result[::-1])]
    return result
