def rotate(grid, turns):
    """Rotate a grid (list of equal-length rows) clockwise by `turns` * 90 degrees.

    Negative turns rotate counter-clockwise; only turns % 4 matters.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    """
    # Handle empty grid or all-empty rows
    if not grid:
        return []

    # Normalize to list of lists
    rows = [list(row) for row in grid]

    # Check all rows have same length
    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("All rows must have the same length")

    # If width is 0, return empty lists (unchanged structure)
    if width == 0:
        return [[] for _ in rows]

    n = turns % 4
    if n == 0:
        return rows

    result = []
    for _ in range(n):
        # 90 degrees clockwise: first column (bottom-up) becomes first row
        result = [list(col) for col in zip(*result[::-1])]

    return result
