def walk_spiral(matrix):
    if not matrix:
        return []
    
    # Check if all lines have the same length
    lengths = [len(row) for row in matrix]
    if not all(length == lengths[0] for length in lengths):
        raise ValueError("Lines differ in length")
    
    if lengths[0] == 0:
        return []
    
    # Track boundaries
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1
    
    result = []
    
    while top <= bottom and left <= right:
        # Traverse top row from left to right
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1
        
        # Traverse right column from top to bottom
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1
        
        # Check if we still have rows left
        if top <= bottom:
            # Traverse bottom row from right to left
            for col in range(right, left - 1, -1):
                result.append(matrix[bottom][col])
            bottom -= 1
        
        # Check if we still have columns left
        if left <= right:
            # Traverse left column from bottom to top
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][left])
            left += 1
    
    return result
