def turn_grid(grid, turns):
    """Rotate a grid of rows counter-clockwise by 90 degrees, `turns` times.

    Only ``turns % 4`` matters; negative values rotate clockwise.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if the rows have different lengths.
    """
    # Convert rows to lists so we can mutate them safely
    rows = [list(row) for row in grid]

    if not rows:
        return []

    # Check all rows have the same length
    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("all rows must have the same length")

    # Handle empty grid (width == 0)
    if width == 0:
        return [[] for _ in rows]

    # Perform counter-clockwise rotation `turns` times
    # Only the remainder modulo 4 matters
    n = turns % 4
    for _ in range(n):
        # Counter-clockwise: first column (bottom to top) becomes first row.
        # This is equivalent to rotating clockwise 3 times, or transposing then reversing rows.
        # We do it directly: new_row[i] = old_row[width-1-i][0] for each column? Let's derive.
        # Actually, counter-clockwise rotation by 90°: 
        # new_grid[j][i] = old_grid[i][width-1-j]
        # So we can build new rows from columns: first row is last column reversed, etc.
        # Simpler: transpose then reverse each row (which gives clockwise), then reverse again?
        # Let's do it step by step: 
        # Clockwise 90°: new_grid[j][i] = old_grid[width-1-i][j]
        # Counter-clockwise 90°: new_grid[j][i] = old_grid[i][width-1-j]
        # We can achieve this by: 
        #   new_rows = [list(col) for col in zip(*rows)][::-1]
        # Let's verify with a small example:
        # grid = [[1,2],[3,4]] (2x2)
        # Counter-clockwise 90° should be [[3,1],[4,2]]? Wait, let's think:
        # Original:
        #   1 2
        #   3 4
        # Rotate counter-clockwise 90°:
        #   2 4
        #   1 3
        # Actually, I need to be careful. Standard matrix rotation:
        # Clockwise 90°: 
        #   3 1
        #   4 2
        # Counter-clockwise 90°:
        #   2 4
        #   1 3
        # Let's check the formula: new_grid[j][i] = old_grid[i][width-1-j]
        # For j=0, i=0: new[0][0] = old[0][1] = 2 ✓
        # For j=0, i=1: new[0][1] = old[1][1] = 4 ✓
        # For j=1, i=0: new[1][0] = old[0][0] = 1 ✓
        # For j=1, i=1: new[1][1] = old[1][0] = 3 ✓
        # So the result is [[2,4],[1,3]]
        # Now what does [list(col) for col in zip(*rows)][::-1] produce?
        # zip(*rows) gives columns: (1,3), (2,4)
        # [list(col) for col in zip(*rows)] = [[1,3],[2,4]]
        # Then reverse: [[2,4],[1,3]] ✓
        # So the formula is correct.
        rows = [list(col) for col in zip(*rows)][::-1]

    return rows
