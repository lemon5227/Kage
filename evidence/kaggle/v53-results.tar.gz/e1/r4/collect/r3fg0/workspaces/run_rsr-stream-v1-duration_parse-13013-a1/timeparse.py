import re

_UNITS = {"d": 86400, "h": 3600, "m": 60, "s": 1}
_ORDER = ["d", "h", "m", "s"]
_PART_RE = re.compile(r"(\d+)([A-Za-z])")


def parse_duration(text):
    """Convert a duration text to total minutes (int).

    A duration is one or more parts written as a non-negative integer
    followed by a unit: d (days), h (hours), m (minutes), s (seconds).
    Example: "1d2h", "90m15s", "1h 30m".

    Spaces between parts are allowed and ignored.
    Units must appear from largest to smallest and each at most once.
    Returns the total number of whole minutes (seconds are dropped).

    Raises ValueError for:
      - empty text
      - missing number
      - unknown unit
      - repeated unit
      - units in wrong order
    """
    if not isinstance(text, str):
        raise ValueError("duration must be a string")
    if text == "":
        raise ValueError("empty duration")

    # Normalize: remove spaces and split into parts
    normalized = re.sub(r"\s+", "", text)

    if not normalized:
        raise ValueError("empty duration")

    total_seconds = 0
    pos = 0
    last_index = -1
    seen = set()

    while pos < len(normalized):
        match = _PART_RE.match(normalized, pos)
        if not match:
            # Either a missing number or an unknown/invalid unit.
            if normalized[pos].isdigit():
                raise ValueError("missing unit at position %d" % pos)
            raise ValueError("missing number at position %d" % pos)

        number, unit = match.group(1), match.group(2)
        if unit not in _UNITS:
            raise ValueError("unknown unit %r" % unit)
        if unit in seen:
            raise ValueError("repeated unit %r" % unit)

        index = _ORDER.index(unit)
        if index <= last_index:
            raise ValueError("units must be in order d, h, m, s")

        seen.add(unit)
        last_index = index
        total_seconds += int(number) * _UNITS[unit]
        pos = match.end()

    return total_seconds // 60
