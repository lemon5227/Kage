def walk_spiral(matrix):
    """Walk through a matrix in counter-clockwise spiral order.

    Starts at the top-left corner, moves down the left edge, then right
    along the bottom line, up the right edge, and left along the top line,
    continuing inwards until every element is visited exactly once.

    Returns a flat list of the visited elements.
    Raises ValueError if the rows have differing lengths.
    """
    if not matrix:
        return []

    # Validate that all rows have the same length
    row_lengths = [len(row) for row in matrix]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("matrix rows must all have the same length")

    if len(matrix[0]) == 0:
        return []

    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1

    while top <= bottom and left <= right:
        # Down the left edge
        for r in range(top, bottom + 1):
            result.append(matrix[r][left])
        left += 1

        # Right along the bottom line
        if top <= bottom:
            for c in range(left, right + 1):
                result.append(matrix[bottom][c])
            bottom -= 1

        # Up the right edge
        if left <= right:
            for r in range(bottom, top - 1, -1):
                result.append(matrix[r][right])
            right -= 1

        # Left along the top line
        if top <= bottom:
            for c in range(right, left - 1, -1):
                result.append(matrix[top][c])
            top += 1

    return result
