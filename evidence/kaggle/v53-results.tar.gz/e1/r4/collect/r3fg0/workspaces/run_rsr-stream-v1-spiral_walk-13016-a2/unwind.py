def spiral(matrix):
    """Return the elements of a matrix in counter-clockwise spiral order.

    The matrix is a list of equally long lists. Traversal starts at the
    top-left corner and moves inwards in a counter-clockwise direction:
    first down the left edge, then to the right along the bottom row,
    then up the right edge, then to the left along the top row, and so on.

    Returns [] for an empty matrix or a matrix whose rows are empty.
    Raises ValueError if the rows differ in length.
    """
    if not matrix:
        return []

    # Check all rows have the same length
    lengths = [len(row) for row in matrix]
    if len(set(lengths)) > 1:
        raise ValueError("matrix rows must all have the same length")

    width = lengths[0]
    if width == 0:
        return []

    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, width - 1

    while top <= bottom and left <= right:
        # Move down the left edge (top -> bottom)
        for row in range(top, bottom + 1):
            result.append(matrix[row][left])
        left += 1

        # Move right along the bottom row (left -> right)
        if top <= bottom:
            for col in range(left, right + 1):
                result.append(matrix[bottom][col])
            bottom -= 1

        # Move up the right edge (bottom -> top)
        if left <= right:
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][right])
            right -= 1

        # Move left along the top row (right -> left)
        if top <= bottom:
            for col in range(right, left - 1, -1):
                result.append(matrix[top][col])
            top += 1

    return result
