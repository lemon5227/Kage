def turn_grid(grid, turns):
    """Rotate a grid of rows clockwise by 90 degrees, `turns` times.

    Only ``turns % 4`` matters; negative values rotate counter-clockwise.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if the rows have different lengths.
    """
    rows = [list(row) for row in grid]

    if not rows:
        return []

    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("all rows must have the same length")

    if width == 0:
        return [[] for _ in rows]

    n = turns % 4
    for _ in range(n):
        # Clockwise: first row (left to right) becomes last column.
        rows = [list(col) for col in zip(*rows)][::-1]

    return rows
