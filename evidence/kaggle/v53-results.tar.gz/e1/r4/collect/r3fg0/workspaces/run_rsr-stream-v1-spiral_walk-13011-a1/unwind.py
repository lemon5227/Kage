def walk_spiral(matrix):
    """Unwind a matrix in spiral order, counter-clockwise.

    Start at the top-left corner and move inwards:
      - down the left edge
      - right along the bottom line
      - up the right edge
      - left along the top line
    Repeat until all elements have been visited.

    The matrix is a list of equally long lists (one per line).
    If the lines differ in length, raise ValueError.
    For [] or a matrix whose lines are empty, return [].
    """
    if not matrix:
        return []

    # Validate that all rows have the same length.
    if not all(isinstance(row, list) for row in matrix):
        raise ValueError("Each row must be a list.")
    first_len = len(matrix[0])
    if first_len == 0:
        return []
    for row in matrix:
        if len(row) != first_len:
            raise ValueError("All rows must have the same length.")

    # Work on a copy of the matrix so we can mark visited cells.
    # We'll use a separate list of booleans to track which elements have been taken.
    n_rows = len(matrix)
    n_cols = first_len
    visited = [[False] * n_cols for _ in range(n_rows)]

    # Direction vectors: down, right, up, left (counter-clockwise spiral)
    directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]
    dir_idx = 0  # current direction index

    r, c = 0, 0  # start at top-left

    while True:
        # Try to move one step in the current direction.
        nr, nc = r + directions[dir_idx][0], c + directions[dir_idx][1]

        # Check bounds and whether the cell has already been visited.
        if not (0 <= nr < n_rows and 0 <= nc < n_cols):
            # Out of bounds: we've finished the spiral.
            break
        if visited[nr][nc]:
            # This cell was already taken; switch to the next direction.
            dir_idx = (dir_idx + 1) % 4
            continue

        # Mark this cell as visited and add it to the result.
        visited[r][c] = True
        result.append(matrix[r][c])

        # Move to the next cell in the current direction.
        r += directions[dir_idx][0]
        c += directions[dir_idx][1]

    return result
