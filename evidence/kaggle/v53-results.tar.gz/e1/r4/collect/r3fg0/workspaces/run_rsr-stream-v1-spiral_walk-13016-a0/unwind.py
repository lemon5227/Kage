def spiral(matrix):
    if not matrix or not matrix[0]:
        return []

    # Check that all rows have the same length
    row_len = len(matrix[0])
    for row in matrix:
        if len(row) != row_len:
            raise ValueError("lines differ in length")

    n = row_len
    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, n - 1

    while top <= bottom and left <= right:
        # go down the left edge
        for r in range(top, bottom + 1):
            result.append(matrix[r][left])
        left += 1

        # go across the bottom line (rightward)
        if left > right:
            break
        for c in range(left, right + 1):
            result.append(matrix[bottom][c])
        bottom -= 1

        # go up the right edge (upward)
        if top > bottom:
            break
        for r in range(bottom, top - 1, -1):
            result.append(matrix[r][right])
        right -= 1

        # go across the top line (leftward)
        if left > right:
            break
        for c in range(right, left - 1, -1):
            result.append(matrix[top][c])
        top += 1

    return result
