def unwind(matrix):
    """Unwind a matrix in clockwise spiral order.

    Starts at the top-left corner and moves inwards in a spiral, clockwise:
    first along the top line to the right, then down the right edge, then
    left along the bottom line, then up the left edge, and so on until every
    element is visited exactly once.

    Returns a flat list of the visited elements.
    Raises ValueError if the rows have differing lengths.
    """
    if not matrix:
        return []

    # Check all rows have the same length
    row_lengths = [len(row) for row in matrix]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("matrix rows must all have the same length")

    if len(matrix[0]) == 0:
        return []

    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1

    while top <= bottom and left <= right:
        # Traverse from left to right along the top row
        for c in range(left, right + 1):
            result.append(matrix[top][c])
        top += 1

        # Traverse from top to bottom along the right column
        if top <= bottom:
            for r in range(top, bottom + 1):
                result.append(matrix[r][right])
            right -= 1

        # Traverse from right to left along the bottom row
        if top <= bottom:
            for c in range(right, left - 1, -1):
                result.append(matrix[bottom][c])
            bottom -= 1

        # Traverse from bottom to top along the left column
        if left <= right:
            for r in range(bottom, top - 1, -1):
                result.append(matrix[r][left])
            left += 1

    return result
