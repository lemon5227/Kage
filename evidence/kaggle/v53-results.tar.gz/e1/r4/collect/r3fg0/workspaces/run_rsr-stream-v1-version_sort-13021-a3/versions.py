def _parse(version):
    if not isinstance(version, str) or version == "":
        raise ValueError("empty version string")
    parts = version.split(".")
    result = []
    for part in parts:
        if not part.isdigit():
            raise ValueError("non-numeric version part: %r" % (part,))
        result.append(int(part))
    return result


def rank_versions(versions):
    """Sort version strings oldest first.

    Versions are dot-separated non-negative integers compared part by part as
    integers. A shorter version that is a prefix of a longer one is older.
    Equal versions are ordered by their string, in the same (ascending)
    direction. Raises ValueError for an empty string or a non-numeric part.
    """
    parsed = [(version, _parse(version)) for version in versions]

    def key(item):
        version, parts = item
        # Pad with -1 so that a prefix ("1.2") sorts before its extension
        # ("1.2.0") in ascending order.
        width = max(len(parts), 1)
        padded = tuple(parts) + (-1,) * (width - len(parts))
        return (padded, version)

    parsed.sort(key=key)
    return [version for version, _ in parsed]