def rotate(grid, turns):
    """Rotate a grid (list of equal-length rows) counter-clockwise by `turns` * 90 degrees.

    Positive turns rotate counter-clockwise; negative turns rotate clockwise.
    Only turns % 4 matters. Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    """
    # Convert to lists of lists (ensure mutable)
    rows = [list(row) for row in grid]

    if not rows:
        return []

    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("All rows must have the same length")

    if width == 0:
        return [[] for _ in rows]

    n = turns % 4
    # Positive n means counter-clockwise rotations.
    # Counter-clockwise 90°: first row (left-to-right) becomes last column (top-to-bottom).
    # Equivalent to: result[i][j] = grid[j][width - 1 - i]
    result = [[grid[j][width - 1 - i] for j in range(width)] for i in range(len(rows))]
    return result
