def rotate(grid, turns):
    """Rotate a grid (list of equal-length rows) clockwise by `turns` * 90 degrees.

    Negative turns rotate counter-clockwise; only turns % 4 matters.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    """
    # Make a copy so we don't modify the input
    rows = [list(row) for row in grid]

    if not rows:
        return []

    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("All rows must have the same length")

    if width == 0:
        return [[] for _ in rows]

    n = turns % 4
    if n == 0:
        return rows

    # Rotate clockwise n times (each rotation is 90 degrees)
    result = rows
    for _ in range(n):
        # 90 degrees clockwise: first column (bottom-up) becomes first row
        result = [list(col) for col in zip(*result[::-1])]
    return result
