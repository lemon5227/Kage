import re

_UNITS = {"d": 86400, "h": 3600, "m": 60, "s": 1}
_ORDER = ["d", "h", "m", "s"]

_PART_RE = re.compile(r"(\d+)([A-Za-z]+)")


def parse_duration(text):
    """Convert a duration text like "1d2h" or "90m15s" to total minutes.

    Parts are a non-negative integer followed by a unit (d, h, m, s).
    Spaces between parts are allowed and ignored. Units must appear from
    largest to smallest and each at most once.

    Returns the total number of whole minutes (seconds are dropped).

    Raises ValueError for empty text, missing number, unknown unit,
    repeated unit or units in the wrong order.
    """
    if not isinstance(text, str):
        raise ValueError("duration text must be a string")

    # Remove whitespace between parts.
    cleaned = re.sub(r"\s+", "", text)
    if not cleaned:
        raise ValueError("empty duration text")

    parts = []
    pos = 0
    while pos < len(cleaned):
        match = _PART_RE.match(cleaned, pos)
        if not match:
            # Either a missing number or an unknown/invalid unit.
            if cleaned[pos].isdigit():
                raise ValueError("missing unit at position %d" % pos)
            raise ValueError("missing number at position %d" % pos)
        number, unit = match.group(1), match.group(2)
        if unit not in _UNITS:
            raise ValueError("unknown unit: %r" % unit)
        parts.append((int(number), unit))
        pos = match.end()

    seen = set()
    last_index = -1
    total_seconds = 0
    for number, unit in parts:
        if unit in seen:
            raise ValueError("repeated unit: %r" % unit)
        seen.add(unit)
        index = _ORDER.index(unit)
        if index <= last_index:
            raise ValueError("units out of order: %r" % unit)
        last_index = index
        total_seconds += number * _UNITS[unit]

    return total_seconds // 60
