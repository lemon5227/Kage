import re

_UNITS = {"d": 1440, "h": 60, "m": 1, "s": 0}
_ORDER = {"d": 0, "h": 1, "m": 2, "s": 3}


def parse_duration(text):
    """Convert a duration text like "1d2h" or "90m15s" to whole minutes.

    Parts are a non-negative integer followed by a unit (d, h, m, s).
    Spaces between parts are allowed and ignored. Units must appear from
    largest to smallest and each at most once. Leftover seconds are dropped.

    Raises ValueError for empty text, missing number, unknown unit,
    repeated unit or units in the wrong order.
    """
    if not isinstance(text, str):
        raise ValueError("duration must be a string")

    # Remove spaces (any whitespace) between parts.
    cleaned = re.sub(r"\s+", "", text)
    if not cleaned:
        raise ValueError("empty duration text")

    parts = re.findall(r"(\d*)([A-Za-z]?)", cleaned)
    # re.findall with optional groups yields trailing empty matches; filter them.
    parts = [p for p in parts if p != ("", "")]

    total_minutes = 0
    seen = set()
    last_order = -1

    for number, unit in parts:
        if not number:
            raise ValueError("missing number in duration part")
        if not unit:
            raise ValueError("missing unit in duration part")
        if unit not in _UNITS:
            raise ValueError("unknown unit: %r" % unit)
        if unit in seen:
            raise ValueError("repeated unit: %r" % unit)
        order = _ORDER[unit]
        if order <= last_order:
            raise ValueError("units out of order: %r" % unit)
        seen.add(unit)
        last_order = order
        total_minutes += int(number) * _UNITS[unit]

    return total_minutes
