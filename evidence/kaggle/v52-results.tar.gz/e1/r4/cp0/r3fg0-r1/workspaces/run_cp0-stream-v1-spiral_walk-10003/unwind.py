def spiral_order(matrix):
    """Unwind a matrix in spiral order counter-clockwise."""
    if not matrix:
        return []
    
    # Check if all lines have the same length
    lengths = [len(row) for row in matrix]
    if not all(length == lengths[0] for length in lengths):
        raise ValueError("Matrix lines differ in length")
    
    if len(matrix) == 0 or len(matrix[0]) == 0:
        return []
    
    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1
    
    while top <= bottom and left <= right:
        # Move down the left edge
        for row in range(top, bottom + 1):
            result.append(matrix[row][left])
        
        # Move right along the bottom line (if there's more rows)
        if top < bottom:
            for col in range(left, right + 1):
                result.append(matrix[bottom][col])
        
        # Move up the right edge (if there's more columns)
        if left < right and top < bottom:
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][right])
        
        # Move left along the top line (if there's more rows)
        if left < right and top < bottom:
            for col in range(right, left - 1, -1):
                result.append(matrix[top][col])
        
        # Shrink the boundaries
        top += 1
        bottom -= 1
        left += 1
        right -= 1
    
    return result
