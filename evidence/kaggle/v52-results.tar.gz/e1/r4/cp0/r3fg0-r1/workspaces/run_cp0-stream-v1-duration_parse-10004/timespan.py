def read_timespan(text):
    # Check for spaces
    if ' ' in text:
        raise ValueError("Text must not contain spaces")
    
    # Check for empty text
    if not text:
        raise ValueError("Empty text")
    
    # Parse each part
    parts = []
    i = 0
    while i < len(text):
        # Read number
        start = i
        while i < len(text) and text[i].isdigit():
            i += 1
        num_str = text[start:i]
        if not num_str:
            raise ValueError("Missing number")
        num = int(num_str)
        
        # Read unit
        if i >= len(text):
            raise ValueError("Missing unit")
        unit = text[i]
        i += 1
        
        parts.append((num, unit))
    
    # Check units are from largest to smallest
    # Order: d > h > m > s
    unit_order = {'d': 3, 'h': 2, 'm': 1, 's': 0}
    for j in range(len(parts)):
        if parts[j][1] not in unit_order:
            raise ValueError("Unknown unit")
        if j > 0:
            prev_unit = parts[j-1][1]
            curr_unit = parts[j][1]
            if unit_order[prev_unit] < unit_order[curr_unit]:
                raise ValueError("Units must appear from largest to smallest")
    
    # Check each unit appears at most once
    seen_units = set()
    for num, unit in parts:
        if unit in seen_units:
            raise ValueError("Repeated unit")
        seen_units.add(unit)
    
    # Calculate total seconds
    total_seconds = 0
    for num, unit in parts:
        total_seconds += num * unit_order[unit]
    
    return total_seconds
