def parse_duration(text):
    """Convert duration text to total minutes (seconds dropped).
    
    Duration is one or more parts: non-negative integer followed by unit.
    Units: d (days), h (hours), m (minutes), s (seconds).
    Returns total whole minutes (leftover seconds are dropped).
    Spaces between parts are allowed and ignored.
    Units must appear from largest to smallest and each at most once.
    Raises ValueError for empty text, missing number, unknown unit, 
    repeated unit or units in wrong order.
    """
    if not text:
        raise ValueError("Empty text")
    
    # Normalize: remove spaces and split by non-digit characters
    normalized = text.replace(' ', '')
    parts = []
    current_num = None
    
    i = 0
    while i < len(normalized):
        if normalized[i].isdigit():
            # Parse number
            num_str = ''
            while i < len(normalized) and normalized[i].isdigit():
                num_str += normalized[i]
                i += 1
            current_num = int(num_str)
            parts.append(current_num)
        else:
            # Should be a unit character
            if not (normalized[i] in 'dhms'):
                raise ValueError(f"Unknown unit or character: {normalized[i]}")
            unit = normalized[i]
            parts.append(unit)
            i += 1
    
    # Check each part has a number followed by a unit
    if len(parts) == 0:
        raise ValueError("Missing number or unit")
    
    # Validate structure: number, unit, number, unit, ...
    valid_structure = True
    for i in range(0, len(parts), 2):
        if parts[i] is None:
            raise ValueError("Missing number before unit")
        if i + 1 >= len(parts):
            raise ValueError("Missing unit after number")
    
    # Check units are from largest to smallest and each at most once
    units = []
    for i in range(0, len(parts), 2):
        unit = parts[i + 1]
        if unit not in 'dhms':
            raise ValueError(f"Unknown unit: {unit}")
        if unit in units:
            raise ValueError(f"Repeated unit: {unit}")
        units.append(unit)
    
    # Check order: days > hours > minutes > seconds
    value_map = {'d': 3, 'h': 2, 'm': 1, 's': 0}
    for i in range(len(units) - 1):
        if value_map[units[i]] < value_map[units[i + 1]]:
            raise ValueError("Units not in correct order")
    
    # Calculate total minutes
    total_minutes = 0
    for i in range(0, len(parts), 2):
        num = parts[i]
        unit = parts[i + 1]
        value_map = {'d': 3, 'h': 2, 'm': 1, 's': 0}
        total_minutes += num * value_map[unit]
    
    return total_minutes
