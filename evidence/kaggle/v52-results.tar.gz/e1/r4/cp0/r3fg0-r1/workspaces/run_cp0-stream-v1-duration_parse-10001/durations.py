def parse_duration(text):
    """Parse a duration text to total minutes."""
    if not text:
        raise ValueError("Empty text")
    
    # Define units in order from largest to smallest
    units = ['d', 'h', 'm', 's']
    unit_values = {
        'd': 24 * 60,  # days to minutes
        'h': 60,        # hours to minutes
        'm': 1,         # minutes to minutes
        's': 1/60       # seconds to minutes (will be dropped)
    }
    
    # Split by spaces and filter out empty parts
    parts = [p.strip() for p in text.split()]
    if not parts:
        raise ValueError("Empty text")
    
    # Parse each part
    total_minutes = 0
    seen_units = set()
    last_unit_index = None
    
    for part in parts:
        if not part:
            continue
            
        # Check if part contains a unit
        if any(part.endswith(unit) for unit in units):
            # Extract the numeric value before the unit
            value_str = part[:-len(part.split('.')[-1]) if '.' in part else part]
            
            # Try to parse as integer
            try:
                value = int(value_str)
            except ValueError:
                raise ValueError(f"Missing number in '{part}'")
            
            # Get the unit
            unit = part.split()[-1] if ' ' in part else part[-1:]
            
            # Check for unknown unit
            if unit not in unit_values:
                raise ValueError(f"Unknown unit '{unit}'")
            
            # Check for repeated unit
            if unit in seen_units:
                raise ValueError(f"Repeated unit '{unit}'")
            
            # Check order (units must be from largest to smallest)
            current_index = units.index(unit)
            if last_unit_index is not None and current_index < last_unit_index:
                raise ValueError(f"Units in wrong order: {part}")
            
            seen_units.add(unit)
            last_unit_index = current_index
            
            # Add to total (convert to minutes)
            total_minutes += value * unit_values[unit]
        else:
            # Part doesn't end with a known unit - invalid format
            raise ValueError(f"Invalid format: '{part}'")
    
    # Drop leftover seconds (already handled by converting to minutes)
    return int(total_minutes)
