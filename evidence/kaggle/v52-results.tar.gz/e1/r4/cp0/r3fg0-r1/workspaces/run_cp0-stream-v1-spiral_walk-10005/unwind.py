def spiral(matrix):
    """Unwind a matrix in spiral order (clockwise)."""
    # Handle empty matrix or all empty lines
    if not matrix or all(not row for row in matrix):
        return []
    
    # Check that all rows have the same length
    lengths = [len(row) for row in matrix]
    if not all(l == lengths[0] for l in lengths):
        raise ValueError("All rows must have the same length")
    
    n = len(matrix)
    m = len(matrix[0])
    
    # Track boundaries
    top, bottom = 0, n - 1
    left, right = 0, m - 1
    
    result = []
    
    while top <= bottom and left <= right:
        # Traverse top row from left to right
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1
        
        # Traverse right column from top to bottom
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1
        
        # Check if we still have rows left
        if top > bottom:
            break
        
        # Traverse bottom row from right to left
        for col in range(right, left - 1, -1):
            result.append(matrix[bottom][col])
        bottom -= 1
        
        # Check if we still have columns left
        if left > right:
            break
        
        # Traverse left column from bottom to top
        for row in range(bottom, top - 1, -1):
            result.append(matrix[row][left])
        left += 1
    
    return result
