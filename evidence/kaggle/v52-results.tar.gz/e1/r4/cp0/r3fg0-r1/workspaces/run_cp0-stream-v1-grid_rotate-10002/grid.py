def rotate(grid, turns):
    """Rotate a grid clockwise by `turns` times.

    The grid is a list of rows (lists) of equal length.
    Rotating by 90 degrees clockwise, turns times; turns is any integer,
    negative turns rotate the other way and only turns modulo 4 matters.
    Returns a new list of lists and does not modify the input.
    An empty grid ([]) or a grid of empty rows is returned unchanged as a new list.
    Raises ValueError if the rows have different lengths.
    """
    # Handle empty grid or grid of empty rows
    if not grid:
        return []

    # Check if all rows are empty lists
    if all(row == [] for row in grid):
        return []

    # Check that all rows have the same length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("rows have different lengths")

    # Normalize turns to 0-3 range (clockwise rotations)
    # Positive turns: clockwise; negative turns: counterclockwise
    # Only turns % 4 matters
    normalized_turns = turns % 4

    # Perform the rotation
    # For a grid with R rows and C columns, rotating clockwise by k times:
    # Result has C rows and R columns.
    # Each element grid[i][j] moves to result[j][R - 1 - i] after one clockwise rotation.
    # After k rotations, the transformation is: result[j][R - 1 - i] = grid[i][j] for k=1
    # But we can compute it more directly: after k rotations, element at (i, j) goes to (j % C, (R - 1 - i) * (C // R) ???)
    # Actually simpler: perform the rotation k times.

    rows = len(grid)
    cols = len(grid[0])

    # Perform rotation k times
    for _ in range(normalized_turns):
        # Rotate clockwise once
        new_grid = []
        for j in range(cols):
            row = []
            for i in range(rows):
                row.append(grid[i][j])
            new_grid.append(row)
        grid = new_grid

    return grid
