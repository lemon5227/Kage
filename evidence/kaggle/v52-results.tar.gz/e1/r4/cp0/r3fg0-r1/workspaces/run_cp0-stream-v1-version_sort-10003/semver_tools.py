def sorted_tags(versions):
    """Sort version strings according to semantic versioning rules."""
    # Validate and parse each version string
    parsed_versions = []
    for version in versions:
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        numeric_parts = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            numeric_parts.append(int(part))
        
        # Missing trailing parts count as 0
        while len(numeric_parts) < 3:
            numeric_parts.append(0)
        
        parsed_versions.append(numeric_parts)
    
    # Sort by the parsed versions, then by string for equal versions
    def version_key(v):
        # First sort by the numeric parts (oldest first)
        return v
    
    # For equal versions, sort by their original string representation
    # We need to handle the case where two versions have the same numeric parts
    # but different string representations (e.g., "1.2" vs "1.2.0")
    # The requirement says: "Equal versions are ordered by their string, in the same direction."
    # This means if two versions are equal numerically, they should be sorted by their string.
    
    # Let's create a key that handles this:
    # 1. Compare numeric parts (tuples of integers)
    # 2. If numeric parts are equal, compare the original string
    
    def version_sort_key(v_str):
        # Parse the version string into a tuple of integers
        parts = v_str.split('.')
        numeric_parts = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {v_str}")
            numeric_parts.append(int(part))
        
        # Pad with zeros to ensure 3 parts
        while len(numeric_parts) < 3:
            numeric_parts.append(0)
        
        # Return a tuple that handles the sorting requirement
        # First, the numeric parts (as a tuple)
        # Then, the original string for tie-breaking
        return (tuple(numeric_parts), v_str)
    
    sorted_versions = sorted(versions, key=version_sort_key)
    return sorted_versions
