def duration_value(text):
    return None
