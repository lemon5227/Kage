def rank_versions(versions):
    """Sort version strings according to semantic versioning rules.
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    Return a new list ordered oldest first (ascending).
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    # Validate and parse each version
    parsed_versions = []
    for version in versions:
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        numeric_parts = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            numeric_parts.append(int(part))
        
        parsed_versions.append(numeric_parts)
    
    # Sort using the custom comparison logic
    def compare_versions(v1, v2):
        # Compare part by part
        max_len = max(len(v1), len(v2))
        
        for i in range(max_len):
            if i >= len(v1):
                # v1 is shorter and a prefix of v2 -> v1 is older
                return -1
            if i >= len(v2):
                # v2 is shorter and a prefix of v1 -> v2 is older
                return 1
            
            part1 = v1[i]
            part2 = v2[i]
            
            if part1 < part2:
                return -1
            elif part1 > part2:
                return 1
        
        # All parts are equal - order by string representation (ascending)
        if str(v1) < str(v2):
            return -1
        else:
            return 1
    
    sorted_versions = sorted(parsed_versions, key=lambda v: (v, ''.join(map(str, v))))
    
    # Convert back to original string format
    result = []
    for version in sorted_versions:
        result.append('.'.join(map(str, version)))
    
    return result
