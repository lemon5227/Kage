def rotate_tiles(grid, turns):
    """Rotate a grid clockwise by 90 degrees, turns times.
    
    The grid is a list of rows (lists) of equal length.
    Negative turns rotate the other way and only turns modulo 4 matters.
    Returns a new list of lists without modifying the input.
    Empty grid or grid of empty rows returned unchanged as new list.
    Raises ValueError if rows have different lengths.
    """
    # Handle empty grid or grid of empty rows
    if not grid or (all(len(row) == 0 for row in grid)):
        return []
    
    # Check that all rows have the same length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Rows have different lengths")
    
    # Normalize turns to 0-3 range (clockwise rotations)
    # Each rotation is 90 degrees clockwise
    normalized_turns = turns % 4
    
    # Rotate the grid clockwise by 90 degrees, normalized_turns times
    # A single clockwise rotation: new_grid[j][i] = grid[len(grid)-1-i][j]
    # Or equivalently: transpose then reverse each row
    rotated = []
    for _ in range(normalized_turns):
        # Transpose the grid
        transposed = [[grid[i][j] for i in range(len(grid))] for j in range(len(grid[0]))]
        # Reverse each row to get clockwise rotation
        rotated = [[row[::-1] for row in transposed]]
    
    return rotated
