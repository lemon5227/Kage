def read_timespan(text):
    # Check for spaces
    if ' ' in text:
        raise ValueError("Text must not contain spaces")
    
    # Check for empty text
    if not text:
        raise ValueError("Empty text")
    
    # Parse the text into parts
    parts = []
    i = 0
    while i < len(text):
        # Extract number
        start = i
        while i < len(text) and text[i].isdigit():
            i += 1
        num_str = text[start:i]
        if not num_str:
            raise ValueError("Missing number")
        num = int(num_str)
        
        # Extract unit
        if i >= len(text):
            raise ValueError("Missing unit")
        unit = text[i]
        i += 1
        
        parts.append((num, unit))
    
    # Check for repeated units
    units = [unit for num, unit in parts]
    if len(units) != len(set(units)):
        raise ValueError("Repeated unit")
    
    # Check order: d > h > m > s
    # Map units to their values (higher value = larger unit)
    unit_values = {'d': 3, 'h': 2, 'm': 1, 's': 0}
    for j in range(len(parts)):
        for k in range(j + 1, len(parts)):
            if unit_values[parts[j][1]] < unit_values[parts[k][1]]:
                raise ValueError("Units in wrong order")
    
    # Calculate total seconds
    total_seconds = 0
    for num, unit in parts:
        total_seconds += num * unit_values[unit]
    
    return total_seconds
