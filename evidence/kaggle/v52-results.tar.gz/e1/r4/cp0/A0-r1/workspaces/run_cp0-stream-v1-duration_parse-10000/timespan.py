def duration_value(text):
    """Convert a duration text to total seconds.
    
    A duration is one or more parts written as a non-negative integer followed by a unit:
    d (days), h (hours), m (minutes), s (seconds).
    Example: "1d2h", "90m15s", "1h 30m"
    
    Returns the total number of seconds as an int.
    Spaces between parts are allowed and ignored.
    Units must appear from largest to smallest and each at most once.
    
    Raises ValueError for:
    - empty text
    - missing number
    - unknown unit
    - repeated unit
    - units in wrong order
    """
    # Remove spaces and split by non-digit characters (units)
    text = text.strip()
    if not text:
        raise ValueError("Empty text")
    
    # Parse the text into parts
    # We'll use regex to extract numbers and units
    import re
    
    # Pattern to match number followed by unit
    pattern = r'(\d+)\s*([dhms])'
    matches = re.findall(pattern, text)
    
    if not matches:
        raise ValueError("Missing number or unknown unit")
    
    # Check for repeated units
    units_seen = []
    for num_str, unit in matches:
        if unit in units_seen:
            raise ValueError(f"Repeated unit: {unit}")
        units_seen.append(unit)
    
    # Check order: units must be from largest to smallest
    # d > h > m > s
    unit_order = {'d': 3, 'h': 2, 'm': 1, 's': 0}
    for i in range(len(units_seen) - 1):
        if unit_order[units_seen[i]] < unit_order[units_seen[i+1]]:
            raise ValueError("Units in wrong order")
    
    # Calculate total seconds
    total_seconds = 0
    for num_str, unit in matches:
        num = int(num_str)
        if unit == 'd':
            total_seconds += num * 24 * 60 * 60
        elif unit == 'h':
            total_seconds += num * 60 * 60
        elif unit == 'm':
            total_seconds += num * 60
        elif unit == 's':
            total_seconds += num
    
    return total_seconds
