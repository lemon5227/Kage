def parse_duration(text):
    """Parse a duration text to total minutes.
    
    A duration is one or more parts written as a non-negative integer followed by a unit:
    d (days), h (hours), m (minutes), s (seconds).
    Example: "1d2h", "90m15s", "1h 30m"
    
    Returns the total number of whole minutes (leftover seconds are dropped) as an int.
    """
    if not text or not text.strip():
        raise ValueError("Empty text")
    
    # Define unit order from largest to smallest: d > h > m > s
    unit_order = ['d', 'h', 'm', 's']
    unit_multipliers = {'d': 24 * 60, 'h': 60, 'm': 1, 's': 1/60}  # seconds to minutes
    
    # Split by spaces and then by units
    parts = text.strip().split()
    
    if not parts:
        raise ValueError("Missing number")
    
    # Parse each part as number + unit
    parsed_parts = []
    for part in parts:
        if not part:
            continue
        # Check if part contains a unit
        if any(part.endswith(unit) for unit in unit_order):
            # Extract number and unit
            num_str = part[:-1]
            unit = part[-1]
            try:
                num = int(num_str)
            except ValueError:
                raise ValueError(f"Missing number in '{part}'")
            if num < 0:
                raise ValueError(f"Non-negative integer required in '{part}'")
            parsed_parts.append((num, unit))
        else:
            # Part doesn't end with a valid unit
            raise ValueError(f"Unknown unit or format in '{part}'")
    
    if not parsed_parts:
        raise ValueError("Missing number")
    
    # Check for repeated units
    units = [unit for num, unit in parsed_parts]
    if len(units) != len(set(units)):
        raise ValueError("Repeated unit")
    
    # Check order: must be from largest to smallest
    for i in range(len(parsed_parts) - 1):
        current_unit = parsed_parts[i][1]
        next_unit = parsed_parts[i+1][1]
        if unit_order.index(current_unit) > unit_order.index(next_unit):
            raise ValueError("Units in wrong order")
    
    # Calculate total minutes
    total_minutes = 0
    for num, unit in parsed_parts:
        total_minutes += num * unit_multipliers[unit]
    
    # Drop leftover seconds (floor to whole minutes)
    return int(total_minutes)
