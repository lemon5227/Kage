def parse_duration(text):
    """
    Convert a duration text to total minutes.
    
    Duration format: non-negative integer followed by unit (d, h, m, s)
    Examples: "1d2h", "90m15s", "1h 30m"
    
    Returns: total number of whole minutes (seconds are dropped)
    Raises: ValueError for invalid input
    """
    # Validate non-empty text
    if not text or not text.strip():
        raise ValueError("Empty text")
    
    # Normalize: remove spaces and split by non-digit characters
    text = text.strip()
    parts = []
    current = ""
    for char in text:
        if char.isdigit():
            current += char
        else:
            if current:
                parts.append(int(current))
                current = ""
            if char not in "dhms":
                raise ValueError(f"Unknown unit or separator: {char}")
            parts.append(char)
    if current:
        parts.append(int(current))
    
    # Check if we have an even number of parts (numbers and units alternating)
    if len(parts) % 2 != 0:
        raise ValueError("Missing number or unit")
    
    # Parse into (number, unit) pairs
    values = []
    for i in range(0, len(parts), 2):
        num = parts[i]
        unit = parts[i + 1]
        if num < 0:
            raise ValueError("Negative number")
        if unit not in "dhms":
            raise ValueError(f"Unknown unit: {unit}")
        values.append((num, unit))
    
    # Check for repeated units
    units = [v[1] for v in values]
    if len(units) != len(set(units)):
        raise ValueError("Repeated unit")
    
    # Check order: units must be from largest to smallest (d > h > m > s)
    unit_order = {"d": 3, "h": 2, "m": 1, "s": 0}
    for i in range(len(values) - 1):
        if unit_order[values[i][1]] < unit_order[values[i+1][1]]:
            raise ValueError("Units in wrong order")
    
    # Calculate total minutes
    total_minutes = 0
    for num, unit in values:
        if unit == "d":
            total_minutes += num * 24 * 60
        elif unit == "h":
            total_minutes += num * 60
        elif unit == "m":
            total_minutes += num
        elif unit == "s":
            # Drop leftover seconds (floor to minutes)
            total_minutes += num // 60
    
    return total_minutes
