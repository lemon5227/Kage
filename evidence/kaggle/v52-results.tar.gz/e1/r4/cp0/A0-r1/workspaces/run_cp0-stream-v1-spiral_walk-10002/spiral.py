def unwind(matrix):
    """Unwind a matrix in spiral order, clockwise."""
    # Handle empty matrix or empty lines
    if not matrix or not matrix[0]:
        return []
    
    # Check if all lines have equal length
    first_len = len(matrix[0])
    for row in matrix:
        if len(row) != first_len:
            raise ValueError("Lines differ in length")
    
    # Initialize boundaries
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1
    
    result = []
    
    while top <= bottom and left <= right:
        # Traverse top row from left to right
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1
        
        # Traverse right column from top to bottom
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1
        
        # Check if there's still rows left
        if top <= bottom:
            # Traverse bottom row from right to left
            for col in range(right, left - 1, -1):
                result.append(matrix[bottom][col])
            bottom -= 1
        
        # Check if there's still columns left
        if left <= right:
            # Traverse left column from bottom to top
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][left])
            left += 1
    
    return result
