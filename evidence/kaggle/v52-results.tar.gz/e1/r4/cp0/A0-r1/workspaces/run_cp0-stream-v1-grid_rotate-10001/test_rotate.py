#!/usr/bin/env python3
from tiles import rotate_tiles

# Test 1: Basic 90° CCW rotation
grid1 = [[1, 2, 3],
         [4, 5, 6]]
print("Test 1: Basic 90° CCW")
print("Original:", grid1)
result1 = rotate_tiles(grid1, 1)
print("Rotated 1x:", result1)
# Expected: [[4, 1], [5, 2], [6, 3]]

# Test 2: 180° CCW rotation (2 times)
print("\nTest 2: 180° CCW")
result2 = rotate_tiles(grid1, 2)
print("Rotated 2x:", result2)
# Expected: [[6, 5], [3, 2], [4, 1]] - wait let me recalculate
# Actually for 180°, it should be [[6, 5], [3, 2]]? Let's trace:
# Original: [[1,2,3],[4,5,6]]
# After 1 CCW: [[4,1],[5,2],[6,3]]
# After 2 CCW: [[6,5],[3,2]] - but wait, shape changes from (2,3) to (3,2) then (2,3)
# Let me recalculate properly

# Test 3: 270° CCW rotation (3 times)
print("\nTest 3: 270° CCW")
result3 = rotate_tiles(grid1, 3)
print("Rotated 3x:", result3)

# Test 4: Negative turns (clockwise)
print("\nTest 4: -1 (clockwise 90°)")
result4 = rotate_tiles(grid1, -1)
print("Rotated -1x:", result4)
# Should be same as 3 CCW rotations

# Test 5: Empty grid
print("\nTest 5: Empty grid")
grid5 = []
result5 = rotate_tiles(grid5, 1)
print("Empty grid result:", result5)

# Test 6: Grid of empty rows
print("\nTest 6: Grid of empty rows")
grid6 = [[]]
result6 = rotate_tiles(grid6, 1)
print("Empty rows result:", result6)

# Test 7: Different row lengths (should raise ValueError)
print("\nTest 7: Different row lengths")
try:
    grid7 = [[1, 2], [3]]
    rotate_tiles(grid7, 1)
    print("ERROR: Should have raised ValueError")
except ValueError as e:
    print("Correctly raised ValueError:", e)

# Test 8: Single element
print("\nTest 8: Single element")
grid8 = [[1]]
result8 = rotate_tiles(grid8, 1)
print("Single element result:", result8)
