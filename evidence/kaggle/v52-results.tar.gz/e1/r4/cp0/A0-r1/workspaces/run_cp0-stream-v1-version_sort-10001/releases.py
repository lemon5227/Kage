def rank_versions(versions):
    """Sort version strings in ascending order (oldest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    def validate_and_parse(version):
        """Validate and parse a version string into a list of integers."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            result.append(int(part))
        return result
    
    # Validate and parse all versions
    parsed_versions = []
    for v in versions:
        parsed_versions.append(validate_and_parse(v))
    
    # Custom comparison function for sorting
    def compare_versions(v1, v2):
        """Compare two version lists. Returns negative if v1 < v2, positive if v1 > v2, 0 if equal."""
        # Compare part by part
        max_len = max(len(v1), len(v2))
        
        for i in range(max_len):
            # If one version is shorter, it's older (smaller)
            if i >= len(v1):
                return -1  # v1 is shorter, so it's older
            if i >= len(v2):
                return 1  # v2 is shorter, so it's older
            
            part1 = v1[i]
            part2 = v2[i]
            
            if part1 < part2:
                return -1
            elif part1 > part2:
                return 1
            else:
                # Parts are equal, continue to next part
                continue
        
        # If we get here, the versions are equal in all compared parts
        # According to requirements: "Equal versions are ordered by their string, in the same direction"
        # Since we're sorting ascending (oldest first), we should maintain stable sort order
        # For equal versions, we can use the original string order as a tiebreaker
        return 0
    
    # Sort using the custom comparison
    sorted_versions = sorted(parsed_versions, key=lambda v: v)
    
    # Return the sorted version strings
    return [f"{v[0]}.{v[1]}{'' if len(v) > 2 else ''}" for v in sorted_versions]
