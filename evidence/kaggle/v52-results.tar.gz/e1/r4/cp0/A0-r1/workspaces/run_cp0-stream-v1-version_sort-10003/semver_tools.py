def sorted_tags(versions):
    """
    Sort version strings according to semantic versioning rules.
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    Missing trailing parts count as 0, so "1.2" and "1.2.0" are equal versions.
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    
    Returns a new list ordered oldest first (ascending).
    """
    def validate_and_parse(version):
        """Validate and parse a version string into a tuple of integers."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            result.append(int(part))
        # Missing trailing parts count as 0
        return result
    
    def compare_versions(v1, v2):
        """Compare two version tuples. Returns negative if v1 < v2, positive if v1 > v2, 0 if equal."""
        # Pad the shorter tuple with zeros to match the longer one
        max_len = max(len(v1), len(v2))
        v1_padded = v1 + [0] * (max_len - len(v1))
        v2_padded = v2 + [0] * (max_len - len(v2))
        
        for i in range(max_len):
            if v1_padded[i] < v2_padded[i]:
                return -1
            elif v1_padded[i] > v2_padded[i]:
                return 1
        # Versions are equal numerically, order by string representation
        if v1 == v2:
            return 0
        # If still equal (shouldn't happen with same numeric values), use string comparison
        return -1 if v1 < v2 else 1
    
    # Validate and parse all versions
    parsed_versions = []
    for version in versions:
        parsed_versions.append(validate_and_parse(version))
    
    # Sort using the comparison function
    sorted_versions = sorted(parsed_versions, key=lambda v: v)
    
    return [f"{','.join(map(str, v))}" for v in sorted_versions]
