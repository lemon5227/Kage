def duration_value(text):
    """Convert duration text to total minutes (whole minutes only).
    
    Args:
        text: Duration string like "1d2h", "90m15s", "1h 30m"
    
    Returns:
        int: Total number of whole minutes
    
    Raises:
        ValueError: For invalid input
    """
    if not text or not text.strip():
        raise ValueError("Empty text")
    
    # Parse the text into parts
    parts = text.strip().split()
    
    # Validate and parse each part
    total_minutes = 0
    units_seen = []
    
    for part in parts:
        if not part:
            continue
            
        # Split number and unit
        num_str, unit = part.split()
        
        # Check for missing number
        if not num_str.isdigit():
            raise ValueError(f"Missing number in part: {part}")
        
        num = int(num_str)
        
        # Validate unit
        unit_map = {
            'd': 24 * 60,   # days to minutes
            'h': 60,        # hours to minutes
            'm': 1,         # minutes to minutes
            's': 1/60       # seconds to minutes (fractional)
        }
        
        if unit not in unit_map:
            raise ValueError(f"Unknown unit: {unit}")
        
        # Check for repeated unit
        if unit in units_seen:
            raise ValueError(f"Repeated unit: {unit}")
        
        # Check order (must be from largest to smallest)
        # d > h > m > s
        unit_order = {'d': 0, 'h': 1, 'm': 2, 's': 3}
        current_order = unit_order[unit]
        
        if units_seen:
            last_unit = units_seen[-1]
            last_order = unit_order[last_unit]
            if current_order < last_order:
                raise ValueError(f"Units in wrong order: {part}")
        
        units_seen.append(unit)
        
        # Add to total (convert to minutes)
        total_minutes += num * unit_map[unit]
    
    # Drop leftover seconds (only keep whole minutes)
    # Since we're converting everything to minutes, we need to floor the result
    return int(total_minutes)
