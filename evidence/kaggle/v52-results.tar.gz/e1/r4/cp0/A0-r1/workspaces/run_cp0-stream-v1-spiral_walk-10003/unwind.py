def spiral_order(matrix):
    """Unwind a matrix in spiral order counter-clockwise."""
    # Handle empty matrix or empty lines
    if not matrix or not matrix[0]:
        return []
    
    # Check if all lines have equal length
    lengths = [len(row) for row in matrix]
    if len(set(lengths)) != 1:
        raise ValueError("Matrix lines differ in length")
    
    n = len(matrix)
    m = len(matrix[0])
    
    result = []
    top, bottom = 0, n - 1
    left, right = 0, m - 1
    
    while top <= bottom and left <= right:
        # Move down the left edge
        for i in range(top, bottom + 1):
            result.append(matrix[i][left])
        
        # Move right along the bottom line
        if top <= bottom:
            for j in range(left, right + 1):
                result.append(matrix[bottom][j])
        
        # Move up the right edge
        if left < right:
            for i in range(bottom, top - 1, -1):
                result.append(matrix[i][right])
        
        # Move left along the top line
        if left < right:
            for j in range(right, left - 1, -1):
                result.append(matrix[top][j])
        
        # Shrink the boundaries
        top += 1
        bottom -= 1
        left += 1
        right -= 1
    
    return result
