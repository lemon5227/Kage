def spiral(matrix):
    # Handle empty matrix or empty lines
    if not matrix or not matrix[0]:
        return []
    
    # Check if all lines have the same length
    first_len = len(matrix[0])
    for row in matrix:
        if len(row) != first_len:
            raise ValueError("Matrix lines differ in length")
    
    # Spiral traversal
    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1
    
    while top <= bottom and left <= right:
        # Traverse from left to right along the top row
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1
        
        # Traverse from top to bottom along the right column
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1
        
        # Check if there's still a row to traverse
        if top <= bottom:
            # Traverse from right to left along the bottom row
            for col in range(right, left - 1, -1):
                result.append(matrix[bottom][col])
            bottom -= 1
        
        # Check if there's still a column to traverse
        if left <= right:
            # Traverse from bottom to top along the left column
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][left])
            left += 1
    
    return result
