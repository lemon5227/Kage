def rotate_tiles(grid, turns):
    """Rotate a grid clockwise by 90 degrees, turns times."""
    # Handle empty grid or grid of empty rows
    if not grid or (not grid[0] and not any(grid)):
        return []
    
    # Check if all rows have the same length
    row_lengths = [len(row) for row in grid]
    if len(set(row_lengths)) != 1:
        raise ValueError("Rows have different lengths")
    
    # Normalize turns to 0-3 range
    turns = turns % 4
    
    # Get dimensions
    rows = len(grid)
    cols = len(grid[0])
    
    # Rotate clockwise by 90 degrees once
    def rotate_once():
        new_grid = []
        for col in range(cols):
            new_row = [grid[row][col] for row in range(rows)]
            new_grid.append(new_row)
        return new_grid
    
    # Apply rotation `turns` times
    current_grid = grid
    for _ in range(turns):
        current_grid = rotate_once()
    
    return current_grid
