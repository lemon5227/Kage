def rotate_tiles(grid, turns):
    """
    Rotate a grid counter-clockwise by 90 degrees, turns times.
    
    Args:
        grid: List of rows (lists) of equal length
        turns: Integer number of rotations (negative rotates the other way)
    
    Returns:
        New list of lists representing the rotated grid
    
    Raises:
        ValueError: If rows have different lengths
    """
    # Handle empty grid or grid of empty rows
    if not grid or (len(grid) == 0 or all(len(row) == 0 for row in grid)):
        return []
    
    # Check that all rows have equal length
    row_lengths = [len(row) for row in grid]
    if len(set(row_lengths)) != 1:
        raise ValueError("Rows have different lengths")
    
    m = len(grid)  # number of rows
    n = len(grid[0])  # number of columns
    
    # Normalize turns to [0, 1, 2, 3] (counter-clockwise rotations)
    # A negative turn means clockwise rotation, which is equivalent to 
    # (4 - abs(turns)) % 4 counter-clockwise rotations
    # But we can just use turns % 4 for counter-clockwise
    # Note: Python's % operator handles negative numbers correctly for this
    # e.g., -1 % 4 = 3, which means 3 CCW rotations = 1 CW rotation
    effective_turns = turns % 4
    
    # Perform the rotation
    # For one CCW rotation: grid of shape (m, n) becomes (n, m)
    # Element at (i, j) moves to (n-1-j, i)
    
    if effective_turns == 0:
        return grid[:]  # Return a copy
    
    # Perform the rotation multiple times
    result = []
    for _ in range(effective_turns):
        # Rotate CCW once
        new_grid = []
        for j in range(n - 1, -1, -1):
            new_row = []
            for i in range(m):
                new_row.append(grid[i][j])
            new_grid.append(new_row)
        result = new_grid
    
    return result
