def sorted_tags(versions):
    """Sort version strings according to semantic versioning rules."""
    # Validate and parse each version string
    parsed_versions = []
    for version in versions:
        if not version:
            raise ValueError("Empty string is not a valid version")
        
        parts = version.split('.')
        numeric_parts = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            numeric_parts.append(int(part))
        # Missing trailing parts count as 0
        parsed_versions.append(numeric_parts)
    
    # Sort according to semantic versioning rules
    # Compare part by part as integers
    # Equal versions are ordered by their string (ascending)
    def compare_versions(v1, v2):
        # Pad shorter lists with zeros for comparison
        max_len = max(len(v1), len(v2))
        v1_padded = v1 + [0] * (max_len - len(v1))
        v2_padded = v2 + [0] * (max_len - len(v2))
        
        # Compare part by part
        for i in range(max_len):
            if v1_padded[i] != v2_padded[i]:
                return v1_padded[i] - v2_padded[i]
        
        # If all parts are equal, order by string representation
        return 0 if v1 == v2 else (v1 < v2) - (v1 > v2)
    
    sorted_versions = sorted(parsed_versions, key=lambda v: (v, ''.join(str(p) for p in v)))
    return [version_str for version_str, _ in sorted_versions]
