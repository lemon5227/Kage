def spiral(matrix):
    """Unwind a matrix in spiral order."""
    # Handle empty matrix or empty lines
    if not matrix or not matrix[0]:
        return []
    
    # Check all lines have equal length
    row_lengths = [len(row) for row in matrix]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Matrix lines differ in length")
    
    n = len(matrix)
    m = len(matrix[0])
    
    # Track boundaries
    top = 0
    bottom = n - 1
    left = 0
    right = m - 1
    
    result = []
    
    while top <= bottom and left <= right:
        # Traverse from left to right along the top row
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1
        
        # Traverse from top to bottom along the right column
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1
        
        # Check if there's still a row to process
        if top > bottom:
            break
        
        # Traverse from right to left along the bottom row
        for col in range(right, left - 1, -1):
            result.append(matrix[bottom][col])
        bottom -= 1
        
        # Check if there's still a column to process
        if left > right:
            break
        
        # Traverse from bottom to top along the left column
        for row in range(bottom, top - 1, -1):
            result.append(matrix[row][left])
        left += 1
    
    return result
