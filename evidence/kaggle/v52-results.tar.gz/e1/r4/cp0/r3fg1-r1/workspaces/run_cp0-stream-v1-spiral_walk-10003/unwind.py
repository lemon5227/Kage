def spiral_order(matrix):
    """Unwind a matrix in spiral order counter-clockwise."""
    if not matrix:
        return []
    
    # Check if all lines have the same length
    if not matrix[0]:
        return []
    
    row_lengths = [len(row) for row in matrix]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Matrix lines differ in length")
    
    n = len(matrix)
    m = len(matrix[0])
    
    # Track boundaries: top, bottom, left, right
    top = 0
    bottom = n - 1
    left = 0
    right = m - 1
    
    result = []
    
    while top <= bottom and left <= right:
        # Move right along the top row
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1
        
        # Move down along the right column
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1
        
        # Check if we've exhausted rows
        if top > bottom:
            continue
        
        # Move left along the bottom row
        for col in range(right, left - 1, -1):
            result.append(matrix[bottom][col])
        bottom -= 1
        
        # Check if we've exhausted columns
        if left > right:
            break
    
    return result
