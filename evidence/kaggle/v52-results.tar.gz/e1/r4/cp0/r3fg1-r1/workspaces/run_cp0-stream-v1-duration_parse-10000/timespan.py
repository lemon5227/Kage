def duration_value(text):
    """Convert a duration text to total seconds."""
    if not text or not text.strip():
        raise ValueError("Empty text")
    
    # Parse the text into parts
    parts = text.split()
    if len(parts) == 0:
        raise ValueError("Missing number")
    
    # Track units and their values
    total_seconds = 0
    seen_units = set()
    last_unit = None
    
    for part in parts:
        if not part:
            continue
            
        # Split number and unit
        if ' ' in part:
            num_str, unit = part.split()
        else:
            num_str = part
            unit = None
        
        # Check for missing number
        if num_str == '' or not num_str.isdigit():
            raise ValueError("Missing number")
        
        num = int(num_str)
        
        # Check for unknown unit
        if unit not in ['d', 'h', 'm', 's']:
            raise ValueError(f"Unknown unit: {unit}")
        
        # Check for repeated unit
        if unit in seen_units:
            raise ValueError(f"Repeated unit: {unit}")
        
        # Check for wrong order (units must be from largest to smallest)
        if last_unit is not None and unit < last_unit:
            raise ValueError("Units in wrong order")
        
        # Convert to seconds
        if unit == 'd':
            total_seconds += num * 24 * 3600
        elif unit == 'h':
            total_seconds += num * 3600
        elif unit == 'm':
            total_seconds += num * 60
        elif unit == 's':
            total_seconds += num
        
        seen_units.add(unit)
        last_unit = unit
    
    return total_seconds
