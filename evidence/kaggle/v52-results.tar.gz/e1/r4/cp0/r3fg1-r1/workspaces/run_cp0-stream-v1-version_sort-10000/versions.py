def sort_versions(versions):
    """Sort version strings in ascending order (oldest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    Missing trailing parts count as 0, so "1.2" and "1.2.0" are equal versions.
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    def validate_and_parse(version_str):
        """Validate a version string and return a list of integers."""
        if not version_str:
            raise ValueError("Empty version string")
        
        parts = version_str.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {part}")
            result.append(int(part))
        return result
    
    # Validate all versions first
    parsed_versions = []
    for version in versions:
        parsed_versions.append(validate_and_parse(version))
    
    # Sort by the parsed integer lists, then by string for equal versions
    def version_key(v):
        """Key function for sorting versions."""
        parsed = v[0]  # The parsed integer list
        # For equal versions (same integer parts), sort by original string
        return (parsed, v[1])
    
    sorted_versions = sorted(versions, key=version_key)
    return sorted_versions
