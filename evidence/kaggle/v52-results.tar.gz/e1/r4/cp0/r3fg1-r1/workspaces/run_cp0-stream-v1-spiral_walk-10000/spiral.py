def spiral(matrix):
    """Unwind a matrix in spiral order, clockwise from top-left."""
    if not matrix:
        return []
    
    # Check if all lines have equal length
    if not matrix[0]:
        return []
    
    row_lengths = [len(row) for row in matrix]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Matrix lines differ in length")
    
    # Handle empty matrix or single element
    if len(matrix) == 1 and len(matrix[0]) == 0:
        return []
    
    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1
    
    while top <= bottom and left <= right:
        # Traverse from left to right along the top row
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1
        
        # Traverse from top to bottom along the right column
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1
        
        # Check if there's still a row to process
        if top > bottom:
            continue
            
        # Traverse from right to left along the bottom row
        for col in range(right, left - 1, -1):
            result.append(matrix[bottom][col])
        bottom -= 1
        
        # Check if there's still a column to process
        if left > right:
            continue
    
    return result
