def rotate_tiles(grid, turns):
    """Rotate a grid clockwise by 90 degrees, turns times.

    The grid is a list of rows (lists) of equal length.
    Rotating by 90 degrees clockwise means: the first column becomes the first row,
    the second column becomes the second row, etc.  This is equivalent to transposing
    and then reversing each row.

    Negative turns rotate the other way (counter-clockwise), and only turns modulo 4
    matters.  An empty grid or a grid of empty rows is returned unchanged as a new list.
    Rows with different lengths raise ValueError.
    """
    # Handle empty grid or all-empty rows
    if not grid:
        return []

    # Check that all rows have the same length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("rows have different lengths")

    # Normalize turns to [0, 1, 2, 3] (clockwise rotations)
    turns = turns % 4

    # If there are no columns (all rows empty), return unchanged
    if not grid[0]:
        return [row[:] for row in grid]

    n_rows = len(grid)
    n_cols = len(grid[0])

    # Perform the rotation
    if turns == 1:
        # Clockwise 90°: first column becomes first row, etc.
        result = []
        for col in range(n_cols):
            row = [grid[row_idx][col] for row_idx in range(n_rows)]
            result.append(row)
        return result
    elif turns == 2:
        # 180°: reverse each row
        return [row[:] for row in reversed(grid)]
    elif turns == 3:
        # 270° clockwise = 90° counter-clockwise
        # First column becomes last row, etc.
        result = []
        for col in range(n_cols):
            row = [grid[row_idx][col] for row_idx in range(n_rows)]
            result.append(row)
        return result[::-1]

    return grid[:]
