def rotate(grid, turns):
    """Rotate a grid counter-clockwise by 90 degrees, turns times."""
    # Handle empty grid or grid of empty rows
    if not grid or (all(not row for row in grid)):
        return []
    
    # Check that all rows have the same length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Rows have different lengths")
    
    num_rows = len(grid)
    num_cols = len(grid[0])
    
    # Normalize turns to [0, 1, 2, 3] (counter-clockwise rotations)
    # Each turn is 90 degrees counter-clockwise
    turns = turns % 4
    
    # Rotate counter-clockwise: 
    # For a grid of shape (num_rows x num_cols), 
    # rotating counter-clockwise by 90 degrees gives shape (num_cols x num_rows)
    # The element at [i][j] moves to [j][num_rows - 1 - i]
    
    if turns == 0:
        return [row[:] for row in grid]  # Return a copy
    
    if turns == 1:
        # One counter-clockwise rotation
        new_grid = []
        for j in range(num_cols):
            row = []
            for i in range(num_rows):
                row.append(grid[i][j])
            new_grid.append(row)
        return new_grid
    
    if turns == 2:
        # Two counter-clockwise rotations = 180 degrees
        # Equivalent to reversing each row and then reversing the order of rows
        new_grid = []
        for i in range(num_rows - 1, -1, -1):
            new_grid.append(grid[i][::-1])
        return new_grid
    
    if turns == 3:
        # Three counter-clockwise rotations = 270 degrees
        # Equivalent to one clockwise rotation (or three counter-clockwise)
        # The element at [i][j] moves to [num_rows - 1 - j][i]
        new_grid = []
        for j in range(num_cols):
            row = []
            for i in range(num_rows):
                row.append(grid[i][j])
            new_grid.append(row)
        return new_grid
    
    # This should not happen due to modulo, but just in case
    raise ValueError("Invalid number of turns")
