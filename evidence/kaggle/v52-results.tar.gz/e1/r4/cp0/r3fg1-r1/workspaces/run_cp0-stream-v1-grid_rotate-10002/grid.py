def rotate(grid, turns):
    """Rotate a grid clockwise by `turns` times.

    The grid is a list of rows (lists) of equal length.
    Rotating by 90 degrees clockwise, ``turns`` is any integer; negative
    ``turns`` rotate the other way and only ``turns % 4`` matters.
    Returns a new list of lists without modifying the input.
    An empty grid ([]) or a grid of empty rows is returned unchanged as a new list.
    Raises ValueError if the rows have different lengths.
    """
    # Handle empty grid or all-empty rows
    if not grid:
        return []

    # Check if all rows are empty lists
    if all(row == [] for row in grid):
        return []

    # Validate that all rows have the same length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("rows have different lengths")

    # Normalize turns to 0-3 range (clockwise rotations)
    turns = turns % 4

    # Rotate the grid
    n_rows = len(grid)
    n_cols = len(grid[0])

    # Create rotated grid
    rotated = [[0] * n_rows for _ in range(n_cols)]
    for r in range(n_rows):
        for c in range(n_cols):
            rotated[c][n_rows - 1 - r] = grid[r][c]

    return rotated
