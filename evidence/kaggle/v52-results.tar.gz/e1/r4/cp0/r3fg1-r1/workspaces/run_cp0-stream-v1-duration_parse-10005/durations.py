def parse_duration(text):
    """Convert duration text to total minutes (integer).
    
    A duration is one or more parts written as a non-negative integer 
    followed by a unit: d (days), h (hours), m (minutes), s (seconds).
    Returns the total number of whole minutes (leftover seconds are dropped).
    Spaces between parts are allowed and ignored.
    Units must appear from largest to smallest and each at most once.
    Raises ValueError for invalid input.
    """
    if not text or not text.strip():
        raise ValueError("Empty text")
    
    # Parse the text into parts
    parts = []
    # Split by spaces first, then process each part
    tokens = text.strip().split()
    
    for token in tokens:
        if not token:
            continue
            
        # Check if token is a valid number followed by unit
        # Format: number + unit (e.g., "1d", "90m")
        if not token[0].isdigit():
            raise ValueError(f"Missing number in token: {token}")
        
        # Extract the numeric part
        try:
            num = int(token.split()[0])
        except ValueError:
            raise ValueError(f"Invalid number in token: {token}")
        
        # Get the unit from the token
        unit_str = token.split()[-1]
        if not unit_str:
            raise ValueError(f"Missing unit in token: {token}")
        
        unit = unit_str.lower()
        if unit not in ['d', 'h', 'm', 's']:
            raise ValueError(f"Unknown unit: {unit}")
        
        parts.append((num, unit))
    
    if not parts:
        raise ValueError("No valid parts found")
    
    # Check units order (largest to smallest)
    # d > h > m > s
    unit_order = {'d': 0, 'h': 1, 'm': 2, 's': 3}
    
    for i in range(len(parts) - 1):
        if unit_order[parts[i][1]] > unit_order[parts[i+1][1]]:
            raise ValueError("Units must appear from largest to smallest")
    
    # Check for repeated units
    units_used = [unit for num, unit in parts]
    if len(units_used) != len(set(units_used)):
        raise ValueError("Each unit can appear at most once")
    
    # Calculate total minutes
    total_minutes = 0
    for num, unit in parts:
        if unit == 'd':
            total_minutes += num * 24 * 60
        elif unit == 'h':
            total_minutes += num * 60
        elif unit == 'm':
            total_minutes += num
        elif unit == 's':
            # Seconds are dropped (leftover)
            total_minutes += num // 60
    
    return total_minutes
