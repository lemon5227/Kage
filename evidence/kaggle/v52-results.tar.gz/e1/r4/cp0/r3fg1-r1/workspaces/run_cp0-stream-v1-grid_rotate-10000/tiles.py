def rotate(grid, turns):
    """Rotate a grid counter-clockwise by 90 degrees, turns times.

    The grid is a list of rows (lists) of equal length.
    Rotating by 90 degrees counter-clockwise means:
        new_grid[i][j] = old_grid[j][len(old_grid) - 1 - i]

    turns can be any integer; only turns modulo 4 matters.
    Negative turns rotate the other way (clockwise).
    Returns a new list of lists without modifying the input.
    An empty grid or a grid of empty rows is returned unchanged as a new list.
    Raises ValueError if the rows have different lengths.
    """
    # Handle empty grid or all-empty rows
    if not grid or (all(not row for row in grid)):
        return []

    # Check that all rows have the same length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("rows have different lengths")

    n = len(grid)
    m = len(grid[0])

    # Normalize turns to [0, 1, 2, 3] (counter-clockwise rotations)
    # A positive turn means counter-clockwise rotation.
    # Negative turns rotate clockwise, which is equivalent to a positive turn in the opposite direction.
    # For example, -1 turn = 3 counter-clockwise turns.
    turns = turns % 4
    if turns < 0:
        turns += 4

    # Perform the rotation
    # Counter-clockwise rotation by 90 degrees:
    # new_grid[i][j] = old_grid[j][n - 1 - i]
    new_grid = [[0] * n for _ in range(m)]
    for i in range(n):
        for j in range(m):
            new_grid[j][n - 1 - i] = grid[i][j]

    return new_grid
