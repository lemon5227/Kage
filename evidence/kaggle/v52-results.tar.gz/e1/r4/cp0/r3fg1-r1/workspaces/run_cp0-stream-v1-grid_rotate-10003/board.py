def rotate_tiles(grid, turns):
    """Rotate a grid clockwise by 90 degrees, turns times.

    The grid is a list of rows (lists) of equal length.
    Rotating by 90 degrees clockwise means: new_grid[i][j] = grid[j][len(grid) - 1 - i].
    Negative turns rotate the other way (counter-clockwise).
    Only turns modulo 4 matters.
    Returns a new list of lists; does not modify the input.
    An empty grid or a grid of empty rows is returned unchanged as a new list.
    Raises ValueError if the rows have different lengths.
    """
    # Handle empty grid or all-empty rows
    if not grid or (all(not row for row in grid)):
        return []

    # Check that all rows have the same length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("rows have different lengths")

    n = len(grid)
    m = len(grid[0])

    # Normalize turns to [0, 1, 2, 3] (clockwise rotations)
    turns = turns % 4

    if turns == 0:
        return [row[:] for row in grid]

    # Build the rotated grid
    # Clockwise rotation: new_grid[i][j] = grid[j][n - 1 - i]
    # This is equivalent to transposing then reversing each row.
    new_grid = [[0] * n for _ in range(m)]
    for i in range(n):
        for j in range(m):
            new_grid[j][n - 1 - i] = grid[i][j]

    return new_grid
