def parse_duration(text):
    """Parse a duration text to total minutes."""
    if not text:
        raise ValueError("Empty text")
    
    # Normalize spaces
    parts = [p.strip() for p in text.split()]
    if not parts:
        raise ValueError("Empty text")
    
    # Parse each part: integer + unit
    units = ['d', 'h', 'm', 's']
    unit_order = {unit: idx for idx, unit in enumerate(units)}
    
    total_minutes = 0
    seen_units = set()
    
    for part in parts:
        if not part:
            continue
            
        # Check format: number followed by unit
        if not part.isdigit():
            raise ValueError(f"Missing number in part: {part}")
        
        value = int(part)
        
        # Get the unit after the number
        if len(part) > 1 and part[-1].isalpha():
            unit = part[-1]
            if unit not in unit_order:
                raise ValueError(f"Unknown unit: {unit}")
            
            # Check for repeated unit
            if unit in seen_units:
                raise ValueError(f"Repeated unit: {unit}")
            
            seen_units.add(unit)
            
            # Convert to minutes
            if unit == 'd':
                total_minutes += value * 24 * 60
            elif unit == 'h':
                total_minutes += value * 60
            elif unit == 'm':
                total_minutes += value
            elif unit == 's':
                # Drop leftover seconds (don't add to minutes)
                pass
        else:
            raise ValueError(f"Invalid format in part: {part}")
    
    # Check units order: must be from largest to smallest
    # We need to verify that the sequence of units is non-increasing in terms of magnitude
    # d > h > m > s, so the indices should be non-increasing
    unit_indices = []
    for part in parts:
        if len(part) > 1 and part[-1].isalpha():
            unit = part[-1]
            if unit in unit_order:
                unit_indices.append(unit_order[unit])
    
    # Check that units appear in correct order (largest to smallest)
    for i in range(len(unit_indices) - 1):
        if unit_indices[i] < unit_indices[i+1]:
            raise ValueError("Units in wrong order")
    
    return total_minutes
