def rank_versions(versions):
    """Sort version strings by dot-separated non-negative integers."""
    
    def validate_version(version_str):
        """Validate that a version string contains only non-negative integers separated by dots."""
        if not version_str:
            raise ValueError("Empty string")
        
        parts = version_str.split('.')
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version_str}")
        
        return parts
    
    def compare_versions(version1, version2):
        """Compare two version strings and return -1, 0, or 1."""
        parts1 = validate_version(version1)
        parts2 = validate_version(version2)
        
        # Pad the shorter list to match the longer one
        max_len = max(len(parts1), len(parts2))
        parts1 = parts1 + [0] * (max_len - len(parts1))
        parts2 = parts2 + [0] * (max_len - len(parts2))
        
        # Compare part by part as integers
        for i in range(max_len):
            num1 = int(parts1[i])
            num2 = int(parts2[i])
            
            if num1 < num2:
                return -1
            elif num1 > num2:
                return 1
            # If equal, continue to next part
        
        # If all parts are equal, return 0
        return 0
    
    # Validate all versions first
    for version in versions:
        validate_version(version)
    
    # Sort using the compare function
    sorted_versions = sorted(versions, key=lambda v: (v,))
    
    # Actually, we need to implement a proper comparison that handles the prefix rule
    # Let's use a custom sort key approach
    
    def version_key(version):
        """Generate a key for sorting versions."""
        parts = validate_version(version)
        # Convert to integers for proper comparison
        int_parts = [int(p) for p in parts]
        # Pad with zeros to handle prefix rule
        max_len = max(len(int_parts), len([int(p) for p in version]))  # This is tricky
        
        # Actually, the rule is: shorter version that is a prefix of longer one is older
        # So "1.2" < "1.2.0"
        # We can use the tuple of integers, but need to handle the prefix case
        return tuple(int_parts)
    
    # Wait, let me reconsider. The standard approach for semantic versioning:
    # Compare each part as integer. If one version is a prefix of another, the shorter one is older.
    # This is naturally handled by comparing tuples of integers because (1, 2) < (1, 2, 0) in Python
    
    sorted_versions = sorted(versions, key=lambda v: tuple(int(p) for p in validate_version(v)))
    
    return sorted_versions
