def read_timespan(text):
    """Convert a duration text to total seconds.

    A duration is one or more parts written as a non-negative integer followed by a unit:
    d (days), h (hours), m (minutes), s (seconds), e.g. "1d2h".
    Returns the total number of seconds as an int.

    The text must not contain spaces; raise ValueError if it does.
    The units must appear from largest to smallest and each at most once.
    Raise ValueError for an empty text, a missing number, an unknown unit,
    a repeated unit or units in the wrong order.
    """
    if not text:
        raise ValueError("empty text")

    if " " in text:
        raise ValueError("text contains spaces")

    # Map units to seconds per unit
    UNIT_SECONDS = {"d": 86400, "h": 3600, "m": 60, "s": 1}

    parts = []
    i = 0
    while i < len(text):
        # Parse integer
        start = i
        while i < len(text) and text[i].isdigit():
            i += 1
        if i == start:
            raise ValueError("missing number")
        num = int(text[start:i])

        # Parse unit
        unit = text[i]
        i += 1
        if unit not in UNIT_SECONDS:
            raise ValueError(f"unknown unit {unit}")
        parts.append((num, unit))

    # Check order: units must be from largest to smallest
    for j in range(len(parts) - 1):
        if parts[j][1] > parts[j + 1][1]:
            raise ValueError("units in wrong order")

    # Check repeated unit
    seen = set()
    for num, unit in parts:
        if unit in seen:
            raise ValueError("repeated unit")
        seen.add(unit)

    total = 0
    for num, unit in parts:
        total += num * UNIT_SECONDS[unit]

    return total
