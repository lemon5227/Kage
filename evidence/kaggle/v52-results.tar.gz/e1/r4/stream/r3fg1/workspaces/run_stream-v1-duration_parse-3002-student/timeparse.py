def parse_duration(text):
    """Parse a duration text to total seconds.
    
    A duration is one or more parts written as a non-negative integer 
    followed by a unit: d (days), h (hours), m (minutes), s (seconds).
    Example: "1d2h" or "90m15s".
    
    Returns the total number of seconds as an int.
    Raises ValueError for invalid input.
    """
    # Check for spaces
    if ' ' in text:
        raise ValueError("Text must not contain spaces")
    
    # Check for empty text
    if not text:
        raise ValueError("Empty text")
    
    # Parse each part
    parts = []
    current_num = None
    
    i = 0
    while i < len(text):
        # Parse number
        if text[i].isdigit():
            num_str = ""
            while i < len(text) and text[i].isdigit():
                num_str += text[i]
                i += 1
            current_num = int(num_str)
        else:
            # Should be a unit character
            unit = text[i]
            i += 1
            
            # Check if it's a valid unit
            if unit not in 'dhms':
                raise ValueError(f"Unknown unit: {unit}")
            
            # Check for repeated unit (if current_num is None, we have missing number)
            if current_num is None:
                raise ValueError("Missing number before unit")
            
            # Check for wrong order (units must be from largest to smallest)
            # d > h > m > s
            unit_order = {'d': 4, 'h': 3, 'm': 2, 's': 1}
            if i < len(text):
                next_unit = text[i]
                if unit in 'dhms':
                    order = unit_order[unit]
                    next_order = unit_order[next_unit]
                    if order < next_order:
                        raise ValueError("Units must appear from largest to smallest")
            
            # Add to parts
            parts.append((unit, current_num))
            current_num = None
        
        i += 1
    
    # Calculate total seconds
    total_seconds = 0
    for unit, num in parts:
        order = {'d': 86400, 'h': 3600, 'm': 60, 's': 1}
        total_seconds += num * order[unit]
    
    return total_seconds
