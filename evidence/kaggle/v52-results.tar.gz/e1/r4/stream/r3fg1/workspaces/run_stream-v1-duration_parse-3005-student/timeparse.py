import re
_UNITS = {'d': 86400, 'h': 3600, 'm': 60, 's': 1}
_ORDER = ['d', 'h', 'm', 's']
_ALLOW_SPACES = True

def to_seconds(text):
    if not isinstance(text, str):
        raise ValueError("duration text must be a string")
    s = text
    if _ALLOW_SPACES:
        s = re.sub(r"\s+", "", s)
    if not s:
        raise ValueError("empty duration text")
    parts = []
    pos = 0
    n = len(s)
    while pos < n:
        start = pos
        while pos < n and s[pos].isdigit():
            pos += 1
        if pos == start:
            raise ValueError("missing number at position %d" % start)
        num = int(s[start:pos])
        ustart = pos
        while pos < n and s[pos].isalpha():
            pos += 1
        if pos == ustart:
            raise ValueError("missing unit at position %d" % ustart)
        unit = s[ustart:pos]
        if unit not in _UNITS:
            raise ValueError("unknown unit: %r" % unit)
        parts.append((num, unit))
    seen = set()
    last = -1
    total = 0
    for num, unit in parts:
        if unit in seen:
            raise ValueError("repeated unit: %r" % unit)
        seen.add(unit)
        idx = _ORDER.index(unit)
        if idx <= last:
            raise ValueError("units out of order: %r" % unit)
        last = idx
        total += num * _UNITS[unit]
    return total
