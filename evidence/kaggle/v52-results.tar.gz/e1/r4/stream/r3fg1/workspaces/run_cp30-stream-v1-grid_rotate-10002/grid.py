def rotate(grid, turns):
    if not isinstance(grid, (list, tuple)):
        raise ValueError("grid must be a list of rows")
    rows = list(grid)
    if not rows:
        return []
    widths = {len(row) for row in rows}
    if len(widths) > 1:
        raise ValueError("all rows must have the same length")
    width = widths.pop()
    if width == 0:
        return [[] for _ in rows]
    n = turns % 4
    result = [list(row) for row in rows]
    for _ in range(n):
        height = len(result)
        result = [
            [result[height - 1 - c][r] for c in range(height)]
            for r in range(len(result[0]))
        ]
    return result
