def unwind(matrix):
    if not matrix:
        return []
    lengths = {len(row) for row in matrix}
    if len(lengths) > 1:
        raise ValueError("matrix rows must all have the same length")
    width = lengths.pop()
    if width == 0:
        return []
    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, width - 1
    while top <= bottom and left <= right:
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1
        if top <= bottom:
            for col in range(right, left - 1, -1):
                result.append(matrix[bottom][col])
            bottom -= 1
        if left <= right:
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][left])
            left += 1
    return result
