def unwind(matrix):
    if not matrix:
        return []
    lengths = {len(r) for r in matrix}
    if len(lengths) > 1:
        raise ValueError("matrix rows must all have the same length")
    width = lengths.pop()
    if width == 0:
        return []
    res = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, width - 1
    cw = True
    while top <= bottom and left <= right:
        if cw:
            for c in range(left, right + 1):
                res.append(matrix[top][c])
            top += 1
            for r in range(top, bottom + 1):
                res.append(matrix[r][right])
            right -= 1
            if top <= bottom:
                for c in range(right, left - 1, -1):
                    res.append(matrix[bottom][c])
                bottom -= 1
            if left <= right:
                for r in range(bottom, top - 1, -1):
                    res.append(matrix[r][left])
                left += 1
        else:
            for r in range(top, bottom + 1):
                res.append(matrix[r][left])
            left += 1
            for c in range(left, right + 1):
                res.append(matrix[bottom][c])
            bottom -= 1
            if left <= right:
                for r in range(bottom, top - 1, -1):
                    res.append(matrix[r][right])
                right -= 1
            if top <= bottom:
                for c in range(right, left - 1, -1):
                    res.append(matrix[top][c])
                top += 1
    return res
