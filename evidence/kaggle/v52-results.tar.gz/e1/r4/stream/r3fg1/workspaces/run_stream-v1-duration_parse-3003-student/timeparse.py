import re

_UNITS = {'d': 86400, 'h': 3600, 'm': 60, 's': 1}
_ORDER = ['d', 'h', 'm', 's']
_ALLOW_SPACES = True

def parse_duration(text):
    """Convert a duration text like "1d2h" or "90m15s" to total minutes.

    Parts are a non-negative integer followed by a unit (d, h, m, s).
    Spaces between parts are allowed and ignored. Units must appear from
    largest to smallest and each at most once.

    Returns the total number of whole minutes (seconds are dropped) as an int.

    Raises ValueError for empty text, missing number, unknown unit,
    repeated unit or units in the wrong order.
    """
    if not isinstance(text, str):
        raise ValueError("duration text must be a string")

    s = text
    if _ALLOW_SPACES:
        s = re.sub(r"\s+", "", s)
    if not s:
        raise ValueError("empty duration text")

    parts = []
    pos = 0
    n = len(s)
    while pos < n:
        start = pos
        while pos < n and s[pos].isdigit():
            pos += 1
        if pos == start:
            raise ValueError("missing number at position %d" % start)
        num = int(s[start:pos])
        ustart = pos
        while pos < n and s[pos].isalpha():
            pos += 1
        if pos == ustart:
            raise ValueError("missing unit at position %d" % ustart)
        unit = s[ustart:pos]
        if unit not in _UNITS:
            raise ValueError("unknown unit: %r" % unit)
        parts.append((num, unit))

    seen = set()
    last = -1
    total_seconds = 0
    for num, unit in parts:
        if unit in seen:
            raise ValueError("repeated unit: %r" % unit)
        seen.add(unit)
        idx = _ORDER.index(unit)
        if idx <= last:
            raise ValueError("units out of order: %r" % unit)
        last = idx
        total_seconds += num * _UNITS[unit]

    return total_seconds // 60
