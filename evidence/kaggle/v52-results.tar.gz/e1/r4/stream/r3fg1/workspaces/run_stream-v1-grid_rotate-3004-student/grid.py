def rotate(grid, turns):
    """Rotate a grid clockwise by turns times.

    The grid is a list of rows (lists) of equal length.
    Rotating by 90 degrees clockwise, turns times; turns is any integer,
    negative turns rotate the other way and only turns modulo 4 matters.
    Returns a new list of lists and does not modify the input.
    An empty grid ([]) or a grid of empty rows is returned unchanged as a new list.
    Raises ValueError if the rows have different lengths.
    """
    # Handle empty grid or grid of empty rows
    if not grid:
        return []
    
    # Check if all rows are empty
    if all(not row for row in grid):
        return []
    
    # Check if rows have equal length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("rows have different lengths")
    
    # Normalize turns to 0-3 range (clockwise rotations)
    # Positive turns rotate clockwise, negative rotate counterclockwise
    # Only turns modulo 4 matters
    normalized_turns = turns % 4
    
    # Get the number of rows and columns
    num_rows = len(grid)
    num_cols = len(grid[0])
    
    # Perform rotation based on normalized_turns
    if normalized_turns == 0:
        # No rotation needed, return a copy to avoid modifying input
        return [row[:] for row in grid]
    
    elif normalized_turns == 1:
        # Rotate 90 degrees clockwise
        # New grid will have num_cols rows and num_rows columns
        # grid[i][j] goes to new_grid[j][num_rows - 1 - i]
        new_grid = [[0] * num_rows for _ in range(num_cols)]
        for i in range(num_rows):
            for j in range(num_cols):
                new_grid[j][num_rows - 1 - i] = grid[i][j]
        return new_grid
    
    elif normalized_turns == 2:
        # Rotate 180 degrees (two 90 degree rotations)
        # New grid will have same dimensions
        # grid[i][j] goes to new_grid[num_rows - 1 - i][num_cols - 1 - j]
        new_grid = [[0] * num_cols for _ in range(num_rows)]
        for i in range(num_rows):
            for j in range(num_cols):
                new_grid[num_rows - 1 - i][num_cols - 1 - j] = grid[i][j]
        return new_grid
    
    elif normalized_turns == 3:
        # Rotate 270 degrees clockwise (or 90 degrees counterclockwise)
        # New grid will have num_cols rows and num_rows columns
        # grid[i][j] goes to new_grid[num_rows - 1 - j][i]
        new_grid = [[0] * num_cols for _ in range(num_rows)]
        for i in range(num_rows):
            for j in range(num_cols):
                new_grid[num_rows - 1 - j][i] = grid[i][j]
        return new_grid
    
    else:
        # This should never happen due to modulo operation, but just in case
        raise ValueError("Invalid rotation amount")
