from functools import cmp_to_key


def _parse(version):
    """Parse a version string into a tuple of ints.

    Raises ValueError for empty strings or non-numeric parts.
    """
    if not isinstance(version, str):
        raise ValueError("version must be a string: %r" % (version,))
    if version == "":
        raise ValueError("version string must not be empty")
    parts = version.split(".")
    numbers = []
    for part in parts:
        if not part.isdigit():
            raise ValueError("invalid version part %r in %r" % (part, version))
        numbers.append(int(part))
    return tuple(numbers)


def _compare(a, b):
    """Compare two parsed version tuples, treating missing trailing parts as 0."""
    length = max(len(a), len(b))
    for i in range(length):
        x = a[i] if i < len(a) else 0
        y = b[i] if i < len(b) else 0
        if x != y:
            return -1 if x < y else 1
    return 0


def sorted_tags(versions):
    """Return a new list of version strings ordered oldest first.

    Versions are compared part by part as integers; missing trailing parts
    count as 0, so "1.2" and "1.2.0" are equal versions. Equal versions are
    ordered by their string, in the same (ascending) direction.

    Raises ValueError for an empty string or any non-numeric part.
    """
    parsed = [(version, _parse(version)) for version in versions]

    def cmp(item_a, item_b):
        version_a, parsed_a = item_a
        version_b, parsed_b = item_b
        result = _compare(parsed_a, parsed_b)
        if result != 0:
            # Ascending: older versions first.
            return result
        # Equal versions: order by string, same direction (ascending).
        if version_a == version_b:
            return 0
        return -1 if version_a < version_b else 1

    ordered = sorted(parsed, key=cmp_to_key(cmp))
    return [version for version, _ in ordered]
