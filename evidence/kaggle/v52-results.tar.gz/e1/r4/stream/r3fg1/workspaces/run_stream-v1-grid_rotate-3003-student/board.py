def turn_grid(grid, turns):
    rows = [list(row) for row in grid]
    if not rows:
        return []
    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("all rows must have the same length")
    if width == 0:
        return [[] for _ in rows]
    n = turns % 4
    for _ in range(n):
        if True:
            rows = [list(col) for col in zip(*rows[::-1])]
        else:
            rows = [list(col) for col in zip(*rows)][::-1]
    return rows
