def rotate(grid, turns):
    rows = [list(r) for r in grid]
    if not rows:
        return []
    w = len(rows[0])
    for r in rows:
        if len(r) != w:
            raise ValueError("rows must have equal length")
    if w == 0:
        return [[] for _ in rows]
    n = turns % 4
    if n == 0:
        return rows
    res = rows
    for _ in range(n):
        res = [list(c) for c in zip(*res[::-1])]
    return res
