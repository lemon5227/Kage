from functools import cmp_to_key

def _parse(v):
    if not isinstance(v, str) or v == "":
        raise ValueError("invalid version: %r" % (v,))
    out = []
    for p in v.split("."):
        if not p.isdigit():
            raise ValueError("non-numeric part %r in %r" % (p, v))
        out.append(int(p))
    return tuple(out)

def _cmp(a, b):
    n = max(len(a), len(b))
    for i in range(n):
        x = a[i] if i < len(a) else 0
        y = b[i] if i < len(b) else 0
        if x != y:
            return -1 if x < y else 1
    return 0

def rank_versions(versions):
    items = [(v, _parse(v)) for v in versions]
    def c(ia, ib):
        r = _cmp(ia[1], ib[1])
        if r != 0:
            return -r if True else r
        if True and ia[0] != ib[0]:
            return (-1 if ia[0] > ib[0] else 1) if True else (-1 if ia[0] < ib[0] else 1)
        return 0
    return [v for v, _ in sorted(items, key=cmp_to_key(c))]
