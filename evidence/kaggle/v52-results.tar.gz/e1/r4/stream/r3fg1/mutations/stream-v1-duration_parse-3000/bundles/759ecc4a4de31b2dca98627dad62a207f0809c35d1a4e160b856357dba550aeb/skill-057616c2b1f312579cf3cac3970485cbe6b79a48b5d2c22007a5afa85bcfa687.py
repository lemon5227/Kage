import os

def run(arguments, context):
    path = arguments['file_path']
    name = arguments['function_name']
    ws = context['workspace_dir']
    full = os.path.join(ws, path)
    os.makedirs(os.path.dirname(full) or ws, exist_ok=True)
    code = '''def {name}(grid, turns):
    if not isinstance(grid, (list, tuple)):
        raise ValueError("grid must be a list of rows")
    rows = list(grid)
    if not rows:
        return []
    widths = {{len(row) for row in rows}}
    if len(widths) > 1:
        raise ValueError("all rows must have the same length")
    width = widths.pop()
    if width == 0:
        return [[] for _ in rows]
    n = turns % 4
    result = [list(row) for row in rows]
    for _ in range(n):
        height = len(result)
        result = [
            [result[height - 1 - c][r] for c in range(height)]
            for r in range(len(result[0]))
        ]
    return result
'''.format(name=name)
    with open(full, 'w', encoding='utf-8') as f:
        f.write(code)
    return {'success': True, 'path': path, 'function_name': name}
