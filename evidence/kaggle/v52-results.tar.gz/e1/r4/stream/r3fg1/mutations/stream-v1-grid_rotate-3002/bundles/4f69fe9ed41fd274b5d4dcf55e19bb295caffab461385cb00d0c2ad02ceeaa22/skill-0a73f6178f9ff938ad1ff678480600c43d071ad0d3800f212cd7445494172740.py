def run(arguments, context):
    import os
    path = arguments['file_path']
    name = arguments['function_name']
    cw = arguments.get('clockwise', True)
    src = '''def {name}(grid, turns):
    rows = [list(row) for row in grid]
    if not rows:
        return []
    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("all rows must have the same length")
    if width == 0:
        return [[] for _ in rows]
    n = turns % 4
    for _ in range(n):
        if {cw}:
            rows = [list(col) for col in zip(*rows[::-1])]
        else:
            rows = [list(col) for col in zip(*rows)][::-1]
    return rows
'''.format(name=name, cw=repr(bool(cw)))
    full = os.path.join(context['workspace_dir'], path)
    d = os.path.dirname(full)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(full, 'w') as f:
        f.write(src)
    return {'success': True, 'path': path, 'function_name': name, 'clockwise': bool(cw)}
