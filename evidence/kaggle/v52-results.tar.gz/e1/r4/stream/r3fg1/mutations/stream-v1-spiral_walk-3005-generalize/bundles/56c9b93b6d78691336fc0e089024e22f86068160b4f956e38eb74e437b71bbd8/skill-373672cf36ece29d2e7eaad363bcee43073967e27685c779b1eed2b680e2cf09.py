def run(arguments, context):
    import os
    path = arguments['file_path']
    name = arguments['function_name']
    cw = arguments.get('clockwise', True)
    src = '''def {name}(matrix):
    if not matrix:
        return []
    lengths = {{len(r) for r in matrix}}
    if len(lengths) > 1:
        raise ValueError("matrix rows must all have the same length")
    width = lengths.pop()
    if width == 0:
        return []
    res = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, width - 1
    cw = {cw!r}
    while top <= bottom and left <= right:
        if cw:
            for c in range(left, right + 1):
                res.append(matrix[top][c])
            top += 1
            for r in range(top, bottom + 1):
                res.append(matrix[r][right])
            right -= 1
            if top <= bottom:
                for c in range(right, left - 1, -1):
                    res.append(matrix[bottom][c])
                bottom -= 1
            if left <= right:
                for r in range(bottom, top - 1, -1):
                    res.append(matrix[r][left])
                left += 1
        else:
            for r in range(top, bottom + 1):
                res.append(matrix[r][left])
            left += 1
            for c in range(left, right + 1):
                res.append(matrix[bottom][c])
            bottom -= 1
            if left <= right:
                for r in range(bottom, top - 1, -1):
                    res.append(matrix[r][right])
                right -= 1
            if top <= bottom:
                for c in range(right, left - 1, -1):
                    res.append(matrix[top][c])
                top += 1
    return res
'''.format(name=name, cw=cw)
    full = os.path.join(context['workspace_dir'], path)
    d = os.path.dirname(full)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(full, 'w') as f:
        f.write(src)
    return {'success': True, 'path': path, 'function_name': name, 'clockwise': cw}
