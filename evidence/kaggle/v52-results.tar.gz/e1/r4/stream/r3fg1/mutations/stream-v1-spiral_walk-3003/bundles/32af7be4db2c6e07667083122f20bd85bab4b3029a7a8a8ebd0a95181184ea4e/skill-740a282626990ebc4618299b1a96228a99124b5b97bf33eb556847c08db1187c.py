def run(arguments, context):
    import os
    path = arguments['file_path']
    name = arguments['function_name']
    src = '''def {name}(matrix):
    if not matrix:
        return []
    cols = len(matrix[0])
    for row in matrix:
        if len(row) != cols:
            raise ValueError("matrix rows must all have the same length")
    if cols == 0:
        return []
    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, cols - 1
    while top <= bottom and left <= right:
        for c in range(left, right + 1):
            result.append(matrix[top][c])
        top += 1
        for r in range(top, bottom + 1):
            result.append(matrix[r][right])
        right -= 1
        if top <= bottom:
            for c in range(right, left - 1, -1):
                result.append(matrix[bottom][c])
            bottom -= 1
        if left <= right:
            for r in range(bottom, top - 1, -1):
                result.append(matrix[r][left])
            left += 1
    return result
'''.replace('{name}', name)
    full = os.path.join(context['workspace_dir'], path)
    d = os.path.dirname(full)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(full, 'w') as f:
        f.write(src)
    return {'success': True, 'path': path, 'function_name': name}
