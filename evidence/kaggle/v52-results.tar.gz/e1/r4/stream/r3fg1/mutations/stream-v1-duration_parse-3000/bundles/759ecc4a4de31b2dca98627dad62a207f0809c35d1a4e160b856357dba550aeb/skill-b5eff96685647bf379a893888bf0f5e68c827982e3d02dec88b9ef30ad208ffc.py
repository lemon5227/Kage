import os
from functools import cmp_to_key

def run(arguments, context):
    path = arguments['file_path']
    fname = arguments['function_name']
    desc = arguments.get('descending', True)
    tie = arguments.get('tie_break_by_string', True)
    src = '''from functools import cmp_to_key

def _parse(v):
    if not isinstance(v, str) or v == "":
        raise ValueError("invalid version: %r" % (v,))
    out = []
    for p in v.split("."):
        if not p.isdigit():
            raise ValueError("non-numeric part %r in %r" % (p, v))
        out.append(int(p))
    return tuple(out)

def _cmp(a, b):
    n = max(len(a), len(b))
    for i in range(n):
        x = a[i] if i < len(a) else 0
        y = b[i] if i < len(b) else 0
        if x != y:
            return -1 if x < y else 1
    return 0

def {fn}(versions):
    items = [(v, _parse(v)) for v in versions]
    def c(ia, ib):
        r = _cmp(ia[1], ib[1])
        if r != 0:
            return -r if {desc} else r
        if {tie} and ia[0] != ib[0]:
            return (-1 if ia[0] > ib[0] else 1) if {desc} else (-1 if ia[0] < ib[0] else 1)
        return 0
    return [v for v, _ in sorted(items, key=cmp_to_key(c))]
'''.replace('{fn}', fname).replace('{desc}', repr(desc)).replace('{tie}', repr(tie))
    full = os.path.join(context['workspace_dir'], path)
    os.makedirs(os.path.dirname(full) or '.', exist_ok=True)
    with open(full, 'w') as f:
        f.write(src)
    return {'success': True, 'path': path, 'function': fname}