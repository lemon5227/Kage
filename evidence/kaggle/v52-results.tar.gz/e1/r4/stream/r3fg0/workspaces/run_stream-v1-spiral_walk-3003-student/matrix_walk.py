def unwind(matrix):
    """Unwind a matrix in spiral order (counter-clockwise)."""
    if not matrix:
        return []
    
    # Check if all lines have the same length
    lengths = [len(row) for row in matrix]
    if not all(length == lengths[0] for length in lengths):
        raise ValueError("All rows must have the same length")
    
    n = len(matrix)
    m = len(matrix[0])
    
    # Handle empty matrix or single element cases
    if n == 0 or m == 0:
        return []
    
    result = []
    top, bottom = 0, n - 1
    left, right = 0, m - 1
    
    while top <= bottom and left <= right:
        # Move down the left edge (top to bottom)
        for row in range(top, bottom + 1):
            result.append(matrix[row][left])
        
        # Move right along the bottom line (left to right)
        if top < bottom:  # Only if we've moved past the first row
            for col in range(left, right + 1):
                result.append(matrix[bottom][col])
        
        # Move up the right edge (bottom to top)
        if left < right:  # Only if we've moved past the first column
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][right])
        
        # Move left along the top line (right to left)
        if top < bottom and left < right:
            for col in range(right, left - 1, -1):
                result.append(matrix[top][col])
        
        # Shrink the boundaries
        top += 1
        bottom -= 1
        left += 1
        right -= 1
    
    return result
