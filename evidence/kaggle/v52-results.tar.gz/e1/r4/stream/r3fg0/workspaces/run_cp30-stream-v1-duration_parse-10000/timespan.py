UNITS = {'d': 86400, 'h': 3600, 'm': 60, 's': 1}
ORDER = ['d', 'h', 'm', 's']
ALLOW_SPACES = True

def duration_value(text):
    if not isinstance(text, str):
        raise ValueError("duration text must be a string")
    if not ALLOW_SPACES and any(c.isspace() for c in text):
        raise ValueError("spaces not allowed")
    total = 0
    seen = []
    i = 0
    n = len(text)
    found = False
    while i < n:
        if text[i].isspace():
            i += 1
            continue
        start = i
        while i < n and text[i].isdigit():
            i += 1
        if i == start:
            raise ValueError("missing number")
        num = int(text[start:i])
        while i < n and text[i].isspace():
            i += 1
        if i >= n:
            raise ValueError("missing unit")
        u = text[i]
        if u not in UNITS:
            raise ValueError("unknown unit %r" % u)
        i += 1
        if u in seen:
            raise ValueError("repeated unit %r" % u)
        if seen and ORDER.index(u) < ORDER.index(seen[-1]):
            raise ValueError("units out of order")
        seen.append(u)
        total += num * UNITS[u]
        found = True
    if not found:
        raise ValueError("empty duration text")
    return total
