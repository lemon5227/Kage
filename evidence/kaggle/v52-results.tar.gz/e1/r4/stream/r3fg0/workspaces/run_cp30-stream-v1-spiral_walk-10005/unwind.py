def spiral(matrix):
    return None
