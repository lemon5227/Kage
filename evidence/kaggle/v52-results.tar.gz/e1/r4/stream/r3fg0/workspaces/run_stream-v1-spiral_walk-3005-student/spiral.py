def unwind(matrix):
    if not matrix:
        return []
    cols = len(matrix[0])
    for row in matrix:
        if len(row) != cols:
            raise ValueError("matrix rows must all have the same length")
    if cols == 0:
        return []
    rows = len(matrix)
    top, bottom, left, right = 0, rows - 1, 0, cols - 1
    out = []
    while top <= bottom and left <= right:
        if False:
            for r in range(top, bottom + 1):
                out.append(matrix[r][left])
            left += 1
            if left <= right:
                for c in range(left, right + 1):
                    out.append(matrix[bottom][c])
                bottom -= 1
            if top <= bottom:
                for r in range(bottom, top - 1, -1):
                    out.append(matrix[r][right])
                right -= 1
            if left <= right:
                for c in range(right, left - 1, -1):
                    out.append(matrix[top][c])
                top += 1
        else:
            for c in range(left, right + 1):
                out.append(matrix[top][c])
            top += 1
            if top <= bottom:
                for r in range(top, bottom + 1):
                    out.append(matrix[r][right])
                right -= 1
            if left <= right:
                for c in range(right, left - 1, -1):
                    out.append(matrix[bottom][c])
                bottom -= 1
            if top <= bottom:
                for r in range(bottom, top - 1, -1):
                    out.append(matrix[r][left])
                left += 1
    return out
