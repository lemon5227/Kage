def _parse(v):
    if not isinstance(v, str) or v == "":
        raise ValueError("empty version string")
    out = []
    for p in v.split("."):
        if not p.isdigit():
            raise ValueError("non-numeric version part: %r" % (p,))
        out.append(int(p))
    return out


def rank_versions(versions):
    """Sort version strings newest first.

    Versions are dot-separated non-negative integers compared part by part as
    integers. A shorter version that is a prefix of a longer one is older.
    Equal versions are ordered by their string, in the same (descending)
    direction. Raises ValueError for an empty string or a non-numeric part.
    """
    parsed = [(v, _parse(v)) for v in versions]

    def key(item):
        v, parts = item
        # Pad with -1 so that a prefix ("1.2") sorts before its extension
        # ("1.2.0") in descending order.
        width = max(len(parts), 1)
        padded = tuple(parts) + (-1,) * (width - len(parts))
        return (padded, v)

    parsed.sort(key=key, reverse=True)
    return [v for v, _ in parsed]
