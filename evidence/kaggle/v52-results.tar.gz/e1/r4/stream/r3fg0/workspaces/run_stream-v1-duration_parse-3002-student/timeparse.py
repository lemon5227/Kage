def parse_duration(text):
    return None
