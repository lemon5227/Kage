from functools import cmp_to_key


def _parse(v):
    if not isinstance(v, str) or v == "":
        raise ValueError("invalid version: %r" % (v,))
    out = []
    for p in v.split("."):
        if not p.isdigit():
            raise ValueError("invalid version part %r in %r" % (p, v))
        out.append(int(p))
    return tuple(out)


def _cmp(a, b):
    pa, pb = _parse(a), _parse(b)
    n = max(len(pa), len(pb))
    for i in range(n):
        x = pa[i] if i < len(pa) else 0
        y = pb[i] if i < len(pb) else 0
        if x != y:
            return -1 if x < y else 1
    if a == b:
        return 0
    return -1 if a > b else 1


def sort_versions(versions):
    """Return a new list of version strings ordered newest first.

    Versions are compared part by part as integers; missing trailing parts
    count as 0, so "1.2" and "1.2.0" are equal versions. Equal versions are
    ordered by their string, in the same (descending) direction.

    Raises ValueError for an empty string or any non-numeric part.
    """
    return sorted(versions, key=cmp_to_key(_cmp))
