def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    cw = arguments.get('clockwise', True)
    err = arguments.get('error_type', 'ValueError')
    src = '''def {fn}(grid, turns):
    rows = [list(r) for r in grid]
    if not rows:
        return []
    w = len(rows[0])
    for r in rows:
        if len(r) != w:
            raise {err}("rows must have equal length")
    if w == 0:
        return [[] for _ in rows]
    n = turns % 4
    if not {cw}:
        n = (-n) % 4
    res = rows
    for _ in range(n):
        res = [list(c) for c in zip(*res[::-1])]
    return res
'''.format(fn=fn, err=err, cw=cw)
    path = os.path.join(context['workspace_dir'], fp)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'function_name': fn}
