import re

def run(arguments, context):
    import os
    path = arguments['file_path']
    fn = arguments['function_name']
    units = arguments.get('units') or {'d': 86400, 'h': 3600, 'm': 60, 's': 1}
    allow_spaces = arguments.get('allow_spaces', False)
    order = list(units.keys())
    src = '''import re

_UNITS = %r
_ORDER = %r
_ALLOW_SPACES = %r
_PART_RE = re.compile(r"(\\d+)([A-Za-z])")


def %s(text):
    if not isinstance(text, str):
        raise ValueError("duration must be a string")
    if text == "":
        raise ValueError("empty duration")
    if not _ALLOW_SPACES and any(ch.isspace() for ch in text):
        raise ValueError("duration must not contain spaces")
    total = 0
    pos = 0
    last_index = -1
    seen = set()
    while pos < len(text):
        match = _PART_RE.match(text, pos)
        if not match:
            if text[pos].isdigit():
                raise ValueError("missing unit at position %%d" %% pos)
            raise ValueError("missing number at position %%d" %% pos)
        number, unit = match.group(1), match.group(2)
        if unit not in _UNITS:
            raise ValueError("unknown unit %%r" %% unit)
        if unit in seen:
            raise ValueError("repeated unit %%r" %% unit)
        index = _ORDER.index(unit)
        if index <= last_index:
            raise ValueError("units must be in order %%s" %% ", ".join(_ORDER))
        seen.add(unit)
        last_index = index
        total += int(number) * _UNITS[unit]
        pos = match.end()
    return total
''' % (units, order, allow_spaces, fn)
    full = os.path.join(context['workspace_dir'], path)
    d = os.path.dirname(full)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(full, 'w') as f:
        f.write(src)
    return {'success': True, 'path': path, 'function_name': fn}
