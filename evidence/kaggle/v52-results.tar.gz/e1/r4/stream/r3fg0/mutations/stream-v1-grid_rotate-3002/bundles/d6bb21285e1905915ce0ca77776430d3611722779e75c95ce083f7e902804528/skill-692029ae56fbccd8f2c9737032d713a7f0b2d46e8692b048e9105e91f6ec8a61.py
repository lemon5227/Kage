def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    cw = arguments.get('clockwise', True)
    et = arguments.get('error_type', 'ValueError')
    src = '''def {fn}(grid, turns):
    rows = [list(r) for r in grid]
    if not rows:
        return []
    w = len(rows[0])
    if any(len(r) != w for r in rows):
        raise {et}("ragged rows")
    if w == 0:
        return [[] for _ in rows]
    n = turns % 4
    if not {cw}:
        n = (-n) % 4
    out = rows
    for _ in range(n):
        h = len(out)
        out = [[out[h - 1 - c][r] for c in range(h)] for r in range(len(out[0]))]
    return out
'''.format(fn=fn, et=et, cw=cw)
    path = os.path.join(context['workspace_dir'], fp)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'function_name': fn}
