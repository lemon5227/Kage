def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    ccw = arguments.get('counter_clockwise', True)
    err = arguments.get('error_type', 'ValueError')
    src = '''def {fn}(matrix):
    if not matrix:
        return []
    cols = len(matrix[0])
    for row in matrix:
        if len(row) != cols:
            raise {err}("matrix rows must all have the same length")
    if cols == 0:
        return []
    rows = len(matrix)
    top, bottom, left, right = 0, rows - 1, 0, cols - 1
    out = []
    while top <= bottom and left <= right:
        if {ccw}:
            for r in range(top, bottom + 1):
                out.append(matrix[r][left])
            left += 1
            if left <= right:
                for c in range(left, right + 1):
                    out.append(matrix[bottom][c])
                bottom -= 1
            if top <= bottom:
                for r in range(bottom, top - 1, -1):
                    out.append(matrix[r][right])
                right -= 1
            if left <= right:
                for c in range(right, left - 1, -1):
                    out.append(matrix[top][c])
                top += 1
        else:
            for c in range(left, right + 1):
                out.append(matrix[top][c])
            top += 1
            if top <= bottom:
                for r in range(top, bottom + 1):
                    out.append(matrix[r][right])
                right -= 1
            if left <= right:
                for c in range(right, left - 1, -1):
                    out.append(matrix[bottom][c])
                bottom -= 1
            if top <= bottom:
                for r in range(bottom, top - 1, -1):
                    out.append(matrix[r][left])
                left += 1
    return out
'''.format(fn=fn, ccw=ccw, err=err)
    path = os.path.join(context['workspace_dir'], fp)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'function_name': fn}
