import os

def run(arguments, context):
    path = arguments['file_path']
    fn = arguments['function_name']
    desc = arguments.get('descending', True)
    tie = arguments.get('tie_break_by_string', True)
    sign = -1 if desc else 1
    src = '''from functools import cmp_to_key

def _parse(v):
    if not isinstance(v, str) or v == "":
        raise ValueError("invalid version: %r" % (v,))
    out = []
    for p in v.split("."):
        if not p.isdigit():
            raise ValueError("invalid version part %r in %r" % (p, v))
        out.append(int(p))
    return tuple(out)

def _cmp(a, b):
    pa, pb = _parse(a), _parse(b)
    n = max(len(pa), len(pb))
    for i in range(n):
        x = pa[i] if i < len(pa) else 0
        y = pb[i] if i < len(pb) else 0
        if x != y:
            return SIGN * (-1 if x < y else 1)
    if TIE:
        if a == b:
            return 0
        return SIGN * (-1 if a > b else 1)
    return 0

def FN(versions):
    return sorted(versions, key=cmp_to_key(_cmp))
'''
    src = src.replace('SIGN', str(sign)).replace('TIE', str(bool(tie))).replace('FN', fn)
    full = os.path.join(context['workspace_dir'], path)
    d = os.path.dirname(full)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(full, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': path, 'function': fn, 'bytes_written': len(src)}
