def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    cw = bool(arguments.get('clockwise', False))
    err = arguments.get('error_type', 'ValueError')
    src = '''def {fn}(grid, turns):
    rows = [list(r) for r in grid]
    if not rows:
        return []
    w = len(rows[0])
    for r in rows:
        if len(r) != w:
            raise {err}("rows must have equal length")
    if w == 0:
        return [[] for _ in rows]
    n = turns % 4
    for _ in range(n):
        t = [list(c) for c in zip(*rows)]
        rows = t[::-1] if {cw} else t[::-1][::-1] if False else ([list(c) for c in zip(*rows)][::-1] if not {cw} else [list(c) for c in zip(*rows[::-1])])
    return rows
'''.format(fn=fn, err=err, cw=cw)
    path = os.path.join(context['workspace_dir'], fp)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'function_name': fn}
