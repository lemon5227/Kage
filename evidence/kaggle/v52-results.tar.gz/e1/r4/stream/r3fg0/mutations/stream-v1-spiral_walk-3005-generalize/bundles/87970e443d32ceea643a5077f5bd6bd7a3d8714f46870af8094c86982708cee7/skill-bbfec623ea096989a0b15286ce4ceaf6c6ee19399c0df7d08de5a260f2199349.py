def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    ccw = arguments.get('counter_clockwise', True)
    err = arguments.get('error_type', 'ValueError')
    src = '''def {fn}(matrix):
    if not matrix:
        return []
    lengths = {{len(r) for r in matrix}}
    if len(lengths) > 1:
        raise {err}("matrix rows must all have the same length")
    width = lengths.pop()
    if width == 0:
        return []
    res = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, width - 1
    ccw = {ccw}
    while top <= bottom and left <= right:
        if ccw:
            for r in range(top, bottom + 1):
                res.append(matrix[r][left])
            left += 1
            if top <= bottom:
                for c in range(left, right + 1):
                    res.append(matrix[bottom][c])
                bottom -= 1
            if left <= right:
                for r in range(bottom, top - 1, -1):
                    res.append(matrix[r][right])
                right -= 1
            if top <= bottom:
                for c in range(right, left - 1, -1):
                    res.append(matrix[top][c])
                top += 1
        else:
            for c in range(left, right + 1):
                res.append(matrix[top][c])
            top += 1
            if left <= right:
                for r in range(top, bottom + 1):
                    res.append(matrix[r][right])
                right -= 1
            if top <= bottom:
                for c in range(right, left - 1, -1):
                    res.append(matrix[bottom][c])
                bottom -= 1
            if left <= right:
                for r in range(bottom, top - 1, -1):
                    res.append(matrix[r][left])
                left += 1
    return res
'''.format(fn=fn, err=err, ccw=ccw)
    path = os.path.join(context['workspace_dir'], fp)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'function_name': fn}
