def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    units = arguments.get('units') or {'d': 86400, 'h': 3600, 'm': 60, 's': 1}
    allow_spaces = arguments.get('allow_spaces', True)
    order = list(units.keys())
    src = '''UNITS = %r
ORDER = %r
ALLOW_SPACES = %r

def %s(text):
    if not isinstance(text, str):
        raise ValueError("duration text must be a string")
    if not ALLOW_SPACES and any(c.isspace() for c in text):
        raise ValueError("spaces not allowed")
    total = 0
    seen = []
    i = 0
    n = len(text)
    found = False
    while i < n:
        if text[i].isspace():
            i += 1
            continue
        start = i
        while i < n and text[i].isdigit():
            i += 1
        if i == start:
            raise ValueError("missing number")
        num = int(text[start:i])
        while i < n and text[i].isspace():
            i += 1
        if i >= n:
            raise ValueError("missing unit")
        u = text[i]
        if u not in UNITS:
            raise ValueError("unknown unit %%r" %% u)
        i += 1
        if u in seen:
            raise ValueError("repeated unit %%r" %% u)
        if seen and ORDER.index(u) < ORDER.index(seen[-1]):
            raise ValueError("units out of order")
        seen.append(u)
        total += num * UNITS[u]
        found = True
    if not found:
        raise ValueError("empty duration text")
    return total
''' % (units, order, allow_spaces, fn)
    path = os.path.join(context['workspace_dir'], fp)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'function_name': fn}