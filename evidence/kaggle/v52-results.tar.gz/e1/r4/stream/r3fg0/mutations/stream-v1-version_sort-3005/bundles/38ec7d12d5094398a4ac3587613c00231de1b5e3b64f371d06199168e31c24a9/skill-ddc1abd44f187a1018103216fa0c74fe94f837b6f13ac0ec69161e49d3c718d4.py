def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    desc = arguments.get('descending', True)
    tie = arguments.get('tie_break_by_string', True)
    src = '''def _parse(v):
    if not isinstance(v, str) or v == "":
        raise ValueError("empty version string")
    out = []
    for p in v.split("."):
        if not p.isdigit():
            raise ValueError("non-numeric version part: %r" % (p,))
        out.append(int(p))
    return out


def {fn}(versions):
    parsed = [(v, _parse(v)) for v in versions]
    width = max([len(p) for _, p in parsed] + [0])
    def key(item):
        v, parts = item
        padded = tuple(parts) + (0,) * (width - len(parts))
        return (padded, v) if {tie} else padded
    parsed.sort(key=key, reverse={desc})
    return [v for v, _ in parsed]
'''.replace('{fn}', fn).replace('{tie}', repr(bool(tie))).replace('{desc}', repr(bool(desc)))
    path = os.path.join(context['workspace_dir'], fp)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'function_name': fn}
