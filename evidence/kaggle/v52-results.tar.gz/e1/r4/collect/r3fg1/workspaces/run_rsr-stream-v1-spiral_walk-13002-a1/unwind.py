def spiral_order(matrix):
    """Unwind a matrix in spiral order, counter-clockwise."""
    if not matrix or not matrix[0]:
        return []
    
    # Check that all rows have the same length
    row_lengths = [len(row) for row in matrix]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Matrix lines differ in length")
    
    n = len(matrix)
    m = len(matrix[0])
    
    # Track boundaries
    top, bottom = 0, n - 1
    left, right = 0, m - 1
    
    result = []
    
    while top <= bottom and left <= right:
        # Move down the left edge
        for row in range(top, bottom + 1):
            result.append(matrix[row][left])
        
        # Move right along the bottom line (if there's more than one row)
        if top < bottom:
            for col in range(left, right + 1):
                result.append(matrix[bottom][col])
        
        # Move up the right edge (if there's more than one column)
        if left < right:
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][right])
        
        # Move left along the top line (if there's more than one row)
        if top < bottom:
            for col in range(right, left - 1, -1):
                result.append(matrix[top][col])
        
        # Shrink the boundaries
        top += 1
        bottom -= 1
        left += 1
        right -= 1
    
    return result
