def rotate_tiles(grid, turns):
    """Rotate a grid (list of equal-length rows) counter-clockwise by `turns` * 90 degrees.

    Negative turns rotate clockwise; only turns % 4 matters.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    """
    rows = [list(row) for row in grid]

    if not rows:
        return []

    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("All rows must have the same length")

    if width == 0:
        return [[] for _ in rows]

    n = turns % 4
    # Counter-clockwise rotation: first column (top-down) becomes first row
    result = rows
    for _ in range(n):
        # 90 degrees counter-clockwise: first column (top-down) becomes first row
        result = [list(col) for col in zip(*rows)]
    return result
