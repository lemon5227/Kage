def spiral_order(matrix):
    if matrix == []:
        return []
    
    # Check if all lines are equally long
    lengths = [len(row) for row in matrix]
    if not all(l == lengths[0] for l in lengths):
        raise ValueError("Matrix lines differ in length")
    
    # Handle empty matrix or single row/col
    if len(matrix) == 0 or len(matrix[0]) == 0:
        return []
    
    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1
    
    while top <= bottom and left <= right:
        # Move down the left edge (counter-clockwise: first down)
        for row in range(top, bottom + 1):
            result.append(matrix[row][left])
        
        # Move right along the bottom line
        if top == bottom:
            break
        for col in range(left, right + 1):
            result.append(matrix[bottom][col])
        
        # Move up the right edge
        if top == bottom:
            break
        for row in range(bottom, top - 1, -1):
            result.append(matrix[row][right])
        
        # Move left along the top line
        if left == right:
            break
        for col in range(right, left - 1, -1):
            result.append(matrix[top][col])
        
        # Shrink the boundaries
        top += 1
        bottom -= 1
        left += 1
        right -= 1
    
    return result
