def spiral(matrix):
    """Unwind a matrix in counter-clockwise spiral order.

    Starts at the top-left corner, goes down the left edge, then right along
    the bottom line, then up the right edge, then left along the top line,
    and so on inwards until every element is visited exactly once.

    Returns a flat list of the visited elements.
    Raises ValueError if the rows have differing lengths.
    """
    if not matrix:
        return []

    rows = len(matrix)
    cols = len(matrix[0]) if matrix else 0
    for row in matrix:
        if len(row) != cols:
            raise ValueError("matrix rows must all have the same length")

    if cols == 0:
        return []

    result = []
    top, bottom = 0, rows - 1
    left, right = 0, cols - 1

    while top <= bottom and left <= right:
        # down the left edge
        for r in range(top, bottom + 1):
            result.append(matrix[r][left])
        left += 1

        # right along the bottom line
        if top <= bottom:
            for c in range(left, right + 1):
                result.append(matrix[bottom][c])
            bottom -= 1

        # up the right edge
        if left <= right:
            for r in range(bottom, top - 1, -1):
                result.append(matrix[r][right])
            right -= 1

        # left along the top line
        if top <= bottom:
            for c in range(right, left - 1, -1):
                result.append(matrix[top][c])
            top += 1

    return result
