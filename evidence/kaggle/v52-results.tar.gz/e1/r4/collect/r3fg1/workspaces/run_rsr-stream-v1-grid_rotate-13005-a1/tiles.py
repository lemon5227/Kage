def rotate_tiles(grid, turns):
    """Rotate a grid (list of equal-length rows) counter-clockwise by `turns` * 90 degrees.

    Negative turns rotate clockwise; only turns % 4 matters.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if rows have different lengths.
    """
    # Normalize to [0, 1, 2, 3] range for rotation count
    n = turns % 4

    if n == 0:
        return [list(row) for row in grid]

    # Counter-clockwise rotation: first column (top-down) becomes first row
    result = []
    for col in zip(*grid):
        result.append(list(col))

    return result
