def spiral_order(matrix):
    """Unwind a matrix in clockwise spiral order.

    The matrix is a list of equally long lists (one per line). Traversal
    starts at the top-left corner and moves inwards in a spiral, clockwise:
    first along the top line to the right, then down the right edge, and so
    on until every element has been taken exactly once.

    Returns all elements in the order visited as one flat list.
    For [] or a matrix whose lines are empty the answer is [].
    If the lines differ in length, raise ValueError.
    """
    if not matrix:
        return []

    # Check that all rows have the same length
    row_lengths = [len(row) for row in matrix]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("matrix rows must all have the same length")

    width = row_lengths[0]
    if width == 0:
        return []

    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, width - 1

    while top <= bottom and left <= right:
        # Traverse top row from left to right
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1

        # Traverse right column from top to bottom
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1

        if top <= bottom:
            # Traverse bottom row from right to left
            for col in range(right, left - 1, -1):
                result.append(matrix[bottom][col])
            bottom -= 1

        if left <= right:
            # Traverse left column from bottom to top
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][left])
            left += 1

    return result
