import re

_UNITS = {"d": 86400, "h": 3600, "m": 60, "s": 1}
_ORDER = ["d", "h", "m", "s"]
_PART_RE = re.compile(r"(\d+)([A-Za-z])")


def read_timespan(text):
    """Convert a duration text like "1d2h" or "90m15s" to total minutes (int).

    Each part is a non-negative integer followed by a unit: d (days), h (hours),
    m (minutes), s (seconds). Spaces between parts are allowed and ignored.
    The units must appear from largest to smallest and each at most once.
    Returns the total number of whole minutes (leftover seconds are dropped).

    Raises ValueError for an empty text, a missing number, an unknown unit,
    a repeated unit, or units in the wrong order.
    """
    if not isinstance(text, str):
        raise ValueError("duration must be a string")
    if text == "":
        raise ValueError("empty duration")

    # Check for spaces - they are allowed and ignored
    parts = text.split()
    if len(parts) == 0:
        raise ValueError("empty duration")

    total_seconds = 0
    last_index = -1
    seen = set()

    for part in parts:
        match = _PART_RE.match(part)
        if not match:
            raise ValueError(f"invalid part: {part}")

        number_str, unit = match.group(1), match.group(2)
        if not number_str.isdigit():
            raise ValueError(f"missing number in part: {part}")

        if unit not in _UNITS:
            raise ValueError(f"unknown unit {unit!r}")

        if unit in seen:
            raise ValueError(f"repeated unit {unit!r}")

        index = _ORDER.index(unit)
        if index <= last_index:
            raise ValueError("units must be in order d, h, m, s")

        seen.add(unit)
        last_index = index
        total_seconds += int(number_str) * _UNITS[unit]

    # Convert to minutes, dropping leftover seconds
    return total_seconds // 60
