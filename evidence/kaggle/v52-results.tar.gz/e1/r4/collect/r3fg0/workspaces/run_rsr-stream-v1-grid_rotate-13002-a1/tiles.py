def spin_board(grid, turns):
    """Rotate a grid counter-clockwise by 90 degrees, `turns` times.

    Only ``turns % 4`` matters; negative values rotate clockwise.
    Returns a new list of lists and never modifies the input.
    Raises ValueError if the rows have different lengths.
    """
    # Work on a copy so the input is never modified
    rows = [list(row) for row in grid]

    if not rows:
        return []

    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("all rows must have the same length")

    if width == 0:
        return [[] for _ in rows]

    # Perform the rotation counter-clockwise `turns` times.
    n = turns % 4
    for _ in range(n):
        # Counter-clockwise: first column (bottom to top) becomes first row.
        rows = [list(col) for col in zip(*rows)][::-1]

    return rows
