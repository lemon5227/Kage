def to_seconds(text):
    return None
