def spiral_order(matrix):
    """Unwind a matrix in spiral order (counter-clockwise)."""
    if not matrix or not matrix[0]:
        return []

    # Validate that all rows have the same length
    row_len = len(matrix[0])
    for row in matrix:
        if len(row) != row_len:
            raise ValueError("Matrix lines differ in length")

    # Work with a copy to avoid mutating the input
    visited = [[False] * row_len for _ in range(len(matrix))]
    result = []

    # Start at top-left corner
    r, c = 0, 0

    while True:
        # Check if we've visited all elements
        if all(visited[r][c] for r in range(len(matrix)) for c in range(row_len)):
            break

        # Move down the left edge (if not already visited)
        if not visited[r][c]:
            result.append(matrix[r][c])
            visited[r][c] = True

        # Move down along the left edge until we hit a visited cell or bottom
        while c == 0 and r < len(matrix) - 1 and not visited[r + 1][c]:
            result.append(matrix[r + 1][c])
            visited[r + 1][c] = True
            r += 1

        # Move right along the bottom line (if not already visited)
        if r == len(matrix) - 1 and c < row_len - 1:
            result.append(matrix[r][c])
            visited[r][c] = True

        # Move right along the bottom line until we hit a visited cell or right edge
        while c < row_len - 1 and not visited[r][c + 1]:
            result.append(matrix[r][c + 1])
            visited[r][c + 1] = True
            c += 1

        # Move up along the right edge (if not already visited)
        if c == row_len - 1 and r > 0:
            result.append(matrix[r][c])
            visited[r][c] = True

        # Move up along the right edge until we hit a visited cell or top edge
        while r > 0 and not visited[r - 1][c]:
            result.append(matrix[r - 1][c])
            visited[r - 1][c] = True
            r -= 1

        # Move left along the top line (if not already visited)
        if r == 0 and c > 0:
            result.append(matrix[r][c])
            visited[r][c] = True

        # Move left along the top line until we hit a visited cell or left edge
        while c > 0 and not visited[r][c - 1]:
            result.append(matrix[r][c - 1])
            visited[r][c - 1] = True
            c -= 1

    return result
