def coalesce(intervals):
    items = []
    for iv in intervals:
        s, e = iv[0], iv[1]
        if s > e:
            raise ValueError("invalid interval: start > end")
        items.append([s, e])
    items.sort(key=lambda x: (x[0], x[1]))
    out = []
    for s, e in items:
        if out and s < out[-1][1]:
            if e > out[-1][1]:
                out[-1][1] = e
        else:
            out.append([s, e])
    return out
