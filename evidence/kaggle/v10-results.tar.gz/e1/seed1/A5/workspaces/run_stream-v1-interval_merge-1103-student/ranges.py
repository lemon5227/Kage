def combine_ranges(intervals):
    """Merge overlapping intervals given as dicts {"start": s, "end": e}.
    
    Returns a new list of merged intervals as dicts with "start" and "end" keys,
    sorted by start ascending. Touching intervals (end == next start) are NOT merged.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Convert dicts to lists for processing
    normalized = []
    for iv in intervals:
        s = iv["start"]
        e = iv["end"]
        if s > e:
            raise ValueError("invalid interval: start > end")
        normalized.append([s, e])
    
    # Sort by start, then by end
    normalized.sort(key=lambda x: (x[0], x[1]))
    
    # Merge overlapping intervals
    merged = []
    for s, e in normalized:
        if merged and s < merged[-1][1]:  # Only merge if strictly overlapping (s < last_end)
            if e > merged[-1][1]:
                merged[-1][1] = e
        else:
            merged.append([s, e])
    
    # Convert back to dicts
    result = []
    for s, e in merged:
        result.append({"start": s, "end": e})
    
    return result
