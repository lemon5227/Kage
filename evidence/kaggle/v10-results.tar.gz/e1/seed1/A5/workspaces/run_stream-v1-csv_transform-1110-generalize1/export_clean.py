import csv
import io

def normalize_table(text):
    """Clean an exported table from CSV text."""
    # Handle empty string
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Header row
    header = rows[0]
    
    # Data rows
    data_rows = rows[1:]
    
    # Strip whitespace from every cell
    for row in data_rows:
        row = [cell.strip() for cell in row]
        data_rows[-1] = row
    
    # Drop rows whose "team" cell is empty
    team_idx = header.index('team')
    data_rows = [row for row in data_rows if row[team_idx] != '' and row[team_idx].strip() != '']
    
    # Lower-case the "email" column
    email_idx = header.index('email')
    for row in data_rows:
        row[email_idx] = row[email_idx].lower()
    
    # Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    unique_rows = []
    for row in data_rows:
        team = row[team_idx]
        if team not in seen_teams:
            seen_teams.add(team)
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    email_idx = header.index('email')
    unique_rows.sort(key=lambda row: row[email_idx])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
