import csv
import io


def tidy_csv(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    try:
        team_idx = header.index('team')
        city_idx = header.index('city')
        score_idx = header.index('score')
    except ValueError:
        team_idx, city_idx, score_idx = 0, 0, 0
    data = [[c.strip() for c in r] for r in rows[1:]]
    # Drop rows whose "score" cell is empty
    data = [r for r in data if len(r) > score_idx and r[score_idx] != ""]
    # Remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for r in data:
        team = r[team_idx] if len(r) > team_idx else ""
        if team in seen:
            continue
        seen.add(team)
        deduped.append(r)
    # Sort rows by "city" ascending as strings (stable)
    deduped.sort(key=lambda r: r[city_idx] if len(r) > city_idx else "")
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in deduped:
        w.writerow(r)
    return out.getvalue()
