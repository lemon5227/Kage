def merge_bookings(intervals):
    """Merge overlapping time ranges.

    Each interval is a two-element list [start, end] of integers.
    Touching intervals (e.g., [1,3] and [3,5]) are merged.
    Returns merged intervals sorted by start ascending.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    items = []
    for iv in intervals:
        s, e = iv[0], iv[1]
        if s > e:
            raise ValueError("invalid interval: start > end")
        items.append([s, e])
    items.sort(key=lambda x: (x[0], x[1]))
    out = []
    for s, e in items:
        if out and s <= out[-1][1]:
            if e > out[-1][1]:
                out[-1][1] = e
        else:
            out.append([s, e])
    return out
