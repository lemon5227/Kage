import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    try:
        ki = header.index('id')
        si = header.index('score')
        ei = header.index('email')
    except ValueError:
        ki, si, ei = 0, 0, 0
    data = [[c.strip() for c in r] for r in rows[1:]]
    # drop rows whose "id" cell is empty
    data = [r for r in data if len(r) > ki and r[ki] != ""]
    # lower-case the "email" column
    if ei is not None and ei < len(data[0]):
        data = [[c.strip() if i != ei else c.strip().lower() for i, c in enumerate(r)] for r in data]
    # remove duplicate rows by "email", keeping the first occurrence
    seen = set()
    deduped = []
    for r in data:
        email = r[ei] if ei is not None and ei < len(r) else ""
        if email in seen:
            continue
        seen.add(email)
        deduped.append(r)
    # sort rows by "score" ascending as strings (stable)
    deduped.sort(key=lambda r: r[si] if si is not None and si < len(r) else "")
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in deduped:
        w.writerow(r)
    return out.getvalue()
