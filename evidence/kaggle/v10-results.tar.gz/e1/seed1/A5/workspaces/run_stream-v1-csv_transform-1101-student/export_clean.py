import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    # Strip whitespace from header
    header = [c.strip() for c in rows[0]]
    # Find column indices
    try:
        team_idx = header.index('team')
        city_idx = header.index('city')
        id_idx = header.index('id')
    except ValueError:
        # If columns not found, use default indices
        team_idx = 0
        city_idx = 1
        id_idx = 2

    # Process data rows (skip header)
    data = [[c.strip() for c in r] for r in rows[1:]]

    # Drop rows whose "team" cell is empty
    data = [r for r in data if len(r) > team_idx and r[team_idx] != ""]

    # Remove duplicate rows by "city", keeping first occurrence
    seen = set()
    deduped = []
    for r in data:
        if len(r) <= city_idx:
            continue
        if r[city_idx] in seen:
            continue
        seen.add(r[city_idx])
        deduped.append(r)

    # Sort rows by "id" ascending as strings (stable)
    # Use a stable sort - Python's sort is stable
    def safe_id(r):
        return r[id_idx] if len(r) > id_idx else ""
    deduped.sort(key=safe_id)

    # Write output with '\n' line endings
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in deduped:
        w.writerow(r)
    return out.getvalue()
