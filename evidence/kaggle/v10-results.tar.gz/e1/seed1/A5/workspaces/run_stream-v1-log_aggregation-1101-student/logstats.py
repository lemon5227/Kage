def summarize(lines):
    """Summarize log lines by service and level.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Returns a dict mapping (service, level) to count for levels ERROR and WARN only.
    Level names are case-insensitive; keys are upper-cased.
    Malformed lines are silently dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service: (with message optional)
        if len(parts) < 3:
            continue
        level = parts[1]
        service = parts[2]
        # The service token must end with a colon (e.g. "auth:")
        if not service.endswith(":"):
            continue
        # Level must be a non-empty alphabetic token
        if not level.isalpha():
            continue
        # Only count ERROR and WARN levels
        if level.upper() not in ("ERROR", "WARN"):
            continue
        key = (service, level.upper())
        counts[key] = counts.get(key, 0) + 1
    return counts
