import csv
import io


def dedupe_export(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    try:
        ki = header.index('name')
        si = header.index('id')
        ei = header.index('email')
    except ValueError:
        ki, si, ei = 0, 0, 0
    data = [[c.strip() for c in r] for r in rows[1:]]
    data = [r for r in data if len(r) > ki and r[ki] != ""]
    # Lower-case the email column if it exists
    if ei < len(data[0]):
        data = [[r[ei].lower() if r[ei] else "" for r in data]]
    seen = set()
    deduped = []
    for r in data:
        if r[ki] in seen:
            continue
        seen.add(r[ki])
        deduped.append(r)
    deduped.sort(key=lambda r: r[si] if len(r) > si else "")
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in deduped:
        w.writerow(r)
    return out.getvalue()
