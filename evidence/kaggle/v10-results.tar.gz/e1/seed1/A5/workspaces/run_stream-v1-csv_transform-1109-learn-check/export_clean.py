import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""
    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]
    cleaned = [[cell.strip() for cell in row] for row in data]
    key_idx = header.index('email')
    cleaned = [row for row in cleaned if row[key_idx] != ""]
    seen = set()
    deduped = []
    for row in cleaned:
        k = row[key_idx]
        if k in seen:
            continue
        seen.add(k)
        deduped.append(row)
    sort_idx = header.index('score')
    deduped.sort(key=lambda row: row[sort_idx])
    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
