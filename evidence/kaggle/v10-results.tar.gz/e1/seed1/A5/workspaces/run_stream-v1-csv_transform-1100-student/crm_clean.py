import csv
import io


def dedupe_export(text):
    if text == "":
        return ""
    
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    
    header = [c.strip() for c in rows[0]]
    data = [[c.strip() for c in r] for r in rows[1:]]
    
    # Find column indices
    try:
        email_idx = header.index('email')
        score_idx = header.index('score')
    except ValueError:
        email_idx, score_idx = 0, 0
    
    # Drop rows whose "score" cell is empty
    data = [r for r in data if len(r) > score_idx and r[score_idx] != ""]
    
    # Lower-case the "email" column
    for row in data:
        if len(row) > email_idx:
            row[email_idx] = row[email_idx].lower()
    
    # Remove duplicate rows by "email", keeping the first occurrence
    seen = set()
    deduped = []
    for r in data:
        if r[email_idx] in seen:
            continue
        seen.add(r[email_idx])
        deduped.append(r)
    
    # Sort rows by "score" ascending as strings (stable)
    deduped.sort(key=lambda r: r[score_idx] if len(r) > score_idx else "")
    
    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(header)
    for r in deduped:
        writer.writerow(r)
    
    return out.getvalue()
