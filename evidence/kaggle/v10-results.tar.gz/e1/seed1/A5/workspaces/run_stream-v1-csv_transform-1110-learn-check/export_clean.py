import csv
import io

def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    n = len(header)
    data = []
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        if len(cells) < n:
            cells += [""] * (n - len(cells))
        else:
            cells = cells[:n]
        data.append(cells)
    ki = header.index('team')
    si = header.index('email')
    data = [r for r in data if r[ki] != ""]
    if 'email':
        li = header.index('email')
        for r in data:
            r[li] = r[li].lower()
    seen = set()
    deduped = []
    for r in data:
        if r[ki] in seen:
            continue
        seen.add(r[ki])
        deduped.append(r)
    deduped.sort(key=lambda r: r[si])
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    w.writerows(deduped)
    return out.getvalue()
