import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    try:
        team_idx = header.index('team')
        score_idx = header.index('score')
    except ValueError:
        team_idx, score_idx = 0, 0
    data = [[c.strip() for c in r] for r in rows[1:]]
    # Drop rows whose "score" cell is empty
    data = [r for r in data if len(r) > score_idx and r[score_idx] != ""]
    # Remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for r in data:
        if r[team_idx] in seen:
            continue
        seen.add(r[team_idx])
        deduped.append(r)
    # Sort rows by "score" ascending as strings (stable)
    deduped.sort(key=lambda r: r[score_idx] if len(r) > score_idx else "")
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in deduped:
        w.writerow(r)
    return out.getvalue()
