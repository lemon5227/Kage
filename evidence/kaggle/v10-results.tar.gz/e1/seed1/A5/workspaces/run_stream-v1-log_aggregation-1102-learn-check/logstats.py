import re

_LINE_RE = re.compile(r'^(\S+)\s+(\S+)\s+(\S+):\s*(.*)$')


def aggregate_log(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        m = _LINE_RE.match(line.strip())
        if not m:
            continue
        level = m.group(2).upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
