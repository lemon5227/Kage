def migrate(cfg):
    # Check if version is 1, otherwise raise ValueError
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1")
    
    # Create a new dict to avoid modifying input
    new_cfg = {}
    new_cfg["version"] = 2
    
    # Process keys
    for key, value in cfg.items():
        if key == "pwd_file":
            new_cfg["password_file"] = value
        elif key == "user":
            new_cfg["username"] = value
        elif key == "cache_size":
            # Will be moved to network dict
            pass
        elif key == "workers":
            # Will be moved to network dict
            pass
        elif key == "timeout_ms":
            if value is not None:
                new_cfg["timeout_s"] = value / 1000.0
        elif value is None:
            # Drop keys with None value
            continue
        else:
            # Keep other keys unchanged
            new_cfg[key] = value
    
    # Create network dict with cache_size and workers
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    
    new_cfg["network"] = network
    
    return new_cfg
