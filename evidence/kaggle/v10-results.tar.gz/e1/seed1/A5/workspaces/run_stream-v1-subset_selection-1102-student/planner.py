def allocate(items, capacity):
    """Choose a subset of items maximizing total value within capacity.

    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Returns the sorted list of ids whose
    total value is as large as possible while total weight stays <= capacity.
    Ties on total value are broken by the lexicographically smallest sorted
    id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant fields so the input is never mutated.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("item weight must be positive")
        entries.append((item["id"], weight, value))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_value, sorted_id_list) achievable with total weight <= c.
    best = [(0, []) for _ in range(capacity + 1)]

    for item_id, weight, value in entries:
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, weight - 1, -1):
            prev_value, prev_ids = best[c - weight]
            cand_value = prev_value + value
            cand_ids = sorted(prev_ids + [item_id])
            cur_value, cur_ids = best[c]
            if cand_value > cur_value or (cand_value == cur_value and cand_ids < cur_ids):
                best[c] = (cand_value, cand_ids)

    return best[capacity][1]
