def coalesce(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"from": s, "to": e} with integer values.
    Intervals that merely touch (e.g. {"from": 1, "to": 3} and {"from": 3, "to": 5})
    are NOT merged; only genuine overlaps (next.from < current.to) are merged.

    Returns a new list of dicts with the same "from"/"to" keys, sorted by start ascending.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and convert to list of tuples
    items = []
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(
                "invalid interval: from %r > to %r" % (start, end)
            )
        items.append((start, end))

    # Sort by start, then by end for deterministic ordering
    items.sort(key=lambda iv: (iv[0], iv[1]))

    merged = []
    for start, end in items:
        if merged and start < merged[-1][1]:
            # Real overlap: extend the current interval if needed.
            if end > merged[-1][1]:
                merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))

    # Convert back to dict format
    return [{"from": start, "to": end} for start, end in merged]
