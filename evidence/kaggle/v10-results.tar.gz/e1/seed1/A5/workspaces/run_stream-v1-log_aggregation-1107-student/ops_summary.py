import re


def count_entries(lines):
    levels = ['INFO', 'DEBUG', 'WARN', 'ERROR', 'FATAL']
    group_field = 'level'
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        m = re.match(r'^\S+\s+(\S+)\s+(\S+):\s*(.*)$', line)
        if not m:
            continue
        level = m.group(1).upper()
        service = m.group(2)
        if level not in levels:
            continue
        if group_field == 'level':
            key = level
        else:
            key = service
        if not key:
            continue
        counts[key] = counts.get(key, 0) + 1
    return counts
