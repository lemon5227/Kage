def coalesce(intervals):
    """Merge overlapping or touching intervals, each represented as a dict {"from": s, "to": e}.
    
    Returns a new list of merged intervals sorted by start ascending.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Extract and validate intervals
    norm = []
    for iv in intervals:
        s = iv["from"]
        e = iv["to"]
        if s > e:
            raise ValueError("invalid interval: start > end")
        norm.append((s, e))
    
    # Sort by start (and end for stability)
    norm.sort(key=lambda p: (p[0], p[1]))
    
    # Merge overlapping or touching intervals
    merged = []
    for s, e in norm:
        if merged and s <= merged[-1][1]:
            if e > merged[-1][1]:
                merged[-1] = (merged[-1][0], e)
        else:
            merged.append((s, e))
    
    # Convert back to dicts with "from"/"to" keys
    result = []
    for s, e in merged:
        result.append({"from": s, "to": e})
    
    return result
