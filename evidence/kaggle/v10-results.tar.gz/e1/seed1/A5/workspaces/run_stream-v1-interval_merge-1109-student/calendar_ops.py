def coalesce(intervals):
    """Merge overlapping bookings.

    Each interval is a dict {"from": s, "to": e} with integer values.
    Returns merged intervals as dicts with the same "from"/"to" keys,
    sorted by start ascending. Touching intervals like [1,3] and [3,5]
    should not be merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate and convert to list of tuples
    items = []
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        items.append((start, end))

    # Sort by start (and end for stability)
    items.sort(key=lambda iv: (iv[0], iv[1]))

    # Merge overlapping intervals
    merged = []
    for start, end in items:
        if merged and start < merged[-1][1]:
            # Real overlap: extend the current interval if needed
            if end > merged[-1][1]:
                merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))

    # Convert back to dicts with "from"/"to" keys
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})

    return result
