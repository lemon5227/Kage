def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns a dictionary {level: count} per level, with level names in uppercase (case-insensitive).
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split by spaces to get parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Check if the third part starts with ':' (service:)
        if not parts[2].startswith(':'):
            continue
        
        # Extract level from second part
        level = parts[1]
        
        # Convert to uppercase for case-insensitive handling
        level_upper = level.upper()
        
        # Increment count for this level
        counts[level_upper] = counts.get(level_upper, 0) + 1
    
    return counts
