import csv
import io


def normalize_table(text):
    """Clean an exported table with the following steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "id" ascending as strings (stable)
    
    Returns cleaned CSV text with the same header.
    """
    if not text or not text.strip():
        return ""
    
    # Parse CSV
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    
    # Process header - strip whitespace from each column
    header = [c.strip() for c in rows[0]]
    
    # Find column indices
    try:
        name_idx = header.index('name')
        score_idx = header.index('score')
        id_idx = header.index('id')
    except ValueError:
        # If columns don't exist, use defaults
        name_idx = 0
        score_idx = 1
        id_idx = 2
    
    # Process data rows - strip whitespace from every cell
    data = [[c.strip() for c in r] for r in rows[1:]]
    
    # Drop rows whose "name" cell is empty
    data = [r for r in data if len(r) > name_idx and r[name_idx] != ""]
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped = []
    for r in data:
        if len(r) <= score_idx:
            continue
        score = r[score_idx]
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped.append(r)
    
    # Sort rows by "id" ascending as strings (stable sort)
    # Use a stable sort - Python's sort is stable
    def safe_id(r):
        return r[id_idx] if len(r) > id_idx else ""
    
    deduped.sort(key=safe_id)
    
    # Write output with \n line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(header)
    for r in deduped:
        writer.writerow(r)
    
    return out.getvalue()
