import unicodedata

def to_key(text):
    """Normalize labels into identifiers."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we need to replace any sequence of non-alphanumeric characters with a single underscore
    import re
    result = re.sub(r'[^a-z0-9]+', '_', lowercased)
    
    # Strip leading and trailing "_"
    return result.strip('_')
