import csv, io
def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    body = rows[1:]
    cleaned = []
    for row in body:
        cells = [c.strip() for c in row]
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[:len(header)]
        cleaned.append(cells)
    def idx(name):
        return header.index(name) if name in header else None
    ki = idx('id')
    si = idx('email')
    li = idx('email') if 'email' is not None else None
    if ki is not None:
        cleaned = [r for r in cleaned if r[ki] != ""]
    if li is not None:
        for r in cleaned:
            r[li] = r[li].lower()
    if ki is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            if r[ki] in seen:
                continue
            seen.add(r[ki])
            deduped.append(r)
        cleaned = deduped
    if si is not None:
        cleaned.sort(key=lambda r: r[si])
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    w.writerows(cleaned)
    return out.getvalue()
