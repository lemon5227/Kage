def upgrade_config(cfg):
    # Check version requirement
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")
    
    # Create new configuration dict
    new_cfg = {"version": 2}
    
    # Rename top-level keys
    if "max_conn" in cfg:
        new_cfg["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        new_cfg["directory"] = cfg["dir"]
    if "host" in cfg:
        new_cfg["hostname"] = cfg["host"]
    
    # Move cache_size and region into limits sub-dict
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    new_cfg["limits"] = limits
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys with None values)
    for key, value in cfg.items():
        if key not in ["max_conn", "dir", "host", "cache_size", "region", "timeout_ms"] and value is not None:
            new_cfg[key] = value
    
    return new_cfg
