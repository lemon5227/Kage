def tally_events(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        if not level:
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
