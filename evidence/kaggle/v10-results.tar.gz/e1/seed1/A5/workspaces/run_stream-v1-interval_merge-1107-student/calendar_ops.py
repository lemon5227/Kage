def coalesce(intervals):
    """Merge overlapping intervals, including touching ones.

    Each interval is a two-element list [start, end] of integers. Intervals
    that touch (e.g. [1, 3] and [3, 5]) are merged.

    Returns a new list of [start, end] lists sorted by start ascending.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and copy without mutating the caller's data.
    items = []
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        items.append([start, end])

    # Sort by start, then by end for deterministic ordering
    items.sort(key=lambda iv: (iv[0], iv[1]))

    merged = []
    for start, end in items:
        if merged and start <= merged[-1][1]:
            # Overlap or touching: extend the current interval if needed.
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    return merged
