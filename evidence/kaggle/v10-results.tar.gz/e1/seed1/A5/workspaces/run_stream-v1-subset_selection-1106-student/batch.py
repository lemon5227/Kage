def allocate(items, capacity):
    """
    Select projects to maximize total value while total weight stays <= capacity.
    Returns sorted list of ids. If tie on total value, return lexicographically smallest sorted id list.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "weight" not in item or "value" not in item or "id" not in item:
            raise ValueError("Each item must have 'id', 'weight', and 'value' keys")
        if not isinstance(item["id"], str):
            raise ValueError("Item id must be a string")
        if not isinstance(item["weight"], int) or item["weight"] <= 0:
            raise ValueError("Weight must be a positive integer")
        if not isinstance(item["value"], int) or item["value"] < 0:
            raise ValueError("Value must be a non-negative integer")
    
    if not items:
        return []
    
    n = len(items)
    # dp[w] = (max_value, sorted_ids) for weight w
    # We'll track the best value and lexicographically smallest id list for each weight
    
    # Initialize dp[0] = (0, [])
    dp = [(-float('inf'), None)] * (capacity + 1)
    dp[0] = (0, [])
    
    # Process each item
    for item in items:
        weight = item["weight"]
        value = item["value"]
        item_id = item["id"]
        
        # Traverse backwards to avoid using same item multiple times
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            if prev_value == -float('inf'):
                continue
            
            new_value = prev_value + value
            # Compare with existing dp[w]
            current_value, current_ids = dp[w]
            
            # We want to maximize value, then minimize lexicographically
            if new_value > current_value:
                dp[w] = (new_value, [item_id] + prev_ids)
            elif new_value == current_value:
                # Compare lexicographically - we need the smaller sorted list
                # But note: we're building from prev_ids + [item_id], which may not be sorted
                # We'll sort at the end anyway
                if [item_id] + prev_ids < current_ids:
                    dp[w] = (new_value, [item_id] + prev_ids)
    
    # Find the maximum value among all weights <= capacity
    max_value = -float('inf')
    best_ids = []
    
    for w in range(capacity + 1):
        if dp[w][0] > max_value:
            max_value = dp[w][0]
            best_ids = dp[w][1]
        elif dp[w][0] == max_value:
            # Compare lexicographically
            if dp[w][1] < best_ids:
                best_ids = dp[w][1]
    
    # Return sorted list of ids
    return sorted(best_ids)
