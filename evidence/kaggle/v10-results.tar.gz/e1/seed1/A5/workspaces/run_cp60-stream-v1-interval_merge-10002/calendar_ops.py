def coalesce(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Touching intervals (end == next start) are merged.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate and convert to list format
    norm = []
    for iv in intervals:
        if not isinstance(iv, dict) or "start" not in iv or "end" not in iv:
            raise ValueError("interval must be a dict with 'start' and 'end' keys")
        s, e = iv["start"], iv["end"]
        if s > e:
            raise ValueError(f"invalid interval: start {s} > end {e}")
        norm.append([s, e])

    # Sort by start, then by end
    norm.sort(key=lambda p: (p[0], p[1]))

    # Merge overlapping intervals (touching intervals are merged)
    merged = []
    for s, e in norm:
        if merged and s <= merged[-1][1]:
            if e > merged[-1][1]:
                merged[-1][1] = e
        else:
            merged.append([s, e])

    # Convert back to dict format
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})

    return result
