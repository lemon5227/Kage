def merge_slots(intervals):
    """Merge overlapping intervals given as dicts {"from": s, "to": e}.
    
    Returns merged intervals as dicts with the same "from"/"to" keys,
    sorted by start ascending. Touching intervals (end == next start) are merged.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate and convert to list format
    norm = []
    for iv in intervals:
        s, e = iv["from"], iv["to"]
        if s > e:
            raise ValueError("invalid interval: start > end")
        norm.append([s, e])
    
    # Sort by start ascending
    norm.sort(key=lambda p: (p[0], p[1]))
    
    # Merge overlapping intervals (touching intervals are merged)
    merged = []
    for s, e in norm:
        if merged and s <= merged[-1][1]:
            if e > merged[-1][1]:
                merged[-1][1] = e
        else:
            merged.append([s, e])
    
    # Convert back to dicts with "from"/"to" keys
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})
    
    return result
