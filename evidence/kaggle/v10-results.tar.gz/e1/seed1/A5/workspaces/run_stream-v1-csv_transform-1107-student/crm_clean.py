import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    try:
        ti = header.index('team')
        ki = header.index('city')
        si = header.index('name')
    except ValueError:
        ti, ki, si = 0, 0, 0
    data = [[c.strip() for c in r] for r in rows[1:]]
    # Drop rows whose 'team' cell is empty
    data = [r for r in data if len(r) > ti and r[ti] != ""]
    # Remove duplicate rows by 'city', keeping the first occurrence
    seen = set()
    deduped = []
    for r in data:
        if r[ki] in seen:
            continue
        seen.add(r[ki])
        deduped.append(r)
    # Sort rows by 'name' ascending as strings (stable)
    deduped.sort(key=lambda r: r[si] if len(r) > si else "")
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in deduped:
        w.writerow(r)
    return out.getvalue()
