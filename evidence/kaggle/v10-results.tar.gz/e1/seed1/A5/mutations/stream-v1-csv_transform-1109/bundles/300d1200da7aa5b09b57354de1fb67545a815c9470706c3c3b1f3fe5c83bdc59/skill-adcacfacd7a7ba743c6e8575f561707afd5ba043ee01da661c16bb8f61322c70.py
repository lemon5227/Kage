import csv, io

def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    key_column = arguments['key_column']
    sort_column = arguments['sort_column']
    line_terminator = arguments.get('line_terminator', '\n')

    code = '''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""
    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]
    cleaned = [[cell.strip() for cell in row] for row in data]
    key_idx = header.index({key!r})
    cleaned = [row for row in cleaned if row[key_idx] != ""]
    seen = set()
    deduped = []
    for row in cleaned:
        k = row[key_idx]
        if k in seen:
            continue
        seen.add(k)
        deduped.append(row)
    sort_idx = header.index({sort!r})
    deduped.sort(key=lambda row: row[sort_idx])
    out = io.StringIO()
    writer = csv.writer(out, lineterminator={term!r})
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
'''.format(fn=function_name, key=key_column, sort=sort_column, term=line_terminator)

    path = context['workspace_dir'] + '/' + target_file
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': target_file}
