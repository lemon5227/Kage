def run(arguments, context):
    import os
    target = arguments['target_file']
    fname = arguments['function_name']
    level_index = int(arguments.get('level_index', 1))
    min_tokens = int(arguments.get('min_tokens', 3))
    src = (
        "def " + fname + "(lines):\n"
        "    counts = {}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        parts = line.split()\n"
        "        if len(parts) < " + str(min_tokens) + ":\n"
        "            continue\n"
        "        level = parts[" + str(level_index) + "]\n"
        "        if not level:\n"
        "            continue\n"
        "        key = level.upper()\n"
        "        counts[key] = counts.get(key, 0) + 1\n"
        "    return counts\n"
    )
    path = os.path.join(context['workspace_dir'], target)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': target, 'function': fname}
