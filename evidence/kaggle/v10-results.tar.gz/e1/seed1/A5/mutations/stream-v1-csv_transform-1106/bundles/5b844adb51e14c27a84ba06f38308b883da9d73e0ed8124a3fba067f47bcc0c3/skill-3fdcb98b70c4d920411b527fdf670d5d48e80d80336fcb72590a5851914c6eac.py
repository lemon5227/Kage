import csv, io

def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    drop_column = arguments['drop_column']
    dedup_column = arguments['dedup_column']
    sort_column = arguments['sort_column']
    line_terminator = arguments.get('line_terminator', '\n')

    code = '''import csv
import io

def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = rows[1:]
    cleaned = []
    for row in data:
        row = [c.strip() for c in row]
        if len(row) < len(header):
            row = row + [""] * (len(header) - len(row))
        cleaned.append(row)
    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None
    di = idx({drop!r})
    if di is not None:
        cleaned = [r for r in cleaned if r[di] != ""]
    ui = idx({dedup!r})
    if ui is not None:
        seen = set()
        out = []
        for r in cleaned:
            k = r[ui]
            if k in seen:
                continue
            seen.add(k)
            out.append(r)
        cleaned = out
    si = idx({sort!r})
    if si is not None:
        cleaned.sort(key=lambda r: r[si])
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator={term!r})
    w.writerow(header)
    w.writerows(cleaned)
    return buf.getvalue()
'''.format(fn=function_name, drop=drop_column, dedup=dedup_column, sort=sort_column, term=line_terminator)

    path = target_file
    if not path.startswith('/'):
        path = context['workspace_dir'].rstrip('/') + '/' + path
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': target_file, 'bytes_written': len(code)}
