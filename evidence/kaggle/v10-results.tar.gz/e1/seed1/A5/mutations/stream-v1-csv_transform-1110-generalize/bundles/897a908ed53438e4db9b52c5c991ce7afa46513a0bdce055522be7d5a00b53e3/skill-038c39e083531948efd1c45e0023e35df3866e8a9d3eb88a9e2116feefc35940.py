import csv, io

def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    key_column = arguments['key_column']
    sort_column = arguments['sort_column']
    lower_column = arguments.get('lower_column')
    line_terminator = arguments.get('line_terminator', '\n')

    def tidy(text):
        if text == '':
            return ''
        rows = list(csv.reader(io.StringIO(text)))
        if not rows:
            return ''
        header = [c.strip() for c in rows[0]]
        data = rows[1:]
        cleaned = []
        for row in data:
            cells = [c.strip() for c in row]
            if len(cells) < len(header):
                cells += [''] * (len(header) - len(cells))
            elif len(cells) > len(header):
                cells = cells[:len(header)]
            cleaned.append(cells)
        try:
            key_idx = header.index(key_column)
        except ValueError:
            key_idx = 0
        cleaned = [r for r in cleaned if r[key_idx] != '']
        if lower_column is not None:
            try:
                low_idx = header.index(lower_column)
            except ValueError:
                low_idx = None
            if low_idx is not None:
                for r in cleaned:
                    r[low_idx] = r[low_idx].lower()
        seen = set()
        deduped = []
        for r in cleaned:
            k = r[key_idx]
            if k in seen:
                continue
            seen.add(k)
            deduped.append(r)
        try:
            sort_idx = header.index(sort_column)
        except ValueError:
            sort_idx = 0
        deduped.sort(key=lambda r: r[sort_idx])
        out = io.StringIO()
        writer = csv.writer(out, lineterminator=line_terminator)
        writer.writerow(header)
        writer.writerows(deduped)
        return out.getvalue()

    src = 'import csv, io\n\ndef ' + function_name + '(text):\n'
    src += '    return _tidy(text)\n\n'
    src += '_tidy = ' + repr(tidy) + '\n'
    path = context['workspace_dir'].rstrip('/') + '/' + target_file
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target_file}
