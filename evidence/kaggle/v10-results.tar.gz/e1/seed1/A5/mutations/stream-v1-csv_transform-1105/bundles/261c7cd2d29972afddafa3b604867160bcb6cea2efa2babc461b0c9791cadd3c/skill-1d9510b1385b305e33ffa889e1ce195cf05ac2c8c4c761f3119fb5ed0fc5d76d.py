import csv, io

def run(arguments, context):
    target = arguments['target_file']
    fname = arguments['function_name']
    key_col = arguments['key_column']
    sort_col = arguments['sort_column']
    lower_col = arguments.get('lower_column')
    term = arguments.get('line_terminator', '\n')
    src = (
        'import csv, io\n'
        'def ' + fname + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    body = rows[1:]\n'
        '    cleaned = []\n'
        '    for row in body:\n'
        '        cells = [c.strip() for c in row]\n'
        '        if len(cells) < len(header):\n'
        '            cells += [""] * (len(header) - len(cells))\n'
        '        elif len(cells) > len(header):\n'
        '            cells = cells[:len(header)]\n'
        '        cleaned.append(cells)\n'
        '    def idx(name):\n'
        '        return header.index(name) if name in header else None\n'
        '    ki = idx(' + repr(key_col) + ')\n'
        '    si = idx(' + repr(sort_col) + ')\n'
        '    li = idx(' + repr(lower_col) + ') if ' + repr(lower_col) + ' is not None else None\n'
        '    if ki is not None:\n'
        '        cleaned = [r for r in cleaned if r[ki] != ""]\n'
        '    if li is not None:\n'
        '        for r in cleaned:\n'
        '            r[li] = r[li].lower()\n'
        '    if ki is not None:\n'
        '        seen = set()\n'
        '        deduped = []\n'
        '        for r in cleaned:\n'
        '            if r[ki] in seen:\n'
        '                continue\n'
        '            seen.add(r[ki])\n'
        '            deduped.append(r)\n'
        '        cleaned = deduped\n'
        '    if si is not None:\n'
        '        cleaned.sort(key=lambda r: r[si])\n'
        '    out = io.StringIO()\n'
        '    w = csv.writer(out, lineterminator=' + repr(term) + ')\n'
        '    w.writerow(header)\n'
        '    w.writerows(cleaned)\n'
        '    return out.getvalue()\n'
    )
    path = context['workspace_dir'].rstrip('/') + '/' + target
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
