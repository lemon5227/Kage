import re


def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    levels = [l.upper() for l in arguments['levels']]
    group_field = arguments['group_field']

    code = '''import re


def {fn}(lines):
    levels = {levels!r}
    group_field = {group_field!r}
    counts = {{}}
    for line in lines:
        if not isinstance(line, str):
            continue
        m = re.match(r'^\\S+\\s+(\\S+)\\s+(\\S+):\\s*(.*)$', line)
        if not m:
            continue
        level = m.group(1).upper()
        service = m.group(2)
        if level not in levels:
            continue
        if group_field == 'level':
            key = level
        else:
            key = service
        if not key:
            continue
        counts[key] = counts.get(key, 0) + 1
    return counts
'''.format(fn=function_name, levels=levels, group_field=group_field)

    path = target_file
    if not path.startswith('/'):
        path = context['workspace_dir'].rstrip('/') + '/' + path
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': target_file}
