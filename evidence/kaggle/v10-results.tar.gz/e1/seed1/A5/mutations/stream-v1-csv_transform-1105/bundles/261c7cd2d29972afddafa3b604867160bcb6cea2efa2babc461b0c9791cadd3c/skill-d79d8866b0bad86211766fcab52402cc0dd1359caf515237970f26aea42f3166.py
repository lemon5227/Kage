import re


def run(arguments, context):
    target_file = arguments["target_file"]
    function_name = arguments["function_name"]
    src = (
        "import re\n\n"
        "_LINE_RE = re.compile(r'^(\\S+)\\s+(\\S+)\\s+(\\S+):\\s*(.*)$')\n\n\n"
        "def " + function_name + "(lines):\n"
        "    counts = {}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        m = _LINE_RE.match(line.strip())\n"
        "        if not m:\n"
        "            continue\n"
        "        level = m.group(2).upper()\n"
        "        counts[level] = counts.get(level, 0) + 1\n"
        "    return counts\n"
    )
    import os
    path = os.path.join(context["workspace_dir"], target_file)
    with open(path, "w", encoding="utf-8") as f:
        f.write(src)
    return {"success": True, "path": target_file, "bytes_written": len(src)}
