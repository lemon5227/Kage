def run(arguments, context):
    import os
    target = arguments['target_file']
    fname = arguments['function_name']
    src = '''def {fname}(intervals):
    norm = []
    for iv in intervals:
        s, e = iv[0], iv[1]
        if s > e:
            raise ValueError("invalid interval: start > end")
        norm.append([s, e])
    norm.sort(key=lambda p: (p[0], p[1]))
    merged = []
    for s, e in norm:
        if merged and s <= merged[-1][1]:
            if e > merged[-1][1]:
                merged[-1][1] = e
        else:
            merged.append([s, e])
    return merged
'''.format(fname=fname)
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
