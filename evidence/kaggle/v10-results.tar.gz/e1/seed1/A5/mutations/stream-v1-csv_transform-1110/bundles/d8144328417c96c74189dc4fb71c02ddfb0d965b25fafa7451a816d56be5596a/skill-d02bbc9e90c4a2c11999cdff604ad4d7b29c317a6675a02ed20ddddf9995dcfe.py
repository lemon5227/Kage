import csv, io

def run(arguments, context):
    target = arguments['target_file']
    fname = arguments['function_name']
    key_col = arguments['key_column']
    sort_col = arguments['sort_column']
    lower_col = arguments.get('lower_column', '')
    term = arguments.get('line_terminator', '\n')
    src = (
        'import csv\nimport io\n\n'
        'def ' + fname + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    n = len(header)\n'
        '    data = []\n'
        '    for row in rows[1:]:\n'
        '        cells = [c.strip() for c in row]\n'
        '        if len(cells) < n:\n'
        '            cells += [""] * (n - len(cells))\n'
        '        else:\n'
        '            cells = cells[:n]\n'
        '        data.append(cells)\n'
        '    ki = header.index(' + repr(key_col) + ')\n'
        '    si = header.index(' + repr(sort_col) + ')\n'
        '    data = [r for r in data if r[ki] != ""]\n'
        '    if ' + repr(lower_col) + ':\n'
        '        li = header.index(' + repr(lower_col) + ')\n'
        '        for r in data:\n'
        '            r[li] = r[li].lower()\n'
        '    seen = set()\n'
        '    deduped = []\n'
        '    for r in data:\n'
        '        if r[ki] in seen:\n'
        '            continue\n'
        '        seen.add(r[ki])\n'
        '        deduped.append(r)\n'
        '    deduped.sort(key=lambda r: r[si])\n'
        '    out = io.StringIO()\n'
        '    w = csv.writer(out, lineterminator=' + repr(term) + ')\n'
        '    w.writerow(header)\n'
        '    w.writerows(deduped)\n'
        '    return out.getvalue()\n'
    )
    path = context['workspace_dir'].rstrip('/') + '/' + target
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
