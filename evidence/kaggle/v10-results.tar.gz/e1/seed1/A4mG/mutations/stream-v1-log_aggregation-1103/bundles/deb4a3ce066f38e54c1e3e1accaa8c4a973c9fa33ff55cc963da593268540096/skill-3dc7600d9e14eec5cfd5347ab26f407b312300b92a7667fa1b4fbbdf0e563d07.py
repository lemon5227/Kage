import os

def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    field_index = arguments.get('field_index', 1)
    min_tokens = arguments.get('min_tokens', 3)
    require_colon_suffix = arguments.get('require_colon_suffix', True)
    uppercase_keys = arguments.get('uppercase_keys', True)

    lines = []
    lines.append('def ' + function_name + '(lines):')
    lines.append('    counts = {}')
    lines.append('    for line in lines:')
    lines.append('        parts = line.split()')
    lines.append('        if len(parts) < ' + str(min_tokens) + ':')
    lines.append('            continue')
    lines.append('        if ' + str(field_index) + ' >= len(parts):')
    lines.append('            continue')
    if require_colon_suffix:
        lines.append('        if not parts[' + str(field_index + 1) + '].endswith(":"):')
        lines.append('            continue')
    lines.append('        key = parts[' + str(field_index) + ']')
    if uppercase_keys:
        lines.append('        key = key.upper()')
    lines.append('        counts[key] = counts.get(key, 0) + 1')
    lines.append('    return counts')
    lines.append('')

    content = '\n'.join(lines)
    path = os.path.join(context['workspace_dir'], target_file)
    with open(path, 'w') as f:
        f.write(content)
    return {'success': True, 'path': target_file, 'bytes_written': len(content)}
