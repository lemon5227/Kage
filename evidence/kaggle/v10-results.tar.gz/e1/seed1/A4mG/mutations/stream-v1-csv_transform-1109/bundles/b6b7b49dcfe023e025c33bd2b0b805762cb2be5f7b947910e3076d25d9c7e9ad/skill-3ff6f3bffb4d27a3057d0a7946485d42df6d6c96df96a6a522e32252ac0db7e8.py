import csv, io


def run(arguments, context):
    target = arguments['target_file']
    fn = arguments['function_name']
    drop_col = arguments['drop_column']
    dedup_col = arguments['dedup_column']
    lower_col = arguments.get('lowercase_column')
    sort_col = arguments.get('sort_column')
    asc = arguments.get('sort_ascending', True)
    le = arguments.get('line_ending', '\n')

    src = (
        'import csv\nimport io\n\n\n'
        'def ' + fn + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    data = [[c.strip() for c in r] for r in rows[1:]]\n'
        '    di = header.index(' + repr(drop_col) + ')\n'
        '    data = [r for r in data if r[di] != ""]\n'
    )
    if lower_col:
        src += (
            '    li = header.index(' + repr(lower_col) + ')\n'
            '    for r in data:\n'
            '        r[li] = r[li].lower()\n'
        )
    src += (
        '    ui = header.index(' + repr(dedup_col) + ')\n'
        '    seen = set()\n'
        '    out_rows = []\n'
        '    for r in data:\n'
        '        k = r[ui]\n'
        '        if k in seen:\n'
        '            continue\n'
        '        seen.add(k)\n'
        '        out_rows.append(r)\n'
    )
    if sort_col:
        src += (
            '    si = header.index(' + repr(sort_col) + ')\n'
            '    out_rows.sort(key=lambda r: r[si], reverse=' + repr(not asc) + ')\n'
        )
    src += (
        '    buf = io.StringIO()\n'
        '    w = csv.writer(buf, lineterminator=' + repr(le) + ')\n'
        '    w.writerow(header)\n'
        '    w.writerows(out_rows)\n'
        '    return buf.getvalue()\n'
    )

    path = target if target.startswith('/') else context['workspace_dir'].rstrip('/') + '/' + target
    with open(path, 'w') as f:
        f.write(src)
    return {'target_file': target, 'function_name': fn, 'bytes_written': len(src)}
