def run(arguments, context):
    import os
    path = arguments['target_file']
    name = arguments['function_name']
    touching = arguments.get('merge_touching', False)
    raise_invalid = arguments.get('raise_on_invalid', True)
    cmp = '<=' if touching else '<'
    lines = []
    lines.append('def %s(intervals):' % name)
    lines.append('    normalized = []')
    lines.append('    for interval in intervals:')
    lines.append('        start, end = interval[0], interval[1]')
    if raise_invalid:
        lines.append('        if start > end:')
        lines.append('            raise ValueError("invalid interval: start %r > end %r" % (start, end))')
    lines.append('        normalized.append([start, end])')
    lines.append('    normalized.sort(key=lambda pair: (pair[0], pair[1]))')
    lines.append('    merged = []')
    lines.append('    for start, end in normalized:')
    lines.append('        if merged and start %s merged[-1][1]:' % cmp)
    lines.append('            if end > merged[-1][1]:')
    lines.append('                merged[-1][1] = end')
    lines.append('        else:')
    lines.append('            merged.append([start, end])')
    lines.append('    return merged')
    content = '\n'.join(lines) + '\n'
    full = os.path.join(context['workspace_dir'], path)
    d = os.path.dirname(full)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(full, 'w') as f:
        f.write(content)
    return {'success': True, 'path': path, 'bytes_written': len(content)}
