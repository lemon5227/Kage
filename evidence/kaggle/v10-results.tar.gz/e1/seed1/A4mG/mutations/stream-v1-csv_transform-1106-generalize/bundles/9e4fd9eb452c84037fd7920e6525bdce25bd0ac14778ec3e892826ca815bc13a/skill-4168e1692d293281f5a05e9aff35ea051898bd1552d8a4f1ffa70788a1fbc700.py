def run(arguments, context):
    import os
    target = arguments['target_file']
    fname = arguments['function_name']
    idx = int(arguments.get('field_index', 1))
    min_tokens = int(arguments.get('min_tokens', 3))
    upper = bool(arguments.get('uppercase_keys', True))
    req_alpha = bool(arguments.get('require_alpha', True))
    req_colon = bool(arguments.get('require_colon_suffix', False))
    lines = []
    lines.append('def %s(lines):' % fname)
    lines.append('    counts = {}')
    lines.append('    for line in lines:')
    lines.append('        if not isinstance(line, str):')
    lines.append('            continue')
    lines.append('        parts = line.split()')
    lines.append('        if len(parts) < %d:' % min_tokens)
    lines.append('            continue')
    lines.append('        if %d >= len(parts):' % idx)
    lines.append('            continue')
    lines.append('        key = parts[%d]' % idx)
    if req_alpha:
        lines.append('        if not key.isalpha():')
        lines.append('            continue')
    if req_colon:
        lines.append('        if %d + 1 >= len(parts) or not parts[%d + 1].endswith(":"):' % (idx, idx))
        lines.append('            continue')
    if upper:
        lines.append('        key = key.upper()')
    lines.append('        counts[key] = counts.get(key, 0) + 1')
    lines.append('    return counts')
    code = '\n'.join(lines) + '\n'
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': target, 'bytes_written': len(code)}