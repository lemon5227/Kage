import json, os

def run(arguments, context):
    target = arguments['target_file']
    fn = arguments['function_name']
    key_col = arguments['key_column']
    sort_col = arguments.get('sort_column', key_col)
    le = arguments.get('line_ending', '\n')
    asc = arguments.get('sort_ascending', True)
    src = (
        'import csv\nimport io\n\n'
        'def ' + fn + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    ki = header.index(' + repr(key_col) + ')\n'
        '    si = header.index(' + repr(sort_col) + ')\n'
        '    data = [[c.strip() for c in r] for r in rows[1:]]\n'
        '    data = [r for r in data if len(r) > ki and r[ki] != ""]\n'
        '    seen = set()\n'
        '    ded = []\n'
        '    for r in data:\n'
        '        if r[ki] in seen:\n'
        '            continue\n'
        '        seen.add(r[ki])\n'
        '        ded.append(r)\n'
        '    ded.sort(key=lambda r: r[si] if len(r) > si else "", reverse=' + repr(not asc) + ')\n'
        '    out = io.StringIO()\n'
        '    w = csv.writer(out, lineterminator=' + repr(le) + ')\n'
        '    w.writerow(header)\n'
        '    for r in ded:\n'
        '        w.writerow(r)\n'
        '    return out.getvalue()\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
