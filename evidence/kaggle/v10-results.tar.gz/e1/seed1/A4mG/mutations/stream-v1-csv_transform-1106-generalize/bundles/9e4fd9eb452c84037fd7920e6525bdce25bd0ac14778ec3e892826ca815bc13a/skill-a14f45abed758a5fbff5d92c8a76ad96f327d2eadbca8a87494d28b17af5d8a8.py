import csv, io

def run(arguments, context):
    target = arguments['target_file']
    fname = arguments['function_name']
    key_col = arguments['key_column']
    sort_col = arguments.get('sort_column') or key_col
    lower_cols = arguments.get('lowercase_columns') or []
    le = arguments.get('line_ending', '\n')
    asc = arguments.get('sort_ascending', True)
    src = (
        'import csv\nimport io\n\n'
        'def ' + fname + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    n = len(header)\n'
        '    data = []\n'
        '    for r in rows[1:]:\n'
        '        r = [c.strip() for c in r]\n'
        '        if len(r) < n:\n'
        '            r = r + [""] * (n - len(r))\n'
        '        data.append(r)\n'
        '    def idx(name):\n'
        '        return header.index(name) if name in header else None\n'
        '    ki = idx(' + repr(key_col) + ')\n'
        '    if ki is not None:\n'
        '        data = [r for r in data if r[ki] != ""]\n'
        '    for col in ' + repr(lower_cols) + ':\n'
        '        ci = idx(col)\n'
        '        if ci is not None:\n'
        '            for r in data:\n'
        '                r[ci] = r[ci].lower()\n'
        '    if ki is not None:\n'
        '        seen = set()\n'
        '        out = []\n'
        '        for r in data:\n'
        '            if r[ki] in seen:\n'
        '                continue\n'
        '            seen.add(r[ki])\n'
        '            out.append(r)\n'
        '        data = out\n'
        '    si = idx(' + repr(sort_col) + ')\n'
        '    if si is not None:\n'
        '        data.sort(key=lambda r: r[si], reverse=' + repr(not asc) + ')\n'
        '    buf = io.StringIO()\n'
        '    w = csv.writer(buf, lineterminator=' + repr(le) + ')\n'
        '    w.writerow(header)\n'
        '    w.writerows(data)\n'
        '    return buf.getvalue()\n'
    )
    path = target if target.startswith('/') else context['workspace_dir'].rstrip('/') + '/' + target
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
