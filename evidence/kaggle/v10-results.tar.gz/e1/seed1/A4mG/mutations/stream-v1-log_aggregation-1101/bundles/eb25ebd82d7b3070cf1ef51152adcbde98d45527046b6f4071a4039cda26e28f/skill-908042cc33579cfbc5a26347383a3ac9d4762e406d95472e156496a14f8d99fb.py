def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    gi = int(arguments.get('group_index', 2))
    li = int(arguments.get('level_index', 1))
    allowed = arguments.get('allowed_levels')
    upper = bool(arguments.get('uppercase_keys', True))
    colon = bool(arguments.get('require_colon_suffix', True))
    min_tokens = int(arguments.get('min_tokens', 3))
    allowed_repr = repr([str(x).upper() for x in allowed]) if allowed else 'None'
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    allowed = ' + allowed_repr + '\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + str(min_tokens) + ':\n'
        '            continue\n'
        '        if allowed is not None:\n'
        '            if parts[' + str(li) + '].upper() not in allowed:\n'
        '                continue\n'
        '        key = parts[' + str(gi) + ']\n'
        '        if ' + repr(colon) + ':\n'
        '            if not key.endswith(":"):\n'
        '                continue\n'
        '            key = key[:-1]\n'
        '        if not key:\n'
        '            continue\n'
        '        if ' + repr(upper) + ':\n'
        '            key = key.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = target if os.path.isabs(target) else os.path.join(context['workspace_dir'], target)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
