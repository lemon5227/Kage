import re


def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    field_index = int(arguments.get('field_index', 1))
    min_tokens = int(arguments.get('min_tokens', 3))
    uppercase_keys = bool(arguments.get('uppercase_keys', True))
    require_colon_suffix = bool(arguments.get('require_colon_suffix', False))

    src = '''import re


def {fn}(lines):
    counts = {{}}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.strip().split()
        if len(parts) < {min_tokens}:
            continue
        if {field_index} >= len(parts):
            continue
        key = parts[{field_index}]
        if {require_colon}:
            if {field_index} + 1 >= len(parts) or not parts[{field_index} + 1].endswith(':'):
                continue
        if {upper}:
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
'''.format(
        fn=function_name,
        min_tokens=min_tokens,
        field_index=field_index,
        require_colon=require_colon_suffix,
        upper=uppercase_keys,
    )

    path = target_file
    if not path.startswith('/'):
        path = context['workspace_dir'].rstrip('/') + '/' + path
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target_file, 'bytes_written': len(src)}
