def run(arguments, context):
    import os
    tf = arguments['target_file']
    fn = arguments['function_name']
    ip = arguments.get('items_param', 'items')
    cp = arguments.get('capacity_param', 'capacity')
    idf = arguments.get('id_field', 'id')
    sf = arguments.get('size_field', 'size')
    scf = arguments.get('score_field', 'score')
    lines = [
        'def %s(%s, %s):' % (fn, ip, cp),
        '    if %s < 0:' % cp,
        '        raise ValueError("capacity must be non-negative")',
        '    entries = []',
        '    for item in %s:' % ip,
        '        size = item[%r]' % sf,
        '        score = item[%r]' % scf,
        '        if size <= 0:',
        '            raise ValueError("item size must be positive")',
        '        entries.append((item[%r], size, score))' % idf,
        '    best = [(0, []) for _ in range(%s + 1)]' % cp,
        '    for item_id, size, score in entries:',
        '        for c in range(%s, size - 1, -1):' % cp,
        '            prev_score, prev_ids = best[c - size]',
        '            cand_score = prev_score + score',
        '            cand_ids = sorted(prev_ids + [item_id])',
        '            cur_score, cur_ids = best[c]',
        '            if cand_score > cur_score or (cand_score == cur_score and cand_ids < cur_ids):',
        '                best[c] = (cand_score, cand_ids)',
        '    return best[%s][1]' % cp,
        '',
    ]
    path = os.path.join(context['workspace_dir'], tf)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write('\n'.join(lines))
    return {'success': True, 'path': tf}
