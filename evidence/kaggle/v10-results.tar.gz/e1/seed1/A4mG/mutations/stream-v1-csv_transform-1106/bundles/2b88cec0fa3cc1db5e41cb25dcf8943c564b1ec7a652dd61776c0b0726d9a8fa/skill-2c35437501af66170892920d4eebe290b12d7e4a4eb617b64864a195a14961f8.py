import csv, io

def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    drop_column = arguments['drop_column']
    dedup_column = arguments['dedup_column']
    sort_column = arguments['sort_column']
    line_ending = arguments.get('line_ending', '\n')
    sort_ascending = arguments.get('sort_ascending', True)

    src = (
        'import csv\n'
        'import io\n'
        '\n'
        'def {fn}(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    data = rows[1:]\n'
        '    cleaned = []\n'
        '    for row in data:\n'
        '        row = [c.strip() for c in row]\n'
        '        if len(row) < len(header):\n'
        '            row = row + [""] * (len(header) - len(row))\n'
        '        cleaned.append(row)\n'
        '    def idx(name):\n'
        '        return header.index(name) if name in header else None\n'
        '    di = idx({drop!r})\n'
        '    if di is not None:\n'
        '        cleaned = [r for r in cleaned if r[di] != ""]\n'
        '    ui = idx({dedup!r})\n'
        '    if ui is not None:\n'
        '        seen = set()\n'
        '        out = []\n'
        '        for r in cleaned:\n'
        '            k = r[ui]\n'
        '            if k in seen:\n'
        '                continue\n'
        '            seen.add(k)\n'
        '            out.append(r)\n'
        '        cleaned = out\n'
        '    si = idx({sort!r})\n'
        '    if si is not None:\n'
        '        cleaned.sort(key=lambda r: r[si], reverse={rev!r})\n'
        '    buf = io.StringIO()\n'
        '    w = csv.writer(buf, lineterminator={le!r})\n'
        '    w.writerow(header)\n'
        '    w.writerows(cleaned)\n'
        '    return buf.getvalue()\n'
    ).format(fn=function_name, drop=drop_column, dedup=dedup_column, sort=sort_column, rev=not sort_ascending, le=line_ending)

    path = target_file
    if not path.startswith('/'):
        path = context['workspace_dir'].rstrip('/') + '/' + path
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target_file, 'bytes_written': len(src)}
