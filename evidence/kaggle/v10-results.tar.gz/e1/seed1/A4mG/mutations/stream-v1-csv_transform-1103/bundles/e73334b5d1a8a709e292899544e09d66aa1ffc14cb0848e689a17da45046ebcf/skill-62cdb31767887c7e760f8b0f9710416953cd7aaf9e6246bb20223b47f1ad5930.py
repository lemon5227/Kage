import json, os

def run(arguments, context):
    target = arguments['target_file']
    fn = arguments['function_name']
    key = arguments['key_column']
    asc = arguments.get('sort_ascending', True)
    le = arguments.get('line_ending', '\n')
    src = '''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    try:
        ki = header.index({key!r})
    except ValueError:
        ki = None
    out_rows = []
    seen = set()
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        name = cells[ki] if ki is not None and ki < len(cells) else ""
        if name == "" or name in seen:
            continue
        seen.add(name)
        out_rows.append(cells)
    out_rows.sort(key=lambda r: r[ki] if ki is not None and ki < len(r) else "", reverse=not {asc!r})
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator={le!r})
    w.writerow(header)
    w.writerows(out_rows)
    return buf.getvalue()
'''.format(fn=fn, key=key, asc=asc, le=le)
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src.encode('utf-8'))}