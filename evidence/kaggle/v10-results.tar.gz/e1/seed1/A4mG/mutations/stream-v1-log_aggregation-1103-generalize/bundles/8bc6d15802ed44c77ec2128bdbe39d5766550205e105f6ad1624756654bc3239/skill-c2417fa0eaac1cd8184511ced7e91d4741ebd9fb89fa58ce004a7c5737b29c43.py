import re

_LINE_RE = re.compile(r"^(\S+)\s+(\S+)\s+(\S+):\s")


def run(arguments, context):
    target_file = arguments["target_file"]
    function_name = arguments["function_name"]
    group_by = arguments.get("group_by", "level")
    allowed_levels = arguments.get("allowed_levels")
    uppercase_keys = arguments.get("uppercase_keys", True)
    allowed = None
    if allowed_levels is not None:
        allowed = {str(x).upper() for x in allowed_levels}
    idx = 1 if group_by == "level" else 2
    lines = [
        "import re",
        "",
        "_LINE_RE = re.compile(r\"^(\\\\S+)\\\\s+(\\\\S+)\\\\s+(\\\\S+):\\\\s\")",
        "",
        "",
        "def %s(lines):" % function_name,
        "    counts = {}",
        "    for line in lines:",
        "        m = _LINE_RE.match(line)",
        "        if not m:",
        "            continue",
        "        level = m.group(2).upper()",
    ]
    if allowed is not None:
        lines.append("        if level not in %r:" % (sorted(allowed),))
        lines.append("            continue")
    lines.append("        key = m.group(%d)" % (idx + 1))
    if uppercase_keys:
        lines.append("        key = key.upper()")
    lines.append("        counts[key] = counts.get(key, 0) + 1")
    lines.append("    return counts")
    content = "\n".join(lines) + "\n"
    path = target_file
    if not path.startswith("/"):
        path = context["workspace_dir"].rstrip("/") + "/" + path
    with open(path, "w") as f:
        f.write(content)
    return {"success": True, "path": target_file, "bytes_written": len(content)}