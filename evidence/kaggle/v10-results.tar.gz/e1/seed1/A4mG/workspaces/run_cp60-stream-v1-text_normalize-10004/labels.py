import unicodedata

def label_id(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    current_run = []
    for char in lowercased:
        if char.isalnum():  # a-z, 0-9
            current_run.append(char)
        else:
            if current_run:
                result.append(''.join(current_run))
                current_run = []
            result.append('-')
    
    if current_run:
        result.append(''.join(current_run))
    
    # Strip leading and trailing "-"
    slug = '-'.join(result)
    while slug.startswith('-'):
        slug = slug[1:]
    while slug.endswith('-'):
        slug = slug[:-1]
    
    return slug
