import csv
import io

def tidy_csv(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    ki = header.index('score')
    si = header.index('city')
    data = [[c.strip() for c in r] for r in rows[1:]]
    data = [r for r in data if len(r) > ki and r[ki] != ""]
    seen = set()
    ded = []
    for r in data:
        if r[ki] in seen:
            continue
        seen.add(r[ki])
        ded.append(r)
    ded.sort(key=lambda r: r[si] if len(r) > si else "", reverse=False)
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in ded:
        w.writerow(r)
    return out.getvalue()
