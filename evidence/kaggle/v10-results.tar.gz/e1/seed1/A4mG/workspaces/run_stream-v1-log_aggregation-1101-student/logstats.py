def summarize(lines):
    """Summarize log lines by service for ERROR and WARN levels only.
    
    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"
    
    Returns a dict mapping service name to count for levels ERROR or WARN.
    Malformed lines are silently dropped. Level names are case-insensitive.
    """
    counts = {}
    valid_levels = {'ERROR', 'WARN'}
    
    for line in lines:
        if not isinstance(line, str):
            continue
        
        parts = line.split()
        # Need at least: timestamp, level, service: (with message optional)
        if len(parts) < 3:
            continue
        
        level = parts[1]
        service = parts[2]
        
        # The service token must end with a colon (e.g. "auth:")
        if not service.endswith(':'):
            continue
        
        # Level must be alphabetic
        if not level.isalpha():
            continue
        
        # Check if level is ERROR or WARN (case-insensitive)
        if level.upper() not in valid_levels:
            continue
        
        key = service  # Keep the service name as-is (without colon)
        counts[key] = counts.get(key, 0) + 1
    
    return counts
