import csv
import io

def tidy_csv(text):
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines and parse CSV
    lines = text.strip().split('\n')
    if len(lines) == 0:
        return ''
    
    # Parse header
    header = lines[0].strip().split(',')
    if len(header) != 4 or header[0] != 'score' or header[1] != 'id' or header[2] != 'team' or header[3] != 'name':
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.strip().split(',')
        if len(cells) != 4:
            continue
        # Strip whitespace from each cell
        score = cells[0].strip()
        id_val = cells[1].strip()
        team = cells[2].strip()
        name = cells[3].strip()
        
        # Drop rows where name is empty
        if not name:
            continue
        
        rows.append((score, id_val, team, name))
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        name = row[3]
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row[3])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
