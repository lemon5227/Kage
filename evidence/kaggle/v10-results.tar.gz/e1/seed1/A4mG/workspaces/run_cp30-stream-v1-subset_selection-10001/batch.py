def allocate(items, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    entries = []
    for item in items:
        size = item["cost"]
        value = item["gain"]
        if size <= 0:
            raise ValueError("size must be positive")
        entries.append((item["id"], size, value))
    best = [(0, []) for _ in range(capacity + 1)]
    for item_id, size, value in entries:
        for c in range(capacity, size - 1, -1):
            prev_value, prev_ids = best[c - size]
            cand_value = prev_value + value
            cand_ids = sorted(prev_ids + [item_id])
            cur_value, cur_ids = best[c]
            if cand_value > cur_value or (cand_value == cur_value and cand_ids < cur_ids):
                best[c] = (cand_value, cand_ids)
    return best[capacity][1]
