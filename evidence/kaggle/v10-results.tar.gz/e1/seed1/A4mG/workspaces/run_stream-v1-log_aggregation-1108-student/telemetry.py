def summarize(lines):
    """
    Parse lines in format: <timestamp> <LEVEL> <service>: <message>
    Return a dict mapping each service for levels ERROR only to how many lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines. Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        timestamp, level, service_part = parts[0], parts[1], parts[2]
        # Check if level is alphabetic and equals ERROR (case-insensitive)
        if not level.isalpha():
            continue
        if level.upper() != "ERROR":
            continue
        # Extract service name from "service: message" format
        # The service part may include the colon and message
        # We need to find the service name before the colon
        if ':' in service_part:
            service = service_part.split(':')[0]
        else:
            # If no colon, treat the whole part as service
            service = service_part
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
