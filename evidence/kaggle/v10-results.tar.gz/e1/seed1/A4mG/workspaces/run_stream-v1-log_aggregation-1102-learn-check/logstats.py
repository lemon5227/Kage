import re


def aggregate_log(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.strip().split()
        if len(parts) < 3:
            continue
        if 1 >= len(parts):
            continue
        key = parts[1]
        if False:
            if 1 + 1 >= len(parts) or not parts[1 + 1].endswith(':'):
                continue
        if True:
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
