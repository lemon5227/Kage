import csv
import io


def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = [[c.strip() for c in r] for r in rows[1:]]
    di = header.index('id')
    data = [r for r in data if r[di] != ""]
    li = header.index('email')
    for r in data:
        r[li] = r[li].lower()
    ui = header.index('email')
    seen = set()
    out_rows = []
    for r in data:
        k = r[ui]
        if k in seen:
            continue
        seen.add(k)
        out_rows.append(r)
    si = header.index('email')
    out_rows.sort(key=lambda r: r[si], reverse=False)
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\n')
    w.writerow(header)
    w.writerows(out_rows)
    return buf.getvalue()
