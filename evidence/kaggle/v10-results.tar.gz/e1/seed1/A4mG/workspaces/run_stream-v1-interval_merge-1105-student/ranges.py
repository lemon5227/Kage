def combine_ranges(intervals):
    """Merge overlapping intervals given as dicts {"begin": s, "finish": e}.
    
    Returns merged intervals as dicts with "begin"/"finish" keys, sorted by begin ascending.
    Touching intervals (e.g. [1,3] and [3,5]) are merged.
    Raises ValueError if any interval has begin > finish.
    The input is not modified.
    """
    # Validate and convert to tuples
    converted = []
    for interval in intervals:
        begin = interval["begin"]
        finish = interval["finish"]
        if begin > finish:
            raise ValueError(
                "invalid interval: begin %r > finish %r" % (begin, finish)
            )
        converted.append((begin, finish))
    
    # Sort by begin, then by finish for deterministic ordering
    converted.sort(key=lambda pair: (pair[0], pair[1]))
    
    # Merge overlapping intervals (including touching)
    merged = []
    for start, end in converted:
        if merged and start <= merged[-1][1]:
            # Overlap or touching: extend the current interval if needed
            if end > merged[-1][1]:
                merged[-1] = (merged[-1][0], end)
        else:
            merged.append([start, end])
    
    # Convert back to dicts with "begin"/"finish" keys
    result = []
    for start, end in merged:
        result.append({"begin": start, "finish": end})
    
    return result
