def coalesce(intervals):
    """Combine overlapping time ranges.

    Each interval is a dict {"from": s, "to": e} with integer values.
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals (e.g. {"from": 1, "to": 3} and {"from": 3, "to": 5}) are merged.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Convert dicts to tuples for processing
    normalized = []
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        normalized.append((start, end))

    # Sort by start, then by end
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlap or touching: extend the current interval if needed
            if end > merged[-1][1]:
                merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))

    # Convert back to dicts with "from"/"to" keys
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})

    return result
