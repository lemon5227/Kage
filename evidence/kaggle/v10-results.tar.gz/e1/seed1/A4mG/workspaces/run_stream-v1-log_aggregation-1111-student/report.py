def count_entries(lines):
    """Count entries by level in log lines.
    
    Each line format: <timestamp> <LEVEL> <service>: <message>
    Returns dict mapping each level (upper-case) to count.
    Skips malformed lines. Omits keys with zero count.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service:
        if len(parts) < 3:
            continue
            
        # Extract level (second part)
        level = parts[1].upper()
        
        # Skip if level is empty or not a valid level
        if not level:
            continue
            
        # Increment count for this level
        counts[level] = counts.get(level, 0) + 1
    
    # Return only non-zero counts (already handled by dict)
    return counts
