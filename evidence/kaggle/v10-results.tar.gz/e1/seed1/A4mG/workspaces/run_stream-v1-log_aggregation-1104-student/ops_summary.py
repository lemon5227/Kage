def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns a dictionary {level: count} per level, with level names in uppercase (case-insensitive).
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split by spaces to get parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Check if the third part contains a colon (service: message)
        # Format: <timestamp> <LEVEL> <service>: <message>
        # So parts[0] = timestamp, parts[1] = LEVEL, parts[2] should start with service:
        
        # Extract level from parts[1]
        level = parts[1].upper()  # Case-insensitive, store as uppercase
        
        # Check if parts[2] starts with a colon (indicating service: message)
        # If not, the line is malformed
        if not parts[2].startswith(':'):
            continue
        
        # The line is valid, increment count for this level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
