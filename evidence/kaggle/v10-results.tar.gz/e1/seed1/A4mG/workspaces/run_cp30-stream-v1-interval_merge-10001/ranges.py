def merge_slots(intervals):
    """Merge overlapping intervals given as dicts {"from": s, "to": e}.

    Returns merged intervals as dicts with the same "from"/"to" keys,
    sorted by start ascending. Touching intervals (e.g. [1,3] and [3,5])
    are merged. Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Convert dicts to lists for processing
    normalized = []
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        normalized.append([start, end])

    # Sort by start, then by end
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    merged = []
    for start, end in normalized:
        if merged and start < merged[-1][1]:
            # Real overlap: extend the current interval if needed.
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            # Touching intervals (start == merged[-1][1]) are merged
            if start == merged[-1][1]:
                if end > merged[-1][1]:
                    merged[-1][1] = end
            merged.append([start, end])

    # Convert back to dicts
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})

    return result
