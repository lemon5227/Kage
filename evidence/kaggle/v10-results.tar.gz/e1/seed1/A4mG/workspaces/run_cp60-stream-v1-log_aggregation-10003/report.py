def aggregate_log(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        if 2 >= len(parts):
            continue
        key = parts[2]
        if 2 + 1 >= len(parts) or not parts[2 + 1].endswith(":"):
            continue
        key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
