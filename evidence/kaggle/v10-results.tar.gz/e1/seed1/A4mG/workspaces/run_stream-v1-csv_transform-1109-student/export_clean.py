import csv
import io

def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    ki = header.index('id')
    si = header.index('score')
    ei = header.index('email')
    data = [[c.strip() for c in r] for r in rows[1:]]
    # Lower-case the email column
    data = [[r[0] if i == ei else r[i] for i, r in enumerate(row)] for row in data]
    data = [r for r in data if len(r) > ki and r[ki] != ""]
    seen = set()
    ded = []
    for r in data:
        if r[ki] in seen:
            continue
        seen.add(r[ki])
        ded.append(r)
    ded.sort(key=lambda r: r[si] if len(r) > si else "", reverse=False)
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in ded:
        w.writerow(r)
    return out.getvalue()
