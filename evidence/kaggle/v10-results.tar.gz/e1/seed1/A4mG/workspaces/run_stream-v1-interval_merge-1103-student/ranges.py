def combine_ranges(intervals):
    """Combine overlapping time ranges.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Touching intervals (e.g. {"start": 1, "end": 3}
    and {"start": 3, "end": 5}) are NOT merged; only real overlaps merge.
    Raises ValueError if any interval has start > end. The input is not modified.
    """
    # Convert dicts to tuples for sorting and comparison
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        normalized.append((start, end))

    # Sort by start, then by end
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    merged = []
    for start, end in normalized:
        if merged and start < merged[-1][1]:
            # Real overlap: extend the current interval if needed.
            if end > merged[-1][1]:
                merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))

    # Convert back to dicts
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})

    return result
