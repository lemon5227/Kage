def digest_lines(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        if 1 >= len(parts):
            continue
        if not parts[2].endswith(":"):
            continue
        key = parts[1]
        key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
