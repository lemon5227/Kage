import csv
import io

def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = rows[1:]
    cleaned = []
    for row in data:
        row = [c.strip() for c in row]
        if len(row) < len(header):
            row = row + [""] * (len(header) - len(row))
        cleaned.append(row)
    def idx(name):
        return header.index(name) if name in header else None
    di = idx('team')
    if di is not None:
        cleaned = [r for r in cleaned if r[di] != ""]
    ui = idx('id')
    if ui is not None:
        seen = set()
        out = []
        for r in cleaned:
            k = r[ui]
            if k in seen:
                continue
            seen.add(k)
            out.append(r)
        cleaned = out
    si = idx('city')
    if si is not None:
        cleaned.sort(key=lambda r: r[si], reverse=False)
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\n')
    w.writerow(header)
    w.writerows(cleaned)
    return buf.getvalue()
