def summarize(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level != 'WARN':
            continue
        service = parts[2]
        counts[service] = counts.get(service, 0) + 1
    return counts
