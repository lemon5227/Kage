import csv
import io


def dedupe_export(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Strip whitespace from every cell in data rows
    cleaned_data = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned_data.append(cells)

    # Drop rows whose "score" cell is empty
    score_idx = header.index("score")
    cleaned_data = [row for row in cleaned_data if row[score_idx] != ""]

    # Lower-case the "email" column
    email_idx = header.index("email")
    for row in cleaned_data:
        row[email_idx] = row[email_idx].lower()

    # Remove duplicate rows by "email", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned_data:
        email = row[email_idx]
        if email in seen:
            continue
        seen.add(email)
        deduped.append(row)

    # Sort rows by "score" ascending as strings (stable)
    sort_idx = header.index("score")
    deduped.sort(key=lambda row: row[sort_idx])

    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()
