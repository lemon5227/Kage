import re

_LINE_RE = re.compile(r"^(\\S+)\\s+(\\S+)\\s+(\\S+):\\s")


def summarize(lines):
    counts = {}
    for line in lines:
        m = _LINE_RE.match(line)
        if not m:
            continue
        level = m.group(2).upper()
        key = m.group(2)
        key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
