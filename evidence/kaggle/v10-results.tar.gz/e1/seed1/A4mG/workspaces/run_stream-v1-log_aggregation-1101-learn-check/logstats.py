def summarize(lines):
    counts = {}
    allowed = ['ERROR', 'WARN']
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        if allowed is not None:
            if parts[1].upper() not in allowed:
                continue
        key = parts[2]
        if True:
            if not key.endswith(":"):
                continue
            key = key[:-1]
        if not key:
            continue
        if True:
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
