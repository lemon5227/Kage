import csv
import io

def dedupe_export(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    n = len(header)
    data = []
    for r in rows[1:]:
        r = [c.strip() for c in r]
        if len(r) < n:
            r = r + [""] * (n - len(r))
        data.append(r)
    def idx(name):
        return header.index(name) if name in header else None
    ki = idx('email')
    if ki is not None:
        data = [r for r in data if r[ki] != ""]
    for col in ['email']:
        ci = idx(col)
        if ci is not None:
            for r in data:
                r[ci] = r[ci].lower()
    if ki is not None:
        seen = set()
        out = []
        for r in data:
            if r[ki] in seen:
                continue
            seen.add(r[ki])
            out.append(r)
        data = out
    si = idx('score')
    if si is not None:
        data.sort(key=lambda r: r[si], reverse=False)
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\n')
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
