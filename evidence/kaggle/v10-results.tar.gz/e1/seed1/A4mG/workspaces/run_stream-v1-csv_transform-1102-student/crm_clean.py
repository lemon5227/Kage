import csv
import io

def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    
    # Find column indices
    email_idx = header.index('email')
    id_idx = header.index('id')
    name_idx = header.index('name')
    
    # Strip whitespace from all cells
    data = [[c.strip() for c in r] for r in rows[1:]]
    
    # Drop rows where "name" cell is empty
    data = [r for r in data if len(r) > name_idx and r[name_idx] != ""]
    
    # Lower-case the email column
    for r in data:
        if len(r) > email_idx:
            r[email_idx] = r[email_idx].lower()
    
    # Remove duplicate rows by "id", keeping first occurrence
    seen = set()
    ded = []
    for r in data:
        if r[id_idx] in seen:
            continue
        seen.add(r[id_idx])
        ded.append(r)
    
    # Sort rows by "id" ascending as strings (stable)
    ded.sort(key=lambda r: r[id_idx] if len(r) > id_idx else "", reverse=False)
    
    # Write output with '\n' line endings
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in ded:
        w.writerow(r)
    return out.getvalue()
