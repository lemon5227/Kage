def aggregate_log(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        if 1 >= len(parts):
            continue
        key = parts[1]
        if not key.isalpha():
            continue
        key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
