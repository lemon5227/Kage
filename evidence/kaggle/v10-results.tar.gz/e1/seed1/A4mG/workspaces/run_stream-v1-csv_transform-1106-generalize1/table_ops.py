import csv
import io

def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    n = len(header)
    data = []
    for r in rows[1:]:
        r = [c.strip() for c in r]
        if len(r) < n:
            r = r + [""] * (n - len(r))
        data.append(r)
    def idx(name):
        return header.index(name) if name in header else None
    
    # Drop rows whose "team" cell is empty
    ti = idx('team')
    if ti is not None:
        data = [r for r in data if r[ti] != ""]
    
    # Deduplicate by "id", keeping first occurrence
    ki = idx('id')
    if ki is not None:
        seen = set()
        out = []
        for r in data:
            if r[ki] in seen:
                continue
            seen.add(r[ki])
            out.append(r)
        data = out
    
    # Sort by "city" ascending as strings (stable)
    si = idx('city')
    if si is not None:
        data.sort(key=lambda r: r[si], reverse=False)
    
    # Write output with \n line endings
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\n')
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
