import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)
    data = cleaned

    # drop rows whose "id" cell is empty
    id_idx = header.index("id")
    filtered = []
    for row in data:
        if id_idx < len(row) and row[id_idx] == "":
            continue
        filtered.append(row)
    data = filtered

    # lower-case the "email" column
    email_idx = header.index("email")
    for row in data:
        if email_idx < len(row):
            row[email_idx] = row[email_idx].lower()

    # remove duplicate rows by "email", keeping the first occurrence
    seen = set()
    deduped = []
    for row in data:
        key = row[email_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    data = deduped

    # sort rows by "email" ascending as strings (stable)
    data.sort(key=lambda row: row[email_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in data:
        writer.writerow(row)
    return out.getvalue()
