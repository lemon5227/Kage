import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    segments = []
    for char in ascii_only:
        if char.isalnum():
            segments.append(char)
        else:
            if segments and not segments[-1].isalnum():
                segments.append("_")
            elif not segments:
                segments.append("_")

    result = "".join(segments)

    # strip leading and trailing "_"
    return result.strip("_")
