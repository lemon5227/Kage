def migrate(cfg):
    """Migrate a v1 config dict to v2.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "pwd_file" -> "password_file"
      "user" -> "username"
    Moves "cache_size" and "workers" into a sub-dict "network" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Make a copy so the input is never modified
    out = {}
    out["version"] = 2

    # Process known v1 keys
    if "pwd_file" in cfg:
        out["password_file"] = cfg["pwd_file"]
    if "user" in cfg:
        out["username"] = cfg["user"]

    # Build the network sub-dict
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    out["network"] = network

    # Handle timeout_ms -> timeout_s conversion
    if "timeout_ms" in cfg:
        out["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Copy over any other keys that are not None
    for key, value in cfg.items():
        if key in ("pwd_file", "user", "cache_size", "workers", "timeout_ms"):
            continue
        if value is None:
            continue
        out[key] = value

    return out
