import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    parts = []
    for ch in ascii_only:
        if ch in "abcdefghijklmnopqrstuvwxyz0123456789":
            parts.append(ch)
        else:
            if parts and parts[-1] != "-":
                parts.append("-")
                # reset the "last char" so that consecutive non-alnum runs don't merge
                # but we need to handle runs correctly: each run of non-alnum becomes a single "-"
                # simpler: use regex or state machine
    # Let's do it properly with a state machine
    result = []
    prev_was_non_alnum = False
    for ch in ascii_only:
        if ch in "abcdefghijklmnopqrstuvwxyz0123456789":
            if not prev_was_non_alnum:
                result.append(ch)
            # else: consecutive alnum chars are kept as is (no hyphen inserted between them)
            prev_was_non_alnum = False
        else:
            if not prev_was_non_alnum:
                result.append("-")
            prev_was_non_alnum = True
    return "".join(result)


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_was_non_alnum = False
    for ch in ascii_only:
        if ch in "abcdefghijklmnopqrstuvwxyz0123456789":
            if not prev_was_non_alnum:
                result.append(ch)
            prev_was_non_alnum = False
        else:
            if not prev_was_non_alnum:
                result.append("-")
            prev_was_non_alnum = True

    # strip leading and trailing "-"
    while result and result[0] == "-":
        result.pop(0)
    while result and result[-1] == "-":
        result.pop()

    handle = "".join(result)

    # if the result is longer than 23 characters, cut it to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        if handle.endswith("-"):
            handle = handle[:-1]

    return handle
