def count_entries(lines):
    """Count lines by log level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to its count. Levels are case-insensitive
    (reported upper-case). Malformed lines are skipped. Keys with zero count
    are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 3:
            continue
        _timestamp, level, rest = parts[0], parts[1], parts[2]
        if not rest.startswith(":"):
            continue
        # The service name is between the colon and the message.
        # We only care about the level.
        if not level:
            continue
        level = level.upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
