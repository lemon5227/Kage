def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Top-level keys are renamed: "dir" -> "directory", "host" -> "hostname".
    "port" and "workers" are moved into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Other keys are kept unchanged; keys whose value is None are dropped.
    """
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 configuration")

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Handle the old top-level keys
    dir_val = cfg.get("dir")
    host_val = cfg.get("host")
    port_val = cfg.get("port")
    workers_val = cfg.get("workers")
    timeout_ms_val = cfg.get("timeout_ms")

    # Build the storage sub-dict if any of these values are present
    storage = {}
    if port_val is not None:
        storage["port"] = port_val
    if workers_val is not None:
        storage["workers"] = workers_val
    if timeout_ms_val is not None:
        storage["timeout_s"] = float(timeout_ms_val) / 1000.0

    result["storage"] = storage

    # Rename top-level keys and add to result
    if dir_val is not None:
        result["directory"] = dir_val
    if host_val is not None:
        result["hostname"] = host_val

    # Add any other keys that are present and not None
    for key, value in cfg.items():
        if key in ("dir", "host", "port", "workers", "timeout_ms"):
            continue  # already handled above
        if value is None:
            continue  # drop None values
        result[key] = value

    return result
