def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per service for levels ERROR, WARN only, case-insensitively (uppercase keys),
    dropping malformed input lines."""
    result = {}
    for line in lines:
        # Strip whitespace and check if line is empty
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service (with colon)
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Check if level is ERROR or WARN
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Extract service (third part, before the colon)
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # So parts[2] should be like "service:"
        service_part = parts[2]
        
        # Check if service_part ends with colon
        if not service_part.endswith(':'):
            continue
        
        # Extract service name
        service_name = service_part[:-1]
        
        # Count the event
        result[service_name] = result.get(service_name, 0) + 1
    
    return result
