#!/usr/bin/env python3
"""Run tests for export_clean.py"""

import sys
sys.path.insert(0, '.')
from export_clean import normalize_table

# Test 1: Basic functionality
test1 = "name,team,city,id,score\nAlice,TeamA,City1,1,A\nBob,TeamB,City2,2,B"
result1 = normalize_table(test1)
print("Test 1 - Basic:")
print(result1)

# Test 2: Empty input
test2 = ""
result2 = normalize_table(test2)
print("\nTest 2 - Empty input:")
print(repr(result2))

# Test 3: Header only
test3 = "name,team,city,id,score"
result3 = normalize_table(test3)
print("\nTest 3 - Header only:")
print(result3)

# Test 4: Strip whitespace
test4 = " name , team , city , id , score \n Alice , TeamA , City1 , 1 , A \n Bob , TeamB , City2 , 2 , B "
result4 = normalize_table(test4)
print("\nTest 4 - Strip whitespace:")
print(result4)

# Test 5: Drop empty name
test5 = "name,team,city,id,score\nAlice,TeamA,City1,1,A\n,TeamB,City2,2,B\nBob,TeamC,City3,3,C"
result5 = normalize_table(test5)
print("\nTest 5 - Drop empty name:")
print(result5)

# Test 6: Remove duplicates by score (keep first)
test6 = "name,team,city,id,score\nAlice,TeamA,City1,1,A\nBob,TeamB,City2,2,B\nCharlie,TeamC,City3,1,A"
result6 = normalize_table(test6)
print("\nTest 6 - Remove duplicates by score:")
print(result6)

# Test 7: Sort by id ascending as strings (stable)
test7 = "name,team,city,id,score\nAlice,TeamA,City1,10,A\nBob,TeamB,City2,2,B\nCharlie,TeamC,City3,1,C"
result7 = normalize_table(test7)
print("\nTest 7 - Sort by id:")
print(result7)

# Test 8: Multiple duplicates
test8 = "name,team,city,id,score\nAlice,TeamA,City1,1,A\nBob,TeamB,City2,2,B\nCharlie,TeamC,City3,1,A\nDavid,TeamD,City4,3,D"
result8 = normalize_table(test8)
print("\nTest 8 - Multiple duplicates:")
print(result8)
