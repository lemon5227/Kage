def summarize(lines):
    """
    Summarize log lines in format: <timestamp> <LEVEL> <service>: <message>
    Returns a dict mapping each service for levels WARN only to count.
    Levels are case-insensitive (reported upper-case). Skip malformed lines.
    Omit keys with zero count.
    """
    service_counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Check if line is empty after stripping
        if not line:
            continue
        
        # Split the line into parts
        # Expected format: <timestamp> <LEVEL> <service>: <message>
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service (with colon)
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Check if level is WARN
        if level != 'WARN':
            continue
        
        # Extract service (third part, before the colon)
        # The service part should be like "service_name:"
        service_part = parts[2]
        
        # Check if service part contains a colon
        if ':' not in service_part:
            continue
        
        # Split to get the service name
        service = service_part.split(':')[0].strip()
        
        # Count the service
        service_counts[service] = service_counts.get(service, 0) + 1
    
    return service_counts
