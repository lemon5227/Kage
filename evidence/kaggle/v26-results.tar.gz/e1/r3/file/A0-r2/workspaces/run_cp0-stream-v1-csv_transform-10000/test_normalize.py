#!/usr/bin/env python3
from crm_clean import normalize_table

# Test 1: Basic functionality
test1 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,another@example.com,Jane"
result1 = normalize_table(test1)
print("Test 1 - Basic:")
print(result1)
print()

# Test 2: Empty name should be dropped
test2 = "score,id,email,name\n1,abc,test@example.com,\n2,def,another@example.com,Jane"
result2 = normalize_table(test2)
print("Test 2 - Empty name dropped:")
print(result2)
print()

# Test 3: Duplicate by name (keep first)
test3 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,test@example.com,Jane"
result3 = normalize_table(test3)
print("Test 3 - Duplicate by name:")
print(result3)
print()

# Test 4: Empty input
test4 = ""
result4 = normalize_table(test4)
print("Test 4 - Empty input:")
print(repr(result4))
print()

# Test 5: Header only
test5 = "score,id,email,name"
result5 = normalize_table(test5)
print("Test 5 - Header only:")
print(result5)
print()

# Test 6: Whitespace stripping
test6 = " score , id , email , name \n 1 , abc , test@example.com , John "
result6 = normalize_table(test6)
print("Test 6 - Whitespace stripping:")
print(result6)
print()

# Test 7: Case insensitivity for email
test7 = "score,id,email,name\n1,abc,TEST@EXAMPLE.COM,John\n2,def,another@example.com,Jane"
result7 = normalize_table(test7)
print("Test 7 - Email lowercasing:")
print(result7)
