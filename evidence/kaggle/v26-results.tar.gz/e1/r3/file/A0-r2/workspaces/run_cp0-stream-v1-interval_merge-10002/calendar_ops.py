def coalesce(intervals):
    # Validate all intervals first
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start = interval["start"]
        end = interval["end"]
        
        if merged and start <= merged[-1]["end"]:
            # Overlapping or touching - merge
            merged[-1]["end"] = max(merged[-1]["end"], end)
        else:
            merged.append({"start": start, "end": end})
    
    return merged
