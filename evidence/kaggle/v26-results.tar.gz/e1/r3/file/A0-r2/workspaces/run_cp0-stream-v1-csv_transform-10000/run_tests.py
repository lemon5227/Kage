#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')
from test_normalize import *
