def coalesce(intervals):
    """
    Combine overlapping time ranges in intervals.
    
    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals in the same [start, end] list form, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start, end = interval
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Create a copy to avoid modifying the input
    result = []
    for interval in intervals:
        result.append(list(interval))
    
    # Sort by start time
    result.sort(key=lambda x: x[0])
    
    # Merge overlapping or touching intervals
    if not result:
        return result
    
    merged = [result[0][:]]  # Make a copy of the first interval
    
    for i in range(1, len(result)):
        current = result[i]
        last = merged[-1]
        
        # If current starts at or before the last ends, they overlap or touch
        if current[0] <= last[1]:
            # Merge them by taking the maximum end
            last[1] = max(last[1], current[1])
        else:
            # No overlap, add the current interval
            merged.append(current[:])
    
    return merged
