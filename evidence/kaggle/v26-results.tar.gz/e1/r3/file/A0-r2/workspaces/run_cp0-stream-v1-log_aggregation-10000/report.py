def count_entries(lines):
    """Count entries by level in log lines.
    
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level (case-insensitive, upper-case) to its count.
    Skips malformed lines and omits keys with zero count.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip malformed lines
        
        # Check format: timestamp, level, service: message
        # We need at least 3 parts: timestamp, level, and the rest should start with service:
        level = parts[1].upper()
        
        # Validate that the level is not empty
        if not level:
            continue
        
        # Count this entry
        counts[level] = counts.get(level, 0) + 1
    
    # Return only non-zero counts (already handled by dict)
    return counts
