def merge_slots(intervals):
    # Check for invalid intervals where start > end
    for start, end in intervals:
        if start > end:
            raise ValueError("Interval start must not be greater than end")
    
    # If no intervals, return empty list
    if not intervals:
        return []
    
    # Sort intervals by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    merged = [sorted_intervals[0][:]]  # Start with the first interval
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # Check if there's a real overlap (current start < last end)
        if current[0] < last[1]:
            # Merge by updating the end to the maximum of both ends
            last[1] = max(last[1], current[1])
        else:
            # No overlap, add the current interval
            merged.append(current[:])
    
    return merged
