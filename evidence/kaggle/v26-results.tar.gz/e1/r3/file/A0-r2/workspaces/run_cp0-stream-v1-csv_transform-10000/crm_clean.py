import csv
import io


def normalize_table(text):
    """
    Process CSV text with header row (columns: score, id, email, name).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "name", keeping the first occurrence
    5. Sort rows by "email" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Extract header
    header = lines[0].strip()
    # Parse header columns
    header_cols = [col.strip() for col in header.split(',')]
    
    # Check if header matches expected columns
    expected_cols = ['score', 'id', 'email', 'name']
    if header_cols != expected_cols:
        # If header doesn't match, return as is (or could raise error)
        # Based on requirements, we assume correct header format
        pass
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = [cell.strip() for cell in line.split(',')]
        if len(cells) < 4:
            continue
        row = {
            'score': cells[0],
            'id': cells[1],
            'email': cells[2],
            'name': cells[3]
        }
        rows.append(row)
    
    # Drop rows whose "name" cell is empty
    rows = [row for row in rows if row['name'] != '' and row['name'].strip() != '']
    
    # Lower-case the "email" column
    for row in rows:
        row['email'] = row['email'].lower()
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        if row['name'] not in seen_names:
            seen_names.add(row['name'])
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row['email'])
    
    # Build output CSV
    output_lines = [header]
    for row in unique_rows:
        # Reconstruct the row with original column order
        line = f"{row['score']},{row['id']},{row['email']},{row['name']}"
        output_lines.append(line)
    
    # Join with '\n' line endings
    return '\n'.join(output_lines)


if __name__ == '__main__':
    # Test examples
    test1 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,another@example.com,Jane"
    print("Test 1:")
    print(normalize_table(test1))
    
    test2 = "score,id,email,name\n1,abc,test@example.com,\n2,def,another@example.com,Jane"
    print("\nTest 2 (empty name):")
    print(normalize_table(test2))
    
    test3 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,test@example.com,Jane"
    print("\nTest 3 (duplicate by name):")
    print(normalize_table(test3))
    
    test4 = ""
    print("\nTest 4 (empty input):")
    print(repr(normalize_table(test4)))
    
    test5 = "score,id,email,name"
    print("\nTest 5 (header only):")
    print(normalize_table(test5))
