#!/bin/bash
python3 test_normalize.py
