import csv
import io

def clean_rows(text):
    """Clean an exported table CSV text with columns: id, team, score."""
    
    # Handle empty string input
    if not text or not text.strip():
        return ''
    
    # Split into lines and handle line endings
    lines = text.split('\n')
    
    # If only header, return just the header
    if len(lines) == 1:
        return lines[0]
    
    # Parse CSV from text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = []
    for row in rows[1:]:
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Drop rows whose "score" cell is empty
        if not cleaned_row[2].strip():
            continue
        
        data_rows.append(cleaned_row)
    
    # Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    unique_rows = []
    for row in data_rows:
        team = row[1]
        if team not in seen_teams:
            seen_teams.add(team)
            unique_rows.append(row)
    
    # Sort rows by "score" ascending as strings (stable)
    # Use stable sort with key on score column (index 2)
    unique_rows.sort(key=lambda row: row[2])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
