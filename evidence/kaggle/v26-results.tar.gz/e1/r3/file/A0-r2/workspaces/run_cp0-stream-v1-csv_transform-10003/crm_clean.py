import csv
import io

def tidy_csv(text):
    """Clean an exported CSV table with header: name, city, score, team."""
    
    # Handle empty input
    if not text.strip():
        return ''
    
    # Split into lines and parse
    lines = text.strip().split('\n')
    
    # Check if header-only input
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].strip().split(',')
    expected_columns = ['name', 'city', 'score', 'team']
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        
        cells = line.split(',')
        if len(cells) != len(header):
            continue
        
        row = {}
        for i, col in enumerate(header):
            cell = cells[i].strip()
            row[col] = cell
        
        # Drop rows where name is empty
        if row.get('name', '').strip() == '':
            continue
        
        rows.append(row)
    
    # Remove duplicate rows by name, keeping first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        name = row['name'].strip()
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Sort by city ascending as strings (stable)
    unique_rows.sort(key=lambda r: r['city'], stable=True)
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write rows
    for row in unique_rows:
        writer.writerow([row[col] for col in header])
    
    return output.getvalue()
