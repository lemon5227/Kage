def digest_lines(lines):
    """Process log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per level, treating level names case-insensitively (upper-case keys),
    dropping malformed input lines."""
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Malformed: need at least timestamp, level, and service
            continue
        
        # Check format: <timestamp> <LEVEL> <service>: <message>
        # The third part should contain the colon
        if parts[2].startswith(':'):
            # This is malformed - service should come before colon
            continue
        
        # Extract level from parts[1]
        level = parts[1].upper()
        
        # Increment count for this level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
