import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII characters
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if ord(c) < 128)

    # lower-case and replace every run of characters outside [a-z0-9] with a single "_"
    text = text.lower()
    parts = []
    for c in text:
        if c in "abcdefghijklmnopqrstuvwxyz0123456789":
            parts.append(c)
        else:
            if parts and parts[-1] != c:
                parts.append("_")
    return "".join(parts)
