def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Top-level keys are renamed: "dir" -> "directory", "host" -> "hostname".
    "port" and "workers" are moved into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Other keys are kept unchanged; keys whose value is None are dropped.
    """
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 configuration")

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Handle the old top-level keys
    directory = cfg.get("dir")
    if directory is not None:
        result["directory"] = directory

    hostname = cfg.get("host")
    if hostname is not None:
        result["hostname"] = hostname

    # Move port and workers into storage
    storage = {}
    port = cfg.get("port")
    if port is not None:
        storage["port"] = port
    workers = cfg.get("workers")
    if workers is not None:
        storage["workers"] = workers
    result["storage"] = storage

    # Handle timeout_ms conversion
    timeout_ms = cfg.get("timeout_ms")
    if timeout_ms is not None:
        result["timeout_s"] = timeout_ms / 1000.0

    # Copy over any other keys that are present and not None
    for key, value in cfg.items():
        if key in ("dir", "host", "port", "workers", "timeout_ms"):
            continue
        if value is None:
            continue
        result[key] = value

    return result
