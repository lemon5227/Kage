def tally_events(lines):
    """Tally log lines by service for ERROR and WARN levels.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Only ERROR and WARN levels are counted (case-insensitive).
    Malformed lines are dropped.
    Returns a dict mapping service name (upper-case key) to count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        _timestamp, level, service, message = parts
        if level.upper() not in ("ERROR", "WARN"):
            continue
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service:
            continue
        counts[service.upper()] = counts.get(service.upper(), 0) + 1
    return counts
