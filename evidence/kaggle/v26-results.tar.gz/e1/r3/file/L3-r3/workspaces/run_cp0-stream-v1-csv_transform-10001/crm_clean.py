import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned_data = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned_data.append(cells)

    # drop rows whose "score" cell is empty
    score_idx = header.index("score") if "score" in header else -1
    if score_idx >= 0:
        cleaned_data = [row for row in cleaned_data if len(row) > score_idx and row[score_idx] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    if score_idx >= 0:
        seen = set()
        deduped = []
        for row in cleaned_data:
            key = row[score_idx] if score_idx < len(row) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(row)
        cleaned_data = deduped

    # sort rows by "name" ascending as strings (stable)
    name_idx = header.index("name") if "name" in header else -1
    if name_idx >= 0:
        cleaned_data.sort(key=lambda row: row[name_idx] if name_idx < len(row) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned_data)
    return out.getvalue()
