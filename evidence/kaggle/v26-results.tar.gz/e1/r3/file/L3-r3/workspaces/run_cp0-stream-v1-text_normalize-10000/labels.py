import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = "".join(c for c in normalized if ord(c) < 128)

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    for c in ascii_only:
        if c.isalnum():
            segments.append(c)
        else:
            if segments and not segments[-1].isalnum():
                # end of a run of non-alnum chars
                pass
            elif not segments or not segments[-1].isalnum():
                # start of a new run of non-alnum chars
                if segments:
                    segments.append("-")
                else:
                    segments.append("-")
    result = "".join(segments)

    # strip leading and trailing "-"
    result = result.strip("-")

    # if longer than 23 characters, cut to 23 and then strip a trailing "-"
    if len(result) > 23:
        result = result[:23]
        if result.endswith("-"):
            result = result[:-1]

    return result
