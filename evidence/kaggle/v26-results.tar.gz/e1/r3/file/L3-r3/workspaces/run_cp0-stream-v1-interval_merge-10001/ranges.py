def merge_slots(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"from": s, "to": e} with integer values.
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals (e.g. [1, 3] and [3, 5]) are merged.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    normalized = []
    for interval in intervals:
        from_val = interval["from"]
        to_val = interval["to"]
        if from_val > to_val:
            raise ValueError(
                "invalid interval: from ({}) > to ({})".format(from_val, to_val)
            )
        normalized.append((from_val, to_val))

    normalized.sort(key=lambda pair: pair[0])

    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching intervals: extend the end if needed.
            if end > merged[-1][1]:
                merged[-1] = (start, end)
        else:
            merged.append((start, end))

    return [{"from": start, "to": end} for start, end in merged]
