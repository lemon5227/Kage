import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    for ch in ascii_only:
        if ch in "abcdefghijklmnopqrstuvwxyz0123456789":
            segments.append(ch)
        else:
            if segments and segments[-1] != "-":
                segments.append("-")
                segments.clear()

    handle = "".join(segments)

    # strip leading and trailing "-"
    while handle.startswith("-"):
        handle = handle[1:]
    while handle.endswith("-"):
        handle = handle[:-1]

    # if the result is longer than 23 characters, cut it to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        while handle.endswith("-"):
            handle = handle[:-1]

    return handle
