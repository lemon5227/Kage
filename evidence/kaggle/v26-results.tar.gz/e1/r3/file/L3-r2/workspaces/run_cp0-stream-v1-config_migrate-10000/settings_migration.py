def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            f"expected version 1, got {version!r}"
        )

    # Work on a copy so the input is never modified
    out = {"version": 2}

    # Rename top-level keys
    if "max_conn" in cfg:
        out["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        out["directory"] = cfg["dir"]
    if "host" in cfg:
        out["hostname"] = cfg["host"]

    # Move cache_size and region into a sub-dict "limits"
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    out["limits"] = limits

    # Handle timeout_ms -> timeout_s conversion
    if "timeout_ms" in cfg:
        out["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Drop keys whose value is None
    for key in list(out.keys()):
        if out[key] is None:
            del out[key]

    return out
