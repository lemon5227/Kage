def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Top-level keys are renamed: "dir" -> "directory", "host" -> "hostname".
    "port" and "workers" are moved into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Other keys are kept unchanged; keys whose value is None are dropped.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process top-level keys
    for key, value in list(cfg.items()):
        if key == "dir":
            result["directory"] = value
        elif key == "host":
            result["hostname"] = value
        elif key == "port":
            # port moves into storage sub-dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["port"] = value
        elif key == "workers":
            # workers moves into storage sub-dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["workers"] = value
        elif key == "timeout_ms":
            if value is None:
                continue  # drop None values
            result["timeout_s"] = float(value) / 1000.0
        else:
            # Keep other keys unchanged
            if value is not None:
                result[key] = value

    # Ensure storage is always present (even if empty)
    if "storage" not in result:
        result["storage"] = {}

    return result
