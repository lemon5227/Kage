def slugify(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization to decompose characters
    text = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    text = ''.join(char for char in text if ord(char) < 128)
    
    # Lower-case
    text = text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    prev_char = None
    for char in text:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char != '-':
                slug.append('-')
                prev_char = '-'
        else:
            prev_char = char
        slug.append(char)
    
    # Actually, simpler approach: split by non-alphanumeric and join with single hyphen
    import re
    slug = re.sub(r'[^a-z0-9]+', '-', text)
    
    # Strip leading and trailing "-"
    slug = slug.strip('-')
    
    return slug
