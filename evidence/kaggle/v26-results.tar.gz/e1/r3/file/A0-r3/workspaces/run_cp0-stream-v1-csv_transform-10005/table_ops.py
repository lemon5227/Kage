import csv
import io

def normalize_table(text):
    """Clean an exported table from CSV text."""
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Check if it's header-only (no data rows)
    lines = text.strip().split('\n')
    if len(lines) < 2:
        # Only header row, return as is
        return text.strip()
    
    # Parse the CSV
    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ''
    
    # Validate columns: id, email, city, name
    expected_cols = ['id', 'email', 'city', 'name']
    if len(header) != len(expected_cols):
        return ''
    
    # Process rows
    processed_rows = []
    seen_emails = set()
    
    for row in reader:
        # Strip whitespace from every cell
        row = [cell.strip() for cell in row]
        
        # Skip if id is empty
        if not row[0]:
            continue
        
        # Lower-case the email column
        row[1] = row[1].lower()
        
        # Remove duplicate rows by email, keeping first occurrence
        if row[1] in seen_emails:
            continue
        seen_emails.add(row[1])
        
        processed_rows.append(row)
    
    # Sort rows by email ascending as strings (stable)
    processed_rows.sort(key=lambda row: row[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in processed_rows:
        writer.writerow(row)
    
    return output.getvalue()
