def convert_settings(cfg):
    """Convert old configuration dict to v2 layout."""
    # Check version requirement
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")
    
    # Create new dict without modifying input
    result = {}
    result["version"] = 2
    
    # Rename top-level keys
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    
    # Move port and retries into storage sub-dict
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "retries" in cfg:
        storage["retries"] = cfg["retries"]
    result["storage"] = storage
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["host", "max_conn", "pwd_file", "port", "retries", "timeout_ms", "version"]:
            if value is not None:
                result[key] = value
    
    return result
