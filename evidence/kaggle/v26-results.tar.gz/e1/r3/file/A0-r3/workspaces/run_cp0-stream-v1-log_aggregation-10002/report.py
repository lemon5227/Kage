def digest_lines(lines):
    result = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split by spaces to get parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1]
        
        # Extract service (third part, before the colon)
        service_part = parts[2]
        if ':' not in service_part:
            continue
        
        service_name = service_part.split(':')[0]
        
        # Count by level (case-insensitive, store with upper-case key)
        level_upper = level.upper()
        result[level_upper] = result.get(level_upper, 0) + 1
    
    return result
