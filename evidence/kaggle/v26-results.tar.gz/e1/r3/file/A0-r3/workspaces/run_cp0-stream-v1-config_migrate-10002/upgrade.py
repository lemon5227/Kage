def upgrade_config(cfg):
    # Check if version is 1, otherwise raise ValueError
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1 for upgrade")
    
    # Create a new dictionary for the upgraded config
    upgraded = {"version": 2}
    
    # Process top-level keys
    # Rename "dir" to "directory"
    if "dir" in cfg:
        upgraded["directory"] = cfg["dir"]
    
    # Rename "pwd_file" to "password_file"
    if "pwd_file" in cfg:
        upgraded["password_file"] = cfg["pwd_file"]
    
    # Rename "max_conn" to "max_connections"
    if "max_conn" in cfg:
        upgraded["max_connections"] = cfg["max_conn"]
    
    # Handle "timeout_ms" - convert to timeout_s
    if "timeout_ms" in cfg:
        upgraded["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Move "region" and "retries" into a sub-dict "network"
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    upgraded["network"] = network
    
    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key not in ["dir", "pwd_file", "max_conn", "timeout_ms", "region", "retries"]:
            # Only keep keys with non-None values
            if value is not None:
                upgraded[key] = value
    
    return upgraded
