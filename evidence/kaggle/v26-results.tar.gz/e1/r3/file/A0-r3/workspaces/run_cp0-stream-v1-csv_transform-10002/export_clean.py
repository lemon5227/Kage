import csv
import io

def normalize_table(text):
    """Clean an exported table from CSV text."""
    # Parse the CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "name" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if row[0] == '':
            continue
        filtered_rows.append(row)
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in filtered_rows:
        score = row[3]  # id is index 3, score is index 4
        if score not in seen_scores:
            seen_scores.add(score)
            deduped_rows.append(row)
    
    # Sort rows by "id" ascending as strings (stable)
    deduped_rows.sort(key=lambda row: row[3])
    
    # Build output CSV text
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()

# Test the function
if __name__ == "__main__":
    # Example test
    test_input = "name,team,city,id,score\nAlice,TeamA,City1,100,95\nBob,TeamB,City2,101,95\nCharlie,TeamC,City3,102,96"
    result = normalize_table(test_input)
    print(result)
