def aggregate_log(lines):
    service_counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed line
        timestamp = parts[0]
        level = parts[1].upper()  # case-insensitive, normalize to uppercase
        service = parts[2]
        if level in ('ERROR', 'WARN'):
            service_counts[service] = service_counts.get(service, 0) + 1
    return service_counts
