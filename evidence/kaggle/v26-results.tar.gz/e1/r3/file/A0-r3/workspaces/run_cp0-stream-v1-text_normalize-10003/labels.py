import unicodedata

def make_handle(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace sequences of non-alphanumeric chars with a single hyphen
    slug = []
    prev_char = None
    for char in lower_text:
        if char.isalnum():
            slug.append(char)
        else:
            if prev_char is not None:
                # This is a run of non-alphanumerics, add a single hyphen
                slug.append('-')
            prev_char = char
    
    # Join and strip leading/trailing hyphens
    result = '-'.join(slug)
    result = result.strip('-')
    
    return result
