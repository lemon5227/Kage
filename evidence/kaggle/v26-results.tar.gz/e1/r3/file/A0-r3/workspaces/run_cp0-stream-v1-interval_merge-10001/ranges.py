def merge_slots(intervals):
    # Validate all intervals first
    for interval in intervals:
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
    
    # If no intervals, return empty list
    if not intervals:
        return []
    
    # Sort by start value
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping/touching intervals
    merged = []
    current = sorted_intervals[0].copy()  # Make a copy to avoid modifying input
    
    for i in range(1, len(sorted_intervals)):
        next_interval = sorted_intervals[i]
        
        # Check if intervals overlap or touch
        if next_interval["from"] <= current["to"]:
            # Merge them
            current["to"] = max(current["to"], next_interval["to"])
        else:
            # No overlap, add current and start new
            merged.append(current)
            current = next_interval.copy()
    
    # Add the last interval
    merged.append(current)
    
    return merged
