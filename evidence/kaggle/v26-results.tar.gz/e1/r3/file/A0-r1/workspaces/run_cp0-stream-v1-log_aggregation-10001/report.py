def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per service for levels ERROR, WARN only, case-insensitive (upper-case keys).
    Drops malformed input lines."""
    result = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) < 3:
            # Malformed: need at least timestamp, level, and service
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        # The service is after the colon in the format: <LEVEL> <service>: <message>
        # So parts[2] should be the service name
        if len(parts) < 3:
            continue
        
        service = parts[2]
        
        # Check if level is ERROR or WARN (case-insensitive, already uppercased)
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Increment count for this service
        result[service] = result.get(service, 0) + 1
    
    return result
