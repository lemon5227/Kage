import csv
import io

def normalize_table(text):
    """Clean an exported table from CSV text."""
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines and check for header-only
    lines = text.strip().split('\n')
    if len(lines) == 1:
        return lines[0]
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    header = next(reader)
    
    # Validate header columns
    expected_columns = ['id', 'email', 'city', 'name']
    if header != expected_columns:
        # If header doesn't match, try to handle gracefully
        # We'll still process but may not be able to validate id column
        pass
    
    # Process rows
    rows = []
    seen_emails = set()
    
    for row in reader:
        # Strip whitespace from each cell
        row = [cell.strip() for cell in row]
        
        # Skip if id is empty
        if not row[0]:  # assuming first column is id
            continue
        
        # Lower-case the email column (second column)
        email = row[1].lower()
        
        # Skip duplicate emails (keep first occurrence)
        if email in seen_emails:
            continue
        seen_emails.add(email)
        
        rows.append(row)
    
    # Sort by email ascending as strings (stable sort)
    # We need to sort by the email column (index 1)
    rows.sort(key=lambda row: row[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in rows:
        writer.writerow(row)
    
    return output.getvalue()
