def digest_lines(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        
        # The second part should be the level
        level = parts[1].upper()
        
        # Check that the third part starts with ':' (indicating service:)
        if not parts[2].startswith(':'):
            continue
        
        counts[level] = counts.get(level, 0) + 1
    
    return counts
