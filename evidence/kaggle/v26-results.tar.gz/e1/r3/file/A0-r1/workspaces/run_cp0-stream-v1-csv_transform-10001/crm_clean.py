import csv
import io


def clean_rows(text):
    """
    Clean CSV text with header row (columns: team, name, city, id, score).
    Returns cleaned CSV text with the same header.
    
    Operations in order:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "name" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Handle header-only input
    if len(rows) == 1:
        return '\n'.join(header) + '\n'
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)
    
    # Step 2: Drop rows whose "score" cell is empty
    # Assuming columns are: team, name, city, id, score (index 4)
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) > 4 and row[4] != '':
            filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in filtered_rows:
        score = row[4] if len(row) > 4 else ''
        if score not in seen_scores:
            seen_scores.add(score)
            deduped_rows.append(row)
    
    # Step 4: Sort rows by "name" ascending as strings (stable)
    # Name is at index 1
    sorted_rows = sorted(deduped_rows, key=lambda row: row[1] if len(row) > 1 else '')
    
    # Build output CSV
    output = []
    output.append(','.join(header))
    for row in sorted_rows:
        output.append(','.join(row))
    
    return '\n'.join(output) + '\n'


if __name__ == '__main__':
    # Test examples
    test1 = "team,name,city,id,score\nA,B,C,D,10\nE,F,G,H,10"
    print("Test 1:", clean_rows(test1))
    
    test2 = "team,name,city,id,score\nA,B,C,D,10"
    print("Test 2:", clean_rows(test2))
    
    test3 = "team,name,city,id,score"
    print("Test 3:", clean_rows(test3))
    
    test4 = ""
    print("Test 4:", clean_rows(test4))
