def count_entries(lines):
    level_counts = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service: message
        if len(parts) < 3:
            continue
        
        # The second part is the level (index 1)
        level = parts[1].upper()
        
        # Skip if level is empty or not a valid string
        if not level:
            continue
        
        # Increment count for this level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    # Return only non-zero counts (already handled by dict)
    return level_counts
