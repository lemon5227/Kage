def allocate(items, capacity):
    """
    Select jobs under a capacity limit to maximize total gain.
    
    Args:
        items: List of dicts with keys 'id', 'cost', 'gain'
        capacity: Maximum total cost allowed
    
    Returns:
        Sorted list of ids whose total gain is maximized while total cost <= capacity
    
    Raises:
        ValueError: If capacity is negative or any cost is <= 0
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if 'id' not in item or not isinstance(item['id'], str):
            raise ValueError("Each item must have a string 'id'")
        if 'cost' not in item or not isinstance(item['cost'], int) or item['cost'] <= 0:
            raise ValueError("Each item must have a positive integer 'cost'")
        if 'gain' not in item or not isinstance(item['gain'], int) or item['gain'] < 0:
            raise ValueError("Each item must have a non-negative integer 'gain'")
    
    if not items:
        return []
    
    # Dynamic programming for 0/1 knapsack
    # dp[i][w] = maximum gain using first i items with total cost <= w
    n = len(items)
    
    # dp[w] = (max_gain, selected_items_set) for capacity w
    # We'll track which items were selected to reconstruct the solution
    
    # Use a dictionary to store the best gain for each cost
    # dp[w] = max gain achievable with exactly cost w
    dp = [0] * (capacity + 1)
    parent = [-1] * (capacity + 1)  # Track which item was added to reach this state
    
    for i in range(n):
        cost = items[i]['cost']
        gain = items[i]['gain']
        # Iterate backwards to avoid using the same item multiple times
        for w in range(capacity, cost - 1, -1):
            if dp[w - cost] + gain > dp[w]:
                dp[w] = dp[w - cost] + gain
                parent[w] = i
    
    # Find the maximum gain achievable within capacity
    max_gain = dp[capacity]
    
    # Reconstruct the selected items
    selected_items = []
    w = capacity
    for i in range(n - 1, -1, -1):
        if parent[w] == i:
            selected_items.append(items[i])
            w -= items[i]['cost']
    
    # Sort by id lexicographically
    selected_ids = sorted([item['id'] for item in selected_items])
    
    return selected_ids
