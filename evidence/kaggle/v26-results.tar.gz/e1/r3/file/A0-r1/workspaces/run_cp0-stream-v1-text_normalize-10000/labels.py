import unicodedata

def make_handle(text):
    """Turn a title into a handle according to specified rules."""
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace any sequence of non-alphanumeric characters with a single hyphen
    result = []
    prev_char = None
    for char in lowercased:
        if char.isalnum():  # alphanumeric means a-z0-9
            result.append(char)
        else:
            if prev_char is not None:  # Only add hyphen if we've already added something
                result.append('-')
            prev_char = char
    
    # Join and strip leading/trailing hyphens
    handle = ''.join(result).strip('-')
    
    # If result is longer than 23 characters, cut to 23 and then strip trailing "-"
    if len(handle) > 23:
        handle = handle[:23].strip('-')
    
    return handle
