import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "team" cell is empty
    try:
        team_idx = header.index("team")
    except ValueError:
        team_idx = None

    if team_idx is not None:
        cleaned = [r for r in cleaned if team_idx < len(r) and r[team_idx] != ""]

    # lower-case the "email" column
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    if email_idx is not None:
        for r in cleaned:
            if email_idx < len(r):
                r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "city", keeping the first occurrence
    try:
        city_idx = header.index("city")
    except ValueError:
        city_idx = None

    if city_idx is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            key = r[city_idx] if city_idx < len(r) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(r)
        cleaned = deduped

    # sort rows by "email" ascending as strings (stable)
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    if email_idx is not None:
        cleaned.sort(key=lambda r: r[email_idx] if email_idx < len(r) else "", stable=True)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        with open(sys.argv[1], "r", encoding="utf-8") as f:
            text = f.read()
        result = tidy_csv(text)
        with open("output.csv", "w", encoding="utf-8") as f:
            f.write(result)
    else:
        print("Usage: python crm_clean.py input.csv")
