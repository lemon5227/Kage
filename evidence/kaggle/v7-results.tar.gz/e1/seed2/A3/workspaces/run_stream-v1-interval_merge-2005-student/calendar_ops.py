def merge_bookings(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns a new list of dicts with the same "start"/"end" keys, sorted by
    start ascending. Touching intervals (e.g. [1, 3] and [3, 5]) are NOT merged.
    Only real overlaps merge.

    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                f"invalid interval: start {start} is greater than end {end}"
            )
        normalized.append((start, end))

    # Sort by start time
    normalized.sort(key=lambda pair: pair[0])

    # Merge overlapping intervals
    merged = []
    for start, end in normalized:
        if merged and start < merged[-1][1]:
            # Overlapping: extend the last interval's end
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    # Convert back to dict format
    return [{"start": start, "end": end} for start, end in merged]
