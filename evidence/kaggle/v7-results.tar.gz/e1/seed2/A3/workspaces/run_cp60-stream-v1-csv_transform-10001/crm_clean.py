import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    data = [[cell.strip() for cell in row] for row in data]

    # find index of "score" column
    try:
        score_idx = header.index("score")
    except ValueError:
        return ""

    # drop rows whose "score" cell is empty
    data = [row for row in data if score_idx < len(row) and row[score_idx] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    seen = set()
    deduped = []
    for row in data:
        key = row[score_idx] if score_idx < len(row) else None
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    data = deduped

    # sort rows by "name" ascending as strings (stable)
    try:
        name_idx = header.index("name")
    except ValueError:
        return ""

    data.sort(key=lambda row: row[name_idx] if name_idx < len(row) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(data)
    return out.getvalue()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        print(clean_rows(sys.argv[1]))
