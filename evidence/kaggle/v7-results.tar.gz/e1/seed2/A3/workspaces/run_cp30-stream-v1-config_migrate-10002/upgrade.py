def upgrade_config(cfg):
    # Raise ValueError if version is not 1
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1 for upgrade")
    
    # Create a new dict for the upgraded configuration
    new_cfg = {"version": 2}
    
    # Process top-level keys
    if "dir" in cfg and cfg["dir"] is not None:
        new_cfg["directory"] = cfg["dir"]
    
    if "pwd_file" in cfg and cfg["pwd_file"] is not None:
        new_cfg["password_file"] = cfg["pwd_file"]
    
    if "max_conn" in cfg and cfg["max_conn"] is not None:
        new_cfg["max_connections"] = cfg["max_conn"]
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg and cfg["timeout_ms"] is not None:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Move region and retries into network sub-dict
    network = {}
    if "region" in cfg and cfg["region"] is not None:
        network["region"] = cfg["region"]
    if "retries" in cfg and cfg["retries"] is not None:
        network["retries"] = cfg["retries"]
    
    # Always include network sub-dict (possibly empty)
    new_cfg["network"] = network
    
    # Keep other keys unchanged
    for key, value in cfg.items():
        if key not in ["dir", "pwd_file", "max_conn", "timeout_ms", "region", "retries"]:
            if value is not None:
                new_cfg[key] = value
    
    return new_cfg
