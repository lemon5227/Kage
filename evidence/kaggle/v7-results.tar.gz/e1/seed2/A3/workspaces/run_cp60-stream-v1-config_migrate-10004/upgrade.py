def migrate(cfg):
    """Migrate a v1 config dict to v2.
    
    Returns a new dict with version 2, without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    
    Transformations:
    - Rename "pwd_file" -> "password_file"
    - Rename "user" -> "username"
    - Move "cache_size" and "workers" into a sub-dict "network"
    - If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (float)
    - Keep other keys unchanged
    - Drop keys whose value is None
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1, got %r" % cfg.get("version"))
    
    # Make a copy to avoid modifying input
    result = dict(cfg)
    result["version"] = 2
    
    # Rename keys
    if "pwd_file" in result:
        result["password_file"] = result.pop("pwd_file")
    if "user" in result:
        result["username"] = result.pop("user")
    
    # Handle timeout_ms conversion
    if "timeout_ms" in result:
        result["timeout_s"] = result["timeout_ms"] / 1000.0
        # Remove the original key
        del result["timeout_ms"]
    
    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in result:
        network["cache_size"] = result.pop("cache_size")
    if "workers" in result:
        network["workers"] = result.pop("workers")
    
    # Ensure network is always present (possibly empty)
    result["network"] = network
    
    # Drop keys with None values
    for key, value in list(result.items()):
        if value is None:
            del result[key]
    
    return result
