def pick_jobs(items, capacity):
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("Weight must be positive")
    
    n = len(items)
    # dp[i][w] = max value using first i items with total weight <= w
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        weight = items[i-1]["weight"]
        value = items[i-1]["value"]
        for w in range(capacity + 1):
            # Option 1: don't include item i-1
            dp[i][w] = dp[i-1][w]
            # Option 2: include item i-1 if weight <= w
            if weight <= w:
                dp[i][w] = max(dp[i][w], dp[i-1][w-weight] + value)
    
    # Find the maximum value achievable
    max_value = 0
    best_weight = 0
    for w in range(capacity + 1):
        if dp[n][w] > max_value:
            max_value = dp[n][w]
            best_weight = w
    
    # Reconstruct the solution
    selected = []
    w = best_weight
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i-1][w]:
            # Item i-1 was included
            selected.append(items[i-1]["id"])
            w -= items[i-1]["weight"]
    
    selected.reverse()
    return selected
