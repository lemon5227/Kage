def merge_slots(intervals):
    """Merge overlapping time ranges.

    Each interval is a two-element list [start, end] of integers.
    Returns a new list of intervals in the same [start, end] form, sorted by start ascending.
    Touching intervals (e.g. [1,3] and [3,5]) are merged.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and normalize
    normalized = []
    for interval in intervals:
        start, end = interval
        if start > end:
            raise ValueError(
                f"invalid interval: start {start} is greater than end {end}"
            )
        normalized.append((start, end))

    # Sort by start
    normalized.sort(key=lambda pair: pair[0])

    # Merge overlapping intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching: extend the current interval if needed
            if end > merged[-1][1]:
                merged[-1] = [merged[-1][0], end]
        else:
            merged.append([start, end])

    return merged
