def summarize(lines):
    """Summarize log entries per level.

    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"

    - Level names are matched case-insensitively (upper-case keys).
    - Only ERROR and WARN levels are counted.
    - Malformed lines are dropped.
    - Returns a dict mapping level name -> count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service: (with optional message)
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service_token = parts[2]
        if not service_token.endswith(":"):
            continue
        service = service_token[:-1]
        if not service:
            continue
        # Count per level, not per service
        counts[level] = counts.get(level, 0) + 1
    return counts
