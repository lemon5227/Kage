def count_entries(lines):
    """Count log entries per service for ERROR and WARN levels.

    Each line is formatted as "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping service name to count, only for ERROR and WARN levels.
    Level names are case-insensitive; keys are upper-case.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        if level.upper() not in ("ERROR", "WARN"):
            continue
        service = parts[2]
        if not service.endswith(":"):
            continue
        key = service
        counts[key] = counts.get(key, 0) + 1
    return counts
