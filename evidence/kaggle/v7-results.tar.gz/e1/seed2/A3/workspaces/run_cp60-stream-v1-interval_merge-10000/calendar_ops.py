def coalesce(intervals):
    """Combine overlapping or touching [start, end] intervals.

    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals in the same [start, end] list form, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] are merged.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(
                f"invalid interval: start {start} is greater than end {end}"
            )
        normalized.append([start, end])

    # Sort by start, then by end
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    return merged
