def select_tasks(items, capacity):
    """Select tasks under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "cost" and a non-negative integer "gain".  Return the sorted list of
    ids whose total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by returning the lexicographically smallest sorted id list.
    An empty selection is allowed.

    Raise ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the data so the input is never modified.
    tasks = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        tasks.append((item["id"], cost, gain))

    # 0/1 knapsack with lexicographic tie-breaking.
    #
    # dp[c] = best (gain, sorted_id_list) achievable with capacity c.
    # We process items one at a time and, for equal gain, keep the
    # lexicographically smallest sorted id list.
    dp = [(0, []) for _ in range(capacity + 1)]

    for tid, cost, gain in tasks:
        # Iterate downwards so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            cand_gain = prev_gain + gain
            cand_ids = sorted(prev_ids + [tid])
            cur_gain, cur_ids = dp[c]
            if cand_gain > cur_gain or (
                cand_gain == cur_gain and cand_ids < cur_ids
            ):
                dp[c] = (cand_gain, cand_ids)

    return dp[capacity][1]
