def allocate(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Return the sorted list of
    ids whose total value is as large as possible while total weight
    stays <= capacity.  Ties on total value are broken by returning the
    lexicographically smallest sorted id list.  An empty selection is allowed.

    Raise ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the data so the input is never modified.
    jobs = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        jobs.append((item["id"], weight, value))

    # 0/1 knapsack with lexicographic tie-breaking.
    #
    # dp[w] = best (value, sorted_id_list) achievable with capacity w.
    # We process items one at a time and, for equal value, keep the
    # lexicographically smallest sorted id list.
    dp = [(0, []) for _ in range(capacity + 1)]

    for jid, weight, value in jobs:
        # Iterate downwards so each item is used at most once.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = sorted(prev_ids + [jid])
            cur_value, cur_ids = dp[w]
            if cand_value > cur_value or (
                cand_value == cur_value and cand_ids < cur_ids
            ):
                dp[w] = (cand_value, cand_ids)

    return dp[capacity][1]
