def migrate(cfg):
    """Migrate a v1 config dict to v2.

    Args:
        cfg (dict): A v1 configuration dictionary.

    Returns:
        dict: A v2 configuration dictionary.

    Raises:
        ValueError: If cfg.get("version") != 1.
    """
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 config")

    # Create a new dict without modifying the input
    result = {"version": 2}

    # Rename top-level keys
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    if "user" in cfg:
        result["username"] = cfg["user"]

    # Handle timeout_ms if present
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Move cache_size and workers into a sub-dict "network"
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    result["network"] = network

    # Keep other keys unchanged, but drop keys whose value is None
    for key, value in cfg.items():
        if key not in ["pwd_file", "user", "cache_size", "workers", "timeout_ms"]:
            if value is not None:
                result[key] = value

    return result
