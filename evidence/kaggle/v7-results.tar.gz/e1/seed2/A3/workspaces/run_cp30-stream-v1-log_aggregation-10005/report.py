def summarize(lines):
    """Count log lines per service for WARN level only.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive and reported upper-case. Malformed lines
    are skipped, and levels with a zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        if level.upper() != "WARN":
            continue
        # The third token must be "<service>:" (service followed by a colon).
        if not parts[2].endswith(":"):
            continue
        service = parts[2].rstrip(":")
        counts[service] = counts.get(service, 0) + 1
    return counts
