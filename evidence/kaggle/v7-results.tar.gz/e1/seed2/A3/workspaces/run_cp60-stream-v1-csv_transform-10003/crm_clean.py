import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    body = rows[1:]

    cleaned = []
    for row in body:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "name" cell is empty
    cleaned = [r for r in cleaned if len(r) > 0 and r[0] != ""]

    # remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        name = r[0]
        if name in seen:
            continue
        seen.add(name)
        deduped.append(r)

    # sort rows by "city" ascending as strings (stable)
    deduped.sort(key=lambda r: r[1] if len(r) > 1 else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
