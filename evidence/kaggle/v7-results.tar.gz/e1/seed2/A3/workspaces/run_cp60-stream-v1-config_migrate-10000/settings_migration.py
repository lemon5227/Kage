def upgrade_config(cfg):
    """Upgrade old configuration dicts to the v2 layout.

    Args:
        cfg: dict with version 1. Keys may include "max_conn", "dir", "host",
             "cache_size", "region", "timeout_ms".

    Returns:
        A new dict with version 2, keys renamed and "limits" sub-dict added.

    Raises:
        ValueError: if cfg.get("version") != 1.
    """
    if cfg.get("version") != 1:
        raise ValueError("cfg must have version 1")

    # Make a copy to avoid modifying the input.
    result = {"version": 2}

    # Rename top-level keys.
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]

    # Move cache_size and region into limits.
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    result["limits"] = limits

    # Handle timeout_ms -> timeout_s.
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Drop keys whose value is None.
    # (Already handled by not including them in the result.)

    return result
