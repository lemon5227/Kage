def merge_bookings(intervals):
    """Merge overlapping time ranges.

    Each interval is a dict {"from": s, "to": e} with integer values.
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate and collect intervals
    valid_intervals = []
    for interval in intervals:
        from_time = interval["from"]
        to_time = interval["to"]
        if from_time > to_time:
            raise ValueError(f"Interval {interval} has start > end")
        valid_intervals.append((from_time, to_time, interval))

    if not valid_intervals:
        return []

    # Sort by start time
    valid_intervals.sort(key=lambda x: x[0])

    # Merge overlapping intervals
    merged = []
    for start, end, original in valid_intervals:
        if not merged:
            merged.append((start, end, original))
        else:
            last_start, last_end, last_original = merged[-1]
            if start <= last_end:  # Real overlap (touching is not an overlap)
                # Merge by extending the end time
                new_end = max(last_end, end)
                merged[-1] = (last_start, new_end, original)
            else:
                merged.append((start, end, original))

    # Convert back to dict format and sort by start ascending
    result = []
    for start, end, original in merged:
        result.append({"from": start, "to": end})

    return result
