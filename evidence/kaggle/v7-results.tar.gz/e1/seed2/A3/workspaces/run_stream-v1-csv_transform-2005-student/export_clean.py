import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "email" cell is empty
    email_idx = header.index("email") if "email" in header else None
    if email_idx is not None:
        cleaned = [r for r in cleaned if email_idx < len(r) and r[email_idx] != ""]

    # lower-case the "email" column
    if email_idx is not None:
        for r in cleaned:
            if email_idx < len(r):
                r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "email", keeping the first occurrence
    if email_idx is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            key = r[email_idx] if email_idx < len(r) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(r)
        cleaned = deduped

    # sort rows by "score" ascending as strings (stable)
    score_idx = header.index("score") if "score" in header else None
    if score_idx is not None:
        cleaned.sort(key=lambda r: r[score_idx] if score_idx < len(r) else "", stable=True)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        with open(sys.argv[1], "r", encoding="utf-8") as f:
            text = f.read()
        result = normalize_table(text)
        with open("output.csv", "w", encoding="utf-8") as f:
            f.write(result)
    else:
        print("Usage: python export_clean.py input.csv")
