import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Ensure we have the expected columns
    expected_cols = ["score", "id", "name"]
    if set(header) != set(expected_cols):
        return ""

    cleaned = []
    for row in data:
        # strip leading/trailing whitespace from every cell
        row = [cell.strip() for cell in row]
        # pad short rows so indexing is safe
        while len(row) < len(header):
            row.append("")
        cleaned.append(row)

    # drop rows whose "score" cell is empty
    cleaned = [row for row in cleaned if row[0] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        key = row[0]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    cleaned = deduped

    # sort rows by "name" ascending as strings (stable)
    try:
        name_idx = header.index("name")
    except ValueError:
        return ""

    cleaned.sort(key=lambda row: row[name_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
