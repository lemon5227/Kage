import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    body = rows[1:]

    cleaned = []
    for row in body:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "id" cell is empty
    cleaned = [r for r in cleaned if len(r) > 0 and r[1] != ""]

    # lower-case the "email" column
    for r in cleaned:
        if len(r) > 0:
            r[0] = r[0].lower()

    # remove duplicate rows by "score", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        score = r[2] if len(r) > 2 else ""
        if score in seen:
            continue
        seen.add(score)
        deduped.append(r)

    # sort rows by "name" ascending as strings (stable)
    deduped.sort(key=lambda r: r[3] if len(r) > 3 else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
