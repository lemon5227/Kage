import csv
import io


def clean_rows(text):
    """Clean an exported CSV table.
    
    Input: CSV text with header row (columns: city, score, email, name, team)
    Output: Cleaned CSV text with the same header
    
    Cleaning rules:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "city", keeping the first occurrence
    5. Sort rows by "name" ascending as strings (stable)
    
    Returns:
        - Empty string returns ''
        - Header-only input returns just the header line
    """
    # Parse CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Check if header-only input
    if len(rows) == 1:
        return '\n'.join(header)
    
    # Process data rows (starting from index 1)
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)
    
    # Step 2: Drop rows whose "score" cell is empty
    # Assuming columns: city, score, email, name, team (indices: 0, 1, 2, 3, 4)
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) < 5:
            continue
        score = row[1]
        if not score:
            continue
        filtered_rows.append(row)
    
    # Step 3: Lower-case the "email" column (index 2)
    lowercased_rows = []
    for row in filtered_rows:
        if len(row) < 5:
            continue
        new_row = list(row)
        new_row[2] = new_row[2].lower()
        lowercased_rows.append(new_row)
    
    # Step 4: Remove duplicate rows by "city", keeping the first occurrence
    seen_cities = set()
    unique_rows = []
    for row in lowercased_rows:
        if len(row) < 5:
            continue
        city = row[0]
        if city not in seen_cities:
            seen_cities.add(city)
            unique_rows.append(row)
    
    # Step 5: Sort rows by "name" ascending as strings (stable)
    # Name is at index 3
    sorted_rows = sorted(unique_rows, key=lambda row: row[3])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in sorted_rows:
        writer.writerow(row)
    
    return output.getvalue()


if __name__ == "__main__":
    # Test example
    test_input = """city,score,email,name,team
NY,100,test@example.com,Alice,Team1
LA,200,bob@example.com,Bob,Team2
NY,150,test@example.com,Charlie,Team3
"""
    result = clean_rows(test_input)
    print(result)
