import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "team" cell is empty
    try:
        team_idx = header.index("team")
    except ValueError:
        team_idx = None

    if team_idx is not None:
        cleaned = [r for r in cleaned if team_idx < len(r) and r[team_idx] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    try:
        score_idx = header.index("score")
    except ValueError:
        score_idx = None

    if score_idx is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            key = r[score_idx] if score_idx < len(r) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(r)
        cleaned = deduped

    # sort rows by "id" ascending as strings (stable)
    try:
        id_idx = header.index("id")
    except ValueError:
        id_idx = None

    if id_idx is not None:
        cleaned.sort(key=lambda r: r[id_idx] if id_idx < len(r) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
