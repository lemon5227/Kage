def convert_settings(cfg):
    """Convert old configuration dict to v2 layout.
    
    Raises ValueError if cfg.get("version") != 1.
    Returns a new dict with version: 2, renamed keys, and moved storage.
    """
    version = cfg.get("version")
    if version != 1:
        raise ValueError("cfg must have version == 1")
    
    # Make a copy to avoid modifying input
    result = {"version": 2}
    
    # Rename top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    
    # Move port and workers into storage sub-dict
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    result["storage"] = storage
    
    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["dir", "host", "port", "workers", "timeout_ms", "version"]:
            if value is not None:
                result[key] = value
    
    return result
