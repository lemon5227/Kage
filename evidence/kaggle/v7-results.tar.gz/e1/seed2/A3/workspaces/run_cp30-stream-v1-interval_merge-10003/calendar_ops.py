def merge_bookings(intervals):
    """Merge overlapping time ranges.

    Each interval is a dict {"from": s, "to": e} with integer values.
    Returns a new list of dicts with the same "from"/"to" keys, sorted by
    start ascending. Touching intervals (e.g. [1, 3] and [3, 5]) are NOT
    merged; only real overlaps merge. Raises ValueError if any interval has
    start > end. The input is not modified.
    """
    normalized = []
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r is greater than end %r" % (start, end)
            )
        normalized.append((start, end))

    normalized.sort(key=lambda pair: pair[0])

    merged = []
    for start, end in normalized:
        if merged and start < merged[-1][1]:
            # Real overlap: extend the current interval if needed.
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    return [{"from": start, "to": end} for start, end in merged]


def merge_slots(intervals):
    """Combine overlapping time ranges.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns a new list of dicts with the same "start"/"end" keys, sorted by
    start ascending. Touching intervals (e.g. [1, 3] and [3, 5]) are merged.
    Raises ValueError if any interval has start > end. The input is not modified.
    """
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r is greater than end %r" % (start, end)
            )
        normalized.append((start, end))

    normalized.sort(key=lambda pair: pair[0])

    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlap or touching: extend the current interval if needed.
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    return [{"start": start, "end": end} for start, end in merged]
