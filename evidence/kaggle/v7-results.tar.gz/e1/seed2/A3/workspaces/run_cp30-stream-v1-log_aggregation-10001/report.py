def tally_events(lines):
    """Tally events per service for ERROR and WARN levels.

    Each line is formatted as "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping service name to count, only for levels ERROR or WARN (case-insensitive).
    Malformed lines are skipped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        # Check if level is ERROR or WARN (case-insensitive)
        if level.upper() not in ("ERROR", "WARN"):
            continue
        service = parts[2]
        # The third token must be "<service>:" (service followed by a colon).
        if not service.endswith(":"):
            continue
        key = service
        counts[key] = counts.get(key, 0) + 1
    return counts
