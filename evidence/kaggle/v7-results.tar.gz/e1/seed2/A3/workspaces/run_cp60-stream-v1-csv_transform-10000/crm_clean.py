import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    data = [[cell.strip() for cell in row] for row in data]

    # find column indices
    try:
        score_idx = header.index("score")
    except ValueError:
        score_idx = None
    try:
        id_idx = header.index("id")
    except ValueError:
        id_idx = None
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None
    try:
        name_idx = header.index("name")
    except ValueError:
        name_idx = None

    # drop rows whose "name" cell is empty
    if name_idx is not None:
        data = [row for row in data if name_idx < len(row) and row[name_idx] != ""]

    # lower-case the "email" column
    if email_idx is not None:
        for row in data:
            if email_idx < len(row):
                row[email_idx] = row[email_idx].lower()

    # remove duplicate rows by "name", keeping the first occurrence
    if name_idx is not None:
        seen = set()
        deduped = []
        for row in data:
            key = row[name_idx] if name_idx < len(row) else None
            if key in seen:
                continue
            seen.add(key)
            deduped.append(row)
        data = deduped

    # sort rows by "email" ascending as strings (stable)
    if email_idx is not None:
        data.sort(key=lambda row: row[email_idx] if email_idx < len(row) else "", stable=True)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(data)
    return out.getvalue()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        print(normalize_table(sys.argv[1]))