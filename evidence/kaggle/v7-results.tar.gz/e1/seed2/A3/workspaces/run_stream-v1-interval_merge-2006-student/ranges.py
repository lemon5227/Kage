def merge_bookings(intervals):
    """Merge overlapping time ranges.

    Each interval is a dict {"begin": s, "finish": e} with integer values.
    Returns a new list of dicts with the same "begin"/"finish" keys, sorted by
    start ascending. Touching intervals (e.g. [1, 3] and [3, 5]) are merged.
    Raises ValueError if any interval has start > end. The input is not modified.
    """
    # Normalize to tuples of (start, end)
    normalized = []
    for interval in intervals:
        start = interval["begin"]
        end = interval["finish"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r is greater than end %r" % (start, end)
            )
        normalized.append((start, end))

    # Sort by start time
    normalized.sort(key=lambda pair: pair[0])

    # Merge overlapping intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching: extend the current interval if needed
            if end > merged[-1][1]:
                merged[-1] = [start, end]
        else:
            merged.append([start, end])

    # Convert back to dicts with "begin"/"finish" keys
    return [{"begin": start, "finish": end} for start, end in merged]
