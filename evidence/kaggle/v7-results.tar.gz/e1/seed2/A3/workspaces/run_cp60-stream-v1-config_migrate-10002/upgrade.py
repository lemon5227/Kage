def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.
    
    Raise ValueError unless cfg.get("version") == 1.
    Return a new dict with "version": 2.
    Rename top-level keys:
      - "dir" -> "directory"
      - "pwd_file" -> "password_file"
      - "max_conn" -> "max_connections"
    Move "region" and "retries" into a sub-dict "network".
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float).
    Keep other keys unchanged and drop keys whose value is None.
    """
    # Check version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")
    
    # Make a copy to avoid modifying the input
    result = {"version": 2}
    
    # Process top-level keys
    for key, value in cfg.items():
        if key == "dir":
            result["directory"] = value
        elif key == "pwd_file":
            result["password_file"] = value
        elif key == "max_conn":
            result["max_connections"] = value
        elif key == "timeout_ms":
            if value is None:
                continue  # drop keys with None value
            result["timeout_s"] = float(value) / 1000.0
        elif key in ("region", "retries"):
            # Move into network sub-dict
            pass  # handled below
    
    # Create network sub-dict if there are region or retries
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    
    if network:
        result["network"] = network
    
    # Drop keys with None values (already handled above for timeout_ms)
    # But also check other keys that might have been None
    for key, value in result.items():
        if value is None:
            del result[key]
    
    return result
