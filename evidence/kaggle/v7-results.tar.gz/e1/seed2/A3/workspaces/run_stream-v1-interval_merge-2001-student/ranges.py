def merge_bookings(intervals):
    """Merge overlapping intervals.
    
    Args:
        intervals: List of [start, end] lists
        
    Returns:
        List of merged [start, end] lists sorted by start ascending
        
    Raises:
        ValueError: If any interval has start > end
    """
    # Validate all intervals
    for interval in intervals:
        if len(interval) != 2 or not isinstance(interval[0], int) or not isinstance(interval[1], int):
            raise ValueError("Each interval must be a two-element list of integers")
        if interval[0] > interval[1]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping or touching intervals
    merged = []
    if not sorted_intervals:
        return merged
    
    current_start, current_end = sorted_intervals[0]
    
    for next_interval in sorted_intervals[1:]:
        next_start, next_end = next_interval
        
        # If intervals overlap or touch (next_start <= current_end), merge them
        if next_start <= current_end:
            # Extend the current interval's end if needed
            current_end = max(current_end, next_end)
        else:
            # No overlap, add current interval and start a new one
            merged.append([current_start, current_end])
            current_start, current_end = next_start, next_end
    
    # Add the last interval
    merged.append([current_start, current_end])
    
    return merged
