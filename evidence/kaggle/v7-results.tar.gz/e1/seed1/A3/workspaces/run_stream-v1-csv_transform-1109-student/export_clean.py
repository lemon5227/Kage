import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "id" cell is empty
    try:
        id_idx = header.index("id")
    except ValueError:
        id_idx = None

    filtered = []
    for cells in cleaned:
        if id_idx is not None and id_idx < len(cells):
            if cells[id_idx] == "":
                continue
        filtered.append(cells)

    # lower-case the "email" column
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    for cells in filtered:
        if email_idx is not None and email_idx < len(cells):
            cells[email_idx] = cells[email_idx].lower()

    # remove duplicate rows by "email", keeping the first occurrence
    seen = set()
    deduped = []
    for cells in filtered:
        if email_idx is not None and email_idx < len(cells):
            email = cells[email_idx]
        else:
            email = ""
        if email in seen:
            continue
        seen.add(email)
        deduped.append(cells)

    # sort rows by "score" ascending as strings (stable)
    try:
        score_idx = header.index("score")
    except ValueError:
        score_idx = None

    deduped.sort(key=lambda cells: cells[score_idx] if score_idx is not None and score_idx < len(cells) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
