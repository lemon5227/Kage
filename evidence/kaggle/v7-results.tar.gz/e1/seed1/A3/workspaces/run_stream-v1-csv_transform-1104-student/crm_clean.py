import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "score" cell is empty
    try:
        score_idx = header.index("score")
    except ValueError:
        score_idx = None

    filtered = []
    for cells in cleaned:
        score = cells[score_idx] if score_idx is not None and score_idx < len(cells) else ""
        if score == "":
            continue
        filtered.append(cells)

    # remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for cells in filtered:
        team = cells[header.index("team")] if "team" in header and header.index("team") < len(cells) else ""
        if team in seen:
            continue
        seen.add(team)
        deduped.append(cells)

    # sort rows by "city" ascending as strings (stable)
    try:
        city_idx = header.index("city")
    except ValueError:
        city_idx = None

    deduped.sort(key=lambda cells: cells[city_idx] if city_idx is not None and city_idx < len(cells) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
