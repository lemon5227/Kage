import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "city" cell is empty
    filtered = []
    for cells in cleaned:
        if len(cells) < 1:
            continue
        city = cells[0]
        if city == "":
            continue
        filtered.append(cells)

    # remove duplicate rows by "city", keeping the first occurrence
    seen = set()
    deduped = []
    for cells in filtered:
        city = cells[0]
        if city in seen:
            continue
        seen.add(city)
        deduped.append(cells)

    # sort rows by "score" ascending as strings (stable)
    # score is at index 2 (city, team, score, name, id)
    def get_score(cells):
        if len(cells) < 3:
            return ""
        return cells[2]

    deduped.sort(key=get_score)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
