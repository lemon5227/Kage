def upgrade_config(cfg):
    """Upgrade old configuration dict to v2 layout.
    
    Returns a new dict with version 2. Does not modify the input.
    Raises ValueError if cfg.get("version") != 1.
    """
    # Check version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(f"Expected version 1, got {version}")
    
    # Make a copy to avoid modifying input
    result = {}
    result["version"] = 2
    
    # Process top-level keys
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Move cache_size and region into limits sub-dict
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    result["limits"] = limits
    
    # Keep other keys unchanged, but drop keys with None values
    for key, value in cfg.items():
        if key not in ["max_conn", "dir", "host", "timeout_ms", "cache_size", "region"]:
            if value is not None:
                result[key] = value
    
    return result
