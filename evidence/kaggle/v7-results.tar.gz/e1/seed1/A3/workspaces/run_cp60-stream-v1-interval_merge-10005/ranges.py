def merge_slots(intervals):
    """Merge overlapping time ranges.

    Each interval is a two-element list [start, end] of integers.
    Return merged intervals in the same [start, end] list form, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] are NOT merged; only real overlaps merge.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(
                f"invalid interval: start {start} is greater than end {end}"
            )
        normalized.append([start, end])

    # Sort by start (and then by end for consistency)
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    # Merge overlapping intervals
    merged = []
    for start, end in normalized:
        if merged and start < merged[-1][1]:
            # Real overlap: merge by taking the maximum end
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            # No overlap (including touching), add new interval
            merged.append([start, end])

    return merged
