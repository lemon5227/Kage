def upgrade_config(cfg):
    """Convert old configuration dict to v2 layout.
    
    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    """
    # Check version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(f"Expected version 1, got {version}")
    
    # Create new dict
    new_cfg = {"version": 2}
    
    # Process top-level keys
    if "dir" in cfg:
        new_cfg["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        new_cfg["max_connections"] = cfg["max_conn"]
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Build network sub-dict
    network_keys = ["region", "retries"]
    network_data = {}
    for key in network_keys:
        if key in cfg:
            network_data[key] = cfg[key]
    
    new_cfg["network"] = network_data
    
    # Drop keys with None values
    for key in list(new_cfg.keys()):
        if new_cfg[key] is None:
            del new_cfg[key]
    
    return new_cfg
