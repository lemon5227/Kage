import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "team" cell is empty
    try:
        team_idx = header.index("team")
    except ValueError:
        team_idx = None

    filtered = []
    for cells in cleaned:
        team = cells[team_idx] if team_idx is not None and team_idx < len(cells) else ""
        if team == "":
            continue
        filtered.append(cells)

    # remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for cells in filtered:
        team = cells[team_idx] if team_idx is not None and team_idx < len(cells) else ""
        if team in seen:
            continue
        seen.add(team)
        deduped.append(cells)

    # lower-case the "email" column
    if team_idx is not None and team_idx < len(deduped[0]):
        email_idx = header.index("email")
        for cells in deduped:
            if email_idx < len(cells):
                cells[email_idx] = cells[email_idx].lower()

    # sort rows by "email" ascending as strings (stable)
    if team_idx is not None and team_idx < len(deduped[0]):
        email_idx = header.index("email")
        deduped.sort(key=lambda cells: cells[email_idx] if email_idx < len(cells) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
