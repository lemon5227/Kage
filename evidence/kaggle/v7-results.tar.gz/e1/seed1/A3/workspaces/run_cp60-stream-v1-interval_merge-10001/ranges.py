def merge_slots(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"from": s, "to": e} with integer values.
    Overlapping intervals are merged; touching intervals (e.g. [1,3] and
    [3,5]) are also merged. Returns a new list of dicts with the same
    "from"/"to" keys, sorted by start ascending. The input is not modified.

    Raises ValueError if any interval has start > end.
    """
    items = []
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        items.append((start, end))

    items.sort(key=lambda pair: (pair[0], pair[1]))

    merged = []
    for start, end in items:
        if merged and start <= merged[-1][1]:
            # Overlap or touching: extend the current interval if needed.
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    return [{"from": s, "to": e} for s, e in merged]
