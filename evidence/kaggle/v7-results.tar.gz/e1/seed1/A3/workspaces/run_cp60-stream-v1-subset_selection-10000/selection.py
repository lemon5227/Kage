def select_tasks(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "cost" and a non-negative integer "gain".  Returns the sorted list
    of ids whose total gain is as large as possible while total cost
    stays <= capacity.  Ties on total gain are broken by choosing
    the lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is never modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the data so the input is never mutated.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # Sort by id so that, among equal-gain solutions, we can prefer the
    # lexicographically smallest sorted id list.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    # dp[w] = best (gain, id_list) achievable with total cost <= w.
    # We process items one at a time (0/1 knapsack) and keep, for each
    # capacity, the best gain and the lexicographically smallest id list
    # achieving it.
    dp = [(0, []) for _ in range(capacity + 1)]

    for idx in range(n):
        item_id, cost, gain = entries[idx]
        # Iterate capacities downward to avoid reusing the same item.
        for w in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[w - cost]
            cand_gain = prev_gain + gain
            cand_ids = prev_ids + [item_id]
            best_gain, best_ids = dp[w]
            if cand_gain > best_gain:
                dp[w] = (cand_gain, cand_ids)
            elif cand_gain == best_gain:
                # Prefer the lexicographically smaller sorted id list.
                if sorted(cand_ids) < sorted(best_ids):
                    dp[w] = (cand_gain, cand_ids)

    return sorted(dp[capacity][1])
