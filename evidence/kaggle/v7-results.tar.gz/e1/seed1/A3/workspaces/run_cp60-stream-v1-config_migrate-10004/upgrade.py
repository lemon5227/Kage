def migrate(cfg):
    """Migrate a v1 config dict to v2.
    
    Returns a new dict with version 2.
    Raises ValueError if cfg.get("version") != 1.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1, got %r" % cfg.get("version"))
    
    # Create new config dict
    new_cfg = {"version": 2}
    
    # Rename top-level keys
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    if "user" in cfg:
        new_cfg["username"] = cfg["user"]
    
    # Handle cache_size and workers
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    new_cfg["network"] = network
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged
    for key, value in cfg.items():
        if key not in ["version", "pwd_file", "user", "cache_size", "workers", "timeout_ms"]:
            # Drop keys whose value is None
            if value is not None:
                new_cfg[key] = value
    
    return new_cfg
