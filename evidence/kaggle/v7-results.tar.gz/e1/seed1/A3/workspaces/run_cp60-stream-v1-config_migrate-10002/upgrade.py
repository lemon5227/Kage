def upgrade_config(cfg):
    """Convert old configuration dict to v2 layout.
    
    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    """
    # Check version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(f"Expected version 1, got {version}")
    
    # Make a copy to avoid modifying input
    result = {}
    result["version"] = 2
    
    # Rename top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    
    # Handle other keys
    for key, value in cfg.items():
        if key not in ("dir", "pwd_file", "max_conn", "version"):
            # Keep the key but rename if needed
            if key == "timeout_ms":
                result["timeout_s"] = value / 1000.0
            else:
                result[key] = value
    
    # Drop keys with None values
    for key in list(result.keys()):
        if result[key] is None:
            del result[key]
    
    # Build network sub-dict
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    result["network"] = network
    
    return result
