def convert_settings(cfg):
    """Convert old configuration dict to v2 layout.
    
    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    Output has "version": 2.
    Renames top-level keys:
      - "host" -> "hostname"
      - "max_conn" -> "max_connections"
      - "pwd_file" -> "password_file"
    Moves "port" and "retries" into a sub-dict "storage".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Check version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(f"Expected version 1, got {version}")
    
    # Make a copy to avoid modifying input
    result = {"version": 2}
    
    # Process top-level keys
    host = cfg.get("host")
    max_conn = cfg.get("max_conn")
    pwd_file = cfg.get("pwd_file")
    port = cfg.get("port")
    retries = cfg.get("retries")
    timeout_ms = cfg.get("timeout_ms")
    
    # Build storage sub-dict
    storage = {}
    if port is not None:
        storage["port"] = port
    if retries is not None:
        storage["retries"] = retries
    
    # Handle timeout_ms conversion
    if timeout_ms is not None:
        result["timeout_s"] = float(timeout_ms) / 1000.0
    
    # Build the main result dict
    result["hostname"] = host
    result["max_connections"] = max_conn
    result["password_file"] = pwd_file
    result["storage"] = storage
    
    # Add other keys from cfg (excluding version, host, max_conn, pwd_file, port, retries, timeout_ms)
    for key, value in cfg.items():
        if key not in ["version", "host", "max_conn", "pwd_file", "port", "retries", "timeout_ms"]:
            # Only include keys with non-None values
            if value is not None:
                result[key] = value
    
    return result
