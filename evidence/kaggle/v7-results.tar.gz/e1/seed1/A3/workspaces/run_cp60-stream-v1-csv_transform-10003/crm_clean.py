import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Ensure we have the expected columns
    expected_cols = ["name", "city", "score", "team"]
    if len(header) != len(expected_cols):
        # If header doesn't match, try to find the columns anyway
        # But we'll proceed with what we have
        pass

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        # Pad or truncate to header length
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[:len(header)]
        cleaned.append(cells)

    # Drop rows whose "name" cell is empty
    name_idx = header.index("name") if "name" in header else 0
    cleaned = [r for r in cleaned if r[name_idx] != ""]

    # Remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[name_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    # Sort rows by "city" ascending as strings (stable)
    city_idx = header.index("city") if "city" in header else 1
    deduped.sort(key=lambda r: r[city_idx])

    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
