import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Check if we have the required columns
    required_cols = ["id", "team", "score"]
    if set(header) != set(required_cols):
        # If header doesn't match, try to find the columns anyway
        # Use the first occurrence of each required column
        id_idx = header.index("id") if "id" in header else 0
        team_idx = header.index("team") if "team" in header else 1
        score_idx = header.index("score") if "score" in header else 2

    cleaned = []
    for row in data:
        # Strip leading/trailing whitespace from every cell
        cells = [cell.strip() for cell in row]
        # Pad or truncate to match header length
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[:len(header)]
        # Check if score cell is empty
        try:
            score_idx = header.index("score")
        except ValueError:
            score_idx = 2
        if cells[score_idx] == "":
            continue
        cleaned.append(cells)

    # Remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        team_idx = header.index("team") if "team" in header else 1
        key = row[team_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    # Sort rows by "score" ascending as strings (stable)
    try:
        score_idx = header.index("score")
    except ValueError:
        score_idx = 2
    deduped.sort(key=lambda r: r[score_idx], stable=True)

    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
