import unicodedata


def make_handle(text):
    """Turn a title into a handle.
    
    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces runs of non-alphanumeric characters with a single "-",
    strips leading/trailing "-", and truncates to 23 characters if needed.
    
    Args:
        text: A string title
        
    Returns:
        A handle string
        
    Raises:
        TypeError: If input is not a string
    """
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Convert to lowercase
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we keep only a-z0-9 and replace other sequences with "-"
    result = []
    prev_char = None
    for char in lowercased:
        if char.isalnum() and char in 'abcdefghijklmnopqrstuvwxyz0123456789':
            result.append(char)
        else:
            # If we encounter a non-alphanumeric character, add a "-" only if the previous character was alphanumeric
            if prev_char is not None and prev_char in 'abcdefghijklmnopqrstuvwxyz0123456789':
                result.append('-')
        prev_char = char
    
    handle = ''.join(result)
    
    # Strip leading and trailing "-"
    handle = handle.strip('-')
    
    # If the result is longer than 23 characters, cut it to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.strip('-')
    
    return handle
