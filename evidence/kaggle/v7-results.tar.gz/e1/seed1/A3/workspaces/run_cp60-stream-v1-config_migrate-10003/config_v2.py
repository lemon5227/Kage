def convert_settings(cfg):
    """Convert old configuration dict to v2 layout.
    
    Raises ValueError if cfg.get("version") != 1.
    Returns a new dict with version: 2, and transformed keys.
    """
    # Check version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(f"Expected version 1, got {version}")
    
    # Make a copy to avoid modifying input
    result = {"version": 2}
    
    # Rename top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    
    # Handle port and workers - move into storage sub-dict
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    result["storage"] = storage
    
    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        try:
            timeout_ms = cfg["timeout_ms"]
            result["timeout_s"] = float(timeout_ms) / 1000.0
        except (TypeError, ValueError):
            raise ValueError(f"timeout_ms must be a number: {cfg['timeout_ms']}")
    
    # Keep other keys unchanged
    for key in cfg:
        if key not in ["version", "dir", "host", "port", "workers", "timeout_ms"]:
            # Drop keys whose value is None
            if cfg[key] is not None:
                result[key] = cfg[key]
    
    return result
