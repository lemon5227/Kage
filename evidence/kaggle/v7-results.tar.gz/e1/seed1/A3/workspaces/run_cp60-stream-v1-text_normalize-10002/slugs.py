import unicodedata

def slugify(text):
    """Build a URL slug from text.
    
    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces runs of non-alphanumeric characters with a single hyphen,
    and strips leading/trailing hyphens.
    
    Args:
        text: Input string to convert to slug
        
    Returns:
        str: URL-friendly slug
        
    Raises:
        TypeError: If input is not a string
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization to decompose characters
    text = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    text = ''.join(char for char in text if ord(char) < 128)
    
    # Lowercase
    text = text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single '-'
    # Manual approach: iterate through characters and build the slug
    result = []
    prev_char = None
    for char in text:
        if char.isalnum():  # alphanumeric (a-z0-9 after lowercasing)
            result.append(char)
        else:
            # If we encounter a non-alphanumeric, check if we need to add a separator
            if not result or prev_char != char:
                # Add a hyphen only if it's not already there (to avoid multiple consecutive hyphens)
                if not result or result[-1] != '-':
                    result.append('-')
        prev_char = char
    
    slug = ''.join(result)
    
    # Strip leading and trailing hyphens
    slug = slug.strip('-')
    
    return slug
