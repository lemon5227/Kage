def digest_lines(lines):
    """Count log lines per level.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    The level may be in any case and must be upper-cased.
    Lines that do not match the format are ignored.

    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service: (with message optional)
        if len(parts) < 3:
            continue
        level = parts[1]
        service = parts[2]
        # The service token must end with a colon (e.g. "auth:")
        if not service.endswith(":"):
            continue
        # Level must be a non-empty alphabetic token
        if not level.isalpha():
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
