def convert_settings(cfg):
    """Convert old configuration dict to v2 layout.
    
    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    """
    version = cfg.get("version")
    if version != 1:
        raise ValueError(f"Expected version 1, got {version}")
    
    # Create a new dict to avoid modifying input
    result = {"version": 2}
    
    # Rename top-level keys
    username = cfg.get("user")
    if username is not None:
        result["username"] = username
    
    directory = cfg.get("dir")
    if directory is not None:
        result["directory"] = directory
    
    # Move cache_size and retries into "limits" sub-dict
    limits = {}
    cache_size = cfg.get("cache_size")
    if cache_size is not None:
        limits["cache_size"] = cache_size
    retries = cfg.get("retries")
    if retries is not None:
        limits["retries"] = retries
    
    result["limits"] = limits
    
    # Handle timeout_ms -> timeout_s conversion
    timeout_ms = cfg.get("timeout_ms")
    if timeout_ms is not None:
        result["timeout_s"] = timeout_ms / 1000.0
    
    # Drop keys with value None (already handled by checking before adding)
    
    return result
