def coalesce(intervals):
    """Merge overlapping bookings. Each interval is a dict {"from": s, "to": e} with integer values.
    
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        from_val = interval["from"]
        to_val = interval["to"]
        if from_val > to_val:
            raise ValueError(f"invalid interval: start {from_val} > end {to_val}")
        normalized.append([from_val, to_val])

    # Sort by start, then by end
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    # Merge overlapping intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching? The requirement says touching should NOT be merged.
            # So we only merge if start < merged[-1][1] (strict overlap)
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    # Convert back to dict format
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})

    return result
