import csv
import io


def dedupe_export(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "score" cell is empty
    try:
        score_idx = header.index("score")
    except ValueError:
        score_idx = None

    filtered = []
    for cells in cleaned:
        score = cells[score_idx] if score_idx is not None and score_idx < len(cells) else ""
        if score == "":
            continue
        filtered.append(cells)

    # lower-case the "email" column
    email_idx = header.index("email") if "email" in header else None
    for cells in filtered:
        if email_idx is not None and email_idx < len(cells):
            cells[email_idx] = cells[email_idx].lower()

    # remove duplicate rows by "email", keeping the first occurrence
    seen = set()
    deduped = []
    for cells in filtered:
        email = cells[email_idx] if email_idx is not None and email_idx < len(cells) else ""
        if email in seen:
            continue
        seen.add(email)
        deduped.append(cells)

    # sort rows by "score" ascending as strings (stable)
    def get_score_key(cells):
        score = cells[score_idx] if score_idx is not None and score_idx < len(cells) else ""
        return score

    deduped.sort(key=get_score_key, stable=True)

    # write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
