def allocate(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    Do not modify the input.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and snapshot the input without mutating it.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # 0/1 knapsack with lexicographic tie-breaking on the sorted id list.
    # dp[w] = best (gain, sorted_id_tuple) achievable with cost <= w.
    dp = [(0, ()) for _ in range(capacity + 1)]

    for item_id, cost, gain in entries:
        for w in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[w - cost]
            cand_gain = prev_gain + gain
            cand_ids = tuple(sorted(prev_ids + (item_id,)))
            cur_gain, cur_ids = dp[w]
            if cand_gain > cur_gain or (cand_gain == cur_gain and cand_ids < cur_ids):
                dp[w] = (cand_gain, cand_ids)

    return list(dp[capacity][1])
