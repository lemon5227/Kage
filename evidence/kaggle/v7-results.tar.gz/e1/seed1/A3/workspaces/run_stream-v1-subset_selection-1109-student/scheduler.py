def plan_batch(items, capacity):
    """
    Picks which jobs to take from items. Each item is a dict with:
    - unique string "id"
    - positive integer "cost"
    - non-negative integer "gain"

    Returns the sorted list of ids whose total gain is as large as possible
    while total cost stays <= capacity. If several selections tie on total gain,
    return the lexicographically smallest sorted id list. An empty selection is allowed.
    Raises ValueError if capacity is negative or any cost is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        if "id" not in item or not isinstance(item["id"], str):
            raise ValueError("Each item must have a unique string 'id'")
        if "cost" not in item or not isinstance(item["cost"], int) or item["cost"] <= 0:
            raise ValueError("Each item must have a positive integer 'cost'")
        if "gain" not in item or not isinstance(item["gain"], int) or item["gain"] < 0:
            raise ValueError("Each item must have a non-negative integer 'gain'")
    
    # Handle empty items list
    if not items:
        return []
    
    n = len(items)
    # dp[i][j] = (max_gain, selected_ids) for first i items with capacity j
    # We'll use a dictionary to store the best gain and the corresponding id list
    # Since we need lexicographically smallest id list when gains tie, we need to be careful
    
    # Initialize: dp[j] = (max_gain, selected_ids) for capacity j
    dp = {}
    dp[0] = (0, [])
    
    for i in range(n):
        item = items[i]
        cost = item["cost"]
        gain = item["gain"]
        new_dp = dp.copy()
        
        # For each capacity j from 0 to capacity
        for j in range(capacity + 1):
            if j >= cost:
                # Try including this item
                prev_gain, prev_ids = dp[j - cost]
                new_gain = prev_gain + gain
                new_ids = prev_ids + [item["id"]]
                
                # Check if this is better than current dp[j]
                if j in new_dp:
                    curr_gain, curr_ids = new_dp[j]
                    if new_gain > curr_gain:
                        new_dp[j] = (new_gain, new_ids)
                    elif new_gain == curr_gain:
                        # Choose lexicographically smaller id list
                        if new_ids < curr_ids:
                            new_dp[j] = (new_gain, new_ids)
                else:
                    new_dp[j] = (new_gain, new_ids)
        
        dp = new_dp
    
    # Find the maximum gain among all capacities <= capacity
    max_gain = 0
    best_ids = []
    
    for j in range(capacity + 1):
        if j in dp:
            gain, ids = dp[j]
            if gain > max_gain:
                max_gain = gain
                best_ids = ids
            elif gain == max_gain:
                if ids < best_ids:
                    best_ids = ids
    
    return sorted(best_ids)
