import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Handle header-only input
    if len(data) == 0:
        out = io.StringIO()
        writer = csv.writer(out, lineterminator="\n")
        writer.writerow(header)
        return out.getvalue()

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        # pad/truncate to header length
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[:len(header)]
        cleaned.append(cells)

    # drop rows whose "team" cell is empty
    team_idx = header.index("team")
    cleaned = [r for r in cleaned if r[team_idx] != ""]

    # remove duplicate rows by "city", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[header.index("city")]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    # sort rows by "name" ascending as strings (stable)
    name_idx = header.index("name")
    deduped.sort(key=lambda r: r[name_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
