def choose(items, capacity):
    """Choose a subset of items maximizing total value with total weight <= capacity.

    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Returns the sorted list of chosen ids.
    Ties on total value are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on a copy so the input is never modified.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # 0/1 knapsack over capacity, tracking the best (value, id-list) per weight.
    # best[w] = (total_value, sorted_id_list) for the best selection with
    # total weight exactly <= w. We keep the lexicographically smallest id list
    # among selections with equal value.
    best = [(0, []) for _ in range(capacity + 1)]

    for item_id, weight, value in entries:
        # Iterate weights downward so each item is used at most once.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = best[w - weight]
            cand_value = prev_value + value
            cand_ids = sorted(prev_ids + [item_id])
            cur_value, cur_ids = best[w]
            if cand_value > cur_value or (cand_value == cur_value and cand_ids < cur_ids):
                best[w] = (cand_value, cand_ids)

    # best[capacity] already accounts for "at most capacity" since we never
    # require exact fill; the empty selection is represented by (0, []).
    return best[capacity][1]
