def coalesce(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"from": s, "to": e} with integer values.
    Intervals that merely touch (e.g. {"from": 1, "to": 3} and {"from": 3, "to": 5})
    are NOT merged; only genuine overlaps (next.from < current.to) are merged.

    Returns a new list of dicts with the same "from"/"to" keys, sorted by start ascending.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and copy without mutating the caller's data.
    items = []
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(
                "invalid interval: from %r > to %r" % (start, end)
            )
        items.append(interval)

    # Sort by start, then by end for deterministic ordering.
    items.sort(key=lambda iv: (iv["from"], iv["to"]))

    merged = []
    for interval in items:
        start = interval["from"]
        end = interval["to"]
        if merged and start < merged[-1]["to"]:
            # Real overlap: extend the current interval if needed.
            if end > merged[-1]["to"]:
                merged[-1]["to"] = end
        else:
            merged.append(interval)

    return merged
