import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "team" cell is empty
    filtered = []
    for cells in cleaned:
        if len(cells) > 3 and cells[3].strip() == "":
            continue
        filtered.append(cells)

    # remove duplicate rows by "id", keeping the first occurrence
    seen = set()
    deduped = []
    for cells in filtered:
        if len(cells) > 1 and cells[1] in seen:
            continue
        seen.add(cells[1])
        deduped.append(cells)

    # sort rows by "city" ascending as strings (stable)
    deduped.sort(key=lambda cells: cells[0] if len(cells) > 0 else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
