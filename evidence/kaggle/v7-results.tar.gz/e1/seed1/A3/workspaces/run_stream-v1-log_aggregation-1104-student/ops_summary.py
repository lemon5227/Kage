def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns a dictionary {name: count} per level, with case-insensitive level names (upper-case keys),
    dropping malformed input lines.
    """
    counts = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # We expect at least 3 parts: timestamp, LEVEL, and the rest (service: message)
        if len(parts) < 3:
            continue
        
        # The second part is the level
        level = parts[1].upper()
        
        # Check if the level is valid (non-empty)
        if not level:
            continue
        
        # Increment the count for this level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
