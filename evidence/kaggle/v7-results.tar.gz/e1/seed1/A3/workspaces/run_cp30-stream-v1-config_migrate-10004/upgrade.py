def migrate(cfg):
    """Migrate a v1 config dict to v2. Return a new dict and do not modify the input.
    
    Raise ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Rename top-level keys "pwd_file" -> "password_file", "user" -> "username".
    Move "cache_size" and "workers" into a sub-dict "network" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keep other keys unchanged and drop keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1")
    
    # Work on a copy to avoid modifying the input
    result = {"version": 2}
    
    # Process top-level keys
    if "pwd_file" in cfg and cfg["pwd_file"] is not None:
        result["password_file"] = cfg["pwd_file"]
    
    if "user" in cfg and cfg["user"] is not None:
        result["username"] = cfg["user"]
    
    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in cfg and cfg["cache_size"] is not None:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg and cfg["workers"] is not None:
        network["workers"] = cfg["workers"]
    result["network"] = network
    
    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg and cfg["timeout_ms"] is not None:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key not in ["pwd_file", "user", "cache_size", "workers", "timeout_ms"]:
            if value is not None:
                result[key] = value
    
    return result
