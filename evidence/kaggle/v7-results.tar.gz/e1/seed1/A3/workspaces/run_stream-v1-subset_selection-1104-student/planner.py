def select_tasks(items, capacity):
    """Pick items maximizing total value with total weight <= capacity.

    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Returns the sorted list of ids of an
    optimal selection. Ties on total value are broken by choosing the
    lexicographically smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the data so the input is never modified.
    data = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("item weight must be positive")
        data.append((item["id"], weight, value))

    n = len(data)

    # dp[c] = best (value, id_list) achievable with capacity c using the
    # items processed so far. We iterate items one at a time (0/1 knapsack).
    # id_list is kept sorted; comparison is (value, then lexicographically
    # smallest sorted id list).
    def better(a, b):
        # Return True if selection a is strictly better than b.
        if a[0] != b[0]:
            return a[0] > b[0]
        return a[1] < b[1]

    dp = [(0, []) for _ in range(capacity + 1)]

    for idx in range(n):
        iid, weight, value = data[idx]
        # Iterate capacities downward to avoid reusing the same item.
        for c in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[c - weight]
            cand_value = prev_value + value
            cand_ids = sorted(prev_ids + [iid])
            cand = (cand_value, cand_ids)
            if better(cand, dp[c]):
                dp[c] = cand

    return list(dp[capacity][1])
