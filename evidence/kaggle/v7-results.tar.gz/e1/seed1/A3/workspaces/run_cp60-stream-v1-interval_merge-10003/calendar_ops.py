def merge_slots(intervals):
    """Merge overlapping time ranges.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Overlapping intervals are merged; touching intervals (e.g. [1,3] and
    [3,5]) are also merged. Returns a new list of dicts with the same
    "start"/"end" keys, sorted by start ascending. The input is not modified.

    Raises ValueError if any interval has start > end.
    """
    # Validate and collect intervals as tuples
    items = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        items.append((start, end))

    # Sort by start, then by end
    items.sort(key=lambda pair: (pair[0], pair[1]))

    # Merge overlapping intervals
    merged = []
    for start, end in items:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching: extend the current interval if needed
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    # Convert back to dicts with "start" and "end" keys
    return [{"start": s, "end": e} for s, e in merged]
