import csv
import io

def tidy_csv(text):
    # Handle empty string
    if not text or not text.strip():
        return ''
    
    # Parse the CSV text
    lines = text.strip().split('\n')
    
    if len(lines) == 0:
        return ''
    
    # Check if it's header-only
    if len(lines) == 1:
        # Strip whitespace from header cells
        header_cells = [cell.strip() for cell in lines[0].split(',')]
        # Return just the header line with proper CSV formatting
        return ','.join(header_cells) + '\n'
    
    # Parse header row
    header_cells = [cell.strip() for cell in lines[0].split(',')]
    
    # Verify columns: score, id, team, name
    if len(header_cells) != 4:
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = [cell.strip() for cell in line.split(',')]
        if len(cells) != 4:
            continue
        score, id_val, team, name = cells
        
        # Drop rows whose "name" cell is empty
        if not name:
            continue
        
        rows.append((score, id_val, team, name))
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        if row[3] not in seen_names:
            seen_names.add(row[3])
            unique_rows.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x[3])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header_cells)
    
    # Write data rows
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
