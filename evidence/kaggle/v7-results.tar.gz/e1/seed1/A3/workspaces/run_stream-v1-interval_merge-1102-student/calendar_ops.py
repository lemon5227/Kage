def coalesce(intervals):
    """Merge overlapping intervals.

    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals in the same [start, end] list form, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")

    # Sort by start (and by end for stability)
    sorted_intervals = sorted(intervals, key=lambda x: (x[0], x[1]))

    merged = []
    for interval in sorted_intervals:
        start, end = interval[0], interval[1]
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1][0], merged[-1][1]
            # Only merge if there is a real overlap (end > last_end)
            if end > last_end:
                merged[-1][1] = end
            else:
                merged.append([start, end])

    return merged
