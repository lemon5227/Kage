import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "id" cell is empty
    filtered = []
    for cells in cleaned:
        if len(cells) > 0 and cells[0] == "":
            continue
        filtered.append(cells)

    # lower-case the "email" column (column index 1)
    for cells in filtered:
        if len(cells) > 1:
            cells[1] = cells[1].lower()

    # remove duplicate rows by "email", keeping the first occurrence
    seen = set()
    deduped = []
    for cells in filtered:
        email = cells[1] if len(cells) > 1 else ""
        if email in seen:
            continue
        seen.add(email)
        deduped.append(cells)

    # sort rows by "email" ascending as strings (stable)
    deduped.sort(key=lambda cells: cells[1] if len(cells) > 1 else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
