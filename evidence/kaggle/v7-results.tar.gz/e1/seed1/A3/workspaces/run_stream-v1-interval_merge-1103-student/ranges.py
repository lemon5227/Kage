def combine_ranges(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Overlapping intervals are merged; touching intervals (e.g. [1,3] and
    [3,5]) are NOT merged. Returns a new list of dicts with the same
    "start"/"end" keys, sorted by start ascending. The input is not modified.

    Raises ValueError if any interval has start > end.
    """
    items = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        items.append((start, end))

    items.sort(key=lambda pair: (pair[0], pair[1]))

    merged = []
    for start, end in items:
        if merged and start < merged[-1][1]:
            # Real overlap: extend the current interval if needed.
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    return [{"start": s, "end": e} for s, e in merged]
