import csv
import io

HEADER = ["city", "email", "name", "id", "team"]


def dedupe_export(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        # pad/truncate to header length
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[:len(header)]
        cleaned.append(cells)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name")
    cleaned = [r for r in cleaned if r[name_idx] != ""]

    # lower-case the "email" column
    email_idx = header.index("email")
    for r in cleaned:
        r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "team", keeping the first occurrence
    team_idx = header.index("team")
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[team_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    # sort rows by "id" ascending as strings (stable)
    id_idx = header.index("id")
    deduped.sort(key=lambda r: r[id_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        print(dedupe_export(sys.argv[1]))
