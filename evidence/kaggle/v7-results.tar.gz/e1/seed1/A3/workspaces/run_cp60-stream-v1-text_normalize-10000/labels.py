import unicodedata

def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for char in lower:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                result.append('-')
            prev_char = char
        else:
            prev_char = char
    
    result_str = ''.join(result)
    
    # Strip leading and trailing "-"
    result_str = result_str.strip('-')
    
    # If longer than 23 characters, cut to 23 and then strip trailing "-"
    if len(result_str) > 23:
        result_str = result_str[:23].strip('-')
    
    return result_str
