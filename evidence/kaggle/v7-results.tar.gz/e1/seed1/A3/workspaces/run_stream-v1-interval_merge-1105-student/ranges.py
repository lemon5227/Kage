def combine_ranges(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"begin": s, "finish": e} with integer values.
    Intervals that touch (e.g. {"begin": 1, "finish": 3} and {"begin": 3, "finish": 5})
    are merged.

    Returns a new list of dicts with the same "begin"/"finish" keys, sorted by begin ascending.
    Raises ValueError if any interval has begin > finish.
    The input is not modified.
    """
    # Validate and copy without mutating the caller's data.
    items = []
    for interval in intervals:
        begin, finish = interval["begin"], interval["finish"]
        if begin > finish:
            raise ValueError(
                "invalid interval: begin %r > finish %r" % (begin, finish)
            )
        items.append(interval)

    # Sort by begin, then by finish for deterministic ordering.
    items.sort(key=lambda iv: (iv["begin"], iv["finish"]))

    merged = []
    for interval in items:
        begin, finish = interval["begin"], interval["finish"]
        if merged and begin < merged[-1]["finish"]:
            # Real overlap: extend the current interval if needed.
            if finish > merged[-1]["finish"]:
                merged[-1]["finish"] = finish
        else:
            merged.append(interval.copy())

    return merged
