def coalesce(intervals):
    """Merge overlapping or touching intervals.
    
    Each interval is a dict {"from": s, "to": e} with integer values.
    Returns merged intervals as dicts with the same "from"/"to" keys,
    sorted by start ascending. Touching intervals like [1,3] and [3,5]
    should be merged. Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        s, e = interval["from"], interval["to"]
        if s > e:
            raise ValueError(
                f"invalid interval: start {s} > end {e}"
            )
        normalized.append([s, e])

    # Sort by start (and then by end for stability)
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    # Convert back to dict format
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})

    return result
