def merge_slots(intervals):
    """Merge overlapping or touching time ranges.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Touching intervals like {"start": 1, "end": 3} and {"start": 3, "end": 5}
    are merged. The result is a new list of dicts with the same "start"/"end" keys,
    sorted by start ascending. The input is not modified.

    Raises ValueError if any interval has start > end.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                f"invalid interval: start {start} is greater than end {end}"
            )
        normalized.append(interval)

    # Sort by start, then by end
    normalized.sort(key=lambda pair: (pair["start"], pair["end"]))

    merged = []
    for interval in normalized:
        start = interval["start"]
        end = interval["end"]
        if merged and start <= merged[-1]["end"]:
            if end > merged[-1]["end"]:
                merged[-1]["end"] = end
        else:
            merged.append({"start": start, "end": end})

    return merged
