def coalesce(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Intervals that touch (e.g. {"start": 1, "end": 3} and {"start": 3, "end": 5})
    are merged if the next start <= current end.

    Returns a new list of dicts with "start" and "end" keys, sorted by start ascending.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and copy without mutating the caller's data.
    items = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        items.append({"start": start, "end": end})

    # Sort by start, then by end for deterministic ordering.
    items.sort(key=lambda iv: (iv["start"], iv["end"]))

    merged = []
    for interval in items:
        start = interval["start"]
        end = interval["end"]
        if merged and start <= merged[-1]["end"]:
            # Overlap or touch: extend the current interval if needed.
            if end > merged[-1]["end"]:
                merged[-1]["end"] = end
        else:
            merged.append({"start": start, "end": end})

    return merged
