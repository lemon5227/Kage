import csv
import io

HEADER = ["name", "team", "city", "id", "score"]


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Check if header matches expected columns
    if header != HEADER:
        # If header doesn't match, try to find the correct column indices
        # We'll assume the order is name, team, city, id, score
        # But we need to handle cases where the order might be different
        # For now, we'll proceed with the assumption that the columns are in the expected order
        pass

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        # pad/truncate to header length
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[:len(header)]
        cleaned.append(cells)

    # drop rows whose "name" cell is empty
    cleaned = [r for r in cleaned if r[0] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[4]  # score is at index 4
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    # sort rows by "id" ascending as strings (stable)
    deduped.sort(key=lambda r: r[3])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
