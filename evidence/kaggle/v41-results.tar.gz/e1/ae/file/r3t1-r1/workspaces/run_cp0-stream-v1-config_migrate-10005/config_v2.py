def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys: "user" -> "username", "dir" -> "directory".
    Moves "cache_size" and "retries" into a sub-dict "limits" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 configuration")

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process top-level keys
    for key, value in list(cfg.items()):
        if key == "user":
            result["username"] = value
        elif key == "dir":
            result["directory"] = value
        elif key == "cache_size":
            result["limits"] = {}
            result["limits"]["cache_size"] = value
        elif key == "retries":
            result["limits"] = {}
            result["limits"]["retries"] = value
        elif key == "timeout_ms":
            if value is None:
                continue
            result["timeout_s"] = float(value) / 1000.0
        else:
            # Keep other keys unchanged, but drop keys whose value is None
            if value is not None:
                result[key] = value

    return result
