def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Renames top-level keys:
      "dir" -> "directory"
      "pwd_file" -> "password_file"
      "max_conn" -> "max_connections"
    Moves "region" and "retries" into a sub-dict "network" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError(
            "upgrade_config requires cfg['version'] == 1; "
            f"got {cfg.get('version')}"
        )

    # Work on a copy so the input is never modified
    out = {}
    out["version"] = 2

    # Process top-level keys
    for key in list(cfg.keys()):
        value = cfg[key]
        if value is None:
            continue  # drop None values

        if key == "dir":
            out["directory"] = value
        elif key == "pwd_file":
            out["password_file"] = value
        elif key == "max_conn":
            out["max_connections"] = value
        elif key == "timeout_ms":
            out["timeout_s"] = value / 1000.0
        else:
            out[key] = value

    # Ensure "network" sub-dict is present
    out["network"] = {}

    # Move "region" and "retries" into the network dict if they exist
    if "region" in cfg:
        out["network"]["region"] = cfg["region"]
    if "retries" in cfg:
        out["network"]["retries"] = cfg["retries"]

    return out
