def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "max_conn" -> "max_connections"
      "dir" -> "directory"
      "host" -> "hostname"
    Moves "cache_size" and "region" into a sub-dict "limits".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError(
            f"expected version 1, got {cfg.get('version')!r}"
        )

    # Work on a copy so the input is never modified.
    out = {"version": 2}

    # Track which keys we've processed so we can drop None values later.
    processed = set()

    # Top-level keys that need renaming or moving.
    if "max_conn" in cfg:
        out["max_connections"] = cfg["max_conn"]
        processed.add("max_conn")
    if "dir" in cfg:
        out["directory"] = cfg["dir"]
        processed.add("dir")
    if "host" in cfg:
        out["hostname"] = cfg["host"]
        processed.add("host")

    # Move cache_size and region into limits.
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
        processed.add("cache_size")
    if "region" in cfg:
        limits["region"] = cfg["region"]
        processed.add("region")
    out["limits"] = limits

    # Handle timeout_ms -> timeout_s.
    if "timeout_ms" in cfg:
        out["timeout_s"] = cfg["timeout_ms"] / 1000.0
        processed.add("timeout_ms")

    # Keep other keys unchanged.
    for key in cfg:
        if key not in processed:
            out[key] = cfg[key]

    # Drop keys whose value is None.
    for key in list(out.keys()):
        if out[key] is None:
            del out[key]

    return out
