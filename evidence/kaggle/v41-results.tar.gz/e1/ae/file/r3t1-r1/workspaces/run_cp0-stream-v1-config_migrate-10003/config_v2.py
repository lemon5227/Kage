def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "dir" -> "directory"
      "host" -> "hostname"
    Moves "port" and "workers" into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 configuration")

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Track which keys we've processed
    processed = set()

    # Handle top-level keys that need renaming or moving
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
        processed.add("dir")
    if "host" in cfg:
        result["hostname"] = cfg["host"]
        processed.add("host")

    # Move port and workers into storage
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
        processed.add("port")
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
        processed.add("workers")
    result["storage"] = storage

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
        processed.add("timeout_ms")

    # Copy other keys unchanged, but skip None values
    for key, value in cfg.items():
        if key in processed:
            continue
        if value is None:
            continue
        result[key] = value

    return result
