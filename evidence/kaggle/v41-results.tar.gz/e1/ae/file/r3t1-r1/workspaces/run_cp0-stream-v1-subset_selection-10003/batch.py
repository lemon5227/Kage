def pick_jobs(items, capacity):
    """Choose a subset of items maximizing total score within capacity.

    Each item is a dict with a unique string "id", a positive integer
    "size" and a non-negative integer "score".  Returns the sorted list
    of ids whose total score is as large as possible while total size
    stays <= capacity.  Ties on total score are broken by the
    lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by id so that we can reason about tie-breaking consistently.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = best (score, chosen_ids) achievable with total size exactly w.
    # We track the chosen ids to resolve ties lexicographically.
    # Using a dict keyed by weight for the best score, and storing the id list.
    # Initialize with weight 0 having score 0 and empty id list.
    dp = [(0, [])]  # weight -> (score, chosen_ids)
    # We'll iterate over items and update dp for each possible weight.
    # Since capacity can be large, we need to be careful about memory.
    # However, the problem statement does not specify constraints on capacity.
    # We'll assume it's reasonable for this implementation.

    # Use a list for dp where index is weight.
    # Initialize dp[0] = (0, []), and all other weights to None (unreachable).
    dp_table = [None] * (capacity + 1)
    dp_table[0] = (0, [])

    for item_id, size, score in entries:
        # Iterate weights descending so each item is used at most once.
        for w in range(capacity, size - 1, -1):
            prev = dp_table[w - size]
            if prev is None:
                continue
            cand_score = prev[0] + score
            cand_ids = prev[1] + [item_id]
            cur = dp_table[w]
            if cur is None or cand_score > cur[0]:
                dp_table[w] = (cand_score, cand_ids)
            elif cand_score == cur[0]:
                # Tie on score: choose lexicographically smallest sorted id list.
                if sorted(cand_ids) < sorted(cur[1]):
                    dp_table[w] = (cand_score, cand_ids)

    # Find the best score across all weights <= capacity.
    best_score = 0
    best_ids = []
    for w in range(capacity + 1):
        entry = dp_table[w]
        if entry is None:
            continue
        score, ids = entry
        if score > best_score:
            best_score = score
            best_ids = ids[:]
        elif score == best_score:
            if sorted(ids) < sorted(best_ids):
                best_ids = ids[:]

    return best_ids
