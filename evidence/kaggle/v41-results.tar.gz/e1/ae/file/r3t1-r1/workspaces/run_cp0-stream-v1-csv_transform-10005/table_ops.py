import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "id" cell is empty
    try:
        id_idx = header.index("id")
    except ValueError:
        id_idx = None

    if id_idx is not None:
        cleaned = [r for r in cleaned if id_idx < len(r) and r[id_idx] != ""]

    # lower-case the "email" column
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    if email_idx is not None:
        for r in cleaned:
            if email_idx < len(r):
                r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "email", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[email_idx] if email_idx is not None and email_idx < len(r) else ""
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    # sort rows by "email" ascending as strings (stable)
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    def sort_key(r):
        return r[email_idx] if email_idx is not None and email_idx < len(r) else ""

    deduped.sort(key=sort_key)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for r in deduped:
        writer.writerow(r)

    return out.getvalue()
