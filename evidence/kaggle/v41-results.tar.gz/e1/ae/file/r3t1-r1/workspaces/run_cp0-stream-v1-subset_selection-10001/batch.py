def allocate(items, capacity):
    """Select a subset of items maximizing total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by choosing the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # Sort by id so that we can reason about lexicographic tie-breaking.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    if n == 0:
        return []

    # dp[c] = best (gain, chosen_ids) achievable with cost exactly c.
    # We track the chosen ids to resolve ties lexicographically.
    # Using a dict keyed by cost for O(capacity) space.
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for idx in range(n):
        item_id, cost, gain = entries[idx]
        # Iterate costs descending so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev = dp[c - cost]
            if prev is None:
                continue
            cand_gain = prev[0] + gain
            cand_ids = prev[1] + [item_id]
            cur = dp[c]
            if cur is None or cand_gain > cur[0]:
                dp[c] = (cand_gain, cand_ids)
            elif cand_gain == cur[0]:
                # Tie on gain: prefer lexicographically smallest sorted id list.
                if sorted(cand_ids) < sorted(cur[1]):
                    dp[c] = (cand_gain, cand_ids)

    # Find the best gain across all feasible costs, then the lexicographically
    # smallest id list among those achieving that gain.
    best_gain = None
    best_ids = None
    for c in range(capacity + 1):
        entry = dp[c]
        if entry is None:
            continue
        gain, ids = entry
        if best_gain is None or gain > best_gain:
            best_gain = gain
            best_ids = ids
        elif gain == best_gain:
            if sorted(ids) < sorted(best_ids):
                best_ids = ids

    return best_ids if best_ids is not None else []
