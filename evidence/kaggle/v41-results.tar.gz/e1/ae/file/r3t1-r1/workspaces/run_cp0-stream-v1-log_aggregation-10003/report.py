def aggregate_log(lines):
    """Aggregate log lines into {service: count} for ERROR and WARN levels.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    - Level names are matched case-insensitively (only ERROR and WARN counted).
    - Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service (with colon), message
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service_part = parts[2]
        if not service_part.endswith(":"):
            continue
        service = service_part[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
