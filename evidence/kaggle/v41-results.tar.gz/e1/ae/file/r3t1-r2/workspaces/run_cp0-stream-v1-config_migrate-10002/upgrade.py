def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Renames top-level keys:
      "dir" -> "directory"
      "pwd_file" -> "password_file"
      "max_conn" -> "max_connections"
    Moves "region" and "retries" into a sub-dict "network" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError("expected version 1")

    # Work on a copy so the input is never modified.
    out = {}
    out["version"] = 2

    # Track which keys we've processed so we can drop None values later.
    processed = set()

    # Handle the renamed top-level keys.
    if "dir" in cfg:
        out["directory"] = cfg["dir"]
        processed.add("dir")
    if "pwd_file" in cfg:
        out["password_file"] = cfg["pwd_file"]
        processed.add("pwd_file")
    if "max_conn" in cfg:
        out["max_connections"] = cfg["max_conn"]
        processed.add("max_conn")

    # Move "region" and "retries" into a sub-dict "network".
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
        processed.add("region")
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
        processed.add("retries")
    out["network"] = network

    # Handle timeout_ms -> timeout_s.
    if "timeout_ms" in cfg:
        out["timeout_s"] = cfg["timeout_ms"] / 1000.0
        processed.add("timeout_ms")

    # Keep other keys unchanged.
    for key in cfg:
        if key not in processed:
            out[key] = cfg[key]
            processed.add(key)

    # Drop keys whose value is None.
    for key in list(out.keys()):
        if out[key] is None:
            del out[key]

    return out
