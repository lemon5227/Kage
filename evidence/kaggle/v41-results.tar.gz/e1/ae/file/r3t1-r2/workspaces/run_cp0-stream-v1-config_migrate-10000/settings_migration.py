def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "max_conn" -> "max_connections"
      "dir" -> "directory"
      "host" -> "hostname"
    Moves "cache_size" and "region" into a sub-dict "limits".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError(
            f"expected config version 1, got {cfg.get('version')}"
        )

    # Work on a copy so the input is never modified
    out = {}
    out["version"] = 2

    # Process top-level keys
    if "max_conn" in cfg:
        out["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        out["directory"] = cfg["dir"]
    if "host" in cfg:
        out["hostname"] = cfg["host"]
    if "timeout_ms" in cfg:
        out["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Move cache_size and region into limits
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    out["limits"] = limits

    # Copy other keys that are not None
    for key, value in cfg.items():
        if key in ("max_conn", "dir", "host", "cache_size", "region", "timeout_ms"):
            continue
        if value is None:
            continue
        out[key] = value

    return out
