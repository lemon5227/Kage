import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    text = normalized.encode("ascii", "ignore").decode("ascii")

    # lower-case
    text = text.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    parts = []
    for ch in text:
        if ch.isalnum():
            parts.append(ch)
        else:
            if parts and not ch.isalnum():
                parts.append("-")
            elif not ch.isalnum():
                pass  # skip non-alnum without adding separator

    result = "".join(parts)
    # strip leading and trailing "-"
    return result.strip("-")
