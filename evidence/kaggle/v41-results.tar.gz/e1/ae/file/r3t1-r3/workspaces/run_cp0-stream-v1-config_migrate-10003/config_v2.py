def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    - Rename top-level keys "dir" -> "directory", "host" -> "hostname".
    - Move "port" and "workers" into a sub-dict "storage" (always present, possibly empty).
    - If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    - Keep other keys unchanged and drop keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 configuration")

    # Work on a copy so the input is never modified
    result = {"version": 2}

    # Handle top-level keys that need renaming or moving
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]

    # Move port and workers into storage
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    result["storage"] = storage

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged, but drop keys whose value is None
    for key in cfg:
        if key not in result and cfg[key] is not None:
            result[key] = cfg[key]

    return result
