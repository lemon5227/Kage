def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "dir" -> "directory"
      "pwd_file" -> "password_file"
      "max_conn" -> "max_connections"
    Moves "region" and "retries" into a sub-dict "network" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1, got %r" % cfg.get("version"))

    # Make a copy so we don't modify the input
    result = {}
    result["version"] = 2

    # Process known old keys
    if "dir" in cfg and cfg["dir"] is not None:
        result["directory"] = cfg["dir"]
    if "pwd_file" in cfg and cfg["pwd_file"] is not None:
        result["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg and cfg["max_conn"] is not None:
        result["max_connections"] = cfg["max_conn"]

    # Move region and retries into network sub-dict
    network = {}
    if "region" in cfg and cfg["region"] is not None:
        network["region"] = cfg["region"]
    if "retries" in cfg and cfg["retries"] is not None:
        network["retries"] = cfg["retries"]
    result["network"] = network

    # Handle timeout_ms -> timeout_s conversion
    if "timeout_ms" in cfg and cfg["timeout_ms"] is not None:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key in ("version", "dir", "pwd_file", "max_conn", "region", "retries", "timeout_ms"):
            continue
        if value is None:
            continue
        result[key] = value

    return result
