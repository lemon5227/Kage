def aggregate_log(lines):
    """Aggregate log lines into a dict of {service: count}.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Only counts entries where the level is ERROR or WARN (case-insensitive).
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        _timestamp, level, service, message = parts
        if not service.endswith(':'):
            continue
        service = service[:-1]
        if not service:
            continue
        try:
            int(_timestamp)
        except ValueError:
            continue
        if level.upper() not in ("ERROR", "WARN"):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
