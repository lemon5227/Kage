def allocate(items, capacity):
    """Select a subset of items maximizing total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by choosing the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_gain, sorted_id_list) achievable with cost exactly c.
    # We track the chosen subset so we can reconstruct the id list.
    prev = [(None, None)] * (capacity + 1)
    for item_id, cost, gain in entries:
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev_c = prev[c - cost]
            cand_gain = prev_c[0] + gain
            cand_ids = prev_c[1] + [item_id] if prev_c[0] is not None else [item_id]
            cur = prev[c]
            if cand_gain > cur[0]:
                prev[c] = (cand_gain, sorted(cand_ids))
            elif cand_gain == cur[0] and sorted(cand_ids) < cur[1]:
                prev[c] = (cand_gain, sorted(cand_ids))

    # The best total gain is the maximum over all capacities <= capacity.
    max_gain = None
    best_ids = None
    for c in range(capacity + 1):
        gain, ids = prev[c]
        if max_gain is None or gain > max_gain:
            max_gain = gain
            best_ids = ids
        elif gain == max_gain and (best_ids is None or ids < best_ids):
            best_ids = ids

    return best_ids
