def merge_slots(intervals):
    """
    Combines overlapping time ranges. Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        if "start" not in interval or "end" not in interval:
            raise ValueError("Each interval must have 'start' and 'end' keys")
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Check if intervals is empty
    if not intervals:
        return []
    
    # Sort intervals by start time
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping or touching intervals
    merged = []
    current_start = sorted_intervals[0]["start"]
    current_end = sorted_intervals[0]["end"]
    
    for interval in sorted_intervals[1:]:
        start = interval["start"]
        end = interval["end"]
        
        # If the current interval overlaps or touches the next interval, merge them
        if start <= current_end:
            current_end = max(current_end, end)
        else:
            # No overlap, add the current interval to merged list and start a new one
            merged.append({"start": current_start, "end": current_end})
            current_start = start
            current_end = end
    
    # Add the last interval
    merged.append({"start": current_start, "end": current_end})
    
    return merged
