def pick_jobs(items, capacity):
    return None
