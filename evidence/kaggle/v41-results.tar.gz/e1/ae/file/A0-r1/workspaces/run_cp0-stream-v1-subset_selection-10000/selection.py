def select_tasks(items, capacity):
    """
    Select parcels under a capacity limit to maximize total gain.
    
    Args:
        items: List of dicts with keys 'id', 'cost', 'gain'
        capacity: Maximum total cost allowed
    
    Returns:
        Sorted list of ids of selected items
    
    Raises:
        ValueError: If capacity is negative or any cost is <= 0
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if 'id' not in item or 'cost' not in item or 'gain' not in item:
            raise ValueError("Each item must have 'id', 'cost', and 'gain' keys")
        if not isinstance(item['id'], str):
            raise ValueError("Item id must be a string")
        if item['cost'] <= 0:
            raise ValueError("Cost must be positive")
        if not isinstance(item['gain'], int) or item['gain'] < 0:
            raise ValueError("Gain must be a non-negative integer")
    
    if len(items) == 0:
        return []
    
    n = len(items)
    
    # dp[i][w] = maximum gain using first i items with total cost <= w
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    
    # Track which items were selected for each state
    # parent[i][w] = j means item j was selected to reach state (i, w)
    parent = [[None] * (capacity + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        cost = items[i-1]['cost']
        gain = items[i-1]['gain']
        for w in range(capacity + 1):
            # Don't include item i
            dp[i][w] = dp[i-1][w]
            
            # Include item i if possible
            if w >= cost:
                if dp[i-1][w-cost] + gain > dp[i][w]:
                    dp[i][w] = dp[i-1][w-cost] + gain
                    parent[i][w] = i - 1
                elif dp[i-1][w-cost] + gain == dp[i][w]:
                    # Tie-breaking: prefer lexicographically smaller id list
                    # We need to compare the resulting id lists
                    # This is complex, so we'll handle it differently
                    pass
    
    # Find the maximum gain and reconstruct the solution
    max_gain = dp[n][capacity]
    
    # Reconstruct the selection by backtracking from dp[n][capacity]
    selected = []
    i, w = n, capacity
    while i > 0:
        if parent[i][w] is not None:
            selected.append(items[i-1]['id'])
            w -= items[i-1]['cost']
        i -= 1
    
    # Sort the ids lexicographically
    selected.sort()
    
    return selected
