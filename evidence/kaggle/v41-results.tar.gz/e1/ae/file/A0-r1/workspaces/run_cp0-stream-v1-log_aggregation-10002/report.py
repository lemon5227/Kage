def digest_lines(lines):
    result = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split by spaces to get parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1]
        
        # Validate format: should have "service:" after level
        # Check that there's a colon in the rest of the line
        rest = ' '.join(parts[2:])
        if ':' not in rest:
            continue
        
        # Count by level (case-insensitive, store with upper-case key)
        key = level.upper()
        result[key] = result.get(key, 0) + 1
    
    return result
