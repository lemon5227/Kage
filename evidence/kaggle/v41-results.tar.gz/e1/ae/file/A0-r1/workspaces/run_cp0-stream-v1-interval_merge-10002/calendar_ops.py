def coalesce(intervals):
    # Validate all intervals first
    for interval in intervals:
        if not isinstance(interval, dict) or "start" not in interval or "end" not in interval:
            raise ValueError("Each interval must be a dict with 'start' and 'end' keys")
        start = interval["start"]
        end = interval["end"]
        if not isinstance(start, int) or not isinstance(end, int):
            raise ValueError("Interval values must be integers")
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort intervals by start
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start = interval["start"]
        end = interval["end"]
        
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            # If current interval overlaps or touches the last interval, merge them
            if start <= last["end"]:
                # Update the end of the last interval to be the maximum of both ends
                last["end"] = max(last["end"], end)
            else:
                merged.append(interval.copy())
    
    return merged
