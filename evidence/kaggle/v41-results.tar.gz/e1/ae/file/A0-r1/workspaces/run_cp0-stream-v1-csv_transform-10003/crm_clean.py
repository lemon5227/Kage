import csv
import io


def tidy_csv(text):
    """Clean an exported CSV table with columns: name, city, score, team."""
    
    # Handle empty string input
    if not text or not text.strip():
        return ''
    
    # Split into lines and handle line endings
    lines = text.split('\n')
    
    # Check if it's header-only input
    if len(lines) == 1:
        return lines[0]
    
    # Parse the CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Extract header
    header = rows[0]
    
    # Validate header columns
    expected_columns = ['name', 'city', 'score', 'team']
    if header != expected_columns:
        raise ValueError(f"Expected columns {expected_columns}, got {header}")
    
    # Clean each cell: strip leading/trailing whitespace
    cleaned_rows = []
    for row in rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "name" cell is empty
    filtered_rows = [row for row in cleaned_rows if row[0] != '']
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in filtered_rows:
        name = row[0]
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Sort rows by "city" ascending as strings (stable)
    sorted_rows = sorted(unique_rows, key=lambda row: row[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(sorted_rows)
    
    return output.getvalue()
