def count_entries(lines):
    """Count entries by level in log lines.
    
    Each line looks like: "<timestamp> <LEVEL> <service>: <message>"
    Returns a dict mapping each level (case-insensitive, upper-case) to its count.
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service:
        if len(parts) < 3:
            continue
            
        # Extract level from parts[1]
        level = parts[1].upper()
        
        # Check if the format is valid: parts[2] should be "service:"
        if not parts[2].endswith(':'):
            continue
            
        # Count this entry
        counts[level] = counts.get(level, 0) + 1
    
    # Return only non-zero counts (already handled by dict)
    return counts
