def digest_lines(lines):
    counts = {}
    for line in lines:
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip lines that don't match format
        
        # Check if second part is a level (common log levels)
        level = parts[1].upper()
        # Common log levels to consider
        valid_levels = {'DEBUG', 'INFO', 'WARN', 'WARNING', 'ERROR', 'FATAL', 'CRITICAL'}
        if level not in valid_levels:
            continue
        
        counts[level] = counts.get(level, 0) + 1
    return counts
