import csv
import io


def normalize_table(text):
    """
    Process CSV text with header row (columns: score, id, email, name).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "name", keeping the first occurrence
    5. Sort rows by "email" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Parse CSV text
    if not text.strip():
        return ''
    
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Extract header
    header = lines[0].strip()
    # Parse header columns
    columns = [col.strip() for col in header.split(',')]
    
    # Check if we have the expected columns
    expected_columns = ['score', 'id', 'email', 'name']
    if columns != expected_columns:
        # If header doesn't match, return empty or handle gracefully
        # Based on requirements, we expect specific columns
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        
        # Split by comma, strip each cell
        cells = [cell.strip() for cell in line.split(',')]
        
        # Ensure we have 4 columns
        if len(cells) < 4:
            continue
        
        score, id_val, email, name = cells[:4]
        
        # Step 2: Drop rows whose "name" cell is empty
        if not name.strip():
            continue
        
        # Step 3: Lower-case the "email" column
        email = email.lower()
        
        rows.append({
            'score': score,
            'id': id_val,
            'email': email,
            'name': name
        })
    
    # Step 4: Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        if row['name'] not in seen_names:
            seen_names.add(row['name'])
            unique_rows.append(row)
    
    # Step 5: Sort rows by "email" ascending as strings (stable)
    unique_rows.sort(key=lambda r: r['email'])
    
    # Build output CSV text
    output_lines = [header]
    for row in unique_rows:
        # Reconstruct the row with original formatting (but cleaned)
        line = f"{row['score']},{row['id']},{row['email']},{row['name']}"
        output_lines.append(line)
    
    # Join with '\n' line endings
    return '\n'.join(output_lines)


if __name__ == '__main__':
    # Test examples
    test1 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,test@example.com,Jane"
    print("Test 1:")
    print(normalize_table(test1))
    
    test2 = "score,id,email,name\n1,abc,test@example.com,John"
    print("\nTest 2:")
    print(normalize_table(test2))
    
    test3 = "score,id,email,name"
    print("\nTest 3 (header only):")
    print(normalize_table(test3))
    
    test4 = ""
    print("\nTest 4 (empty):")
    print(normalize_table(test4))
