def summarize(lines):
    """
    Summarize log lines, counting occurrences of WARN level per service.
    
    Each line format: "<timestamp> <LEVEL> <service>: <message>"
    Returns a dict mapping each service (for WARN level) to its count.
    Levels are case-insensitive (reported as upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Check if the line has the expected format (service should be followed by ':')
        # We'll assume the format is correct if we have at least 3 parts
        # and the service part exists
        
        # Only count WARN level
        if level == 'WARN':
            counts[service] = counts.get(service, 0) + 1
    
    # Return only services with non-zero counts
    return counts
