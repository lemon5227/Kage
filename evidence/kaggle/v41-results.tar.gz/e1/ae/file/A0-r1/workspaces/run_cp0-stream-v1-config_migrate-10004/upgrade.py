def migrate(cfg):
    # Check if version is 1, otherwise raise ValueError
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1")
    
    # Create a new dict to avoid modifying input
    result = {}
    result["version"] = 2
    
    # Process keys
    for key, value in cfg.items():
        # Drop keys with None value
        if value is None:
            continue
        
        # Handle specific key transformations
        if key == "pwd_file":
            result["password_file"] = value
        elif key == "user":
            result["username"] = value
        elif key == "cache_size":
            # Move into network dict
            if "network" not in result:
                result["network"] = {}
            result["network"]["cache_size"] = value
        elif key == "workers":
            # Move into network dict
            if "network" not in result:
                result["network"] = {}
            result["network"]["workers"] = value
        elif key == "timeout_ms":
            # Convert to timeout_s (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value
    
    return result
