def aggregate_log(lines):
    """Aggregate log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns {name: count} per service for levels ERROR, WARN only,
    treating level names case-insensitively (upper-case keys), dropping malformed input lines.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        if len(parts) < 3:
            # Malformed line (need at least timestamp, level, service)
            continue
            
        timestamp = parts[0]
        level = parts[1].upper()
        service_part = parts[2]
        
        # Check if service part contains colon
        if ':' not in service_part:
            # Malformed line (service should be followed by colon)
            continue
            
        service = service_part.split(':')[0]
        
        # Only count ERROR and WARN levels
        if level not in ('ERROR', 'WARN'):
            continue
            
        counts[service] = counts.get(service, 0) + 1
    
    return counts
