def choose(items, capacity):
    return None
