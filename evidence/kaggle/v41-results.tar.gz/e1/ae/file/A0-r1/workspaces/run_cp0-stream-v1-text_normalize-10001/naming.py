import unicodedata


def slugify(text):
    """Convert a title into a handle (slug).
    
    Args:
        text: A string to convert
        
    Returns:
        A slugified string
        
    Raises:
        TypeError: If input is not a string
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    slug = []
    previous_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if previous_char is None or previous_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                slug.append('_')
                previous_char = None
            else:
                previous_char = None  # Reset to avoid multiple underscores
        else:
            slug.append(char)
            previous_char = char
    
    result = ''.join(slug)
    
    # Strip leading and trailing "_"
    return result.strip('_')
