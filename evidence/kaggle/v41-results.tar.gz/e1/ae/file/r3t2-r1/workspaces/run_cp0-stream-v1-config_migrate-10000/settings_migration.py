def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "max_conn" -> "max_connections"
      "dir" -> "directory"
      "host" -> "hostname"
    Moves "cache_size" and "region" into a sub-dict "limits" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError("Unsupported configuration version: expected 1")

    # Work on a copy so the input is never modified.
    out = {"version": 2}

    # Handle top-level keys that need renaming or moving.
    if "max_conn" in cfg:
        out["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        out["directory"] = cfg["dir"]
    if "host" in cfg:
        out["hostname"] = cfg["host"]

    # Move cache_size and region into limits.
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    out["limits"] = limits

    # Handle timeout_ms -> timeout_s conversion.
    if "timeout_ms" in cfg:
        out["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged, but drop keys whose value is None.
    for key in cfg:
        if key not in out and cfg[key] is not None:
            out[key] = cfg[key]

    return out
