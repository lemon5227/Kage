import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "score" cell is empty
    try:
        score_idx = header.index("score")
    except ValueError:
        score_idx = None

    if score_idx is not None:
        cleaned = [r for r in cleaned if score_idx < len(r) and r[score_idx] != ""]

    # remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[header.index("team")] if "team" in header else None
        if key is None or key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    # sort rows by "score" ascending as strings (stable)
    try:
        score_idx = header.index("score")
    except ValueError:
        score_idx = None

    def sort_key(r):
        if score_idx is not None and score_idx < len(r):
            return (r[score_idx],)
        return ()

    deduped.sort(key=sort_key, stable=True)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for r in deduped:
        writer.writerow(r)

    return out.getvalue()
