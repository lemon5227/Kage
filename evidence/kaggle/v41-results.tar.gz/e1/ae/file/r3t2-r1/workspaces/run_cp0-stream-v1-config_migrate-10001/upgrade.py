def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "host" -> "hostname"
      "max_conn" -> "max_connections"
      "pwd_file" -> "password_file"
    Moves "port" and "retries" into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError("Unsupported version: expected 1, got %r" % cfg.get("version"))

    # Work on a copy so the input is never modified.
    out = {"version": 2}

    # Handle top-level keys that need renaming or moving.
    host = cfg.get("host")
    if host is not None:
        out["hostname"] = host

    max_conn = cfg.get("max_conn")
    if max_conn is not None:
        out["max_connections"] = max_conn

    pwd_file = cfg.get("pwd_file")
    if pwd_file is not None:
        out["password_file"] = pwd_file

    port = cfg.get("port")
    retries = cfg.get("retries")
    if port is not None or retries is not None:
        out["storage"] = {}
        if port is not None:
            out["storage"]["port"] = port
        if retries is not None:
            out["storage"]["retries"] = retries

    timeout_ms = cfg.get("timeout_ms")
    if timeout_ms is not None:
        out["timeout_s"] = timeout_ms / 1000.0

    # Copy over any other keys that are present and not None.
    for key, value in cfg.items():
        if key in ("host", "max_conn", "pwd_file", "port", "retries", "timeout_ms"):
            continue
        if value is None:
            continue
        out[key] = value

    return out
