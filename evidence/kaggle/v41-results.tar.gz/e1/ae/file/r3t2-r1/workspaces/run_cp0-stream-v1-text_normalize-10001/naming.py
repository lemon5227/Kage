import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    runs = []
    for char in ascii_only:
        if char in "abcdefghijklmnopqrstuvwxyz0123456789":
            runs.append(char)
        else:
            if runs and runs[-1] not in "abcdefghijklmnopqrstuvwxyz0123456789":
                runs[-1] = "_"
            else:
                runs.append("_")

    result = "".join(runs)

    # strip leading and trailing "_"
    return result.strip("_")
