def count_entries(lines):
    """Count lines by log level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (reported upper-case). Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        _timestamp, level, service, message = parts
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service.isalnum():
            continue
        if not message.strip():
            continue
        level = level.strip().upper()
        if not level:
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
