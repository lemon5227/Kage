def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "dir" -> "directory"
      "pwd_file" -> "password_file"
      "max_conn" -> "max_connections"
    Moves "region" and "retries" into a sub-dict "network" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported for upgrade")

    # Make a copy so we don't modify the input
    result = {}
    result["version"] = 2

    # Process keys in a deterministic order
    for key in sorted(cfg.keys()):
        value = cfg[key]

        # Drop keys with None values
        if value is None:
            continue

        if key == "dir":
            result["directory"] = value
        elif key == "pwd_file":
            result["password_file"] = value
        elif key == "max_conn":
            result["max_connections"] = value
        elif key == "region":
            network = result.get("network", {})
            network["region"] = value
            result["network"] = network
        elif key == "retries":
            network = result.get("network", {})
            network["retries"] = value
            result["network"] = network
        elif key == "timeout_ms":
            result["timeout_s"] = value / 1000.0
        else:
            result[key] = value

    return result
