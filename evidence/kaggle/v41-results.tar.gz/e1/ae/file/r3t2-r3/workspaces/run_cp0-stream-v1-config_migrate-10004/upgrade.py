def migrate(cfg):
    """Migrate a v1 config dict to v2.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "pwd_file" -> "password_file"
      "user" -> "username"
    Moves "cache_size" and "workers" into a sub-dict "network" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Make a copy so the input is never modified.
    out = {}
    out["version"] = 2

    # Check version requirement.
    if cfg.get("version") != 1:
        raise ValueError("only v1 configs are supported")

    # Process top-level keys.
    for key in list(cfg.keys()):
        value = cfg[key]
        if value is None:
            continue  # drop keys with None value

        if key == "pwd_file":
            out["password_file"] = value
        elif key == "user":
            out["username"] = value
        elif key == "cache_size":
            out["network"] = out.get("network", {})
            out["network"]["cache_size"] = value
        elif key == "workers":
            out["network"] = out.get("network", {})
            out["network"]["workers"] = value
        elif key == "timeout_ms":
            out["timeout_s"] = value / 1000.0
        else:
            out[key] = value

    return out
