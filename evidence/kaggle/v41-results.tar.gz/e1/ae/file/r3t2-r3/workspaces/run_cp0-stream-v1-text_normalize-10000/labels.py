import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    handle = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    for ch in handle:
        if ch in "abcdefghijklmnopqrstuvwxyz0123456789":
            if segments and segments[-1] != ch:
                segments.append(ch)
        else:
            if segments:
                segments.append("-")
    handle = "".join(segments)

    # strip leading and trailing "-"
    handle = handle.strip("-")

    # if longer than 23, cut to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.rstrip("-")

    return handle
