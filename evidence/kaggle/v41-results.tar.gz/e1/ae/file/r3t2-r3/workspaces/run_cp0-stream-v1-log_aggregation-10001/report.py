def tally_events(lines):
    """Tally log lines by service for ERROR and WARN levels.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    - Level names are matched case-insensitively; only ERROR and WARN are counted.
    - Malformed lines are dropped.
    - Returns a dict mapping service name (upper-case key) to the number of events.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        _timestamp, level, service, message = parts
        if not service.endswith(':'):
            continue
        service = service[:-1]
        if not service:
            continue
        if level.upper() not in ("ERROR", "WARN"):
            continue
        key = service.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
