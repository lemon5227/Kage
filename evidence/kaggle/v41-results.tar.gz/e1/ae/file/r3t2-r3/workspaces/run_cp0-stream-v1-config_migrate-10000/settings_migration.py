def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "max_conn" -> "max_connections"
      "dir" -> "directory"
      "host" -> "hostname"
    Moves "cache_size" and "region" into a sub-dict "limits" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported")

    # Make a copy so we don't modify the input
    result = {}
    result["version"] = 2

    # Process top-level keys
    for key in ["max_conn", "dir", "host"]:
        if key in cfg:
            new_key = {
                "max_conn": "max_connections",
                "dir": "directory",
                "host": "hostname"
            }[key]
            result[new_key] = cfg[key]

    # Move cache_size and region into limits
    limits = {}
    for key in ["cache_size", "region"]:
        if key in cfg:
            limits[key] = cfg[key]
    result["limits"] = limits

    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged (but drop None values)
    for key, value in cfg.items():
        if key in ["max_conn", "dir", "host", "cache_size", "region", "timeout_ms"]:
            continue
        if value is None:
            continue
        result[key] = value

    return result
