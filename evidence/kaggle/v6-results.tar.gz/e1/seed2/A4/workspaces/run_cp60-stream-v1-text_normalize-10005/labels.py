import unicodedata

def to_key(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single '_'
    result = []
    previous_char = None
    for char in lowercased:
        if char.isalnum():  # alphanumeric means a-z, A-Z, 0-9
            result.append(char)
        else:
            # If we encounter a non-alphanumeric character, check if we need to add an underscore
            # We only add an underscore if the previous character was not an underscore (to avoid multiple underscores)
            if previous_char != '_':
                result.append('_')
            previous_char = '_'
    
    # Join and strip leading/trailing underscores
    key = ''.join(result).strip('_')
    
    return key
