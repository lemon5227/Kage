def convert_settings(cfg):
    # Check version requirement
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")
    
    # Create a new dict for the converted settings
    result = {"version": 2}
    
    # Process top-level keys
    # Rename keys
    if "host" in cfg and cfg["host"] is not None:
        result["hostname"] = cfg["host"]
    
    if "max_conn" in cfg and cfg["max_conn"] is not None:
        result["max_connections"] = cfg["max_conn"]
    
    if "pwd_file" in cfg and cfg["pwd_file"] is not None:
        result["password_file"] = cfg["pwd_file"]
    
    # Move port and retries into storage sub-dict
    storage = {}
    if "port" in cfg and cfg["port"] is not None:
        storage["port"] = cfg["port"]
    if "retries" in cfg and cfg["retries"] is not None:
        storage["retries"] = cfg["retries"]
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg and cfg["timeout_ms"] is not None:
        result["storage"] = storage
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Add storage sub-dict if it has content, otherwise still include it (empty)
    if storage or "timeout_s" in result:
        result["storage"] = storage
    
    # Keep other keys unchanged
    for key, value in cfg.items():
        if key not in ["host", "max_conn", "pwd_file", "port", "retries", "timeout_ms", "version"]:
            if value is not None:
                result[key] = value
    
    return result
