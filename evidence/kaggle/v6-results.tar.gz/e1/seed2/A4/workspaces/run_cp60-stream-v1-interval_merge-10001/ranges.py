def merge_slots(intervals):
    """
    Merge overlapping intervals. Each interval is a dict {"from": s, "to": e} with integer values.
    Return merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
    
    if not intervals:
        return []
    
    # Sort by start (from) value
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    merged = [sorted_intervals[0]]
    
    for current in sorted_intervals[1:]:
        prev = merged[-1]
        # Check if intervals overlap or touch
        if current["from"] <= prev["to"]:
            # Merge them
            prev["to"] = max(prev["to"], current["to"])
        else:
            merged.append(current)
    
    return merged
