import csv
import io


def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    body = rows[1:]
    cleaned = []
    for row in body:
        row = [c.strip() for c in row]
        if len(row) < len(header):
            row = row + [""] * (len(header) - len(row))
        cleaned.append(row)
    
    di = header.index('name') if 'name' in header else None
    ui = header.index('name') if 'name' in header else None
    si = header.index('email') if 'email' in header else None
    
    # Drop rows whose "name" cell is empty
    if di is not None:
        cleaned = [r for r in cleaned if r[di] != ""]
    
    # Remove duplicate rows by "name", keeping the first occurrence
    if ui is not None:
        seen = set()
        out = []
        for r in cleaned:
            if r[ui] in seen:
                continue
            seen.add(r[ui])
            out.append(r)
        cleaned = out
    
    # Lower-case the "email" column
    if si is not None:
        cleaned = [r[:si] + [r[si].lower() if r[si] else ""] + r[si+1:] for r in cleaned]
    
    # Sort rows by "email" ascending as strings (stable)
    if si is not None:
        cleaned.sort(key=lambda r: r[si] if r[si] else "")
    
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(cleaned)
    return buf.getvalue()
