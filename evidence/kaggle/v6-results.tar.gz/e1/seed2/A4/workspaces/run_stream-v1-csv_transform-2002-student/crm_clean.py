import csv
import io

def tidy_csv(text):
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines
    lines = text.strip().split('\n')
    
    # Check if header-only
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    # Expected columns: team, city, name, score, id
    # Map indices
    idx_team = header.index('team')
    idx_city = header.index('city')
    idx_name = header.index('name')
    idx_score = header.index('score')
    idx_id = header.index('id')
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) < len(header):
            continue
        row = {}
        for i, col in enumerate(header):
            row[col] = cells[i].strip()
        rows.append(row)
    
    # Drop rows whose "id" cell is empty
    rows = [row for row in rows if row.get('id', '').strip() != '' ]
    
    # Remove duplicate rows by "city", keeping the first occurrence
    seen_cities = set()
    unique_rows = []
    for row in rows:
        city = row.get('city', '').strip()
        if city not in seen_cities:
            seen_cities.add(city)
            unique_rows.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row.get('name', '').strip(), stable=True)
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow([row.get(col, '') for col in header])
    
    return output.getvalue()
