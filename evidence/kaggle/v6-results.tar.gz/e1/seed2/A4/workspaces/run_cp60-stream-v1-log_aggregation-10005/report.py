def summarize(lines):
    """
    Summarize lines in format '<timestamp> <LEVEL> <service>: <message>'.
    Returns a dict mapping each service for levels WARN only to how many lines it has.
    Levels are case-insensitive (reported upper-case). Skip malformed lines. Omit keys with zero count.
    """
    service_counts = {}
    
    for line in lines:
        # Split the line into tokens
        parts = line.split()
        
        # Check if line has at least 4 tokens (timestamp, level, service, message)
        if len(parts) < 4:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Normalize to upper case
        service = parts[2]
        
        # Only count lines with WARN level
        if level != "WARN":
            continue
        
        # Increment count for this service
        service_counts[service] = service_counts.get(service, 0) + 1
    
    # Return only services with non-zero counts (already filtered by condition)
    return service_counts
