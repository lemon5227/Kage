def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns {name: count} per service for levels ERROR, WARN only, treating level names case-insensitively (upper-case keys),
    dropping malformed input lines.
    """
    service_counts = {}
    
    for line in lines:
        # Split by whitespace
        parts = line.split()
        
        # Need at least 3 tokens: timestamp, level, service
        if len(parts) < 3:
            continue
        
        # Extract level (index 1) and service (index 2)
        level = parts[1]
        service = parts[2]
        
        # Check if level is ERROR or WARN (case-insensitive)
        if level.upper() not in ('ERROR', 'WARN'):
            continue
        
        # Count the service
        service_counts[service] = service_counts.get(service, 0) + 1
    
    return service_counts
