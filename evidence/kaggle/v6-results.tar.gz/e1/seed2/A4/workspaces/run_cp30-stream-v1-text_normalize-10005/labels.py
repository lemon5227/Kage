import unicodedata


def to_key(text):
    """Normalize text into a key identifier.
    
    - Apply unicodedata NFKD normalization
    - Drop non-ASCII characters
    - Lower-case
    - Replace every run of characters outside [a-z0-9] with a single "_"
    - Strip leading and trailing "_"
    - Raise TypeError for non-string input
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we need to replace any sequence of non-alphanumeric characters with a single underscore
    result = []
    current_run = []
    for char in lowercased:
        if char.isalnum():  # alphanumeric means a-z, A-Z, 0-9
            current_run.append(char)
        else:
            if current_run:
                result.append(''.join(current_run))
                current_run = []
            result.append('_')
    if current_run:
        result.append(''.join(current_run))
    
    # Join and strip leading/trailing underscores
    key = ''.join(result)
    key = key.strip('_')
    
    return key
