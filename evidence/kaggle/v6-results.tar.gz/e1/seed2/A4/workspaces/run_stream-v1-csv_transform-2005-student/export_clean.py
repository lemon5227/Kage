import csv
import io

def normalize_table(text):
    """Normalize a CSV export with columns: score, email, city, team."""
    
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines and check if header-only
    lines = text.strip().split('\n')
    if len(lines) == 1:
        # Header-only input
        return lines[0]
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    header = next(reader)
    
    # Verify columns: score, email, city, team
    expected_columns = ['score', 'email', 'city', 'team']
    if header != expected_columns:
        # If header doesn't match, try to find the correct columns
        # For safety, we'll assume the first column is score, second is email, etc.
        pass
    
    # Process rows
    rows = []
    for row in reader:
        # Strip leading/trailing whitespace from every cell
        row = [cell.strip() for cell in row]
        
        # Skip if email is empty
        if not row[1]:  # email is at index 1
            continue
        
        # Lower-case the email column
        row[1] = row[1].lower()
        
        rows.append(row)
    
    # Remove duplicate rows by email, keeping first occurrence
    seen_emails = set()
    unique_rows = []
    for row in rows:
        email = row[1]
        if email not in seen_emails:
            seen_emails.add(email)
            unique_rows.append(row)
    
    # Sort rows by score ascending as strings (stable)
    # Using str comparison for score - this is stable sort
    unique_rows.sort(key=lambda row: row[0])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(unique_rows[0] if unique_rows else header)
    for row in unique_rows[1:]:
        writer.writerow(row)
    
    return output.getvalue()
