def migrate(cfg):
    # Raise ValueError if version is not 1
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1")
    
    # Create a new dict for v2
    v2_cfg = {"version": 2}
    
    # Rename top-level keys
    if "pwd_file" in cfg:
        v2_cfg["password_file"] = cfg["pwd_file"]
    if "user" in cfg:
        v2_cfg["username"] = cfg["user"]
    
    # Move cache_size and workers into a sub-dict "network"
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    v2_cfg["network"] = network
    
    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        v2_cfg["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Keep other keys unchanged
    for key, value in cfg.items():
        if key not in ["pwd_file", "user", "cache_size", "workers", "timeout_ms"]:
            # Drop keys whose value is None
            if value is not None:
                v2_cfg[key] = value
    
    return v2_cfg
