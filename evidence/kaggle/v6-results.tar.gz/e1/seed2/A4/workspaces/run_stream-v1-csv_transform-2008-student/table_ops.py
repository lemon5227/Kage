import csv
import io


def tidy_csv(text: str) -> str:
    """
    Clean CSV text with header row (columns: id, team, name).
    
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "name" cell is empty
    - Remove duplicate rows by "id", keeping the first occurrence
    - Sort rows by "team" ascending as strings (stable)
    
    Returns cleaned CSV text with the same header.
    """
    lines = text.strip().split('\n')
    
    if len(lines) < 1:
        return ''
    
    # Parse header
    header = lines[0].split(',')
    if 'id' not in header or 'team' not in header or 'name' not in header:
        return ''
    
    # Find column indices
    id_idx = header.index('id')
    team_idx = header.index('team')
    name_idx = header.index('name')
    
    # Parse data rows
    rows = []
    seen_ids = set()
    
    for line in lines[1:]:
        if not line.strip():
            continue
        
        cells = line.split(',')
        
        # Strip whitespace from each cell
        cells = [cell.strip() for cell in cells]
        
        # Ensure we have enough columns
        if len(cells) < max(id_idx + 1, team_idx + 1, name_idx + 1):
            continue
        
        # Get values
        row_id = cells[id_idx]
        team = cells[team_idx]
        name = cells[name_idx]
        
        # Drop rows whose "name" cell is empty
        if not name:
            continue
        
        # Remove duplicate rows by "id", keeping the first occurrence
        if row_id in seen_ids:
            continue
        seen_ids.add(row_id)
        
        rows.append((row_id, team, name))
    
    # Sort rows by "team" ascending as strings (stable)
    rows.sort(key=lambda x: x[1])
    
    # Build output CSV
    output_lines = [','.join(header)]
    
    for row_id, team, name in rows:
        output_lines.append(f"{row_id},{team},{name}")
    
    return '\n'.join(output_lines)


if __name__ == '__main__':
    # Test examples
    test1 = "id,team,name\n1,A,TeamA\n2,B,TeamB\n3,A,TeamA"
    print("Test 1:", tidy_csv(test1))
    
    test2 = "id,team,name\n1,A,\n2,B,TeamB"
    print("Test 2:", tidy_csv(test2))
    
    test3 = "id,team,name"
    print("Test 3:", tidy_csv(test3))
