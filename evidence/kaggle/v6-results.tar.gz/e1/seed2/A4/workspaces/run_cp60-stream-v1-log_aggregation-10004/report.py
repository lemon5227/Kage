def digest_lines(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        if 1 >= len(parts):
            continue
        field = parts[1]
        if 2 >= len(parts) or not parts[2].endswith(':'):
            continue
        key = field.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
