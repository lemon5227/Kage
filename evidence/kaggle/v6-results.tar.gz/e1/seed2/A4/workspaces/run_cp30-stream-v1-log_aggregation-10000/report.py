def count_entries(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        if 1 >= len(parts):
            continue
        field = parts[1]
        key = field.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
