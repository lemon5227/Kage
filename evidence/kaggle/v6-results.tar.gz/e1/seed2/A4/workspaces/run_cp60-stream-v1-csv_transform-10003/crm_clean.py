import csv
import io


def tidy_csv(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    n = len(header)
    data = []
    for r in rows[1:]:
        r = [c.strip() for c in r]
        while len(r) < n:
            r.append("")
        data.append(r)
    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None
    di = idx('name')
    if di is not None:
        data = [r for r in data if r[di] != ""]
    li = idx('')
    if li is not None:
        for r in data:
            r[li] = r[li].lower()
    ui = idx('name')
    if ui is not None:
        seen = set()
        out = []
        for r in data:
            k = r[ui]
            if k in seen:
                continue
            seen.add(k)
            out.append(r)
        data = out
    si = idx('city')
    if si is not None:
        data.sort(key=lambda r: r[si])
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
