def merge_slots(intervals):
    """
    Merge overlapping intervals. Each interval is a two-element list [start, end] of integers.
    Return merged intervals in the same [start, end] list form, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # If no intervals, return empty list
    if not intervals:
        return []
    
    # Sort by start time first
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    merged = [sorted_intervals[0][:]]  # Start with the first interval
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # Check if intervals overlap (current start < last end)
        # Note: touching intervals (current start == last end) do NOT merge
        if current[0] < last[1]:
            # Overlap detected, merge them
            last[1] = max(last[1], current[1])
        else:
            # No overlap, add current interval
            merged.append(current[:])
    
    return merged
