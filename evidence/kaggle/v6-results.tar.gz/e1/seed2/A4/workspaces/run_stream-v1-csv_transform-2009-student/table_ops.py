import csv
import io

def dedupe_export(text):
    """Process CSV text and return cleaned CSV text."""
    if not text or not text.strip():
        return ''
    
    # Parse the CSV text
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Check if it's header-only
    if len(lines) == 1:
        # Strip whitespace from header cells
        header_cells = [cell.strip() for cell in lines[0].split(',')]
        return ','.join(header_cells) + '\n'
    
    # Parse header row
    header_cells = [cell.strip() for cell in lines[0].split(',')]
    if len(header_cells) != 4 or header_cells[0] != 'team' or header_cells[1] != 'name' or header_cells[2] != 'score' or header_cells[3] != 'email':
        # If header doesn't match expected columns, return as-is with stripped cells
        return ','.join(header_cells) + '\n'
    
    # Parse data rows
    data_rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = [cell.strip() for cell in line.split(',')]
        if len(cells) < 4:
            continue
        team, name, score, email = cells[0], cells[1], cells[2], cells[3]
        
        # Drop rows whose "team" cell is empty
        if not team:
            continue
        
        # Lower-case the "email" column
        email = email.lower()
        
        data_rows.append({
            'team': team,
            'name': name,
            'score': score,
            'email': email
        })
    
    # Remove duplicate rows by "team", keeping first occurrence
    seen_teams = set()
    unique_rows = []
    for row in data_rows:
        if row['team'] not in seen_teams:
            seen_teams.add(row['team'])
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x['email'])
    
    # Build output CSV
    output_lines = []
    output_lines.append(','.join(header_cells))
    for row in unique_rows:
        output_lines.append(f"{row['team']},{row['name']},{row['score']},{row['email']}")
    
    return '\n'.join(output_lines) + '\n'
