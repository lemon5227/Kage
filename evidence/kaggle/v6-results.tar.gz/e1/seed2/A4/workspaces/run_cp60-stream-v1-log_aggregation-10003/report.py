def aggregate_log(lines):
    """Aggregate log strings into {name: count} per service for levels ERROR, WARN only.
    
    Log format: "<timestamp> <LEVEL> <service>: <message>"
    - Case-insensitive level matching (upper-case keys)
    - Drops malformed input lines
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
            
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Check if level is ERROR or WARN
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Validate that service is followed by a colon (format: service: message)
        # The service should not contain a colon, and there should be a colon after it
        # We can check if the line has a colon after the third token
        # Find the position of the first colon in the line
        colon_pos = line.find(':')
        if colon_pos == -1 or colon_pos < len(service):
            # If no colon found, or colon is within the service part, skip
            continue
            
        # Count this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
