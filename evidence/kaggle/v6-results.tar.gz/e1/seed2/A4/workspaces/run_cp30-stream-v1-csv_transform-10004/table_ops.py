import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    body = rows[1:]
    cleaned = []
    for row in body:
        row = [c.strip() for c in row]
        if len(row) < len(header):
            row = row + [""] * (len(header) - len(row))
        cleaned.append(row)
    di = header.index('score') if 'score' in header else None
    ui = header.index('team') if 'team' in header else None
    si = header.index('score') if 'score' in header else None
    if di is not None:
        cleaned = [r for r in cleaned if r[di] != ""]
    if ui is not None:
        seen = set()
        out = []
        for r in cleaned:
            if r[ui] in seen:
                continue
            seen.add(r[ui])
            out.append(r)
        cleaned = out
    if si is not None:
        cleaned.sort(key=lambda r: r[si])
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(cleaned)
    return buf.getvalue()
