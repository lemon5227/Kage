def coalesce(intervals):
    """
    Merge overlapping intervals. Each interval is a dict {"start": s, "end": e} with integer values.
    Return merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raise ValueError if any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        if interval["start"] > interval["end"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    if not intervals:
        return []
    
    # Sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    merged = [sorted_intervals[0].copy()]
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # Check if intervals overlap or touch (current start <= last end)
        if current["start"] <= last["end"]:
            # Merge them
            last["end"] = max(last["end"], current["end"])
        else:
            merged.append(current.copy())
    
    return merged
