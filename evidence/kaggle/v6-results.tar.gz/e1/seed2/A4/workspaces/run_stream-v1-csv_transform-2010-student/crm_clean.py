#!/usr/bin/env python3
"""Clean exported CSV table data."""

import csv
import io


def clean_rows(text):
    """Clean an exported CSV text with header row (city, score, email, name, team).
    
    Returns cleaned CSV text with the same header.
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "score" cell is empty
    - Lower-case the "email" column
    - Remove duplicate rows by "city", keeping the first occurrence
    - Sort rows by "name" ascending as strings (stable)
    """
    # Parse CSV text
    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ''  # Empty input
    
    # Validate header
    expected_header = ['city', 'score', 'email', 'name', 'team']
    if header != expected_header:
        raise ValueError(f"Expected header {expected_header}, got {header}")
    
    # Process rows
    rows = []
    seen_cities = set()
    
    for row in reader:
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Drop rows whose "score" cell is empty
        if not cleaned_row[1]:  # score is at index 1
            continue
        
        # Lower-case the "email" column
        cleaned_row[2] = cleaned_row[2].lower()
        
        # Remove duplicate rows by "city", keeping first occurrence
        city = cleaned_row[0]
        if city in seen_cities:
            continue
        seen_cities.add(city)
        
        rows.append(cleaned_row)
    
    # Sort rows by "name" ascending as strings (stable sort)
    # Use a stable sort - Python's sorted is stable
    rows.sort(key=lambda row: row[3])  # name is at index 3
    
    # Write output CSV with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write rows
    for row in rows:
        writer.writerow(row)
    
    return output.getvalue()


if __name__ == '__main__':
    # Test example
    test_input = """city,score,email,name,team
NY,100,test@example.com,Alice,Team1
LA,200,another@example.com,Bob,Team2
NY,150,duplicate@example.com,Charlie,Team3
SF,,empty@example.com,Dave,Team4
"""
    result = clean_rows(test_input)
    print(result)
