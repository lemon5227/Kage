#!/usr/bin/env python3
"""Test the clean_rows function."""

from crm_clean import clean_rows

# Test case 1: Basic functionality
test_input = """city,score,email,name,team
NY,100,test@example.com,Alice,Team1
LA,200,another@example.com,Bob,Team2
NY,150,duplicate@example.com,Charlie,Team3
SF,,empty@example.com,Dave,Team4
"""

result = clean_rows(test_input)
print("Test 1 - Basic functionality:")
print(result)
print()

# Test case 2: Header-only input
header_only = "city,score,email,name,team"
result2 = clean_rows(header_only)
print("Test 2 - Header-only input:")
print(repr(result2))
print()

# Test case 3: Empty input
empty_input = ""
result3 = clean_rows(empty_input)
print("Test 3 - Empty input:")
print(repr(result3))
print()

# Test case 4: Whitespace stripping
whitespace_test = """ city , 100 , test@example.com , Alice , Team1 
 LA , 200 , Another@Example.com , Bob , Team2 
"""
result4 = clean_rows(whitespace_test)
print("Test 4 - Whitespace stripping:")
print(result4)
