#!/usr/bin/env python3
"""Run the test script."""
import sys
sys.path.insert(0, '.')
from test_crm import *
