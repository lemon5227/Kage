import unicodedata


def slugify(text):
    """Build a URL slug from text.
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with a single "-", and
    strips leading/trailing "-".
    
    Raises TypeError if text is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we replace any sequence of non-alphanumeric characters with "-"
    slug = ''
    for char in lowercased:
        if char.isalnum():  # alphanumeric means a-z, A-Z, 0-9
            slug += char
        else:
            # If we encounter a non-alphanumeric character, add a single "-"
            # but only if the previous character was not already a "-"
            if not slug.endswith('-'):
                slug += '-'
    
    # Strip leading and trailing "-"
    slug = slug.strip('-')
    
    return slug
