import unicodedata
import re


def make_handle(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply unicodedata NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = re.sub(r'[^a-z0-9]+', '-', lower)
    
    # Strip leading and trailing "-"
    result = result.strip('-')
    
    # If the result is longer than 23 characters, cut to 23 and then strip a trailing "-"
    if len(result) > 23:
        result = result[:23]
        result = result.strip('-')
    
    return result
