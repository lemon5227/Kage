def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns {name: count} per service for levels ERROR and WARN only,
    treating level names case-insensitively (upper-case keys), dropping malformed input lines.
    """
    counts = {}
    for line in lines:
        # Split the line into whitespace-delimited tokens
        tokens = line.split()
        # Need at least 3 tokens: timestamp, LEVEL, service:
        if len(tokens) < 3:
            continue
        
        level = tokens[1]
        service = tokens[2]
        
        # Check if level is ERROR or WARN (case-insensitive)
        if level.upper() not in ('ERROR', 'WARN'):
            continue
        
        # Count the service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
