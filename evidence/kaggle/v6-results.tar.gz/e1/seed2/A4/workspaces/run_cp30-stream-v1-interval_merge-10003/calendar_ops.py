def merge_slots(intervals):
    """
    Merge overlapping or touching time intervals.
    
    Args:
        intervals: List of dicts with "start" and "end" keys, where start and end are integers.
        
    Returns:
        List of merged interval dicts sorted by start ascending.
        
    Raises:
        ValueError: If any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        if interval["start"] > interval["end"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping or touching intervals
    merged = []
    if not sorted_intervals:
        return merged
    
    current_start = sorted_intervals[0]["start"]
    current_end = sorted_intervals[0]["end"]
    
    for interval in sorted_intervals[1:]:
        start = interval["start"]
        end = interval["end"]
        
        # If the current interval overlaps or touches the next interval, merge them
        if start <= current_end:
            current_end = max(current_end, end)
        else:
            # No overlap, add the current interval and start a new one
            merged.append({"start": current_start, "end": current_end})
            current_start = start
            current_end = end
    
    # Add the last interval
    merged.append({"start": current_start, "end": current_end})
    
    return merged
