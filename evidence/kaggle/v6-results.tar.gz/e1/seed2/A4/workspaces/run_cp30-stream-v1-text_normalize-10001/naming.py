import unicodedata


def slugify(text):
    """Convert a title into a handle (slug).
    
    Args:
        text: A string to convert.
        
    Returns:
        A slugified string.
        
    Raises:
        TypeError: If text is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we replace any sequence of non-alphanumeric characters with "_"
    slugified = ''
    for char in lowercased:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            slugified += char
        else:
            # If we encounter a non-alphanumeric character, add "_" only once
            if not slugified.endswith('_'):
                slugified += '_'
    
    # Strip leading and trailing "_"
    return slugified.strip('_')
