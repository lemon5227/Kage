def coalesce(intervals):
    """Merge overlapping intervals.
    
    Args:
        intervals: List of dicts with "start" and "end" keys, integer values.
        
    Returns:
        List of merged interval dicts sorted by start ascending.
        
    Raises:
        ValueError: If any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        if interval["start"] > interval["end"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    if not intervals:
        return []
    
    # Sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    merged = [sorted_intervals[0].copy()]
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # Check if intervals overlap or touch (current start <= last end)
        if current["start"] <= last["end"]:
            # Merge them
            last["end"] = max(last["end"], current["end"])
        else:
            # No overlap, add new interval
            merged.append(current.copy())
    
    return merged
