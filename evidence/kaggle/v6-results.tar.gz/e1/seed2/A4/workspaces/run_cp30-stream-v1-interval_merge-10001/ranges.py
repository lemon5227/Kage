def merge_slots(intervals):
    """
    Merge overlapping intervals. Each interval is a dict {"from": s, "to": e} with integer values.
    Return merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
    
    if not intervals:
        return []
    
    # Sort by start (from) first
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    merged = []
    current = sorted_intervals[0].copy()
    
    for interval in sorted_intervals[1:]:
        # Check if intervals overlap or touch
        if interval["from"] <= current["to"]:
            # Merge them
            current["to"] = max(current["to"], interval["to"])
        else:
            # No overlap, add current and start new
            merged.append(current)
            current = interval.copy()
    
    # Add the last interval
    merged.append(current)
    
    return merged
