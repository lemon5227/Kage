def count_entries(lines):
    """
    Process lines in format: <timestamp> <LEVEL> <service>: <message>
    Return a dict mapping each level (case-insensitive, upper-case) to its count.
    Skip malformed lines and omit keys with zero count.
    """
    level_counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, and the rest (service: message)
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report as upper-case
        
        # Validate timestamp format (basic check - should be non-empty)
        if not timestamp:
            continue
        
        # The rest of the line is "service: message"
        # We don't need to validate this further for counting purposes
        # Just ensure we have a valid level
        if not level:
            continue
        
        # Increment count for this level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    # Omit keys with zero count (already handled by not adding them)
    return level_counts
