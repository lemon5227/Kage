def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    fi = int(arguments['field_index'])
    mt = int(arguments['min_tokens'])
    norm = arguments.get('normalize', 'none')
    suf = arguments.get('require_suffix', '')
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + repr(mt) + ':\n'
        '            continue\n'
        '        if ' + repr(fi) + ' >= len(parts):\n'
        '            continue\n'
        '        if ' + repr(suf) + ' and (' + repr(fi + 1) + ' >= len(parts) or not parts[' + repr(fi + 1) + '].endswith(' + repr(suf) + ')):\n'
        '            continue\n'
        '        val = parts[' + repr(fi) + ']\n'
        '        if ' + repr(norm) + ' == "upper":\n'
        '            val = val.upper()\n'
        '        elif ' + repr(norm) + ' == "lower":\n'
        '            val = val.lower()\n'
        '        counts[val] = counts.get(val, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], fp)
    with open(path, 'w') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn}
