def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    fi = arguments['filter_field_index']
    allowed = [str(v).upper() for v in arguments['allowed_values']]
    gi = arguments['group_field_index']
    mt = arguments['min_tokens']
    suf = arguments.get('require_suffix', '') or ''
    norm = arguments.get('normalize', 'none')
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + str(mt) + ':\n'
        '            continue\n'
        '        if parts[' + str(fi) + '].upper() not in ' + repr(allowed) + ':\n'
        '            continue\n'
        '        tok = parts[' + str(gi) + ']\n'
        '        if ' + repr(suf) + ' and not tok.endswith(' + repr(suf) + '):\n'
        '            continue\n'
        '        if ' + repr(suf) + ':\n'
        '            tok = tok[:-len(' + repr(suf) + ')]\n'
        '        if not tok:\n'
        '            continue\n'
        '        if ' + repr(norm) + ' == "upper":\n'
        '            tok = tok.upper()\n'
        '        elif ' + repr(norm) + ' == "lower":\n'
        '            tok = tok.lower()\n'
        '        counts[tok] = counts.get(tok, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], fp)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn, 'bytes_written': len(src)}
