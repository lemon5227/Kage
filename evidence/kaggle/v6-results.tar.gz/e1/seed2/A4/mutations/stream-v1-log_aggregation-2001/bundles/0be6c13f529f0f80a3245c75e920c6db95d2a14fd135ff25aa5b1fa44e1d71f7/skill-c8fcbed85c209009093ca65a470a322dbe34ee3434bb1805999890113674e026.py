import re

def run(arguments, context):
    import os
    path = os.path.join(context['workspace_dir'], arguments['file_path'])
    fn = arguments['function_name']
    idx = arguments.get('field_index', 1)
    up = arguments.get('uppercase', True)
    suffix = arguments.get('required_suffix', ':')
    min_tok = arguments.get('min_tokens', 3)
    src = ''
    if os.path.exists(path):
        with open(path) as f:
            src = f.read()
    body = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        s = line.strip()\n'
        '        if ' + repr(suffix) + ' and ' + repr(suffix) + ' not in s:\n'
        '            continue\n'
        '        parts = s.split()\n'
        '        if len(parts) < ' + str(min_tok) + ':\n'
        '            continue\n'
        '        key = parts[' + str(idx) + ']\n'
        '        if ' + repr(up) + ':\n'
        '            key = key.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    pat = re.compile(r'^def\s+' + re.escape(fn) + r'\s*\(.*?(?=^def\s|\Z)', re.S | re.M)
    if pat.search(src):
        src = pat.sub(body, src)
    else:
        src = src.rstrip() + '\n\n' + body
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': arguments['file_path']}
