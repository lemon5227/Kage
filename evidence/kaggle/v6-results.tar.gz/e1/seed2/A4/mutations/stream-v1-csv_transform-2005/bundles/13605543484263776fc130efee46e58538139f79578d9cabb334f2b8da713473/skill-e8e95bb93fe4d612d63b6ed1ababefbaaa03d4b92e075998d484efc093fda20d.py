import csv, io

def run(arguments, context):
    fp = arguments['file_path']
    fn = arguments['function_name']
    drop = arguments['drop_empty_column']
    low = arguments['lower_column']
    ded = arguments['dedupe_column']
    srt = arguments['sort_column']
    src = (
        'import csv\nimport io\n\n'
        'def ' + fn + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    data = [[c.strip() for c in r] for r in rows[1:]]\n'
        '    def idx(name):\n'
        '        return header.index(name) if name in header else None\n'
        '    di, li, qi, si = idx(' + repr(drop) + '), idx(' + repr(low) + '), idx(' + repr(ded) + '), idx(' + repr(srt) + ')\n'
        '    if di is not None:\n'
        '        data = [r for r in data if len(r) > di and r[di] != ""]\n'
        '    if li is not None:\n'
        '        for r in data:\n'
        '            if len(r) > li:\n'
        '                r[li] = r[li].lower()\n'
        '    if qi is not None:\n'
        '        seen = set()\n'
        '        out = []\n'
        '        for r in data:\n'
        '            k = r[qi] if len(r) > qi else None\n'
        '            if k in seen:\n'
        '                continue\n'
        '            seen.add(k)\n'
        '            out.append(r)\n'
        '        data = out\n'
        '    if si is not None:\n'
        '        data.sort(key=lambda r: r[si] if len(r) > si else "")\n'
        '    buf = io.StringIO()\n'
        '    w = csv.writer(buf, lineterminator="\\n")\n'
        '    w.writerow(header)\n'
        '    w.writerows(data)\n'
        '    return buf.getvalue()\n'
    )
    path = context['workspace_dir'].rstrip('/') + '/' + fp
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'bytes_written': len(src)}
