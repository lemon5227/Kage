def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    idf = arguments['id_field']
    wf = arguments['weight_field']
    vf = arguments['value_field']
    src = '''def {fn}(items, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    entries = []
    for item in items:
        w = item["{wf}"]
        v = item["{vf}"]
        if w <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["{idf}"], w, v))
    entries.sort(key=lambda e: e[0])
    n = len(entries)
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())
    for i in range(n):
        iid, w, v = entries[i]
        for c in range(capacity, w - 1, -1):
            prev = dp[c - w]
            if prev is None:
                continue
            cv = prev[0] + v
            cids = prev[1] + (iid,)
            cur = dp[c]
            if cur is None or cv > cur[0]:
                dp[c] = (cv, cids)
            elif cv == cur[0] and sorted(cids) < sorted(cur[1]):
                dp[c] = (cv, cids)
    best_v = None
    best_ids = None
    for c in range(capacity + 1):
        e = dp[c]
        if e is None:
            continue
        v, ids = e
        sids = sorted(ids)
        if best_v is None or v > best_v:
            best_v = v
            best_ids = sids
        elif v == best_v and sids < best_ids:
            best_ids = sids
    return best_ids if best_ids is not None else []
'''.format(fn=fn, idf=idf, wf=wf, vf=vf)
    path = os.path.join(context['workspace_dir'], fp)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'function': fn}
