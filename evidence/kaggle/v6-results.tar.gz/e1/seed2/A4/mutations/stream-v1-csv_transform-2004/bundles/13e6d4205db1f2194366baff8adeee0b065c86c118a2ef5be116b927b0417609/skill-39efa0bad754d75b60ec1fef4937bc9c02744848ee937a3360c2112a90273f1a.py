import os

def run(arguments, context):
    path = os.path.join(context['workspace_dir'], arguments['file_path'])
    fn = arguments['function_name']
    idx = arguments['field_index']
    min_tokens = arguments['min_tokens']
    norm = arguments['normalize']
    suffix = arguments.get('require_suffix', '')
    lines = [
        f'def {fn}(lines):',
        '    counts = {}',
        '    for line in lines:',
        '        if not isinstance(line, str):',
        '            continue',
        '        parts = line.split()',
        f'        if len(parts) < {min_tokens}:',
        '            continue',
        f'        if {idx} >= len(parts):',
        '            continue',
        f'        field = parts[{idx}]',
    ]
    if suffix:
        lines += [
            f'        if {idx + 1} >= len(parts) or not parts[{idx + 1}].endswith({suffix!r}):',
            '            continue',
        ]
    if norm == 'upper':
        lines.append('        key = field.upper()')
    elif norm == 'lower':
        lines.append('        key = field.lower()')
    else:
        lines.append('        key = field')
    lines += [
        '        counts[key] = counts.get(key, 0) + 1',
        '    return counts',
    ]
    with open(path, 'w') as f:
        f.write('\n'.join(lines) + '\n')
    return {'success': True, 'path': arguments['file_path']}
