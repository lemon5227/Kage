import csv, io

def run(arguments, context):
    fp = arguments['file_path']
    fn = arguments['function_name']
    drop_col = arguments['drop_empty_column']
    dedup_col = arguments['dedup_column']
    sort_col = arguments['sort_column']
    src = '''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    body = rows[1:]
    cleaned = []
    for row in body:
        row = [c.strip() for c in row]
        if len(row) < len(header):
            row = row + [""] * (len(header) - len(row))
        cleaned.append(row)
    di = header.index({drop_col!r}) if {drop_col!r} in header else None
    ui = header.index({dedup_col!r}) if {dedup_col!r} in header else None
    si = header.index({sort_col!r}) if {sort_col!r} in header else None
    if di is not None:
        cleaned = [r for r in cleaned if r[di] != ""]
    if ui is not None:
        seen = set()
        out = []
        for r in cleaned:
            if r[ui] in seen:
                continue
            seen.add(r[ui])
            out.append(r)
        cleaned = out
    if si is not None:
        cleaned.sort(key=lambda r: r[si])
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\\n")
    w.writerow(header)
    w.writerows(cleaned)
    return buf.getvalue()
'''.format(fn=fn, drop_col=drop_col, dedup_col=dedup_col, sort_col=sort_col)
    path = context['workspace_dir'].rstrip('/') + '/' + fp
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'file_path': fp, 'function_name': fn}
