import csv, io

def run(arguments, context):
    fp = arguments['file_path']
    fn = arguments['function_name']
    drop_col = arguments['drop_empty_column']
    dedup_col = arguments['dedup_column']
    sort_col = arguments['sort_column']
    lower_col = arguments.get('lower_column', '')
    src = '''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    n = len(header)
    data = []
    for r in rows[1:]:
        r = [c.strip() for c in r]
        while len(r) < n:
            r.append("")
        data.append(r)
    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None
    di = idx({drop_col!r})
    if di is not None:
        data = [r for r in data if r[di] != ""]
    li = idx({lower_col!r})
    if li is not None:
        for r in data:
            r[li] = r[li].lower()
    ui = idx({dedup_col!r})
    if ui is not None:
        seen = set()
        out = []
        for r in data:
            k = r[ui]
            if k in seen:
                continue
            seen.add(k)
            out.append(r)
        data = out
    si = idx({sort_col!r})
    if si is not None:
        data.sort(key=lambda r: r[si])
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\\n")
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
'''.format(fn=fn, drop_col=drop_col, dedup_col=dedup_col, sort_col=sort_col, lower_col=lower_col)
    path = context['workspace_dir'].rstrip('/') + '/' + fp
    with open(path, 'w') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn, 'bytes_written': len(src)}
