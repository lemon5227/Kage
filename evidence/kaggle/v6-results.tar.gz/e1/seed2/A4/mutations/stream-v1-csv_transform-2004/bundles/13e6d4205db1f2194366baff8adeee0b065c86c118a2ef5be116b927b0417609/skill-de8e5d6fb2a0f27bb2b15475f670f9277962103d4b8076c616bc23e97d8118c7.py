def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    idf = arguments['id_field']
    wf = arguments['weight_field']
    vf = arguments['value_field']
    src = (
        'def {fn}(items, capacity):\n'
        '    if capacity < 0:\n'
        '        raise ValueError("capacity must be non-negative")\n'
        '    entries = []\n'
        '    for item in items:\n'
        '        w = item["{wf}"]\n'
        '        v = item["{vf}"]\n'
        '        if w <= 0:\n'
        '            raise ValueError("weight must be positive")\n'
        '        entries.append((item["{idf}"], w, v))\n'
        '    best = [(0, ()) for _ in range(capacity + 1)]\n'
        '    for iid, w, v in entries:\n'
        '        for c in range(capacity, w - 1, -1):\n'
        '            pv, pi = best[c - w]\n'
        '            cv = pv + v\n'
        '            ci = tuple(sorted(pi + (iid,)))\n'
        '            bv, bi = best[c]\n'
        '            if cv > bv or (cv == bv and ci < bi):\n'
        '                best[c] = (cv, ci)\n'
        '    return list(best[capacity][1])\n'
    ).format(fn=fn, idf=idf, wf=wf, vf=vf)
    path = os.path.join(context['workspace_dir'], fp)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'function': fn}
