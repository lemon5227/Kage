import os

def run(arguments, context):
    fp = arguments['file_path']
    fn = arguments['function_name']
    fi = arguments['field_index']
    mt = arguments['min_tokens']
    norm = arguments['normalize']
    suf = arguments['require_suffix']
    ffi = arguments['filter_field_index']
    fv = arguments['filter_value']
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + repr(mt) + ':\n'
        '            continue\n'
        '        if ' + repr(ffi) + ' >= 0:\n'
        '            if ' + repr(ffi) + ' >= len(parts):\n'
        '                continue\n'
        '            if parts[' + repr(ffi) + '].upper() != ' + repr(fv.upper()) + ':\n'
        '                continue\n'
        '        if ' + repr(fi) + ' >= len(parts):\n'
        '            continue\n'
        '        val = parts[' + repr(fi) + ']\n'
        '        if ' + repr(suf) + ':\n'
        '            if not val.endswith(' + repr(suf) + '):\n'
        '                continue\n'
        '            val = val[:-len(' + repr(suf) + ')]\n'
        '        if not val:\n'
        '            continue\n'
        '        if ' + repr(norm) + ' == "upper":\n'
        '            val = val.upper()\n'
        '        elif ' + repr(norm) + ' == "lower":\n'
        '            val = val.lower()\n'
        '        counts[val] = counts.get(val, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], fp)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'bytes_written': len(src)}
