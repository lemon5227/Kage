def digest_lines(lines):
    """
    Process log lines in format: <timestamp> <LEVEL> <service>: <message>
    Returns a dict mapping each level (upper-case) to its count.
    Malformed lines are skipped.
    """
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Check if the second part looks like a level (non-empty)
        level = parts[1].upper()
        if not level or not level.isalpha():
            continue
        
        # Count this level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    # Return only non-zero counts
    return {level: count for level, count in level_counts.items() if count > 0}
