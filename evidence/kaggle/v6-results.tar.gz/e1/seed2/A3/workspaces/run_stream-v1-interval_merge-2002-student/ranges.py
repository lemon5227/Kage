def coalesce(intervals):
    """Merge overlapping intervals.

    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals in the same [start, end] list form, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] are merged.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate and normalize
    normalized = []
    for interval in intervals:
        start, end = interval
        if start > end:
            raise ValueError(f"invalid interval: start {start} is greater than end {end}")
        normalized.append((start, end))

    # Sort by start
    normalized.sort()

    # Merge overlapping intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching: extend the current interval
            if end > merged[-1][1]:
                merged[-1] = [merged[-1][0], end]
        else:
            merged.append([start, end])

    return merged
