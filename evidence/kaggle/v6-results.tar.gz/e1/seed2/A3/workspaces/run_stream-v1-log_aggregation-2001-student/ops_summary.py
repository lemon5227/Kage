def tally_events(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        # Check if second part looks like a level (common log levels)
        level = parts[1].upper()
        # Common log levels to consider
        valid_levels = {'DEBUG', 'INFO', 'WARN', 'WARNING', 'ERROR', 'FATAL', 'CRITICAL'}
        if level not in valid_levels:
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
