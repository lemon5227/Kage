import csv
import io

def clean_rows(text):
    """Clean an exported CSV table with specified rules."""
    # Parse the CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Validate expected columns
    expected_cols = ['city', 'score', 'email', 'name', 'team']
    if header != expected_cols:
        # If header doesn't match, still process but use the actual header
        pass
    
    # Process data rows (starting from index 1)
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        new_row = [cell.strip() for cell in row]
        cleaned_rows.append(new_row)
    
    # Step 2: Drop rows whose "score" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if row[1] == '':  # score is at index 1
            continue
        filtered_rows.append(row)
    
    # Step 3: Lower-case the "email" column (index 2)
    for row in filtered_rows:
        row[2] = row[2].lower()
    
    # Step 4: Remove duplicate rows by "city", keeping the first occurrence
    seen_cities = set()
    deduped_rows = []
    for row in filtered_rows:
        city = row[0]
        if city not in seen_cities:
            seen_cities.add(city)
            deduped_rows.append(row)
    
    # Step 5: Sort rows by "name" ascending as strings (stable)
    # Use a stable sort - Python's sorted is stable
    deduped_rows.sort(key=lambda row: row[3])  # name is at index 3
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(deduped_rows)
    
    return output.getvalue()
