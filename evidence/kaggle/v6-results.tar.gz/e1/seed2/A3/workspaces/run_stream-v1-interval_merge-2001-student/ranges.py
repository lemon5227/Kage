def merge_bookings(intervals):
    # Validate all intervals
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Interval {start}, {end} has start > end")
    
    # If no intervals, return empty list
    if not intervals:
        return []
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = [sorted_intervals[0][:]]  # Start with the first interval
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # If current starts at or before the last ends, they overlap or touch
        if current[0] <= last[1]:
            # Merge them by taking the minimum start and maximum end
            merged[-1][0] = min(last[0], current[0])
            merged[-1][1] = max(last[1], current[1])
        else:
            # No overlap, add current interval
            merged.append(current[:])
    
    return merged
