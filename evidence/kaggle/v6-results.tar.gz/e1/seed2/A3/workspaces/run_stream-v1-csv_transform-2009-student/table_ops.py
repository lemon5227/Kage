import csv
import io


def dedupe_export(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip whitespace from every cell
    cleaned = [[cell.strip() for cell in row] for row in data]

    # drop rows whose "team" cell is empty
    try:
        team_idx = header.index("team")
    except ValueError:
        team_idx = None

    if team_idx is not None:
        cleaned = [row for row in cleaned if len(row) > team_idx and row[team_idx] != ""]

    # lower-case the "email" column
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    if email_idx is not None:
        for row in cleaned:
            if len(row) > email_idx:
                row[email_idx] = row[email_idx].lower()

    # remove duplicate rows by "team", keeping the first occurrence
    if team_idx is not None:
        seen = set()
        deduped = []
        for row in cleaned:
            key = row[team_idx] if len(row) > team_idx else None
            if key in seen:
                continue
            seen.add(key)
            deduped.append(row)
        cleaned = deduped

    # sort rows by "email" ascending as strings (stable)
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    if email_idx is not None:
        cleaned.sort(key=lambda row: row[email_idx] if len(row) > email_idx else "", stable=True)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
