#!/usr/bin/env python3
"""Clean exported CSV table text."""

import csv
import io


def normalize_table(text):
    """Clean an exported table.
    
    Input: CSV text with header row (columns: score, team, id, name, city)
    Returns: Cleaned CSV text with the same header.
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ''
    
    # Validate header columns
    expected_cols = ['score', 'team', 'id', 'name', 'city']
    if len(header) != len(expected_cols):
        # If header doesn't match, still process what we have
        pass
    
    # Strip whitespace from all cells and collect rows
    rows = []
    for row in reader:
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Drop rows where "team" cell is empty
        if len(cleaned_row) > 1 and cleaned_row[1] == '':
            continue
        
        rows.append(cleaned_row)
    
    # Remove duplicate rows by "score", keeping first occurrence
    seen_scores = set()
    unique_rows = []
    for row in rows:
        if len(row) < 1:
            continue
        score = row[0]
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort rows by "id" ascending as strings (stable)
    # The id is at index 2
    unique_rows.sort(key=lambda row: row[2] if len(row) > 2 else '')
    
    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    if header:
        writer.writerow(header)
    
    # Write data rows
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()


if __name__ == '__main__':
    # Test with sample input
    sample = """score,team,id,name,city
100,A,1,Team A,City A
90,B,2,Team B,City B
100,A,3,Team A Duplicate,City A
50,C,,Team C,City C
"""
    result = normalize_table(sample)
    print(result)
