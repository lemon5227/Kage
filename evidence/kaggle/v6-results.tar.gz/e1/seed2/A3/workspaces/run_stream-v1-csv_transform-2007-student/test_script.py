#!/usr/bin/env python3
from export_clean import normalize_table

sample = """score,team,id,name,city
100,A,1,Team A,City A
90,B,2,Team B,City B
100,A,3,Team A Duplicate,City A
50,C,,Team C,City C
"""

result = normalize_table(sample)
print(result)
