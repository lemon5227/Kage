def merge_bookings(intervals):
    """Merge overlapping time ranges.

    Each interval is a dict {"from": s, "to": e} with integer values.
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate and collect intervals
    valid_intervals = []
    for interval in intervals:
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
        valid_intervals.append((s, e))

    if not valid_intervals:
        return []

    # Sort by start time
    valid_intervals.sort(key=lambda x: x[0])

    merged = []
    for s, e in valid_intervals:
        if not merged:
            merged.append([s, e])
        else:
            last_start, last_end = merged[-1]
            if s <= last_end:  # real overlap
                merged[-1][1] = max(last_end, e)
            else:
                merged.append([s, e])

    # Convert back to dicts and sort by start
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})

    return result
