import csv
import io

def normalize_table(text):
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines and parse CSV
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Parse header
    header = lines[0].strip().split(',')
    if len(header) != 4 or header[0] != 'score' or header[1] != 'email' or header[2] != 'city' or header[3] != 'team':
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) != 4:
            continue
        score, email, city, team = [cell.strip() for cell in cells]
        
        # Skip rows with empty email
        if not email:
            continue
        
        # Lower-case the email column
        email = email.lower()
        
        rows.append({
            'score': score,
            'email': email,
            'city': city,
            'team': team
        })
    
    # Remove duplicate rows by email, keeping first occurrence
    seen_emails = set()
    unique_rows = []
    for row in rows:
        if row['email'] not in seen_emails:
            seen_emails.add(row['email'])
            unique_rows.append(row)
    
    # Sort rows by score ascending as strings (stable)
    unique_rows.sort(key=lambda x: x['score'])
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(['score', 'email', 'city', 'team'])
    for row in unique_rows:
        writer.writerow([row['score'], row['email'], row['city'], row['team']])
    
    return output.getvalue()
