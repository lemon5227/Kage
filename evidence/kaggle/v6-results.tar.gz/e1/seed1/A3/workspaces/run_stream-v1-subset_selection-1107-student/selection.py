def plan_batch(items, capacity):
    """Choose a subset of items maximizing total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of chosen ids.
    Ties on total gain are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on a copy so the input is never modified.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # 0/1 knapsack over capacity, tracking the best (gain, id-list) per cost.
    # best[c] = (total_gain, sorted_id_list) for the best selection with
    # total cost exactly <= c. We keep the lexicographically smallest id list
    # among selections with equal gain.
    best = [(0, []) for _ in range(capacity + 1)]

    for item_id, cost, gain in entries:
        # Iterate costs downward so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = best[c - cost]
            cand_gain = prev_gain + gain
            cand_ids = sorted(prev_ids + [item_id])
            cur_gain, cur_ids = best[c]
            if cand_gain > cur_gain or (cand_gain == cur_gain and cand_ids < cur_ids):
                best[c] = (cand_gain, cand_ids)

    # best[capacity] already accounts for "at most capacity" since we never
    # require exact fill; the empty selection is represented by (0, []).
    return best[capacity][1]
