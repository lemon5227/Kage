def count_entries(lines):
    """Count entries by level in log lines.
    
    Each line format: <timestamp> <LEVEL> <service>: <message>
    Returns a dict mapping each level (upper-case) to its count.
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
            
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Validate format: service should contain ':'
        if not service.startswith(':'):
            continue
            
        # Count the entry
        counts[level] = counts.get(level, 0) + 1
    
    # Return only non-zero counts
    return {level: count for level, count in counts.items() if count > 0}
