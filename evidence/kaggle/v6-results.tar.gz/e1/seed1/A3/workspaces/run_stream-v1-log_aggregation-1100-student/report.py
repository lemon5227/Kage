def count_entries(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        timestamp, level, rest = parts
        if ":" not in rest:
            continue
        service, _, message = rest.partition(":")
        if not service.strip() or not message.strip():
            continue
        level = level.upper()
        counts[level] = counts.get(level, 0) + 1
    return counts

def tally_events(lines):
    # Count occurrences of WARN level per service
    warn_counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        timestamp, level, rest = parts
        if ":" not in rest:
            continue
        service, _, message = rest.partition(":")
        if not service.strip() or not message.strip():
            continue
        level = level.upper()
        if level == "WARN":
            warn_counts[service] = warn_counts.get(service, 0) + 1
    return warn_counts
