def tally_events(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        timestamp, level, rest = parts
        if ":" not in rest:
            continue
        service, _, message = rest.partition(":")
        if not service.strip() or not message.strip():
            continue
        level = level.upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
