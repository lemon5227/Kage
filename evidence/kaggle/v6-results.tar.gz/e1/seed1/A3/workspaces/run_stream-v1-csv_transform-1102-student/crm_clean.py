import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "name" cell is empty
    try:
        name_idx = header.index("name")
    except ValueError:
        name_idx = None

    filtered = []
    for cells in cleaned:
        name = cells[name_idx] if name_idx is not None and name_idx < len(cells) else ""
        if name == "":
            continue
        filtered.append(cells)

    # remove duplicate rows by "id", keeping the first occurrence
    seen = set()
    deduped = []
    for cells in filtered:
        id_val = cells[header.index("id")] if header.index("id") is not None and header.index("id") < len(cells) else ""
        if id_val in seen:
            continue
        seen.add(id_val)
        deduped.append(cells)

    # sort rows by "id" ascending as strings (stable)
    try:
        id_idx = header.index("id")
    except ValueError:
        id_idx = None

    deduped.sort(key=lambda cells: cells[id_idx] if id_idx is not None and id_idx < len(cells) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
