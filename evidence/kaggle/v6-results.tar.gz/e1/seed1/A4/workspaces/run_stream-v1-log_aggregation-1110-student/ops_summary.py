def tally_events(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    - Level case may vary and must be upper-cased
    - Ignore lines that do not match the format
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip lines that don't match format
        
        # Check if second part looks like a level (non-empty string)
        level = parts[1]
        if not level:
            continue
            
        # Upper-case the level
        level_upper = level.upper()
        
        # Count it
        counts[level_upper] = counts.get(level_upper, 0) + 1
    
    return counts
