import csv
import io


def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    
    # Parse header and find column indices
    header = [c.strip() for c in rows[0]]
    id_idx = header.index("id")
    email_idx = header.index("email")
    name_idx = header.index("name")
    
    # Process data rows
    out_rows = []
    seen = set()
    
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        
        # Ensure row has enough columns
        if len(cells) < max(id_idx + 1, email_idx + 1, name_idx + 1):
            continue
            
        # Check if "name" is empty - drop such rows
        if cells[name_idx] == "":
            continue
        
        # Lower-case the "email" column
        cells[email_idx] = cells[email_idx].lower()
        
        # Check for duplicate by "id"
        k = cells[id_idx]
        if k in seen:
            continue
        seen.add(k)
        
        out_rows.append(cells)
    
    # Sort rows by "id" ascending as strings (stable sort)
    out_rows.sort(key=lambda r: r[id_idx])
    
    # Write output with csv module using '\n' line endings
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(out_rows)
    return buf.getvalue()
