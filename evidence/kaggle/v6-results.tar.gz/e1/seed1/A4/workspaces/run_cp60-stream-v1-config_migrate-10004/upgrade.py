def migrate(cfg):
    return None
