import sys
sys.path.insert(0, '.')
from test_crm import *
