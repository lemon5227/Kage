from crm_clean import dedupe_export

# Test case 1: Basic functionality
test_input = """id,email,score,team,city
1,john@example.com,100,team1,New York
2,jane@example.com,50,team2,Los Angeles
3,john@example.com,75,team1,Chicago
4,bob@example.com,,team3,Boston
5,alice@example.com,25,team4,Seattle"""

result = dedupe_export(test_input)
print("Test 1 - Basic functionality:")
print(result)
print()

# Test case 2: Header-only input
test_input2 = """id,email,score,team,city"""
result2 = dedupe_export(test_input2)
print("Test 2 - Header-only input:")
print(repr(result2))
print()

# Test case 3: Empty string input
test_input3 = ""
result3 = dedupe_export(test_input3)
print("Test 3 - Empty string input:")
print(repr(result3))
