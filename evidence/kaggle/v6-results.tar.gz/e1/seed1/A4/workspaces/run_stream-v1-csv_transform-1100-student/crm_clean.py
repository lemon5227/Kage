import csv
import io


def dedupe_export(text):
    """
    Process CSV text with header row (columns: id, email, score, team, city).
    Returns cleaned CSV text.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "email", keeping the first occurrence
    5. Sort rows by "score" ascending as strings (stable)
    """
    # Parse CSV text
    lines = text.strip().split('\n')
    
    if len(lines) == 0:
        return ''
    
    # Extract header
    header = lines[0].split(',')
    
    # Check if required columns exist
    required_cols = ['id', 'email', 'score', 'team', 'city']
    for col in required_cols:
        if col not in header:
            return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) != len(header):
            continue
        
        row = {}
        for i, col in enumerate(header):
            row[col] = cells[i].strip()
        rows.append(row)
    
    # Step 2: Drop rows whose "score" cell is empty
    rows = [row for row in rows if row['score'] != '' and row['score'].strip() != '']
    
    # Step 3: Lower-case the "email" column
    for row in rows:
        row['email'] = row['email'].lower()
    
    # Step 4: Remove duplicate rows by "email", keeping the first occurrence
    seen_emails = set()
    unique_rows = []
    for row in rows:
        email = row['email']
        if email not in seen_emails:
            seen_emails.add(email)
            unique_rows.append(row)
    
    # Step 5: Sort rows by "score" ascending as strings (stable)
    # Use stable sort - Python's sort is stable
    unique_rows.sort(key=lambda row: row['score'])
    
    # Build output CSV text
    output_lines = [','.join(header)]
    for row in unique_rows:
        # Preserve original order of columns from header
        values = []
        for col in header:
            values.append(row[col])
        output_lines.append(','.join(values))
    
    return '\n'.join(output_lines)


if __name__ == '__main__':
    # Test example
    test_input = """id,email,score,team,city
1,john@example.com,100,team1,New York
2,jane@example.com,50,team2,Los Angeles
3,john@example.com,75,team1,Chicago
4,bob@example.com,,team3,Boston
5,alice@example.com,25,team4,Seattle"""
    
    result = dedupe_export(test_input)
    print(result)
