def summarize(lines):
    result = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed line
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2].rstrip(':')
        
        if level in ('ERROR', 'WARN'):
            result[service] = result.get(service, 0) + 1
    
    return result
