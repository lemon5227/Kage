def summarize(lines):
    """
    Parse lines in format '<timestamp> <LEVEL> <service>: <message>'
    Return a dict mapping each level to how many lines it has.
    Levels are case-insensitive (report them upper-case).
    Skip malformed lines. Omit keys with zero count.
    """
    level_counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service: message
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Count the level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    # Return dict with only non-zero counts (already handled by default dict behavior)
    return level_counts
