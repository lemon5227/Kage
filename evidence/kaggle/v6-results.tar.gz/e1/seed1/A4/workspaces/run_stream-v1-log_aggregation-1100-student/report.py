def tally_events(lines):
    """
    Parse lines in format: <timestamp> <LEVEL> <service>: <message>
    Count occurrences of WARN level per service.
    Skip malformed lines. Return dict with only services having count > 0.
    """
    service_counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report as upper-case
        service_part = parts[2]
        
        # Check if service part contains a colon (service: message)
        if ':' not in service_part:
            continue
        
        # Extract the service name (before the colon)
        service = service_part.split(':')[0]
        
        # Only count WARN level
        if level == 'WARN':
            service_counts[service] = service_counts.get(service, 0) + 1
    
    # Return only services with non-zero count
    return {k: v for k, v in service_counts.items() if v > 0}
