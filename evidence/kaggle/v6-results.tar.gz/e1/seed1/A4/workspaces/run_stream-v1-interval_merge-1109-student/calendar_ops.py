def coalesce(intervals):
    # Validate that start <= end for each interval
    for interval in intervals:
        if interval["from"] > interval["to"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start (from)
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals (only real overlaps, not touching)
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            # Only merge if there's a real overlap: start < last["to"]
            if interval["from"] < last["to"]:
                # Merge by updating the end to the maximum of the two ends
                last["to"] = max(last["to"], interval["to"])
            else:
                merged.append(interval.copy())
    
    return merged
