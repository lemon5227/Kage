def digest_lines(lines):
    counts = {}
    for line in lines:
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Malformed: need at least timestamp, level, and service
            continue
        
        # Format: <timestamp> <LEVEL> <service>: <message>
        # The first part is timestamp, second is LEVEL, third is service
        level = parts[1].upper()
        
        # Increment count for this level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
