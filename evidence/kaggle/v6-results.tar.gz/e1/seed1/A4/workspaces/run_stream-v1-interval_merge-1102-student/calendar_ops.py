def coalesce(intervals):
    """Merge overlapping intervals in a list of [start, end] lists.
    
    Args:
        intervals: List of two-element lists [start, end] of integers.
        
    Returns:
        List of merged intervals sorted by start ascending.
        
    Raises:
        ValueError: If any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        if len(interval) != 2 or not isinstance(interval[0], int) or not isinstance(interval[1], int):
            raise ValueError("Each interval must be a two-element list of integers")
        start, end = interval
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if merged and start < merged[-1][1]:
            # Overlapping - merge by extending the end
            merged[-1] = [merged[-1][0], max(merged[-1][1], end)]
        else:
            merged.append(interval)
    
    return merged
