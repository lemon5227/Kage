def combine_ranges(intervals):
    """Merge overlapping bookings in intervals."""
    # Check for invalid intervals (start > end)
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Interval {start}, {end} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last_start, last_end = merged[-1]
            current_start, current_end = interval
            if current_start <= last_end:  # Overlapping or touching
                merged[-1] = [last_start, max(last_end, current_end)]
            else:
                merged.append(interval)
    
    return merged
