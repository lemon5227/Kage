import csv
import io


def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    try:
        ki = header.index("team")
    except ValueError:
        ki = None
    out_rows = []
    seen = set()
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        k = cells[ki] if ki is not None and ki < len(cells) else ""
        if k == "" or k in seen:
            continue
        seen.add(k)
        out_rows.append(cells)
    out_rows.sort(key=lambda r: r[ki] if ki is not None and ki < len(r) else "")
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(out_rows)
    return buf.getvalue()
