def merge_slots(intervals):
    """
    Merge overlapping intervals in a list of [start, end] pairs.
    
    Args:
        intervals: List of two-element lists [start, end] of integers
        
    Returns:
        List of merged intervals sorted by start ascending
        
    Raises:
        ValueError: If any interval has start > end
    """
    # Validate all intervals first
    for interval in intervals:
        if interval[0] > interval[1]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # If no intervals, return empty list
    if not intervals:
        return []
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = [sorted_intervals[0][:]]  # Start with the first interval
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # Check if current overlaps with the last merged interval
        # Overlap occurs if current start < last end (strictly less than)
        # Touching intervals like [1,3] and [3,5] are NOT merged because 3 is not < 3
        if current[0] < last[1]:
            # Merge by updating the end to the maximum of both ends
            last[1] = max(last[1], current[1])
        else:
            # No overlap, add current interval as a new merged interval
            merged.append(current[:])
    
    return merged
