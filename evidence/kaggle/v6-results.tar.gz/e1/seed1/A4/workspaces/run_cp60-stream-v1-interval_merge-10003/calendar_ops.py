def merge_slots(intervals):
    norm = []
    for iv in intervals:
        s = iv['start']
        e = iv['end']
        if s > e:
            raise ValueError("invalid interval: start %r > end %r" % (s, e))
        norm.append((s, e))
    norm.sort(key=lambda p: (p[0], p[1]))
    merged = []
    for s, e in norm:
        if merged and s <= merged[-1][1]:
            if e > merged[-1][1]:
                merged[-1][1] = e
        else:
            merged.append([s, e])
    return [{'start': s, 'end': e} for s, e in merged]
