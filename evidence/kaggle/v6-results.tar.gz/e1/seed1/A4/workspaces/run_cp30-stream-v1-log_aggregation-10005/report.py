def summarize(lines):
    """
    Summarize log lines where level is WARN.
    Each line format: <timestamp> <LEVEL> <service>: <message>
    Returns dict mapping service to count of WARN lines.
    """
    service_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Check if level is WARN
        if level == 'WARN':
            service_counts[service] = service_counts.get(service, 0) + 1
    
    # Omit keys with zero count (already handled by not adding zeros)
    return service_counts
