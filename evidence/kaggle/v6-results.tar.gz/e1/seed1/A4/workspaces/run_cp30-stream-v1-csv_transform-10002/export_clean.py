import csv
import io


def normalize_table(text):
    """Clean an exported table with CSV text input."""
    if text == "":
        return ""
    
    # Parse CSV
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    
    header = [c.strip() for c in rows[0]]
    
    # Find column indices
    name_idx = header.index("name") if "name" in header else -1
    score_idx = header.index("score") if "score" in header else -1
    id_idx = header.index("id") if "id" in header else -1
    
    # Process data rows
    out_rows = []
    seen_scores = set()
    
    for row in rows[1:]:
        # Strip whitespace from all cells
        cells = [c.strip() for c in row]
        
        # Skip if name is empty
        if name_idx >= 0 and name_idx < len(cells) and cells[name_idx] == "":
            continue
        
        # Skip duplicate by score (keep first occurrence)
        if score_idx >= 0 and score_idx < len(cells):
            score = cells[score_idx]
            if score in seen_scores:
                continue
            seen_scores.add(score)
        
        out_rows.append(cells)
    
    # Sort by id ascending as strings (stable sort)
    # Use a stable sort - Python's sort is stable
    if id_idx >= 0 and id_idx < len(out_rows[0]):
        out_rows.sort(key=lambda r: r[id_idx] if len(r) > id_idx else "")
    
    # Write output with csv module using '\n' line endings
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(out_rows)
    
    return buf.getvalue()
