import csv
import io

def clean_rows(text):
    """Clean CSV text with header row (columns: city, team, score, name, id).
    
    Returns cleaned CSV text with the same header.
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "city" cell is empty
    - Remove duplicate rows by "city", keeping the first occurrence
    - Sort rows by "score" ascending as strings (stable)
    """
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # If header-only input, return just the header line
    if len(rows) == 1:
        return '\n'.join(header)
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        new_row = [cell.strip() for cell in row]
        cleaned_rows.append(new_row)
    
    # Step 2: Drop rows whose "city" cell is empty
    # city is at index 0
    filtered_rows = []
    for row in cleaned_rows:
        if row[0] == '':
            continue
        filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "city", keeping the first occurrence
    seen_cities = set()
    deduped_rows = []
    for row in filtered_rows:
        city = row[0]
        if city not in seen_cities:
            seen_cities.add(city)
            deduped_rows.append(row)
    
    # Step 4: Sort rows by "score" ascending as strings (stable)
    # score is at index 2
    # Use stable sort - Python's sort is stable
    deduped_rows.sort(key=lambda row: row[2])
    
    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()
