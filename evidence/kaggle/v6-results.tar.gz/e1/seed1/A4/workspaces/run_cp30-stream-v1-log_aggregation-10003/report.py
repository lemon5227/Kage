def aggregate_log(lines):
    """Aggregate log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per service for levels ERROR, WARN only, treating level names case-insensitively,
    dropping malformed input lines."""
    result = {}
    for line in lines:
        parts = line.strip().split()
        if len(parts) < 3:
            continue  # malformed line
        
        # Check if second part is a valid level (ERROR or WARN, case-insensitive)
        level = parts[1].upper()
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Service is third part after the colon
        service_part = parts[2]
        if ':' not in service_part:
            continue  # malformed line
        
        service = service_part.split(':')[0]
        
        result[service] = result.get(service, 0) + 1
    
    return result
