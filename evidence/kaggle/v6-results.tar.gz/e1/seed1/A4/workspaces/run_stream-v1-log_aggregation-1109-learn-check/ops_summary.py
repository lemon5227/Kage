def digest_lines(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        if not parts[2].endswith(":"):
            continue
        key = parts[1].upper()
        if not key:
            continue
        counts[key] = counts.get(key, 0) + 1
    return counts
