def slugify(text):
    """Build a URL slug from text.
    
    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces runs of non-alphanumeric characters with a single hyphen,
    and strips leading/trailing hyphens.
    
    Args:
        text: Input string to convert to slug.
        
    Returns:
        str: URL-friendly slug.
        
    Raises:
        TypeError: If input is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lowercase
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single '-'
    slug = ''
    prev_char = None
    for char in lower_text:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                slug += '-'
            prev_char = char
        else:
            prev_char = None
    
    # Strip leading and trailing hyphens
    slug = slug.strip('-')
    
    return slug
