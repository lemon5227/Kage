def merge_slots(intervals):
    # Validate all intervals first
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        if interval["from"] > interval["to"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # If no intervals, return empty list
    if not intervals:
        return []
    
    # Sort by 'from' value
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals
    merged = [sorted_intervals[0]]
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # Check if intervals overlap or touch (current['from'] <= last['to'])
        if current["from"] <= last["to"]:
            # Merge them
            last["to"] = max(last["to"], current["to"])
        else:
            merged.append(current)
    
    return merged
