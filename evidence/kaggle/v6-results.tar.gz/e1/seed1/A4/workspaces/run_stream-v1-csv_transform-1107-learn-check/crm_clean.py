import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = [[c.strip() for c in r] for r in rows[1:]]

    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None

    di = idx('team')
    if di is not None:
        data = [r for r in data if di < len(r) and r[di] != ""]

    ci = idx('city')
    if ci is not None:
        seen = set()
        out = []
        for r in data:
            k = r[ci] if ci < len(r) else ""
            if k in seen:
                continue
            seen.add(k)
            out.append(r)
        data = out

    si = idx('name')
    if si is not None:
        data.sort(key=lambda r: r[si] if si < len(r) else "")

    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
