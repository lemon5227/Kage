def digest_lines(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        timestamp = parts[0]
        level = parts[1].upper()
        # Check if third part contains a colon (service:)
        if ':' not in parts[2]:
            continue
        # Line matches format
        counts[level] = counts.get(level, 0) + 1
    return counts
