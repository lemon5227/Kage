import unicodedata
import re

def label_id(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # Strip leading and trailing "-"
    slug = re.sub(r'[^a-z0-9]+', '-', lowercased).strip('-')
    
    return slug
