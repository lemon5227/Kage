def convert_settings(cfg):
    # Check version - raise ValueError if not version 1
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")
    
    # Create new dict with v2 layout
    result = {
        "version": 2,
        "directory": cfg.get("dir"),
        "hostname": cfg.get("host"),
        "storage": {}
    }
    
    # Add port and workers to storage if they exist
    if "port" in cfg:
        result["storage"]["port"] = cfg["port"]
    if "workers" in cfg:
        result["storage"]["workers"] = cfg["workers"]
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["dir", "host", "port", "workers", "timeout_ms", "version"]:
            if value is not None:
                result[key] = value
    
    return result
