def count_entries(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed line
        level = parts[1].upper()
        counts[level] = counts.get(level, 0) + 1
    return {k: v for k, v in counts.items() if v > 0}
