def migrate(cfg):
    # Check version
    if cfg.get("version") != 1:
        raise ValueError("Only v1 config is supported for migration")
    
    # Create new dict
    new_cfg = {"version": 2}
    
    # Rename keys
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    if "user" in cfg:
        new_cfg["username"] = cfg["user"]
    
    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    new_cfg["network"] = network
    
    # Handle timeout_ms
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged
    for key, value in cfg.items():
        if key not in ["version", "pwd_file", "user", "cache_size", "workers", "timeout_ms"]:
            # Drop keys whose value is None
            if value is not None:
                new_cfg[key] = value
    
    return new_cfg
