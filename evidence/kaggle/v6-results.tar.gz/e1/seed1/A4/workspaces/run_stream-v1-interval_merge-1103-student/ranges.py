def combine_ranges(intervals):
    # Validate intervals and sort by start
    if not intervals:
        return []
    
    # Validate each interval and sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x['start'])
    
    # Check for invalid intervals (start > end)
    for interval in intervals:
        if interval['start'] > interval['end']:
            raise ValueError("Interval start must not be greater than end")
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            current_start, current_end = merged[-1]['start'], merged[-1]['end']
            new_start, new_end = interval['start'], interval['end']
            # Only merge if there is a real overlap (new_start < current_end)
            # Touching intervals (new_start == current_end) should NOT be merged
            if new_start < current_end:
                merged[-1]['end'] = max(current_end, new_end)
            else:
                merged.append(interval)
    
    return merged
