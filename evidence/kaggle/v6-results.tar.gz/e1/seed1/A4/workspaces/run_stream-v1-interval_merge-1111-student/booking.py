def coalesce(intervals):
    """Combine overlapping time ranges in intervals."""
    # Validate intervals: start must not be greater than end
    for interval in intervals:
        if len(interval) != 2 or not isinstance(interval[0], int) or not isinstance(interval[1], int):
            raise ValueError("Each interval must be a two-element list of integers")
        start, end = interval
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort intervals by start
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if merged and start <= merged[-1][1]:
            # Overlapping or touching? Only merge if start < merged[-1][1] (real overlap)
            # Touching intervals like [1,3] and [3,5] should NOT be merged
            if start < merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append(interval)
    
    return merged
