def combine_ranges(intervals):
    """Merge overlapping intervals.
    
    Args:
        intervals: List of dicts with "begin" and "finish" keys
        
    Returns:
        List of merged interval dicts sorted by begin ascending
        
    Raises:
        ValueError: If any interval has start > end
    """
    # Validate all intervals first
    for interval in intervals:
        begin = interval["begin"]
        finish = interval["finish"]
        if begin > finish:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by begin
    sorted_intervals = sorted(intervals, key=lambda x: x["begin"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            # Check if current interval overlaps or touches the last one
            if interval["begin"] <= last["finish"]:
                # Merge by updating the finish of the last interval
                last["finish"] = max(last["finish"], interval["finish"])
            else:
                # No overlap, add the current interval
                merged.append(interval.copy())
    
    return merged
