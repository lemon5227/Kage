import unicodedata


def make_handle(text):
    """Convert a title into a handle according to the specified rules."""
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace any sequence of non-alphanumeric characters with a single hyphen
    result = []
    previous_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            # If this is a non-alphanumeric character and the previous was also non-alphanumeric, skip it
            if previous_char is not None and previous_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                continue
            # Otherwise, add a hyphen
            result.append('-')
        else:
            result.append(char)
        previous_char = char
    
    # Join the result
    handle = ''.join(result)
    
    # Strip leading and trailing "-"
    handle = handle.strip('-')
    
    # If the result is longer than 23 characters, cut it to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.strip('-')
    
    return handle
