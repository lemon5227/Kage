import csv
import io


def tidy_csv(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    
    # Find column indices
    name_idx = header.index("name") if "name" in header else None
    city_idx = header.index("city") if "city" in header else None
    
    out_rows = []
    seen = set()
    
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        # Check if name is empty
        k = cells[name_idx] if name_idx is not None and name_idx < len(cells) else ""
        if k == "" or k in seen:
            continue
        seen.add(k)
        out_rows.append(cells)
    
    # Sort by city ascending as strings (stable sort - Python's sort is stable by default)
    if city_idx is not None and out_rows and city_idx < len(out_rows[0]):
        out_rows.sort(key=lambda r: r[city_idx] if city_idx < len(r) else "")
    else:
        # If no city column, keep original order (stable)
        out_rows.sort(key=lambda r: "")
    
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(out_rows)
    return buf.getvalue()
