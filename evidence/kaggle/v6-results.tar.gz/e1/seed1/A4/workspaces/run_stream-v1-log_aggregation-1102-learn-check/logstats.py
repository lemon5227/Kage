def aggregate_log(lines):
    """Aggregate log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match.
    """
    level_counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip lines that don't match format
        # Format: timestamp level service: message
        # We need at least 3 parts to extract level
        try:
            level = parts[1].upper()
            level_counts[level] = level_counts.get(level, 0) + 1
        except (IndexError, ValueError):
            continue
    return level_counts
