import csv
import io


def normalize_table(text):
    if text == "":
        return ""
    
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    
    header = [c.strip() for c in rows[0]]
    
    # Find column indices
    name_idx = header.index("name")
    email_idx = header.index("email")
    
    # Process rows
    out_rows = []
    seen = set()
    
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        
        # Check if name is empty
        name_val = cells[name_idx] if name_idx < len(cells) else ""
        if name_val == "":
            continue
        
        # Skip duplicates by name (keep first occurrence)
        if name_val in seen:
            continue
        
        seen.add(name_val)
        
        # Lower-case the email column
        email_val = cells[email_idx].lower() if email_idx < len(cells) else ""
        
        # Create a modified row with lowercased email
        out_row = cells[:]  # copy
        out_row[email_idx] = email_val
        out_rows.append(out_row)
    
    # Sort by email ascending (stable)
    out_rows.sort(key=lambda r: r[email_idx] if email_idx < len(r) else "")
    
    # Write output with \n line endings
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(out_rows)
    
    return buf.getvalue()
