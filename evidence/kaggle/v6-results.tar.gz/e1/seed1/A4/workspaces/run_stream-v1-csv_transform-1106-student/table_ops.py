import csv
import io


def normalize_table(text):
    """Normalize CSV text with header row (columns: city, id, name, team).
    
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "team" cell is empty
    - Remove duplicate rows by "id", keeping the first occurrence
    - Sort rows by "city" ascending as strings (stable)
    
    Returns cleaned CSV text with the same header.
    """
    if text == "":
        return ""
    
    # Parse CSV
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    
    # Process header: strip whitespace from all columns
    header = [c.strip() for c in rows[0]]
    
    # Find column indices
    city_idx = header.index("city")
    id_idx = header.index("id")
    team_idx = header.index("team")
    
    # Process data rows
    out_rows = []
    seen_ids = set()
    
    for row in rows[1:]:
        # Strip whitespace from all cells
        cells = [c.strip() for c in row]
        
        # Check if team cell is empty
        if cells[team_idx] == "":
            continue
        
        # Check for duplicate by id
        row_id = cells[id_idx]
        if row_id in seen_ids:
            continue
        seen_ids.add(row_id)
        
        # Add to output rows
        out_rows.append(cells)
    
    # Sort by city ascending (stable sort)
    out_rows.sort(key=lambda r: r[city_idx])
    
    # Write output CSV with \n line endings
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(out_rows)
    
    return buf.getvalue()
