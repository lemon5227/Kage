import unicodedata

def make_handle(text):
    """Build a URL slug from text.
    
    - Apply unicodedata NFKD normalization
    - Drop non-ASCII characters
    - Lower-case
    - Replace every run of characters outside [a-z0-9] with a single "-"
    - Strip leading and trailing "-"
    """
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace any sequence of non-alphanumeric characters with a single hyphen
    slug = []
    previous_was_alnum = False
    for char in lowercased:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            slug.append(char)
            previous_was_alnum = True
        else:
            # Non-alphanumeric character - add hyphen only if not the first character
            if len(slug) > 0 or not previous_was_alnum:
                slug.append('-')
            previous_was_alnum = False
    
    result = ''.join(slug)
    
    # Strip leading and trailing "-"
    result = result.strip('-')
    
    return result
