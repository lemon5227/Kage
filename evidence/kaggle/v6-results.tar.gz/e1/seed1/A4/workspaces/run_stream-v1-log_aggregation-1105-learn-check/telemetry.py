def summarize(lines):
    """
    Process lines in format: <timestamp> <LEVEL> <service>: <message>
    Return dict mapping each service (for ERROR and WARN levels only) to count.
    Levels are case-insensitive (reported as uppercase). Skip malformed lines.
    Omit keys with zero count.
    """
    counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report as uppercase
        service_part = parts[2]
        
        # Check if the service part contains a colon (service: message)
        if ':' not in service_part:
            continue
        
        # Split service and message
        service, _, message = service_part.partition(':')
        service = service.strip()
        
        # Only count ERROR and WARN levels
        if level in ('ERROR', 'WARN'):
            counts[service] = counts.get(service, 0) + 1
    
    # Return only non-zero counts
    return {k: v for k, v in counts.items() if v > 0}
