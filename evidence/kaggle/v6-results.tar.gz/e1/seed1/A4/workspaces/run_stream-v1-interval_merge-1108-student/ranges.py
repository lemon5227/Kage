def coalesce(intervals):
    # Validate all intervals first
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        if interval["from"] > interval["to"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by 'from' value
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last = merged[-1]
            # Check if intervals overlap (not just touching)
            if interval["from"] < last["to"]:
                # Overlap - merge by taking the max of 'to' values
                new_to = max(last["to"], interval["to"])
                merged[-1] = {"from": last["from"], "to": new_to}
            else:
                # No overlap, add the interval
                merged.append(interval)
    
    return merged
