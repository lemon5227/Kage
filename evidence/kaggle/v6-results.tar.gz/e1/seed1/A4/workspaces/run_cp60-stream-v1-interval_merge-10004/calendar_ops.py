def merge_slots(intervals):
    """
    Merge overlapping intervals in a list of [start, end] integer pairs.
    
    Args:
        intervals: List of two-element lists [start, end] of integers.
        
    Returns:
        List of merged intervals sorted by start ascending.
        
    Raises:
        ValueError: If any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        if len(interval) != 2 or not isinstance(interval[0], int) or not isinstance(interval[1], int):
            raise ValueError("Each interval must be a two-element list of integers")
        start, end = interval
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort intervals by start
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals (only real overlaps, not touching)
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start < last_end:  # Overlapping only (not touching)
                # Merge by extending the end
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])
    
    return merged
