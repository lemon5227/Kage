import unicodedata


def slugify(text):
    """Build a URL slug from text.
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with a single "-",
    and strips leading/trailing "-".
    
    Raises TypeError if text is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we replace any sequence of non-alphanumeric characters with "-"
    slug = ''
    prev_char = None
    for char in lower_text:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            slug += char
        else:
            if prev_char is None or not char.isalnum():
                # Only add "-" if it's the first non-alnum or after another non-alnum
                # Actually, we want to replace runs of non-alnum with a single "-"
                # So we need to track if we've already added a "-"
                if not slug.endswith('-'):
                    slug += '-'
        prev_char = char
    
    # Strip leading and trailing "-"
    slug = slug.strip('-')
    
    return slug
