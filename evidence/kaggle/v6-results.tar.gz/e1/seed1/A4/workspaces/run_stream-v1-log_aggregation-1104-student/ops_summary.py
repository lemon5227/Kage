def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'
    
    Returns a dictionary mapping level names (uppercase) to counts, dropping malformed lines.
    """
    result = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split by spaces - we expect at least 3 parts: timestamp, LEVEL, service: message
        parts = line.split()
        
        # Need at least 3 parts to be valid
        if len(parts) < 3:
            continue
        
        # The second part (index 1) is the level
        level = parts[1]
        
        # Validate that the format is correct: after LEVEL, there should be a service name followed by colon
        # Format: <timestamp> <LEVEL> <service>: <message>
        # So parts[2] should be something like "service:" (with colon)
        if len(parts) < 3 or not parts[2].endswith(':'):
            continue
        
        # Count the level (case-insensitive, store as uppercase)
        result[level.upper()] = result.get(level.upper(), 0) + 1
    
    return result
