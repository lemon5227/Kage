def coalesce(intervals):
    """Merge overlapping or touching intervals, raising ValueError if any interval has start > end."""
    # Check for invalid intervals (start > end)
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Interval {start}, {end} has start > end")
    
    # Sort intervals by start
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping or touching intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start <= last_end + 1:  # Overlapping or touching (touching means start == last_end + 1)
                # Merge by extending the end
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])
    
    return merged
