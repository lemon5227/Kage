def coalesce(intervals):
    """Combine overlapping time ranges.
    
    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals sorted by start ascending.
    Touching intervals like [1,3] and [3,5] are NOT merged.
    Raises ValueError if any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        start, end = interval
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if merged and start < merged[-1][1]:
            # Overlapping - merge by extending the end
            merged[-1] = [merged[-1][0], max(merged[-1][1], end)]
        else:
            merged.append(interval)
    
    return merged
