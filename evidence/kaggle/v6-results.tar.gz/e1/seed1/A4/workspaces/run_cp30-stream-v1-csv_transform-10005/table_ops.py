import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text."""
    if text == "":
        return ""
    
    # Parse CSV
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    
    # Get header and strip whitespace
    header = [c.strip() for c in rows[0]]
    
    # Find column indices
    id_idx = header.index("id")
    email_idx = header.index("email")
    
    # Process data rows
    out_rows = []
    seen_emails = set()
    
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        
        # Skip if id is empty
        if cells[id_idx] == "":
            continue
        
        # Lower-case email
        email = cells[email_idx].lower()
        
        # Skip duplicates by email
        if email in seen_emails:
            continue
        seen_emails.add(email)
        
        # Store row with lowercased email
        out_rows.append(cells)
    
    # Sort by email ascending (stable sort)
    out_rows.sort(key=lambda r: r[email_idx])
    
    # Write output with \n line endings
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(out_rows)
    
    return buf.getvalue()
