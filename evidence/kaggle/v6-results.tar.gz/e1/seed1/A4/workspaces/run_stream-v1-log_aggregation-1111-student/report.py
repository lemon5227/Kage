def count_entries(lines):
    """Count entries by level in lines.
    
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (reported upper-case).
    Skip malformed lines. Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service: ...
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        # Skip if level is empty or not a valid string
        if not level:
            continue
        counts[level] = counts.get(level, 0) + 1
    
    # Return only non-zero counts (already handled by dict)
    return counts
