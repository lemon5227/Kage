import csv
import io


def dedupe_export(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    body = rows[1:]
    cleaned = []
    for row in body:
        cells = [c.strip() for c in row]
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[:len(header)]
        cleaned.append(cells)
    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None
    ki = idx('name')
    li = idx('email') if 'email' else None
    si = idx('id')
    if ki is not None:
        cleaned = [r for r in cleaned if r[ki] != ""]
    if li is not None:
        for r in cleaned:
            r[li] = r[li].lower()
    if ki is not None:
        seen = set()
        out = []
        for r in cleaned:
            k = r[ki]
            if k in seen:
                continue
            seen.add(k)
            out.append(r)
        cleaned = out
    if si is not None:
        cleaned.sort(key=lambda r: r[si], reverse=False)
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(cleaned)
    return buf.getvalue()
