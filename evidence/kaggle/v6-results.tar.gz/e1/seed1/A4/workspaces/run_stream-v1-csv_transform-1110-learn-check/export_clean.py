import csv
import io

def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    n = len(header)
    def idx(name):
        return header.index(name) if name in header else -1
    ki = idx('team')
    si = idx('email')
    li = idx('email')
    data = []
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        if len(cells) < n:
            cells += [""] * (n - len(cells))
        elif len(cells) > n:
            cells = cells[:n]
        data.append(cells)
    if ki >= 0:
        data = [r for r in data if r[ki] != ""]
    if li >= 0:
        for r in data:
            r[li] = r[li].lower()
    if ki >= 0:
        seen = set()
        ded = []
        for r in data:
            if r[ki] in seen:
                continue
            seen.add(r[ki])
            ded.append(r)
        data = ded
    if si >= 0:
        data.sort(key=lambda r: r[si], reverse=False)
    out = io.StringIO()
    w = csv.writer(out, lineterminator="\n")
    w.writerow(header)
    w.writerows(data)
    return out.getvalue()
