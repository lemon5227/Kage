import unicodedata
import re


def slugify(text):
    """Convert a title into a handle (slug)."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we replace any sequence of non-alphanumeric characters with a single underscore
    slug = re.sub(r'[^a-z0-9]+', '_', lowercased)
    
    # Strip leading and trailing "_"
    slug = slug.strip('_')
    
    return slug
