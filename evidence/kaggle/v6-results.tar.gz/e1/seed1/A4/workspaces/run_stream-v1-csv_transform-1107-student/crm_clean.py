import csv
import io

def clean_rows(text):
    """Clean an exported CSV table.
    
    Input: CSV text with header row (columns: score, id, city, team, name)
    Output: Cleaned CSV text with the same header
    
    Cleaning steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "team" cell is empty
    3. Remove duplicate rows by "city", keeping the first occurrence
    4. Sort rows by "name" ascending as strings (stable)
    
    Returns: Cleaned CSV text with '\n' line endings
    """
    # Parse CSV text into a list of rows
    lines = text.strip().split('\n')
    
    if len(lines) == 0:
        return ''
    
    # Extract header
    header = lines[0].split(',')
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        # Strip whitespace from each cell
        cells = [cell.strip() for cell in cells]
        rows.append(cells)
    
    # Drop rows whose "team" cell is empty
    # Assuming columns are: score, id, city, team, name (index 0,1,2,3,4)
    filtered_rows = []
    for row in rows:
        if len(row) < 5:
            continue
        if row[3] == '':  # team is empty
            continue
        filtered_rows.append(row)
    
    # Remove duplicate rows by "city" (index 2), keeping first occurrence
    seen_cities = set()
    deduped_rows = []
    for row in filtered_rows:
        if len(row) < 5:
            continue
        city = row[2]
        if city not in seen_cities:
            seen_cities.add(city)
            deduped_rows.append(row)
    
    # Sort rows by "name" (index 4) ascending as strings (stable)
    deduped_rows.sort(key=lambda row: row[4])
    
    # Write output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()
