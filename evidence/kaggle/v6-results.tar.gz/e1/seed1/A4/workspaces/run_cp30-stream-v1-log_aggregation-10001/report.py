def tally_events(lines):
    """Tally events by service for ERROR and WARN levels only.
    
    Log format: <timestamp> <LEVEL> <service>: <message>
    Returns: {name: count} with uppercase keys, dropping malformed lines.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Check if it's an ERROR or WARN level
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Count the event for this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
