def merge_slots(intervals):
    """
    Merge overlapping time ranges. Each interval is a dict {"start": s, "end": e} with integer values.
    Return merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        if "start" not in interval or "end" not in interval:
            raise ValueError("Each interval must have 'start' and 'end' keys")
        if interval["start"] > interval["end"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort intervals by start time
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping or touching intervals
    merged = []
    for interval in sorted_intervals:
        start = interval["start"]
        end = interval["end"]
        
        if not merged:
            merged.append({"start": start, "end": end})
        else:
            last = merged[-1]
            # If current interval overlaps or touches the last merged interval
            if start <= last["end"]:
                # Merge by updating the end of the last interval
                last["end"] = max(last["end"], end)
            else:
                merged.append({"start": start, "end": end})
    
    return merged
