def select_tasks(items, capacity):
    """
    Select tasks to maximize total score while keeping total size <= capacity.
    
    Args:
        items: List of dicts with keys 'id' (unique string), 'size' (positive int), 'score' (non-negative int)
        capacity: Maximum total size allowed
    
    Returns:
        Sorted list of ids of selected tasks
    
    Raises:
        ValueError: If capacity is negative or any size is <= 0
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if 'id' not in item or 'size' not in item or 'score' not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if not isinstance(item['id'], str):
            raise ValueError("Item id must be a string")
        if not isinstance(item['size'], int) or item['size'] <= 0:
            raise ValueError("Item size must be a positive integer")
        if not isinstance(item['score'], int) or item['score'] < 0:
            raise ValueError("Item score must be a non-negative integer")
    
    if not items:
        return []
    
    n = len(items)
    
    # dp[i][w] = (max_score, selected_ids) for first i items with total size <= w
    # We'll store the best (score, id_list) for each capacity
    # To handle ties lexicographically, we compare scores first, then id lists
    
    # Initialize: dp[w] = (max_score, selected_ids) for capacity w
    # We'll use a list where index is capacity, value is (score, tuple of ids)
    dp = [(0, ())] * (capacity + 1)
    
    # Process each item
    for i in range(n):
        item = items[i]
        size = item['size']
        score = item['score']
        item_id = item['id']
        
        # Create a copy to avoid modifying the previous dp array while iterating
        new_dp = list(dp)  # shallow copy of the list
        
        for w in range(capacity, size - 1, -1):
            # Option 1: Don't include this item
            # Option 2: Include this item (if it fits)
            current_score, current_ids = dp[w]
            include_score = dp[w - size][0] + score
            include_ids = dp[w - size][1] + (item_id,)
            
            # Compare: prefer higher score, then lexicographically smaller id list
            if include_score > current_score:
                new_dp[w] = (include_score, include_ids)
            elif include_score == current_score:
                # Compare lexicographically: smaller tuple is better
                if current_ids < include_ids:
                    new_dp[w] = (current_score, current_ids)
                # else keep include_ids
        
        dp = new_dp
    
    # The answer is the best result for capacity <= capacity
    max_score, best_ids = dp[capacity]
    
    # Return sorted list of ids
    return sorted(best_ids)
