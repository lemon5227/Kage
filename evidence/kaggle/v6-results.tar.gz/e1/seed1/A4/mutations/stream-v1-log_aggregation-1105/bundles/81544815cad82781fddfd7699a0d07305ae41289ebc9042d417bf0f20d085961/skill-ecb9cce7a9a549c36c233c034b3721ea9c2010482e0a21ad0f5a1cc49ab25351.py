def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    gi = arguments['group_field_index']
    fi = arguments['filter_field_index']
    allowed = [v.upper() for v in arguments.get('allowed_values', [])]
    mt = arguments['min_tokens']
    ci = arguments['require_colon_token_index']
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + str(mt) + ':\n'
        '            continue\n'
        '        if ' + str(ci) + ' >= 0 and ":" not in parts[' + str(ci) + ']:\n'
        '            continue\n'
        '        if ' + str(fi) + ' >= 0:\n'
        '            fv = parts[' + str(fi) + '].upper()\n'
        '            if fv not in ' + repr(allowed) + ':\n'
        '                continue\n'
        '        gv = parts[' + str(gi) + ']\n'
        '        if not gv:\n'
        '            continue\n'
        '        counts[gv] = counts.get(gv, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], fp)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'bytes_written': len(src)}
