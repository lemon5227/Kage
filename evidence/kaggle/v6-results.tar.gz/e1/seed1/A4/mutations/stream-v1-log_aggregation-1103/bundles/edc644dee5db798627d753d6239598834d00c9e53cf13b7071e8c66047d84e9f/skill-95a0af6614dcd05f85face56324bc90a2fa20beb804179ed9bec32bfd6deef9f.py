def run(arguments, context):
    import os
    path = arguments['file_path']
    if not os.path.isabs(path):
        path = os.path.join(context['workspace_dir'], path)
    fn = arguments['function_name']
    idx = int(arguments['field_index'])
    min_tokens = int(arguments['min_tokens'])
    colon_idx = int(arguments['require_colon_token_index'])
    lines = []
    lines.append('def ' + fn + '(lines):')
    lines.append('    counts = {}')
    lines.append('    for line in lines:')
    lines.append('        tokens = line.split()')
    lines.append('        if len(tokens) < ' + str(min_tokens) + ':')
    lines.append('            continue')
    if colon_idx >= 0:
        lines.append('        if not tokens[' + str(colon_idx) + '].endswith(":"):')
        lines.append('            continue')
    lines.append('        if ' + str(idx) + ' >= len(tokens):')
    lines.append('            continue')
    lines.append('        key = tokens[' + str(idx) + '].upper()')
    lines.append('        counts[key] = counts.get(key, 0) + 1')
    lines.append('    return counts')
    content = '\n'.join(lines) + '\n'
    with open(path, 'w') as f:
        f.write(content)
    return {'success': True, 'path': path, 'bytes_written': len(content.encode())}