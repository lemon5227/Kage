def run(arguments, context):
    import os
    path = arguments['file_path']
    fn = arguments['function_name']
    idx = int(arguments['field_index'])
    min_tokens = int(arguments['min_tokens'])
    colon_idx = int(arguments['require_colon_token_index'])
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        tokens = line.split()\n'
        '        if len(tokens) < ' + str(min_tokens) + ':\n'
        '            continue\n'
        '        if ' + str(colon_idx) + ' >= 0:\n'
        '            if ' + str(colon_idx) + ' >= len(tokens):\n'
        '                continue\n'
        '            if not tokens[' + str(colon_idx) + '].endswith(":"):\n'
        '                continue\n'
        '        if ' + str(idx) + ' >= len(tokens):\n'
        '            continue\n'
        '        key = tokens[' + str(idx) + '].upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    full = os.path.join(context['workspace_dir'], path)
    os.makedirs(os.path.dirname(full) or '.', exist_ok=True)
    with open(full, 'w') as f:
        f.write(src)
    return {'success': True, 'path': path, 'bytes_written': len(src)}
