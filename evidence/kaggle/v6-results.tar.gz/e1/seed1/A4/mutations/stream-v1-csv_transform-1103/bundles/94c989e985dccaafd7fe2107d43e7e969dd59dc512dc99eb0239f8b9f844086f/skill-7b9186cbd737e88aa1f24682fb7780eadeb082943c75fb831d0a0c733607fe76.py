import json

def run(arguments, context):
    path = arguments['file_path']
    fn = arguments['function_name']
    key = arguments['key_column']
    code = f'''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    try:
        ki = header.index("{key}")
    except ValueError:
        ki = None
    out_rows = []
    seen = set()
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        k = cells[ki] if ki is not None and ki < len(cells) else ""
        if k == "" or k in seen:
            continue
        seen.add(k)
        out_rows.append(cells)
    out_rows.sort(key=lambda r: r[ki] if ki is not None and ki < len(r) else "")
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\\n")
    w.writerow(header)
    w.writerows(out_rows)
    return buf.getvalue()
'''
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': path, 'bytes_written': len(code)}
