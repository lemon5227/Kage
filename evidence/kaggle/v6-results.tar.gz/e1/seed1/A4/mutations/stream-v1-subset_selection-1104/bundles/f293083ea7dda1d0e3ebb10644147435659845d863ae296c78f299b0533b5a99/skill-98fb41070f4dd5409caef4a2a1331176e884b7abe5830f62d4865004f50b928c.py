def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    idf = arguments['id_field']
    wf = arguments['weight_field']
    vf = arguments['value_field']
    src = '''def {fn}(items, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    work = []
    for item in items:
        w = item["{wf}"]
        if w <= 0:
            raise ValueError("weight must be positive")
        work.append((item["{idf}"], w, item["{vf}"]))
    best = [(0, ()) for _ in range(capacity + 1)]
    for iid, w, v in work:
        for c in range(capacity, w - 1, -1):
            pv, pi = best[c - w]
            cv = pv + v
            ci = tuple(sorted(pi + (iid,)))
            bv, bi = best[c]
            if cv > bv or (cv == bv and ci < bi):
                best[c] = (cv, ci)
    return list(best[capacity][1])
'''.format(fn=fn, idf=idf, wf=wf, vf=vf)
    path = os.path.join(context['workspace_dir'], fp)
    with open(path, 'w') as f:
        f.write(src)
    return {"success": True, "file_path": fp, "function_name": fn}
