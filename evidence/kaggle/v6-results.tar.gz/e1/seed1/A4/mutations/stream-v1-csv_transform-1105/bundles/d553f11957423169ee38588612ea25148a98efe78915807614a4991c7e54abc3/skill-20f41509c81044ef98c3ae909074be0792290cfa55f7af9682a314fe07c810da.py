def run(arguments, context):
    import os
    path = arguments['file_path']
    name = arguments['function_name']
    if not os.path.isabs(path):
        path = os.path.join(context['workspace_dir'], path)
    code = '''def %s(intervals):
    normalized = []
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError("invalid interval: start > end")
        normalized.append([start, end])
    normalized.sort(key=lambda pair: (pair[0], pair[1]))
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    return merged
''' % name
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': path, 'function_name': name}
