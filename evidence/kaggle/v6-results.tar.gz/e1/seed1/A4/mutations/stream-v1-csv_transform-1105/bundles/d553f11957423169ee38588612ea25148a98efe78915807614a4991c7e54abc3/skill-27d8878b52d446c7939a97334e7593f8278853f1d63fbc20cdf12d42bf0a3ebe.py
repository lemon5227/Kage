import csv, io


def run(arguments, context):
    fp = arguments['file_path']
    fn = arguments['function_name']
    key_col = arguments['key_column']
    sort_col = arguments['sort_column']
    lower_col = arguments['lower_column']
    desc = arguments['descending']
    src = '''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    body = rows[1:]
    cleaned = []
    for row in body:
        cells = [c.strip() for c in row]
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[:len(header)]
        cleaned.append(cells)
    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None
    ki = idx({key!r})
    li = idx({lower!r}) if {lower!r} else None
    si = idx({sort!r})
    if ki is not None:
        cleaned = [r for r in cleaned if r[ki] != ""]
    if li is not None:
        for r in cleaned:
            r[li] = r[li].lower()
    if ki is not None:
        seen = set()
        out = []
        for r in cleaned:
            k = r[ki]
            if k in seen:
                continue
            seen.add(k)
            out.append(r)
        cleaned = out
    if si is not None:
        cleaned.sort(key=lambda r: r[si], reverse={desc!r})
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\\n")
    w.writerow(header)
    w.writerows(cleaned)
    return buf.getvalue()
'''.format(fn=fn, key=key_col, lower=lower_col, sort=sort_col, desc=desc)
    path = fp if fp.startswith('/') else context['workspace_dir'].rstrip('/') + '/' + fp
    with open(path, 'w') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn, 'written': True}
