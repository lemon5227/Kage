import csv, io

def run(arguments, context):
    fp = arguments['file_path']
    fn = arguments['function_name']
    key_col = arguments['key_column']
    sort_col = arguments['sort_column']
    lower_col = arguments.get('lower_column', '')
    desc = bool(arguments.get('descending', False))
    src = (
        'import csv\nimport io\n\n'
        'def ' + fn + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    n = len(header)\n'
        '    def idx(name):\n'
        '        return header.index(name) if name in header else -1\n'
        '    ki = idx(' + repr(key_col) + ')\n'
        '    si = idx(' + repr(sort_col) + ')\n'
        '    li = idx(' + repr(lower_col) + ')\n'
        '    data = []\n'
        '    for row in rows[1:]:\n'
        '        cells = [c.strip() for c in row]\n'
        '        if len(cells) < n:\n'
        '            cells += [""] * (n - len(cells))\n'
        '        elif len(cells) > n:\n'
        '            cells = cells[:n]\n'
        '        data.append(cells)\n'
        '    if ki >= 0:\n'
        '        data = [r for r in data if r[ki] != ""]\n'
        '    if li >= 0:\n'
        '        for r in data:\n'
        '            r[li] = r[li].lower()\n'
        '    if ki >= 0:\n'
        '        seen = set()\n'
        '        ded = []\n'
        '        for r in data:\n'
        '            if r[ki] in seen:\n'
        '                continue\n'
        '            seen.add(r[ki])\n'
        '            ded.append(r)\n'
        '        data = ded\n'
        '    if si >= 0:\n'
        '        data.sort(key=lambda r: r[si], reverse=' + repr(desc) + ')\n'
        '    out = io.StringIO()\n'
        '    w = csv.writer(out, lineterminator="\\n")\n'
        '    w.writerow(header)\n'
        '    w.writerows(data)\n'
        '    return out.getvalue()\n'
    )
    path = fp if fp.startswith('/') else context['workspace_dir'].rstrip('/') + '/' + fp
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'file_path': fp, 'function_name': fn}
