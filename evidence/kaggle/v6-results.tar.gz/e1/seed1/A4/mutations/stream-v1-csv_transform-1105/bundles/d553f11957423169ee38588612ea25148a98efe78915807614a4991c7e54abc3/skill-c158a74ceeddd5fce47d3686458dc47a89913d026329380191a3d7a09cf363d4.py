def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    idf = arguments['id_field']
    sf = arguments['size_field']
    scf = arguments['score_field']
    code = '''def {fn}(items, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    entries = []
    for item in items:
        size = item["{sf}"]
        score = item["{scf}"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["{idf}"], size, score))
    best = [(0, []) for _ in range(capacity + 1)]
    for item_id, size, score in entries:
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = best[c - size]
            cand_score = prev_score + score
            cand_ids = sorted(prev_ids + [item_id])
            cur_score, cur_ids = best[c]
            if cand_score > cur_score or (cand_score == cur_score and cand_ids < cur_ids):
                best[c] = (cand_score, cand_ids)
    return best[capacity][1]
'''.format(fn=fn, idf=idf, sf=sf, scf=scf)
    path = os.path.join(context['workspace_dir'], fp)
    with open(path, 'w') as f:
        f.write(code)
    return {"success": True, "path": fp, "bytes_written": len(code)}
