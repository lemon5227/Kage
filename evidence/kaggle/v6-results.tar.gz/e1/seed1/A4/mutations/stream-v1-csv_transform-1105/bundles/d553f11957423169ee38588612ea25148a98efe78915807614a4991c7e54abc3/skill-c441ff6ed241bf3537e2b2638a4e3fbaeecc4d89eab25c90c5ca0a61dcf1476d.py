def run(arguments, context):
    import os
    path = arguments['file_path']
    fn = arguments['function_name']
    sk = arguments['start_key']
    ek = arguments['end_key']
    if not os.path.isabs(path):
        path = os.path.join(context['workspace_dir'], path)
    src = (
        'def ' + fn + '(intervals):\n'
        '    norm = []\n'
        '    for iv in intervals:\n'
        '        s = iv[' + repr(sk) + ']\n'
        '        e = iv[' + repr(ek) + ']\n'
        '        if s > e:\n'
        '            raise ValueError("invalid interval: start %r > end %r" % (s, e))\n'
        '        norm.append((s, e))\n'
        '    norm.sort(key=lambda p: (p[0], p[1]))\n'
        '    merged = []\n'
        '    for s, e in norm:\n'
        '        if merged and s <= merged[-1][1]:\n'
        '            if e > merged[-1][1]:\n'
        '                merged[-1][1] = e\n'
        '        else:\n'
        '            merged.append([s, e])\n'
        '    return [{' + repr(sk) + ': s, ' + repr(ek) + ': e} for s, e in merged]\n'
    )
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': path, 'bytes_written': len(src)}
