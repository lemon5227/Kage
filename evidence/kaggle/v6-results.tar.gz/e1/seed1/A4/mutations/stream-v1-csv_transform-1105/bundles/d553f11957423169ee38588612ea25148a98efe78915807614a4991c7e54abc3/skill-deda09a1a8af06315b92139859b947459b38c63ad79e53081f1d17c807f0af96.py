def run(arguments, context):
    import os
    path = os.path.join(context['workspace_dir'], arguments['file_path'])
    fn = arguments['function_name']
    idx = arguments['field_index']
    min_tokens = arguments['min_tokens']
    colon_idx = arguments['require_colon_token_index']
    lines = []
    lines.append('def ' + fn + '(lines):')
    lines.append('    counts = {}')
    lines.append('    for line in lines:')
    lines.append('        if not isinstance(line, str):')
    lines.append('            continue')
    lines.append('        parts = line.split()')
    lines.append('        if len(parts) < ' + str(min_tokens) + ':')
    lines.append('            continue')
    if colon_idx >= 0:
        lines.append('        if not parts[' + str(colon_idx) + '].endswith(":"):')
        lines.append('            continue')
    lines.append('        key = parts[' + str(idx) + '].upper()')
    lines.append('        if not key:')
    lines.append('            continue')
    lines.append('        counts[key] = counts.get(key, 0) + 1')
    lines.append('    return counts')
    src = '\n'.join(lines) + '\n'
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': arguments['file_path'], 'bytes_written': len(src)}
