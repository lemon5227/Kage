def run(arguments, context):
    import os
    path = arguments['file_path']
    if not os.path.isabs(path):
        path = os.path.join(context['workspace_dir'], path)
    fn = arguments['function_name']
    fi = int(arguments['field_index'])
    mt = int(arguments['min_tokens'])
    ci = int(arguments['require_colon_token_index'])
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        tokens = line.split()\n'
        '        if len(tokens) < ' + str(mt) + ':\n'
        '            continue\n'
        '        if ' + str(ci) + ' >= 0 and not tokens[' + str(ci) + '].endswith(":"):\n'
        '            continue\n'
        '        if ' + str(fi) + ' >= len(tokens):\n'
        '            continue\n'
        '        key = tokens[' + str(fi) + '].upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': path, 'bytes_written': len(src)}
