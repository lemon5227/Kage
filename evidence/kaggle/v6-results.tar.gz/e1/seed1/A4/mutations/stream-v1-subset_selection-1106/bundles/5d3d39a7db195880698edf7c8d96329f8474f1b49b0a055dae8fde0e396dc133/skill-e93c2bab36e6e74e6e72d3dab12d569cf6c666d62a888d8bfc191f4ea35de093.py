def run(arguments, context):
    import os
    p = arguments
    fn = p['function_name']
    ip = p['items_param']
    cp = p['capacity_param']
    idf = p['id_field']
    wf = p['weight_field']
    vf = p['value_field']
    cem = p['capacity_error_message']
    wem = p['weight_error_message']
    lines = []
    lines.append('def ' + fn + '(' + ip + ', ' + cp + '):')
    lines.append('    if ' + cp + ' < 0:')
    lines.append('        raise ValueError(' + repr(cem) + ')')
    lines.append('    entries = []')
    lines.append('    for item in ' + ip + ':')
    lines.append('        w = item[' + repr(wf) + ']')
    lines.append('        v = item[' + repr(vf) + ']')
    lines.append('        if w <= 0:')
    lines.append('            raise ValueError(' + repr(wem) + ')')
    lines.append('        entries.append((item[' + repr(idf) + '], w, v))')
    lines.append('    best = [(0, []) for _ in range(' + cp + ' + 1)]')
    lines.append('    for iid, w, v in entries:')
    lines.append('        for c in range(' + cp + ', w - 1, -1):')
    lines.append('            pv, pi = best[c - w]')
    lines.append('            cv = pv + v')
    lines.append('            ci = sorted(pi + [iid])')
    lines.append('            bv, bi = best[c]')
    lines.append('            if cv > bv or (cv == bv and ci < bi):')
    lines.append('                best[c] = (cv, ci)')
    lines.append('    return best[' + cp + '][1]')
    code = '\n'.join(lines) + '\n'
    path = os.path.join(context['workspace_dir'], p['file_path'])
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': p['file_path'], 'bytes_written': len(code)}
