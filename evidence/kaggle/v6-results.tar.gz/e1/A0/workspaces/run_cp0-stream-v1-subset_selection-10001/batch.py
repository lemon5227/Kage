def allocate(items, capacity):
    """
    Select jobs under a capacity limit to maximize total gain.
    
    Args:
        items: List of dicts with keys 'id', 'cost', 'gain'
        capacity: Maximum total cost allowed
    
    Returns:
        Sorted list of ids for the optimal selection
    
    Raises:
        ValueError: If capacity is negative or any cost is <= 0
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "id" not in item or not isinstance(item["id"], str):
            raise ValueError("Each item must have a string 'id'")
        if "cost" not in item or not isinstance(item["cost"], int) or item["cost"] <= 0:
            raise ValueError("Each item must have a positive integer 'cost'")
        if "gain" not in item or not isinstance(item["gain"], int) or item["gain"] < 0:
            raise ValueError("Each item must have a non-negative integer 'gain'")
    
    # Handle empty items list
    if not items:
        return []
    
    n = len(items)
    
    # Dynamic programming for 0/1 knapsack
    # dp[i][w] = maximum gain using first i items with total cost <= w
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    
    # Track which items were selected for each state
    # parent[i][w] = index of item selected (or -1 if not selected)
    parent = [[-1] * (capacity + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        cost = items[i-1]["cost"]
        gain = items[i-1]["gain"]
        for w in range(capacity + 1):
            # Don't include item i
            dp[i][w] = dp[i-1][w]
            
            # Include item i if it fits
            if cost <= w:
                if dp[i-1][w-cost] + gain > dp[i][w]:
                    dp[i][w] = dp[i-1][w-cost] + gain
                    parent[i][w] = i - 1  # mark that item i was selected
    
    # Find the maximum gain achievable
    max_gain = dp[n][capacity]
    
    # Reconstruct the solution by backtracking
    selected_items = []
    w = capacity
    for i in range(n, 0, -1):
        if parent[i][w] == i - 1:
            selected_items.append(items[i-1]["id"])
            w -= items[i-1]["cost"]
    
    # Sort the ids lexicographically
    selected_items.sort()
    
    return selected_items
