#!/usr/bin/env python3
"""Test export_clean.py"""

from export_clean import normalize_table

# Test 1: Basic functionality
test_input = """name,team,city,id,score
Alice,TeamA,City1,100,95
Bob,TeamB,City2,200,85
Charlie,TeamC,City3,300,95
David,TeamD,City4,400,75"""

result = normalize_table(test_input)
print("Test 1 - Basic:")
print(result)
print()

# Test 2: Empty string input
result2 = normalize_table('')
print("Test 2 - Empty input:")
print(repr(result2))
print()

# Test 3: Header-only input
test3 = "name,team,city,id,score"
result3 = normalize_table(test3)
print("Test 3 - Header only:")
print(repr(result3))
print()

# Test 4: Row with empty name
test4 = """name,team,city,id,score
,A,B,C,D
Alice,TeamA,City1,100,95"""
result4 = normalize_table(test4)
print("Test 4 - Empty name row:")
print(result4)
print()

# Test 5: Duplicate scores
test5 = """name,team,city,id,score
Alice,TeamA,City1,100,95
Bob,TeamB,City2,200,85
Charlie,TeamC,City3,300,95"""
result5 = normalize_table(test5)
print("Test 5 - Duplicate scores:")
print(result5)
