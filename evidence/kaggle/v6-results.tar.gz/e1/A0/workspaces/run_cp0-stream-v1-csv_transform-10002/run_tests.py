#!/usr/bin/env python3
"""Run tests for export_clean.py"""

import subprocess
import sys

# Run the test script
result = subprocess.run([sys.executable, 'test_export_clean.py'], 
                        capture_output=True, text=True)
print(result.stdout)
if result.stderr:
    print("STDERR:", result.stderr)
