#!/usr/bin/env python3
"""Clean exported table CSV text."""

import csv
import io


def normalize_table(text):
    """Clean an exported table CSV text.
    
    Input: CSV text with header row (columns: name, team, city, id, score)
    Returns: Cleaned CSV text with the same header.
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse the CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Check if header-only input
    if len(rows) == 1:
        return rows[0][0] + '\n'
    
    # Extract header
    header = rows[0]
    # Ensure expected columns exist
    expected_cols = ['name', 'team', 'city', 'id', 'score']
    if len(header) != len(expected_cols):
        # If header doesn't match, use first column as name for filtering
        # We'll still process but be flexible
        pass
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        if len(row) < 5:
            continue  # Skip rows with insufficient columns
        cleaned_row = [cell.strip() for cell in row]
        # Drop rows whose "name" cell is empty
        if not cleaned_row[0].strip():
            continue
        cleaned_rows.append(cleaned_row)
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in cleaned_rows:
        score = row[4].strip() if len(row) > 4 else ''
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort rows by "id" ascending as strings (stable)
    # The id is at index 3
    unique_rows.sort(key=lambda row: row[3].strip(), reverse=False)
    
    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()


if __name__ == '__main__':
    # Test example
    test_input = """name,team,city,id,score
Alice,TeamA,City1,100,95
Bob,TeamB,City2,200,85
Charlie,TeamC,City3,300,95
David,TeamD,City4,400,75"""
    result = normalize_table(test_input)
    print(result)
