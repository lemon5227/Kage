import unicodedata
import re

def label_id(text):
    """Build a URL slug from text.
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with a single hyphen,
    and strips leading/trailing hyphens.
    
    Raises TypeError for non-string input.
    """
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single '-'
    result = re.sub(r'[^a-z0-9]+', '-', lowercased)
    
    # Strip leading and trailing '-'
    result = result.strip('-')
    
    return result
