def merge_slots(intervals):
    # Check for invalid intervals first
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Interval {start}, {end} has start > end")
    
    # If no intervals, return empty list
    if not intervals:
        return []
    
    # Sort intervals by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    merged = []
    current_start, current_end = sorted_intervals[0]
    
    for i in range(1, len(sorted_intervals)):
        next_start, next_end = sorted_intervals[i]
        
        # Check if there's a real overlap (not just touching)
        if next_start < current_end:
            # Overlap exists, merge them
            current_end = max(current_end, next_end)
        else:
            # No overlap, push current and start new
            merged.append([current_start, current_end])
            current_start, current_end = next_start, next_end
    
    # Add the last interval
    merged.append([current_start, current_end])
    
    return merged
