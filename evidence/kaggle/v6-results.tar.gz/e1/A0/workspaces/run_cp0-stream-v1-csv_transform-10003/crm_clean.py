import csv
import io


def tidy_csv(text):
    """Clean an exported CSV table.
    
    Input: CSV text with header row (columns: name, city, score, team)
    Output: Cleaned CSV text with same header
    
    Cleaning steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Remove duplicate rows by "name", keeping first occurrence
    4. Sort rows by "city" ascending as strings (stable)
    
    Returns empty string for empty input, header-only input returns just the header line.
    """
    # Parse CSV text into a list of lists
    lines = text.strip().split('\n')
    
    if not lines:
        return ''
    
    # Check if it's header-only
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    if len(header) != 4 or header[0] != 'name' or header[1] != 'city' or header[2] != 'score' or header[3] != 'team':
        return ''
    
    # Parse data rows
    rows = []
    for i in range(1, len(lines)):
        line = lines[i].strip()
        if not line:
            continue
        cells = line.split(',')
        if len(cells) != 4:
            continue
        
        # Strip whitespace from each cell
        name = cells[0].strip()
        city = cells[1].strip()
        score = cells[2].strip()
        team = cells[3].strip()
        
        # Drop rows where name is empty
        if not name:
            continue
        
        rows.append((name, city, score, team))
    
    # Remove duplicates by name, keeping first occurrence
    seen = set()
    unique_rows = []
    for row in rows:
        if row[0] not in seen:
            seen.add(row[0])
            unique_rows.append(row)
    
    # Sort by city ascending as strings (stable sort)
    unique_rows.sort(key=lambda x: x[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
