def digest_lines(lines):
    result = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split by spaces to get parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1]
        
        # Convert to uppercase for case-insensitive handling
        level_upper = level.upper()
        
        # Increment count for this level
        result[level_upper] = result.get(level_upper, 0) + 1
    
    return result
