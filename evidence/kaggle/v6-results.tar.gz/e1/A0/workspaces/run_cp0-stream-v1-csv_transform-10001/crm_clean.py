import csv
import io


def clean_rows(text):
    """
    Clean CSV text with header row (columns: team, name, city, id, score).
    Returns cleaned CSV text with the same header.
    
    Operations in order:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "name" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Parse CSV
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Extract header
    header = lines[0].strip()
    if not header:
        return ''
    
    # Check if header matches expected columns
    expected_header = 'team,name,city,id,score'
    if header != expected_header:
        # If header doesn't match, we still process it but warn
        pass
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        try:
            cells = line.split(',')
            if len(cells) < 5:
                continue
            row = {
                'team': cells[0].strip(),
                'name': cells[1].strip(),
                'city': cells[2].strip(),
                'id': cells[3].strip(),
                'score': cells[4].strip()
            }
            rows.append(row)
        except Exception:
            continue
    
    # Step 1: Strip leading/trailing whitespace from every cell (already done above)
    
    # Step 2: Drop rows whose "score" cell is empty
    filtered_rows = []
    for row in rows:
        if not row['score']:
            continue
        filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in filtered_rows:
        score = row['score']
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Step 4: Sort rows by "name" ascending as strings (stable)
    sorted_rows = sorted(unique_rows, key=lambda row: row['name'])
    
    # Build output CSV
    output_lines = [header]
    for row in sorted_rows:
        output_lines.append(f"{row['team']},{row['name']},{row['city']},{row['id']},{row['score']}")
    
    return '\n'.join(output_lines)


if __name__ == '__main__':
    # Test examples
    test1 = "team,name,city,id,score\nA,B,C,D,10\nE,F,G,H,10"
    print("Test 1:", clean_rows(test1))
    
    test2 = "team,name,city,id,score\nA,B,C,D,10"
    print("Test 2:", clean_rows(test2))
    
    test3 = "team,name,city,id,score"
    print("Test 3:", clean_rows(test3))
    
    test4 = ""
    print("Test 4:", clean_rows(test4))
