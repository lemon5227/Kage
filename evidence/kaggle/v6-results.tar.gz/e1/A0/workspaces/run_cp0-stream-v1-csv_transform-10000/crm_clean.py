import csv
import io


def normalize_table(text):
    """
    Process CSV text with header row (columns: score, id, email, name).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "name", keeping the first occurrence
    5. Sort rows by "email" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Parse the CSV text
    lines = text.strip().split('\n')
    
    if not lines:
        return ''
    
    # Check if it's header-only
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    if len(header) != 4 or header[0] != 'score' or header[1] != 'id' or header[2] != 'email' or header[3] != 'name':
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) != 4:
            continue
        
        score, id_val, email, name = cells
        
        # Step 1: Strip leading/trailing whitespace from every cell
        score = score.strip()
        id_val = id_val.strip()
        email = email.strip()
        name = name.strip()
        
        # Step 2: Drop rows whose "name" cell is empty
        if not name:
            continue
        
        # Step 3: Lower-case the "email" column
        email = email.lower()
        
        rows.append({
            'score': score,
            'id': id_val,
            'email': email,
            'name': name
        })
    
    # Step 4: Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        if row['name'] not in seen_names:
            seen_names.add(row['name'])
            unique_rows.append(row)
    
    # Step 5: Sort rows by "email" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x['email'])
    
    # Build output CSV text
    output_lines = [','.join(header)]
    for row in unique_rows:
        output_lines.append(f"{row['score']},{row['id']},{row['email']},{row['name']}")
    
    return '\n'.join(output_lines)


if __name__ == '__main__':
    # Test examples
    test1 = "score,id,email,name\n1,abc,test@example.com,John"
    print("Test 1:", normalize_table(test1))
    
    test2 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,test@example.com,Jane"
    print("Test 2:", normalize_table(test2))
    
    test3 = "score,id,email,name\n1,abc,test@example.com,\n2,def,test@example.com,John"
    print("Test 3:", normalize_table(test3))
    
    test4 = ""
    print("Test 4:", normalize_table(test4))
    
    test5 = "score,id,email,name"
    print("Test 5:", normalize_table(test5))
