def merge_slots(intervals):
    # Validate all intervals first
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Convert to list of tuples for sorting
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    if not sorted_intervals:
        return []
    
    merged = [sorted_intervals[0]]
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # Check if intervals overlap or touch
        if current["from"] <= last["to"]:
            # Merge them
            last["to"] = max(last["to"], current["to"])
        else:
            merged.append(current)
    
    return merged
