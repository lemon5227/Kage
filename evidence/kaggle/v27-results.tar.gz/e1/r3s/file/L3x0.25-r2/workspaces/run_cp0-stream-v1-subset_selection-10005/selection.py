def allocate(items, capacity):
    """Select items to maximize total score while keeping total size <= capacity.
    
    Returns a sorted list of item ids. If multiple selections tie on total score,
    returns the lexicographically smallest sorted id list. An empty selection is allowed.
    Raises ValueError if capacity is negative or any size is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        if "size" not in item or "score" not in item:
            raise ValueError("Each item must have 'size' and 'score' keys")
        if item["size"] <= 0:
            raise ValueError("size must be positive")
    
    # Handle empty items list
    if not items:
        return []
    
    # Create a list of (id, size, score) tuples
    items_list = [(item["id"], item["size"], item["score"]) for item in items]
    
    # Sort by score descending, then by id ascending for tie-breaking
    # We'll use dynamic programming for the knapsack problem
    n = len(items_list)
    
    # dp[i][w] = (max_score, selected_ids) for first i items with capacity w
    # We need to track which items were selected to handle tie-breaking
    
    # Initialize dp table
    # dp[w] will store (max_score, sorted_ids) for capacity w
    dp = [([], 0)] * (capacity + 1)
    
    for i in range(n):
        item_id, size, score = items_list[i]
        # Create a copy of dp to avoid modifying while iterating
        new_dp = [list(dp[w]) for w in range(capacity + 1)]
        
        for w in range(size, capacity + 1):
            # Option 1: don't include this item
            score1, ids1 = dp[w]
            # Option 2: include this item
            score2, ids2 = dp[w - size]
            new_score = score2 + score
            new_ids = ids2 + [item_id]
            
            # Compare: maximize score, then lexicographically smallest ids
            if new_score > score1:
                new_dp[w] = (new_ids, new_score)
            elif new_score == score1:
                # Compare lexicographically
                if sorted(new_ids) < sorted(ids1):
                    new_dp[w] = (new_ids, new_score)
        
        dp = new_dp
    
    # Find the best result across all capacities
    max_score = 0
    best_ids = []
    
    for w in range(capacity + 1):
        score, ids = dp[w]
        if score > max_score:
            max_score = score
            best_ids = ids
        elif score == max_score:
            if sorted(ids) < sorted(best_ids):
                best_ids = ids
    
    return sorted(best_ids)
