def merge_slots(intervals):
    """Combine overlapping time ranges.
    
    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals in the same [start, end] list form, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if merged and start < merged[-1][1]:
            # Overlap: merge by extending the end
            merged[-1] = [merged[-1][0], max(merged[-1][1], end)]
        else:
            merged.append(interval)
    
    return merged
