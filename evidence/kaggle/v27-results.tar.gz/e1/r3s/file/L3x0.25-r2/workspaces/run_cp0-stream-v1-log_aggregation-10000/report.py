def count_entries(lines):
    """Count occurrences of log levels in lines.
    
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (report them upper-case).
    Skip malformed lines. Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        # Skip if level is not a valid log level (e.g., empty or non-alphanumeric)
        if not level.isalpha():
            continue
        counts[level] = counts.get(level, 0) + 1
    return {k: v for k, v in counts.items() if v > 0}
