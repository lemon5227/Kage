def digest_lines(lines):
    """Process log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per level, case-insensitive (upper-case keys), dropping malformed lines."""
    counts = {}
    for line in lines:
        if not line.strip():
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # Format: <timestamp> <LEVEL> <service>: <message>
        # parts[0] = timestamp, parts[1] = LEVEL, parts[2] should contain service: message
        level = parts[1].upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
