def pick_jobs(items, capacity):
    """Choose parcels to maximize total score while total size stays <= capacity.
    
    Each item is a dict with a unique string "id", a positive integer "size" 
    and a non-negative integer "score". Return the sorted list of ids whose 
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically 
    smallest sorted id list. An empty selection is allowed.
    
    Raise ValueError if capacity is negative or any size is <= 0.
    Do not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        item_id = item.get("id")
        size = item.get("size")
        score = item.get("score")
        
        if item_id is None or size is None or score is None:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        
        if not isinstance(item_id, str):
            raise ValueError("Item id must be a string")
        
        if size <= 0:
            raise ValueError("Item size must be positive")
        
        if not isinstance(score, int) or score < 0:
            raise ValueError("Item score must be a non-negative integer")
    
    # If no items, return empty list
    if not items:
        return []
    
    n = len(items)
    
    # dp[i][w] = (max_score, chosen_ids) for first i items with capacity w
    # We'll store the best (score, id_list) for each capacity
    # Initialize dp[0][w] = (0, []) for all w
    dp = [[(0, [])] * (capacity + 1) for _ in range(n + 1)]
    
    # For each item, update dp table
    for i in range(1, n + 1):
        item = items[i - 1]
        item_id = item["id"]
        size = item["size"]
        score = item["score"]
        
        for w in range(capacity + 1):
            # Option 1: don't include item i
            dp[i][w] = dp[i - 1][w]
            
            # Option 2: include item i if capacity allows
            if w >= size:
                prev_score, prev_ids = dp[i - 1][w - size]
                new_score = prev_score + score
                new_ids = prev_ids + [item_id]
                
                # Compare with current best for this capacity
                if new_score > dp[i][w][0]:
                    dp[i][w] = (new_score, sorted(new_ids))
                elif new_score == dp[i][w][0] and new_ids < dp[i][w][1]:
                    dp[i][w] = (new_score, new_ids)
    
    # The answer is the best result across all capacities <= capacity
    max_score = 0
    best_ids = []
    
    for w in range(capacity + 1):
        score, ids = dp[n][w]
        if score > max_score:
            max_score = score
            best_ids = ids
        elif score == max_score and ids < best_ids:
            best_ids = ids
    
    return best_ids
