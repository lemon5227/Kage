import unicodedata


def slugify(text):
    """Build a URL slug from text.
    
    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces every run of non-alphanumeric characters with a single "-",
    and strips leading/trailing "-".
    
    Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lowercase
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                slug.append('-')
            prev_char = char
        else:
            prev_char = None
    
    result = ''.join(slug)
    
    # Strip leading and trailing "-"
    return result.strip('-')
