import csv
import io

def clean_rows(text):
    # Parse CSV text into list of dicts
    reader = csv.reader(io.StringIO(text))
    rows = []
    for row in reader:
        rows.append(dict(zip(row, ['team', 'name', 'city', 'id', 'score'])))
    
    if not rows:
        return ''
    
    # Extract header from first row
    header = rows[0].keys()
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in rows:
        cleaned_row = {k: v.strip() for k, v in row.items()}
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "score" cell is empty
    cleaned_rows = [row for row in cleaned_rows if row['score'] != '']
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in cleaned_rows:
        score = row['score']
        if score not in seen_scores:
            seen_scores.add(score)
            deduped_rows.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    deduped_rows.sort(key=lambda row: row['name'])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(deduped_rows[0].keys())
    for row in deduped_rows:
        writer.writerow([row[k] for k in deduped_rows[0].keys()])
    
    return output.getvalue()
