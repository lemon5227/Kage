def upgrade_config(cfg):
    """Upgrade old configuration dicts to the v2 layout."""
    version = cfg.get("version")
    if version != 1:
        raise ValueError(f"Expected version 1, got {version}")
    
    # Create a new dict for the upgraded configuration
    upgraded = {"version": 2}
    
    # Rename top-level keys
    if "max_conn" in cfg:
        upgraded["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        upgraded["directory"] = cfg["dir"]
    if "host" in cfg:
        upgraded["hostname"] = cfg["host"]
    
    # Move cache_size and region into limits sub-dict
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    upgraded["limits"] = limits
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        upgraded["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged, but drop keys whose value is None
    for key, value in cfg.items():
        if key not in ["max_conn", "dir", "host", "cache_size", "region", "timeout_ms"]:
            if value is not None:
                upgraded[key] = value
    
    return upgraded
