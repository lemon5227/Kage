def make_handle(text):
    """Build a URL slug from text.
    
    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces runs of non-alphanumeric characters with a single "-",
    and strips leading/trailing "-".
    
    Raises TypeError if text is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lowercase
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to split on non-alphanumeric characters and join with "-"
    parts = []
    current = []
    for char in lowercased:
        if char.isalnum():  # a-z and 0-9
            current.append(char)
        else:
            if current:
                parts.append(''.join(current))
                current = []
            # Add separator for non-alphanumeric runs
            # But we need to handle consecutive non-alphanumerics as a single "-"
            # We'll collect the separators and join them later
    if current:
        parts.append(''.join(current))
    
    # Now replace any remaining consecutive separators with a single "-"
    # Actually, let's do it more simply: split on non-alphanumeric and join with "-"
    # But we need to ensure that runs of non-alphanumerics become a single "-"
    # The above approach already handles this by collecting parts
    
    # However, there's an issue: if there are consecutive non-alphanumerics,
    # they should be replaced by a single "-". Let's handle this properly.
    
    # Better approach: use regex to replace one or more non-alphanumeric chars with "-"
    import re
    slug = re.sub(r'[^\w\s-]', '-', lowercased)
    # This replaces any character that is not word (alphanumeric + underscore), whitespace, or hyphen with "-"
    # But we want to replace runs of non-alphanumeric with a single "-", so we need to collapse multiple "-"
    slug = re.sub(r'-+', '-', slug)
    
    # Strip leading and trailing "-"
    slug = slug.strip('-')
    
    return slug
