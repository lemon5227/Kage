def digest_lines(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service:
        if len(parts) < 3:
            continue
        
        # Check if the third part starts with "service:"
        if not parts[2].startswith("service:"):
            continue
        
        # Extract level from parts[1]
        level = parts[1].upper()
        
        # Count the level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
