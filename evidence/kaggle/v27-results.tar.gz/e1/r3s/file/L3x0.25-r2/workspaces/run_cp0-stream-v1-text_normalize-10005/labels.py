import unicodedata


def to_key(text):
    """Normalize labels into identifiers.
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with a single underscore,
    and strips leading/trailing underscores.
    
    Raises TypeError if text is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we need to replace any sequence of non-alphanumeric chars with "_"
    result = []
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is not None:
                # Skip consecutive non-alphanumeric characters
                continue
            else:
                result.append('_')
                prev_char = char
        else:
            result.append(char)
            prev_char = char
    
    # Strip leading and trailing underscores
    key = ''.join(result).strip('_')
    
    return key
