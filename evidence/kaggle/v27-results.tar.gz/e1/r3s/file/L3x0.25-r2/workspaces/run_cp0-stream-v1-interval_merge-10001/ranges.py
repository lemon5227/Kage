def merge_slots(intervals):
    """Merge overlapping intervals. Each interval is a dict {"from": s, "to": e}.
    
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Raises ValueError if any interval has start > end.
    """
    # Validate and extract intervals
    validated = []
    for interval in intervals:
        from_val = interval["from"]
        to_val = interval["to"]
        if from_val > to_val:
            raise ValueError(f"Interval {interval} has start > end")
        validated.append((from_val, to_val))
    
    # Sort by start time
    validated.sort(key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for start, end in validated:
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start <= last_end:  # Overlapping or touching
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])
    
    # Convert back to dict format
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})
    
    return result
