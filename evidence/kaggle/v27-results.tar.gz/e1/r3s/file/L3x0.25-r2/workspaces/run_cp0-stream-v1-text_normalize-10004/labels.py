import unicodedata

def label_id(text):
    """Build a URL slug from text.
    
    - Apply NFKD normalization
    - Drop non-ASCII characters
    - Lower-case
    - Replace every run of characters outside [a-z0-9] with a single "-"
    - Strip leading and trailing "-"
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to split on any character that is not a-z or 0-9
    slug = []
    previous_was_alnum = False
    for char in lower:
        if char.isalnum():  # a-z and 0-9
            slug.append(char)
            previous_was_alnum = True
        else:
            if previous_was_alnum:
                slug.append('-')
            previous_was_alnum = False
    
    result = ''.join(slug)
    
    # Strip leading and trailing "-"
    result = result.strip('-')
    
    return result
