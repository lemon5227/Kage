def tally_events(lines):
    """Tally events from log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    
    Returns a dictionary {name: count} per service for levels ERROR and WARN only,
    treating level names case-insensitively (upper-case keys), dropping malformed input lines.
    """
    counts = {}
    
    for line in lines:
        if not line or not line.strip():
            continue
            
        parts = line.split()
        if len(parts) < 3:
            continue
            
        # parts[0] = timestamp, parts[1] = LEVEL, parts[2] should contain "service: message"
        level = parts[1].upper()
        
        # Only process ERROR and WARN levels
        if level not in ('ERROR', 'WARN'):
            continue
            
        # Extract service from parts[2] which is "service: message"
        service_part = parts[2]
        if not service_part.startswith(':'):
            continue
            
        service = service_part.split(':', 1)[0].strip()
        
        if not service:
            continue
            
        counts[service] = counts.get(service, 0) + 1
    
    return counts
