import csv
import io

def normalize_table(text):
    if not text.strip():
        return ''
    
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Parse header
    header = lines[0].strip().split(',')
    if 'name' not in header or 'email' not in header:
        return ''
    
    # Parse rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.strip().split(',')
        if len(cells) < len(header):
            continue
        row = {}
        for i, col in enumerate(header):
            if i < len(cells):
                row[col] = cells[i].strip()
            else:
                row[col] = ''
        rows.append(row)
    
    # Drop rows whose "name" cell is empty
    rows = [r for r in rows if r.get('name', '').strip() != '']
    
    # Lower-case the "email" column
    for row in rows:
        row['email'] = row.get('email', '').lower()
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for row in rows:
        name = row.get('name', '').strip()
        if name in seen:
            continue
        seen.add(name)
        deduped.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    deduped.sort(key=lambda r: r.get('email', ''), stable=True)
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped:
        values = [row.get(col, '') for col in header]
        writer.writerow(values)
    
    return output.getvalue()
