def select_tasks(items, capacity):
    """Select parcels under a capacity limit.
    
    Each item is a dict with a unique string "id", a positive integer "cost" 
    and a non-negative integer "gain". Return the sorted list of ids whose 
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically 
    smallest sorted id list. An empty selection is allowed.
    Raise ValueError if capacity is negative or any cost is <= 0.
    Do not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "id" not in item or not isinstance(item["id"], str):
            raise ValueError("Each item must have a unique string 'id'")
        if "cost" not in item or not isinstance(item["cost"], int) or item["cost"] <= 0:
            raise ValueError("Each item must have a positive integer 'cost'")
        if "gain" not in item or not isinstance(item["gain"], int) or item["gain"] < 0:
            raise ValueError("Each item must have a non-negative integer 'gain'")
    
    # Handle empty items list
    if not items:
        return []
    
    # Create a list of (cost, gain, id) tuples
    items_list = [(item["cost"], item["gain"], item["id"]) for item in items]
    
    # Sort by gain descending, then by cost ascending for tie-breaking
    # This helps with the knapsack algorithm
    items_list.sort(key=lambda x: (-x[1], x[0]))
    
    # Dynamic programming approach for 0/1 knapsack
    # dp[i][w] = maximum gain using first i items with weight limit w
    n = len(items_list)
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        cost, gain, item_id = items_list[i - 1]
        for w in range(capacity + 1):
            # Don't include this item
            dp[i][w] = dp[i - 1][w]
            # Include this item if it fits
            if cost <= w:
                dp[i][w] = max(dp[i][w], dp[i - 1][w - cost] + gain)
    
    # Reconstruct the solution
    result_ids = []
    w = capacity
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i - 1][w]:
            # This item was included
            result_ids.append(items_list[i - 1][2])
            w -= items_list[i - 1][0]
    
    # Sort the result lexicographically
    result_ids.sort()
    
    return result_ids
