def select_tasks(items, capacity):
    """Select a subset of items maximizing total gain under capacity constraint.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and normalize items
    validated = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        validated.append((item["id"], cost, gain))

    n = len(validated)
    if n == 0:
        return []

    # dp[w] = (max_gain, sorted_id_list) for capacity w
    # We track the best (gain, id_list) achievable at each capacity.
    # Initialize with (0, []) for capacity 0.
    dp = [(0, []) for _ in range(capacity + 1)]

    for idx in range(n):
        item_id, cost, gain = validated[idx]
        # Iterate capacities downward to avoid using the same item twice
        for w in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[w - cost]
            cand_gain = prev_gain + gain
            cand_ids = sorted(prev_ids + [item_id])
            if cand_gain > dp[w][0]:
                dp[w] = (cand_gain, cand_ids)
            elif cand_gain == dp[w][0]:
                # Tie: choose lexicographically smallest sorted id list
                if cand_ids < dp[w][1]:
                    dp[w] = (cand_gain, cand_ids)

    # The answer is the best result across all capacities <= capacity
    best_gain = 0
    best_ids = []
    for w in range(capacity + 1):
        gain, ids = dp[w]
        if gain > best_gain:
            best_gain = gain
            best_ids = ids
        elif gain == best_gain:
            if ids < best_ids:
                best_ids = ids

    return best_ids
