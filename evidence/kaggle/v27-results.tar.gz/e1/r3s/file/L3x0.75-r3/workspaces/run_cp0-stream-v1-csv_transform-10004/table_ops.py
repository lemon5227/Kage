import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        if len(row) < len(header):
            continue
        values = dict(zip(header, row[:len(header)]))
        if values.get("score", "").strip() == "":
            continue
        cleaned.append(values)

    # remove duplicates by team, keep first occurrence
    seen = set()
    deduped = []
    for item in cleaned:
        team = item["team"]
        if team in seen:
            continue
        seen.add(team)
        deduped.append(item)

    # sort by score ascending as strings (stable)
    deduped.sort(key=lambda x: x["score"])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for item in deduped:
        writer.writerow([item[h] for h in header])

    return out.getvalue()
