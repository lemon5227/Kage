def pick_jobs(items, capacity):
    """Choose parcels to maximize total score while total size stays <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible, breaking ties by lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and collect items
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = best (score, id_list) achievable with total size exactly w
    # We track the lexicographically smallest id list among those with the
    # same score. Use a tuple (score, id_tuple) for comparison.
    NEG = None  # sentinel for unreachable sizes
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for idx in range(n):
        item_id, size, score = entries[idx]
        # Iterate capacities descending to avoid reusing the same item
        for w in range(capacity, size - 1, -1):
            prev = dp[w - size]
            if prev is None:
                continue
            cand_score = prev[0] + score
            cand_ids = prev[1] + (item_id,)
            cur = dp[w]
            if cur is None or (cand_score, cand_ids) > (cur[0], cur[1]):
                dp[w] = (cand_score, cand_ids)

    # Find the best score among all reachable capacities
    best_score = None
    best_ids = None
    for w in range(capacity + 1):
        entry = dp[w]
        if entry is None:
            continue
        score, ids = entry
        if best_score is None or (score, ids) > (best_score, best_ids):
            best_score = score
            best_ids = ids

    return sorted(best_ids)
