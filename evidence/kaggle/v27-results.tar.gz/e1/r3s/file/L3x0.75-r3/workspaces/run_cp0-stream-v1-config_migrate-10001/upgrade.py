def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Rename top-level keys:
      "host" -> "hostname"
      "max_conn" -> "max_connections"
      "pwd_file" -> "password_file"
    Move "port" and "retries" into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keep other keys unchanged and drop keys whose value is None.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError("Expected configuration version 1, got %r" % version)

    # Make a copy so we don't modify the input
    result = {}
    result["version"] = 2

    # Process known old keys
    host = cfg.get("host")
    if host is not None:
        result["hostname"] = host

    max_conn = cfg.get("max_conn")
    if max_conn is not None:
        result["max_connections"] = max_conn

    pwd_file = cfg.get("pwd_file")
    if pwd_file is not None:
        result["password_file"] = pwd_file

    port = cfg.get("port")
    retries = cfg.get("retries")
    if port is not None or retries is not None:
        result["storage"] = {}
        if port is not None:
            result["storage"]["port"] = port
        if retries is not None:
            result["storage"]["retries"] = retries

    timeout_ms = cfg.get("timeout_ms")
    if timeout_ms is not None:
        result["timeout_s"] = timeout_ms / 1000.0

    # Copy over any other keys that are not None
    for key, value in cfg.items():
        if key in ("host", "max_conn", "pwd_file", "port", "retries", "timeout_ms"):
            continue
        if value is None:
            continue
        result[key] = value

    return result
