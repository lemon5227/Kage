import unicodedata


def to_key(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    runs = []
    prev_char = None
    for char in ascii_only:
        if prev_char is None or char != prev_char:
            runs.append(char)
        prev_char = char

    result = ""
    for char in runs:
        if char in "abcdefghijklmnopqrstuvwxyz0123456789":
            result += char
        else:
            result += "_"

    # strip leading and trailing "_"
    return result.strip("_")
