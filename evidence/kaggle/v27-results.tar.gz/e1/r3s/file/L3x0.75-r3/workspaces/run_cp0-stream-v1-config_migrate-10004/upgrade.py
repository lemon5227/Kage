def migrate(cfg):
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1")

    # Create a new dict without modifying the input
    new_cfg = {}

    # Copy over keys that are not None
    for key, value in cfg.items():
        if value is None:
            continue

        if key == "version":
            new_cfg["version"] = 2
        elif key == "pwd_file":
            new_cfg["password_file"] = value
        elif key == "user":
            new_cfg["username"] = value
        elif key == "cache_size":
            # Move into network sub-dict
            if "network" not in new_cfg:
                new_cfg["network"] = {}
            new_cfg["network"]["cache_size"] = value
        elif key == "workers":
            # Move into network sub-dict
            if "network" not in new_cfg:
                new_cfg["network"] = {}
            new_cfg["network"]["workers"] = value
        elif key == "timeout_ms":
            # Convert to seconds (float)
            new_cfg["timeout_s"] = value / 1000.0
        else:
            new_cfg[key] = value

    return new_cfg
