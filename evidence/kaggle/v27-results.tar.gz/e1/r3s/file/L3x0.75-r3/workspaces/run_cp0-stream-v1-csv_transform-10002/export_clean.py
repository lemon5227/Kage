import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = rows[0]
    # columns: name, team, city, id, score
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "name" cell is empty
    name_idx = 0  # first column is name
    filtered = []
    for cells in cleaned:
        if len(cells) <= name_idx:
            continue
        if cells[name_idx] == "":
            continue
        filtered.append(cells)

    # remove duplicate rows by "score", keeping the first occurrence
    seen = set()
    deduped = []
    for cells in filtered:
        score = cells[-1]  # last column is score
        if score in seen:
            continue
        seen.add(score)
        deduped.append(cells)

    # sort rows by "id" ascending as strings (stable)
    id_idx = 3  # fourth column is id
    deduped.sort(key=lambda cells: cells[id_idx] if len(cells) > id_idx else "")

    # write output with '\n' line endings using csv module
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for cells in deduped:
        writer.writerow(cells)

    return out.getvalue()
