def allocate(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    Does not modify the input.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy items without modifying the original dicts
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    n = len(entries)
    if n == 0:
        return []

    # Sort by id for deterministic tie-breaking on equal gains
    entries.sort(key=lambda x: x[0])

    # dp[i][c] = best (gain, selected_ids) using a subset of the first i items
    # with total cost <= c. We track the chosen ids to resolve ties.
    # Using a dict keyed by cost for the best gain and the lexicographically
    # smallest id list among those achieving that gain.
    # We iterate items in order and update the best for each capacity.

    # best[c] = (gain, sorted_id_list) for capacity c
    best = [None] * (capacity + 1)
    best[0] = (0, [])

    for idx in range(n):
        item_id, cost, gain = entries[idx]
        # Iterate capacities downward so each item is used at most once
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = best[c - cost]
            cand_gain = prev_gain + gain
            cand_ids = sorted(prev_ids + [item_id])
            cur = best[c]
            if cur is None:
                best[c] = (cand_gain, cand_ids)
            else:
                # Prefer larger gain; on tie, prefer lexicographically smaller id list
                if cand_gain > cur[0]:
                    best[c] = (cand_gain, cand_ids)
                elif cand_gain == cur[0] and cand_ids < cur[1]:
                    best[c] = (cand_gain, cand_ids)

    # The answer is the best gain over all capacities <= capacity, with tie-breaking
    max_gain = 0
    best_ids = []
    for c in range(capacity + 1):
        gain, ids = best[c]
        if gain > max_gain:
            max_gain = gain
            best_ids = ids
        elif gain == max_gain and ids < best_ids:
            best_ids = ids

    return best_ids
