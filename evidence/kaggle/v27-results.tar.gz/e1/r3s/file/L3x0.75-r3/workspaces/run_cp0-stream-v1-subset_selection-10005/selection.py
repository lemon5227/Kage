def allocate(items, capacity):
    """Select a subset of items maximizing total score within capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and normalize items
    validated = []
    for item in items:
        item_id = item["id"]
        size = item["size"]
        score = item["score"]

        if not isinstance(item_id, str) or not item_id:
            raise ValueError("item id must be a non-empty string")
        if size <= 0:
            raise ValueError("item size must be positive")
        if not isinstance(score, int) or score < 0:
            raise ValueError("item score must be a non-negative integer")

        validated.append((item_id, size, score))

    # 0/1 knapsack via DP over capacity.
    # dp[c] = (best_score, best_id_list) for capacity c.
    # We iterate items and update the dp table in reverse to avoid using the
    # same item twice.
    dp = [(0, []) for _ in range(capacity + 1)]

    for item_id, size, score in validated:
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[c - size]
            cand_score = prev_score + score
            cand_ids = prev_ids + [item_id]
            if cand_score > dp[c][0]:
                dp[c] = (cand_score, cand_ids)
            elif cand_score == dp[c][0]:
                # Tie: choose lexicographically smallest sorted id list.
                if sorted(cand_ids) < sorted(dp[c][1]):
                    dp[c] = (cand_score, cand_ids)

    # The best total score is at capacity.
    best_score, best_ids = dp[capacity]

    # Return the sorted list of ids.
    return sorted(best_ids)
