def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Return the sorted list of ids whose
    total value is as large as possible while total weight stays <= capacity.
    If several selections tie on total value, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raise ValueError if capacity is negative or any weight is <= 0.
    Do not modify the input.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy items without modifying the original dicts
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = (max_value, sorted_id_list) for capacity w
    # We track the best (value, id_list) for each weight.
    # Use a dict keyed by weight to store (value, tuple_of_ids).
    # Initialize with empty selection at weight 0.
    dp = [(0, ())]  # weight -> (value, tuple_of_ids)
    # We'll iterate over items and update dp for each possible weight.
    # Since capacity can be large, we need to limit the weight we consider.
    # The maximum useful weight is capacity.
    for item_id, weight, value in entries:
        # Iterate weights from capacity down to 0 (like 0/1 knapsack)
        # But we need to update dp in place; we can use a temporary dict.
        new_dp = dp[:]  # copy
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = prev_ids + (item_id,)
            if cand_value > new_dp[w][0]:
                new_dp[w] = (cand_value, cand_ids)
            elif cand_value == new_dp[w][0]:
                # Tie: choose lexicographically smallest sorted id list.
                # Compare the tuple of ids (already sorted? we'll keep them sorted).
                if cand_ids < new_dp[w][1]:
                    new_dp[w] = (cand_value, cand_ids)
        dp = new_dp

    # The answer is the best value at capacity, with its id list.
    best_value, best_ids = dp[capacity]
    return list(best_ids)
