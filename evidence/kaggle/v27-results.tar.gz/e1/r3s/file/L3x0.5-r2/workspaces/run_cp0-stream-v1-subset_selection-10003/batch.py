def pick_jobs(items, capacity):
    """Choose parcels to maximize total score while total size stays <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    Does not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("size must be positive")

    # Handle empty items list
    if not items:
        return []

    # Create a list of (id, size, score) tuples
    items_list = [(item["id"], item["size"], item["score"]) for item in items]

    n = len(items_list)
    if n == 0:
        return []

    # Use dynamic programming for the 0/1 knapsack problem.
    # dp[i][w] = (max_score, chosen_ids) for considering first i items with capacity w.
    # We'll store the best score and the lexicographically smallest id list for that score.
    # To handle tie-breaking, we compare scores first, then lexicographically.

    # Initialize dp table: dp[w] = (max_score, chosen_ids) for capacity w.
    # We'll use a list of tuples where index is capacity.
    # dp[w] = (score, tuple_of_ids)
    dp = [(0, ()) for _ in range(capacity + 1)]

    for idx in range(n):
        item_id, size, score = items_list[idx]
        # Iterate backwards to avoid using the same item multiple times.
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[w - size]
            new_score = prev_score + score
            new_ids = prev_ids + (item_id,)
            # Compare: maximize score, then minimize lexicographically.
            if new_score > dp[w][0]:
                dp[w] = (new_score, new_ids)
            elif new_score == dp[w][0]:
                # Choose the lexicographically smaller tuple of ids.
                if new_ids < dp[w][1]:
                    dp[w] = (new_score, new_ids)

    # The answer is the best result across all capacities <= capacity.
    best_score = 0
    best_ids = ()
    for w in range(capacity + 1):
        score, ids = dp[w]
        if score > best_score:
            best_score = score
            best_ids = ids
        elif score == best_score:
            if ids < best_ids:
                best_ids = ids

    return list(best_ids)
