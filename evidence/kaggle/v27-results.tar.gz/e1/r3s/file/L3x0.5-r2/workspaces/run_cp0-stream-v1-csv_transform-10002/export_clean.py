import csv
import io

def normalize_table(text):
    if text.strip() == "":
        return ""
    
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ""
    
    header = rows[0]
    # columns: name, team, city, id, score
    
    # strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # drop rows whose "name" cell is empty
    data_rows = [row for row in cleaned_rows if row[0] != ""]
    
    # remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in data_rows:
        score = row[-1]  # last column is score
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped_rows.append(row)
    
    # sort rows by "id" ascending as strings (stable)
    # id is the fourth column (index 3)
    def id_key(row):
        return row[3]
    
    deduped_rows.sort(key=id_key)
    
    # write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()
