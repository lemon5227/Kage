def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Renames top-level keys:
      "dir" -> "directory"
      "pwd_file" -> "password_file"
      "max_conn" -> "max_connections"
    Moves "region" and "retries" into a sub-dict "network" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError("Expected configuration version 1, got: {}".format(version))

    # Make a copy to avoid modifying the input
    result = {}
    result["version"] = 2

    # Process keys
    for key, value in cfg.items():
        if key == "dir":
            result["directory"] = value
        elif key == "pwd_file":
            result["password_file"] = value
        elif key == "max_conn":
            result["max_connections"] = value
        elif key == "region":
            # Move into network sub-dict
            if "network" not in result:
                result["network"] = {}
            result["network"]["region"] = value
        elif key == "retries":
            # Move into network sub-dict
            if "network" not in result:
                result["network"] = {}
            result["network"]["retries"] = value
        elif key == "timeout_ms":
            # Convert to timeout_s (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value

    # Drop keys whose value is None (already handled by not copying them)
    # But ensure network exists even if empty
    if "network" not in result:
        result["network"] = {}

    return result
