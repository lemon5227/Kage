def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Return the sorted list of ids whose
    total value is as large as possible while total weight stays <= capacity.
    If several selections tie on total value, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raise ValueError if capacity is negative or any weight is <= 0.
    Do not modify the input.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        weight = item.get("weight")
        if weight is None or weight <= 0:
            raise ValueError("weight must be a positive integer")

    # Use dynamic programming for the 0/1 knapsack problem.
    # dp[w] = (max_value, sorted_ids) for capacity w.
    # We'll track the best value and the lexicographically smallest id list
    # among those achieving that value.
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for item in items:
        item_id = item["id"]
        weight = item["weight"]
        value = item["value"]

        # Iterate backwards to avoid using the same item multiple times.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            new_value = prev_value + value
            new_ids = sorted(prev_ids + [item_id])

            # Compare with current dp[w]: prefer larger value, then lexicographically smaller ids.
            if dp[w] is None:
                dp[w] = (new_value, new_ids)
            else:
                curr_value, curr_ids = dp[w]
                if new_value > curr_value:
                    dp[w] = (new_value, new_ids)
                elif new_value == curr_value:
                    # Choose lexicographically smallest sorted id list.
                    if new_ids < curr_ids:
                        dp[w] = (new_value, new_ids)

    # The answer is the best value across all capacities, with the lexicographically
    # smallest id list among those achieving that value.
    max_value = 0
    best_ids = []
    for w in range(capacity + 1):
        val, ids = dp[w]
        if val > max_value:
            max_value = val
            best_ids = ids
        elif val == max_value:
            if ids < best_ids:
                best_ids = ids

    return best_ids
