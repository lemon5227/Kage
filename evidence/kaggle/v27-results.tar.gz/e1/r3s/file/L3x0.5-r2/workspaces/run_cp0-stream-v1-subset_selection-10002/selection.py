def select_tasks(items, capacity):
    """Select a subset of tasks to maximize total score while keeping total size <= capacity.

    Each item is a dict with:
        - "id": unique string identifier
        - "size": positive integer
        - "score": non-negative integer

    Returns the sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total score,
    return the lexicographically smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        if "size" not in item or "score" not in item or "id" not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if not isinstance(item["size"], int) or item["size"] <= 0:
            raise ValueError("size must be a positive integer")
        if not isinstance(item["score"], int) or item["score"] < 0:
            raise ValueError("score must be a non-negative integer")
    
    # Empty items list or capacity 0 with no valid items
    if not items or capacity == 0:
        return []
    
    # Use dynamic programming for the 0/1 knapsack problem
    # dp[i][w] = maximum score using first i items with total size <= w
    n = len(items)
    # dp[w] = (max_score, selected_ids) for capacity w
    # We'll track both the max score and the selection to handle tie-breaking
    
    # Initialize: dp[w] = (0, []) for all w from 0 to capacity
    dp = [(0, []) for w in range(capacity + 1)]
    
    for i in range(n):
        item = items[i]
        size = item["size"]
        score = item["score"]
        item_id = item["id"]
        
        # Iterate backwards to avoid using the same item multiple times
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[w - size]
            new_score = prev_score + score
            # Compare with current dp[w] and update if better or tie-breaking
            if new_score > dp[w][0]:
                dp[w] = (new_score, [item_id] + prev_ids)
            elif new_score == dp[w][0]:
                # Tie-breaking: choose lexicographically smallest sorted id list
                current_ids = dp[w][1]
                # Both lists are sorted, so we can compare directly
                if [item_id] + prev_ids < current_ids:
                    dp[w] = (new_score, [item_id] + prev_ids)
    
    # The answer is the best result across all capacities from 0 to capacity
    max_score = 0
    best_ids = []
    for w in range(capacity + 1):
        score, ids = dp[w]
        if score > max_score:
            max_score = score
            best_ids = ids
        elif score == max_score:
            # Tie-breaking: choose lexicographically smallest sorted id list
            if ids < best_ids:
                best_ids = ids
    
    return sorted(best_ids)
