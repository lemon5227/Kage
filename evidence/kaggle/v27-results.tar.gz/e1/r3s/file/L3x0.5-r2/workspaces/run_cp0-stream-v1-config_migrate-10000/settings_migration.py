def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.
    
    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    Output has "version": 2.
    Renames top-level keys:
      - "max_conn" -> "max_connections"
      - "dir" -> "directory"
      - "host" -> "hostname"
    Moves "cache_size" and "region" into a sub-dict "limits".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")

    # Make a copy to avoid modifying the input
    result = dict(cfg)
    result["version"] = 2

    # Rename top-level keys
    if "max_conn" in result:
        result["max_connections"] = result.pop("max_conn")
    if "dir" in result:
        result["directory"] = result.pop("dir")
    if "host" in result:
        result["hostname"] = result.pop("host")

    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in result:
        result["timeout_s"] = result["timeout_ms"] / 1000.0
        # Remove the original key
        del result["timeout_ms"]

    # Move cache_size and region into limits
    limits = {}
    if "cache_size" in result:
        limits["cache_size"] = result.pop("cache_size")
    if "region" in result:
        limits["region"] = result.pop("region")
    result["limits"] = limits

    # Drop keys whose value is None
    for key in list(result.keys()):
        if result[key] is None:
            del result[key]

    return result
