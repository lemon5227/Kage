def digest_lines(lines):
    """Parse log lines in format "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping level name (uppercase) to count, dropping malformed lines.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        # Validate level is a known log level (optional; here we accept any non-empty string)
        if not level:
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
