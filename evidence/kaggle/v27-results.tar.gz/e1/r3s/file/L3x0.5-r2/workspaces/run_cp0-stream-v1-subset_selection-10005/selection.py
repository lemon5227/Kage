def allocate(items, capacity):
    """Select a subset of items to maximize total score while keeping total size <= capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer
      - "score": non-negative integer

    Returns the sorted list of ids of selected items.
    If multiple selections tie on total score, returns the lexicographically smallest sorted id list.
    An empty selection is allowed.

    Raises ValueError if capacity is negative or any item size is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for item in items:
        if "size" not in item or "score" not in item or "id" not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if not isinstance(item["size"], int) or item["size"] <= 0:
            raise ValueError("size must be a positive integer")
        if not isinstance(item["score"], int) or item["score"] < 0:
            raise ValueError("score must be a non-negative integer")

    # Handle empty items list
    if not items:
        return []

    n = len(items)
    # dp[i][w] = (max_score, chosen_ids) for first i items with capacity w
    # We'll store the best score and the lexicographically smallest id list among ties.
    # Using a list of tuples: (score, tuple_of_ids)
    # Initialize with (-1, ()) to indicate no selection possible
    dp = [(-1, ())] * (capacity + 1)

    for i in range(n):
        item = items[i]
        size = item["size"]
        score = item["score"]
        new_dp = list(dp)  # copy current dp row
        for w in range(capacity + 1):
            if dp[w] == (-1,()):
                continue
            if w + size > capacity:
                continue
            # Try adding this item to the selection at capacity w
            prev_score, prev_ids = dp[w]
            new_score = prev_score + score
            new_ids = tuple(sorted([item["id"]] + list(prev_ids)))
            # Compare with existing entry at capacity w+size
            if new_score > dp[w + size][0]:
                dp[w + size] = (new_score, new_ids)
            elif new_score == dp[w + size][0]:
                # Tie: choose lexicographically smallest id list
                if new_ids < dp[w + size][1]:
                    dp[w + size] = (new_score, new_ids)
        # Update dp for next iteration
        dp = new_dp

    # The answer is the best result across all capacities
    best_score = max(score for score, _ in dp) if dp else 0
    best_ids = [id_ for score, id_tuple in dp if score == best_score][0] if best_score != -1 else []
    return sorted(best_ids)
