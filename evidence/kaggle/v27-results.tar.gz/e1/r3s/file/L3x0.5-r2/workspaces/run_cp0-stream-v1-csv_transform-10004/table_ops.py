import csv
import io


def clean_rows(text):
    if text.strip() == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = rows[0]
    # Ensure we have the expected columns
    if len(header) < 3 or header[0] != "id" or header[1] != "team" or header[2] != "score":
        return ""

    data = rows[1:]

    # Strip leading/trailing whitespace from every cell
    cleaned_data = []
    for row in data:
        stripped_row = [cell.strip() for cell in row]
        cleaned_data.append(stripped_row)

    # Drop rows whose "score" cell is empty
    filtered_data = []
    for row in cleaned_data:
        if len(row) < 3 or row[2] == "":
            continue
        filtered_data.append(row)

    # Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    deduped_data = []
    for row in filtered_data:
        team = row[1]
        if team in seen_teams:
            continue
        seen_teams.add(team)
        deduped_data.append(row)

    # Sort rows by "score" ascending as strings (stable)
    deduped_data.sort(key=lambda row: row[2])

    # Write output with '\n' line endings using csv module
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_data:
        writer.writerow(row)

    return output.getvalue()
