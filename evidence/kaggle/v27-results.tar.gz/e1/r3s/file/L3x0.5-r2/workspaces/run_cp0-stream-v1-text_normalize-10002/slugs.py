import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization to decompose characters
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters
    text = "".join(char for char in text if ord(char) < 128)

    # Lower-case
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    current = ""
    for char in text:
        if char.isalnum():
            current += char
        else:
            if current:
                segments.append(current)
                current = ""
            segments.append("-")
    if current:
        segments.append(current)

    # Strip leading and trailing "-"
    return "-".join(segments).strip("-")
