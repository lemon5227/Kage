def select_tasks(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Return the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raise ValueError if capacity is negative or any cost is <= 0.
    Do not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")
    
    # Empty items list
    if not items:
        return []
    
    # Create a list of (gain, cost, id) tuples
    items_list = [(item["gain"], item["cost"], item["id"]) for item in items]
    
    # Sort by gain descending, then by cost ascending for tie-breaking
    # This helps with the lexicographically smallest id list requirement
    items_list.sort(key=lambda x: (-x[0], x[1]))
    
    # Use dynamic programming for 0/1 knapsack
    # dp[i] = maximum gain achievable with capacity i
    dp = [0] * (capacity + 1)
    
    # Track which items were selected for each capacity
    # parent[i] = index of last item added to reach capacity i
    parent = [-1] * (capacity + 1)
    
    for idx, (gain, cost, item_id) in enumerate(items_list):
        # Iterate backwards to avoid using the same item multiple times
        for cap in range(capacity, cost - 1, -1):
            if dp[cap - cost] + gain > dp[cap]:
                dp[cap] = dp[cap - cost] + gain
                parent[cap] = idx
    
    # Reconstruct the selected items
    selected_indices = []
    cap = capacity
    while cap > 0:
        idx = parent[cap]
        if idx != -1:
            selected_indices.append(idx)
            cap -= items_list[idx][1]
    
    # Get the item ids in the order they appear in items_list
    selected_ids = [items_list[idx][2] for idx in selected_indices]
    
    # Sort the ids lexicographically to ensure deterministic output
    selected_ids.sort()
    
    return selected_ids
