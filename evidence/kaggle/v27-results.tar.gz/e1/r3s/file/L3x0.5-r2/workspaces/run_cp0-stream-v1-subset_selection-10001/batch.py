def allocate(items, capacity):
    """Select jobs under a capacity limit to maximize total gain.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    Does not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")

    # Handle empty items list
    if not items:
        return []

    # Create a list of (id, cost, gain) tuples
    jobs = [(item["id"], item["cost"], item["gain"]) for item in items]

    # Sort by gain descending, then by id ascending for tie-breaking
    # This helps with the lexicographically smallest result when gains tie
    jobs.sort(key=lambda x: (-x[2], x[0]))

    # Use dynamic programming for 0/1 knapsack
    # dp[c] = (max_gain, selected_ids) for capacity c
    # We'll track the best gain and the lexicographically smallest id list
    # among all selections with that gain.

    # Initialize dp[0] = (0, []) and dp[c] = (-inf, None) for c > 0
    dp = [(0, [])] + [(-float('inf'), None)] * capacity

    for cost, gain, job_id in jobs:
        # Iterate backwards to avoid using the same item multiple times
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            new_gain = prev_gain + gain
            new_ids = prev_ids + [job_id]
            # Update if we get a better gain, or same gain but lexicographically smaller id list
            if new_gain > dp[c][0]:
                dp[c] = (new_gain, new_ids)
            elif new_gain == dp[c][0]:
                # Compare lexicographically
                if new_ids < dp[c][1]:
                    dp[c] = (new_gain, new_ids)

    # Find the best gain across all capacities <= capacity
    max_gain = 0
    best_ids = []
    for c in range(capacity + 1):
        gain, ids = dp[c]
        if gain > max_gain:
            max_gain = gain
            best_ids = ids
        elif gain == max_gain:
            if ids < best_ids:
                best_ids = ids

    return sorted(best_ids)
