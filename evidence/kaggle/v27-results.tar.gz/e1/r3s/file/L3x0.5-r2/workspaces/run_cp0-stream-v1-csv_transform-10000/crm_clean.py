import csv
import io


def normalize_table(text):
    if text.strip() == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = rows[0]
    # columns: score, id, email, name
    data_rows = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name")
    filtered_rows = []
    for row in cleaned_rows:
        if not row[name_idx]:
            continue
        filtered_rows.append(row)

    # lower-case the "email" column
    email_idx = header.index("email")
    for row in filtered_rows:
        row[email_idx] = row[email_idx].lower()

    # remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    deduped_rows = []
    for row in filtered_rows:
        name = row[name_idx]
        if name in seen_names:
            continue
        seen_names.add(name)
        deduped_rows.append(row)

    # sort rows by "email" ascending as strings (stable)
    deduped_rows.sort(key=lambda row: row[email_idx])

    # write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
