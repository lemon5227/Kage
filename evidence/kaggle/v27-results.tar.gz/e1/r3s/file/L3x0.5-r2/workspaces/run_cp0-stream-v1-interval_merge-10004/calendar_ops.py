def merge_slots(intervals):
    """Merge overlapping intervals. Each interval is [start, end] of integers.
    Touching intervals like [1,3] and [3,5] are NOT merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    Returns merged intervals sorted by start ascending.
    """
    # Validate and normalize intervals
    validated = []
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
        validated.append(interval)

    # Sort by start time
    sorted_intervals = sorted(validated, key=lambda x: x[0])

    merged = []
    for start, end in sorted_intervals:
        if merged and start < merged[-1][1]:
            # Real overlap: merge by extending the end
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])

    return merged
