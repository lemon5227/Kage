def choose(items, capacity):
    """Select jobs under a capacity limit to maximize total value.
    
    Each item is a dict with unique string "id", positive integer "weight",
    and non-negative integer "value". Returns sorted list of ids whose
    total value is as large as possible while total weight stays <= capacity.
    If several selections tie on total value, return the lexicographically
    smallest sorted id list. An empty selection is allowed.
    
    Raises ValueError if capacity is negative or any weight is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "id" not in item or not isinstance(item["id"], str):
            raise ValueError("Each item must have a string 'id'")
        if "weight" not in item or not isinstance(item["weight"], int):
            raise ValueError("Each item must have an integer 'weight'")
        if "value" not in item or not isinstance(item["value"], int):
            raise ValueError("Each item must have an integer 'value'")
        if item["weight"] <= 0:
            raise ValueError("Weight must be positive")
    
    if not items:
        return []
    
    n = len(items)
    # dp[w] = (max_value, sorted_ids) for weight exactly w
    # We'll track the best value and corresponding ids
    # Use a dictionary mapping weight to (value, ids_tuple)
    # Since we need lexicographically smallest ids when values tie,
    # we'll store tuples and compare appropriately
    
    # Initialize: dp[0] = (0, ()) - zero weight gives zero value with empty selection
    dp = [(-1)] * (capacity + 1)
    dp[0] = (0, ())
    
    # For each item, update dp table
    for item in items:
        id_ = item["id"]
        weight = item["weight"]
        value = item["value"]
        
        # Iterate backwards to avoid using same item multiple times
        for w in range(capacity, weight - 1, -1):
            # Check if we can improve dp[w] by including this item
            prev_value, prev_ids = dp[w - weight]
            new_value = prev_value + value
            new_ids = prev_ids + (id_,)
            
            # Compare: if new_value > dp[w][0], update
            # If equal, choose lexicographically smaller ids tuple
            current_value, current_ids = dp[w]
            if new_value > current_value:
                dp[w] = (new_value, new_ids)
            elif new_value == current_value:
                # Choose lexicographically smaller ids tuple
                if new_ids < current_ids:
                    dp[w] = (new_value, new_ids)
    
    # Find the maximum value among all weights <= capacity
    max_value = 0
    best_ids = ()
    
    for w in range(capacity + 1):
        if dp[w][0] > max_value:
            max_value = dp[w][0]
            best_ids = dp[w][1]
        elif dp[w][0] == max_value:
            # Choose lexicographically smaller
            if dp[w][1] < best_ids:
                best_ids = dp[w][1]
    
    return sorted(best_ids)
