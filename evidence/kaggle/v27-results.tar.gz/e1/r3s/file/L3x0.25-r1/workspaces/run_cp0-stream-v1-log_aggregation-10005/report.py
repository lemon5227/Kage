def summarize(lines):
    """
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Return a dict mapping each service for levels WARN only to how many lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines.
    Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        if not line or not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        # Check if the line format is correct: "<timestamp> <LEVEL> <service>: <message>"
        # The service must be followed by a colon
        if not service.endswith(':'):
            continue
        # Only count WARN level
        if level != 'WARN':
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
