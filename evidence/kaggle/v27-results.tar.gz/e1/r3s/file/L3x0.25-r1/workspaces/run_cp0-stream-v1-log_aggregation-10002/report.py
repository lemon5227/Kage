def digest_lines(lines):
    """Process log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns a dictionary {name: count} per level, with level names in uppercase.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not line.strip():
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # Format: <timestamp> <LEVEL> <service>: <message>
        # The third part should contain a colon to separate service from message
        if ':' not in parts[2]:
            continue
        level = parts[1].upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
