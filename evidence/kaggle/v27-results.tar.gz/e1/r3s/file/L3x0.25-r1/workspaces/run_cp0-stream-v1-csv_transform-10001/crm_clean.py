import csv
import io

def clean_rows(text):
    # Parse CSV text into list of dicts
    reader = csv.reader(io.StringIO(text))
    rows = []
    for row in reader:
        rows.append(dict(zip(row, ['team', 'name', 'city', 'id', 'score'])))
    
    if not rows:
        return ''
    
    # Extract header from first row
    header = rows[0].keys()
    
    # Process remaining rows
    processed = []
    for i in range(1, len(rows)):
        row = rows[i]
        
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Drop rows whose "score" cell is empty
        if not cleaned_row[4].strip():
            continue
        
        processed.append(cleaned_row)
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped = []
    for row in processed:
        score = row[4]
        if score not in seen_scores:
            seen_scores.add(score)
            deduped.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    deduped.sort(key=lambda row: row[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(deduped[0])  # header
    for row in deduped[1:]:
        writer.writerow(row)
    
    return output.getvalue()
