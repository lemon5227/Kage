def allocate(items, capacity):
    """Select items to maximize total score while keeping total size <= capacity.
    
    Args:
        items: List of dicts with keys "id" (str), "size" (int > 0), "score" (int >= 0).
        capacity: Non-negative integer representing maximum total size allowed.
    
    Returns:
        Sorted list of item ids that achieve the maximum total score.
        If multiple selections tie on total score, returns the lexicographically smallest sorted id list.
    
    Raises:
        ValueError: If capacity is negative or any item has size <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        if "id" not in item or "size" not in item or "score" not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if not isinstance(item["id"], str):
            raise ValueError("Item id must be a string")
        if item["size"] <= 0:
            raise ValueError("Item size must be positive")
        if not isinstance(item["score"], int) or item["score"] < 0:
            raise ValueError("Item score must be a non-negative integer")
    
    # Handle empty items list
    if not items:
        return []
    
    n = len(items)
    
    # dp[i][w] = (max_score, chosen_ids) for first i items with total size <= w
    # We'll store the best score and the lexicographically smallest id list achieving it
    dp = [[(0, [])] * (capacity + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        item = items[i - 1]
        size = item["size"]
        score = item["score"]
        prev_row = dp[i - 1]
        current_row = dp[i]
        
        for w in range(capacity + 1):
            # Option 1: don't include item i
            current_row[w] = (prev_row[i][w][0], prev_row[i][w][1].copy())
            
            # Option 2: include item i if size <= w
            if size <= w:
                prev_score, prev_ids = prev_row[i - 1][w - size]
                new_score = prev_score + score
                new_ids = prev_ids.copy()
                new_ids.append(item["id"])
                
                # Compare with current best for this capacity
                if new_score > prev_row[i][w][0]:
                    current_row[w] = (new_score, new_ids)
                elif new_score == prev_row[i][w][0]:
                    # Lexicographically smallest id list
                    if new_ids < prev_row[i][w][1]:
                        current_row[w] = (new_score, new_ids)
    
    # Find the maximum score across all capacities
    max_score = 0
    best_ids = []
    
    for w in range(capacity + 1):
        score, ids = dp[n][w]
        if score > max_score:
            max_score = score
            best_ids = ids.copy()
        elif score == max_score:
            # Lexicographically smallest
            if ids < best_ids:
                best_ids = ids.copy()
    
    return sorted(best_ids)
