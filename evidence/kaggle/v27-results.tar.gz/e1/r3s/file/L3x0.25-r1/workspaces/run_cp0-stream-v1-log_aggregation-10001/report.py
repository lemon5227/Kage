def tally_events(lines):
    """Tally events from log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    
    Returns a dict {name: count} for services with ERROR or WARN levels (case-insensitive).
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) < 3:
            continue
        
        # parts[0] = timestamp, parts[1] = LEVEL, parts[2] should be "service: message"
        level = parts[1].upper()
        service_part = parts[2]
        
        # Check if service part contains a colon
        if ':' not in service_part:
            continue
        
        service = service_part.split(':')[0]
        
        # Only count ERROR and WARN levels
        if level in ('ERROR', 'WARN'):
            counts[service] = counts.get(service, 0) + 1
    
    return counts
