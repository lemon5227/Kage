import unicodedata

def make_handle(text):
    """Turn a title into a handle according to specified rules."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is not None:
                result.append('-')
            prev_char = None
        else:
            result.append(char)
            prev_char = char
    
    # Join and strip leading/trailing "-"
    handle = ''.join(result).strip('-')
    
    # If longer than 23 characters, cut to 23 and strip trailing "-"
    if len(handle) > 23:
        handle = handle[:23].strip('-')
    
    return handle
