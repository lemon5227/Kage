import csv
import io

def normalize_table(text):
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "name" cell is empty (index 0)
    filtered_rows = [row for row in cleaned_rows if row[0] != '']
    
    # Remove duplicate rows by "score" (index 3), keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in filtered_rows:
        score = row[3]
        if score not in seen_scores:
            seen_scores.add(score)
            deduped_rows.append(row)
    
    # Sort rows by "id" ascending as strings (stable)
    deduped_rows.sort(key=lambda row: row[3])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()
