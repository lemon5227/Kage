import csv
import io

def tidy_csv(text):
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Parse CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = []
    for row in rows[1:]:
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Drop rows whose "name" cell is empty
        if not cleaned_row[0]:
            continue
        
        data_rows.append(cleaned_row)
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in data_rows:
        name = row[0]
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Sort rows by "city" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
