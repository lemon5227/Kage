def merge_slots(intervals):
    """Merge overlapping intervals. Each interval is a dict {"from": s, "to": e} with integer values.
    Return merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged. Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate and convert intervals to a list of (start, end) tuples
    validated = []
    for interval in intervals:
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
        validated.append((s, e))
    
    # Sort by start time
    validated.sort(key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for start, end in validated:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching - merge
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    
    # Convert back to dict format
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})
    
    return result
