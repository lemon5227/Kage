def slugify(text):
    """Build a URL slug from text.
    
    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces runs of non-alphanumeric characters with a single hyphen,
    and strips leading/trailing hyphens.
    
    Raises TypeError if text is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # NFKD normalization decomposes characters into base + combining marks
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lowercase
    lower_text = ascii_text.lower()
    
    # Replace runs of non-alphanumeric characters with a single hyphen
    slug = []
    previous_char_is_alnum = False
    for char in lower_text:
        if char.isalnum():
            slug.append(char)
            previous_char_is_alnum = True
        else:
            if not previous_char_is_alnum:
                slug.append('-')
                previous_char_is_alnum = False
    
    result = ''.join(slug)
    
    # Strip leading and trailing hyphens
    while result.startswith('-'):
        result = result[1:]
    while result.endswith('-'):
        result = result[:-1]
    
    return result
