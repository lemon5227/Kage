import csv
import io

def normalize_table(text):
    # Handle empty string
    if not text.strip():
        return ''
    
    # Parse CSV text into list of dicts
    reader = csv.reader(io.StringIO(text))
    rows = []
    for row in reader:
        if len(row) < 4:
            continue
        rows.append(dict(zip(['id', 'email', 'city', 'name'], row)))
    
    # Handle header-only input (no data rows)
    if not rows:
        return '\n'.join(['id', 'email', 'city', 'name']) + '\n'
    
    # Strip leading/trailing whitespace from every cell
    for row in rows:
        row['id'] = row['id'].strip()
        row['email'] = row['email'].strip()
        row['city'] = row['city'].strip()
        row['name'] = row['name'].strip()
    
    # Drop rows whose "id" cell is empty
    rows = [r for r in rows if r['id']]
    
    # Lower-case the "email" column
    for row in rows:
        row['email'] = row['email'].lower()
    
    # Remove duplicate rows by "email", keeping the first occurrence
    seen_emails = set()
    deduped_rows = []
    for row in rows:
        if row['email'] not in seen_emails:
            seen_emails.add(row['email'])
            deduped_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    deduped_rows.sort(key=lambda r: r['email'])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(['id', 'email', 'city', 'name'])
    for row in deduped_rows:
        writer.writerow([row['id'], row['email'], row['city'], row['name']])
    
    return output.getvalue()
