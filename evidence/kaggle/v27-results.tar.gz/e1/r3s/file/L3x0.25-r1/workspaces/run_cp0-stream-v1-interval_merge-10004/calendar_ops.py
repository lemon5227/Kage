def merge_slots(intervals):
    """Merge overlapping intervals. Each interval is [start, end] of integers.
    Return merged intervals sorted by start ascending. Touching intervals are not merged.
    Raise ValueError if any interval has start > end. Do not modify the input."""
    # Validate and copy intervals to avoid modifying input
    validated = []
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
        validated.append(interval)
    
    # Sort by start time
    sorted_intervals = sorted(validated, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if merged and start < merged[-1][1]:
            # Overlapping: extend the last interval's end
            merged[-1] = [merged[-1][0], max(merged[-1][1], end)]
        else:
            merged.append(interval)
    
    return merged
