def digest_lines(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service:
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, upper-case the level
        # Check if third part starts with ':' (service:)
        if not parts[2].startswith(':'):
            continue
        
        # Valid line - count it
        counts[level] = counts.get(level, 0) + 1
    
    return counts
