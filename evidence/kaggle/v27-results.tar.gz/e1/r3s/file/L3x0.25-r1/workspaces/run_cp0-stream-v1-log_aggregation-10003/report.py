def aggregate_log(lines):
    """Aggregate log strings into {service: count} for ERROR and WARN levels only.
    
    Log format: "<timestamp> <LEVEL> <service>: <message>"
    - Only counts lines with ERROR or WARN levels (case-insensitive)
    - Returns dictionary with uppercase service keys
    - Drops malformed input lines
    """
    counts = {}
    for line in lines:
        if not line or not isinstance(line, str):
            continue
        
        parts = line.split()
        if len(parts) < 3:
            continue
        
        level = parts[1].upper()
        service = parts[2]
        
        if level not in ('ERROR', 'WARN'):
            continue
        
        counts[service] = counts.get(service, 0) + 1
    
    return counts
