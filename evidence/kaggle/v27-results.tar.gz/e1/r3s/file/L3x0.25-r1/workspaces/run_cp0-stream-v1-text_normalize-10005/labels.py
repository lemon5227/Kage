import unicodedata


def to_key(text):
    """Normalize labels into identifiers.
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with a single underscore,
    and strips leading/trailing underscores.
    
    Raises TypeError if text is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we replace any sequence of non-alphanumeric characters with "_"
    identifier = []
    prev_char_is_alnum = False
    for char in lowercased:
        if char.isalnum():  # a-z and 0-9
            identifier.append(char)
            prev_char_is_alnum = True
        else:
            if not prev_char_is_alnum:
                identifier.append('_')
                prev_char_is_alnum = False
    
    result = ''.join(identifier)
    
    # Strip leading and trailing "_"
    return result.strip('_')
