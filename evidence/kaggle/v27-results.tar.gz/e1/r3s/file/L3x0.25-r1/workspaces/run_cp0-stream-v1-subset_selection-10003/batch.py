def pick_jobs(items, capacity):
    """Choose parcels to maximize total score while total size stays <= capacity.
    
    Each item is a dict with a unique string "id", a positive integer "size" 
    and a non-negative integer "score". Return the sorted list of ids whose 
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically 
    smallest sorted id list. An empty selection is allowed.
    
    Raise ValueError if capacity is negative or any size is <= 0.
    Do not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        item_id = item.get("id")
        size = item.get("size")
        score = item.get("score")
        
        if item_id is None or size is None or score is None:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        
        if not isinstance(item_id, str):
            raise ValueError("Item id must be a string")
        
        if size <= 0:
            raise ValueError("Item size must be positive")
        
        if not isinstance(score, int) or score < 0:
            raise ValueError("Item score must be a non-negative integer")
    
    # If no items, return empty list
    if not items:
        return []
    
    n = len(items)
    
    # dp[i][w] = (max_score, chosen_ids) for first i items with capacity w
    # We'll store the best (score, id_list) for each capacity
    # Since we need lexicographically smallest when scores tie, we need to be careful
    
    # Initialize: dp[w] = (max_score, chosen_ids) for capacity w
    # We'll use a list where index is capacity, value is (score, tuple of ids)
    dp = [(0, ())] * (capacity + 1)
    
    # Process each item
    for item in items:
        item_id = item["id"]
        size = item["size"]
        score = item["score"]
        
        # Iterate backwards to avoid using the same item multiple times
        for w in range(capacity, size - 1, -1):
            # Option 1: don't include this item
            score1, ids1 = dp[w]
            
            # Option 2: include this item (if we have enough capacity)
            score2, ids2 = dp[w - size]
            new_score = score2 + score
            new_ids = ids2 + (item_id,)
            
            # Choose the better option: higher score, or if tie, lexicographically smaller id list
            if new_score > score1:
                dp[w] = (new_score, new_ids)
            elif new_score == score1:
                # Compare lexicographically
                if new_ids < ids1:
                    dp[w] = (new_score, new_ids)
    
    # The answer is the best result for any capacity from 0 to capacity
    max_score = 0
    best_ids = ()
    
    for w in range(capacity + 1):
        score, ids = dp[w]
        if score > max_score:
            max_score = score
            best_ids = ids
        elif score == max_score:
            if ids < best_ids:
                best_ids = ids
    
    return sorted(best_ids)
