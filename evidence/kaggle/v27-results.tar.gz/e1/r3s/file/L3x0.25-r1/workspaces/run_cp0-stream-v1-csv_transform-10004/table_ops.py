import csv
import io

def clean_rows(text):
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Parse CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)
    
    # Drop rows whose "score" cell is empty
    # Score is at index 2 (id=0, team=1, score=2)
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) > 2 and row[2] == '':
            continue
        filtered_rows.append(row)
    
    # Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    deduped_rows = []
    for row in filtered_rows:
        if len(row) < 2:
            continue
        team = row[1]
        if team in seen_teams:
            continue
        seen_teams.add(team)
        deduped_rows.append(row)
    
    # Sort rows by "score" ascending as strings (stable)
    # Score is at index 2
    sorted_rows = sorted(deduped_rows, key=lambda row: row[2] if len(row) > 2 else '')
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in sorted_rows:
        writer.writerow(row)
    
    return output.getvalue()
