import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # NFKD normalization
    text = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters
    text = ''.join(char for char in text if ord(char) < 128)
    
    # Lower-case
    text = text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for char in text:
        if char.isalnum():
            result.append(char)
        else:
            if prev_char is not None:
                result.append('-')
            prev_char = char
    
    # Strip leading and trailing "-"
    result = ''.join(result).strip('-')
    
    return result
