def merge_slots(intervals):
    """Merge overlapping intervals. Each interval is a dict {"from": s, "to": e} with integer values.
    Return merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged. Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate and convert intervals to a list of (start, end) tuples
    normalized = []
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
        normalized.append((start, end))

    # Sort by start time
    normalized.sort(key=lambda x: x[0])

    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching: extend the last interval
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))

    # Convert back to dict format
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})

    return result
