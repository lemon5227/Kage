def allocate(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Return the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raise ValueError if capacity is negative or any cost is <= 0.
    Do not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")

    # Handle empty items list
    if not items:
        return []

    # Create a list of (id, gain, cost) tuples
    jobs = [(item["id"], item["gain"], item["cost"]) for item in items]

    # Sort by gain descending, then by cost ascending for tie-breaking
    # This helps with the lexicographic requirement when gains are equal
    jobs.sort(key=lambda x: (-x[1], x[2]))

    # Use dynamic programming for 0/1 knapsack
    # dp[i][c] = maximum gain using first i jobs with capacity c
    n = len(jobs)
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        job_id, gain, cost = jobs[i - 1]
        for c in range(capacity + 1):
            # Option 1: don't include this job
            dp[i][c] = dp[i - 1][c]
            # Option 2: include this job if capacity allows
            if cost <= c:
                dp[i][c] = max(dp[i][c], dp[i - 1][c - cost] + gain)

    # Reconstruct the selected jobs
    selected = []
    c = capacity
    for i in range(n, 0, -1):
        job_id, gain, cost = jobs[i - 1]
        if dp[i][c] != dp[i - 1][c]:
            selected.append(job_id)
            c -= cost

    # Return sorted list of ids (lexicographically smallest when ties occur)
    return sorted(selected)
