import csv
import io

def normalize_table(text):
    if text == "":
        return ""
    
    # Parse CSV text into a list of dicts
    reader = csv.reader(io.StringIO(text))
    rows = []
    for row in reader:
        rows.append(dict(zip(row, ["name", "team", "city", "id", "score"])))
    
    if not rows:
        return ""
    
    # Extract header from first row
    header = rows[0].keys()
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in rows:
        cleaned_row = {k: v.strip() for k, v in row.items()}
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "name" cell is empty
    filtered_rows = [row for row in cleaned_rows if row["name"] != "" and row["name"] is not None]
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in filtered_rows:
        score = row["score"]
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped_rows.append(row)
    
    # Sort rows by "id" ascending as strings (stable)
    deduped_rows.sort(key=lambda row: row["id"])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow([row[k] for k in header])
    
    return output.getvalue()
