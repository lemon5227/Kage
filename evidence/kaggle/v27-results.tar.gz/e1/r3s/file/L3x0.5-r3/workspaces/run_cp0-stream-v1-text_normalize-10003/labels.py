import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters
    text = "".join(c for c in text if ord(c) < 128)

    # Lower-case
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    parts = []
    current = ""
    for c in text:
        if c.isalnum():
            current += c
        else:
            if current:
                parts.append(current)
                current = ""
            parts.append("-")
    if current:
        parts.append(current)

    text = "".join(parts)

    # Strip leading and trailing "-"
    return text.strip("-")
