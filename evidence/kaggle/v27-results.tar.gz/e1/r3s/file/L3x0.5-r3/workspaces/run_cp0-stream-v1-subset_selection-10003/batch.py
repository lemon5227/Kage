def pick_jobs(items, capacity):
    """Choose parcels to maximize total score while total size stays <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    Does not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("size must be positive")

    # Handle empty items list
    if not items:
        return []

    # Create a list of (id, size, score) tuples
    items_list = [(item["id"], item["size"], item["score"]) for item in items]

    n = len(items_list)

    # dp[i][w] = (max_score, chosen_ids) for first i items with capacity w
    # We'll store the best score and the lexicographically smallest id list
    # among those achieving that score.
    # Initialize dp[0][w] = (0, []) for all w >= 0
    dp = [[(0, [])] * (capacity + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        item_id, size, score = items_list[i - 1]
        for w in range(capacity + 1):
            # Option 1: don't include this item
            best_score, best_ids = dp[i - 1][w]

            # Option 2: include this item if size <= w
            if size <= w:
                prev_score, prev_ids = dp[i - 1][w - size]
                new_score = prev_score + score
                new_ids = prev_ids + [item_id]

                # Compare: prefer higher score; if tie, prefer lexicographically smaller id list
                if new_score > best_score:
                    best_score = new_score
                    best_ids = new_ids
                elif new_score == best_score:
                    # Compare lexicographically
                    if sorted(new_ids) < sorted(best_ids):
                        best_ids = new_ids

            dp[i][w] = (best_score, best_ids)

    # The answer is the best result across all capacities from 0 to capacity
    max_score, best_ids = dp[n][capacity]

    # Return the sorted list of ids
    return sorted(best_ids)
