def select_tasks(items, capacity):
    """Select a subset of tasks to maximize total score while keeping total size <= capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer
      - "score": non-negative integer

    Returns a sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total
    score, return the lexicographically smallest sorted id list.

    Raises ValueError if capacity is negative or any size is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        if "size" not in item or "score" not in item or "id" not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if not isinstance(item["size"], int) or item["size"] <= 0:
            raise ValueError("size must be a positive integer")
        if not isinstance(item["score"], int) or item["score"] < 0:
            raise ValueError("score must be a non-negative integer")

    # Handle empty items list
    if not items:
        return []

    # Use dynamic programming for the 0/1 knapsack problem
    # dp[i][w] = maximum score using first i items with total size <= w
    n = len(items)
    # We'll track which items were selected to reconstruct the solution
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    parent = [[None] * (capacity + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        prev = dp[i - 1]
        curr = dp[i]
        size = items[i - 1]["size"]
        score = items[i - 1]["score"]

        for w in range(capacity + 1):
            # Option 1: don't include item i-1
            curr[w] = prev[w]

            # Option 2: include item i-1 if it fits
            if w >= size:
                if prev[w - size] + score > curr[w]:
                    curr[w] = prev[w - size] + score
                    parent[i][w] = (i - 1, w - size)

    # Find the maximum score achievable with capacity <= capacity
    max_score = dp[n][capacity]

    # Reconstruct the selected items
    selected = []
    w = capacity
    for i in range(n, 0, -1):
        if parent[i][w] is not None:
            item_idx = i - 1
            selected.append(items[item_idx]["id"])
            w -= items[item_idx]["size"]

    # The reconstruction gives items in reverse order; sort lexicographically
    return sorted(selected)
