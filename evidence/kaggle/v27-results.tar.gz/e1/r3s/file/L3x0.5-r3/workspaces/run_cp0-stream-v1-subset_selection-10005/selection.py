def allocate(items, capacity):
    """Select a subset of items to maximize total score while keeping total size <= capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer
      - "score": non-negative integer

    Returns the sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total score,
    return the lexicographically smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for item in items:
        if "size" not in item or "score" not in item or "id" not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if not isinstance(item["size"], int) or item["size"] <= 0:
            raise ValueError("size must be a positive integer")
        if not isinstance(item["score"], int) or item["score"] < 0:
            raise ValueError("score must be a non-negative integer")

    # Handle empty items list
    if not items:
        return []

    # Use dynamic programming for the 0/1 knapsack problem with scores
    # dp[w] = (max_score, sorted_ids) for capacity w
    # We'll track the best score and lexicographically smallest id list for each capacity
    
    # Initialize dp[0] = (0, []) and others as (-1, None)
    dp = [(0, [])] * (capacity + 1)
    
    # Process items one by one
    for item in items:
        item_id = item["id"]
        size = item["size"]
        score = item["score"]
        
        # Iterate backwards to avoid using the same item multiple times
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[w - size]
            new_score = prev_score + score
            new_ids = prev_ids + [item_id]
            
            # Compare with current dp[w]
            if new_score > dp[w][0]:
                dp[w] = (new_score, sorted(new_ids))
            elif new_score == dp[w][0]:
                # Choose lexicographically smallest sorted id list
                if sorted(new_ids) < dp[w][1]:
                    dp[w] = (new_score, sorted(new_ids))
    
    # The answer is the best score across all capacities, with lexicographically smallest id list
    max_score = 0
    best_ids = []
    
    for w in range(capacity + 1):
        score, ids = dp[w]
        if score > max_score:
            max_score = score
            best_ids = ids
        elif score == max_score:
            if ids < best_ids:
                best_ids = ids
    
    return best_ids
