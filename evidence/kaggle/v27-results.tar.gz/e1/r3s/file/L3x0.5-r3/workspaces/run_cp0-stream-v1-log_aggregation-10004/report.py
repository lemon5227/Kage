def digest_lines(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if not level.isalpha():
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
