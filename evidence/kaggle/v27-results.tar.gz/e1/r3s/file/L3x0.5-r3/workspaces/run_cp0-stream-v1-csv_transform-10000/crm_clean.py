import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = rows[0]
    data_rows = rows[1:]

    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)

    # Drop rows whose "name" cell is empty
    name_idx = header.index("name")
    cleaned_rows = [row for row in cleaned_rows if row[name_idx] != "" and row[name_idx] is not None]

    # Lower-case the "email" column
    email_idx = header.index("email")
    for row in cleaned_rows:
        row[email_idx] = row[email_idx].lower()

    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    deduped_rows = []
    for row in cleaned_rows:
        name = row[name_idx]
        if name in seen_names:
            continue
        seen_names.add(name)
        deduped_rows.append(row)

    # Sort rows by "email" ascending as strings (stable)
    deduped_rows.sort(key=lambda row: row[email_idx])

    # Write output with '\n' line endings using csv module
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)

    return output.getvalue()
