def tally_events(lines):
    """Tally log lines by service for ERROR and WARN levels.
    
    Lines are formatted as "<timestamp> <LEVEL> <service>: <message>".
    Returns {name: count} per service for levels ERROR, WARN only,
    treating level names case-insensitively (upper-case keys), dropping
    malformed input lines.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        service = parts[2]
        if level not in ("ERROR", "WARN"):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
