def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Top-level keys are renamed: "dir" -> "directory", "host" -> "hostname".
    "port" and "workers" are moved into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Other keys are kept unchanged; keys whose value is None are dropped.
    """
    # Validate input version
    if cfg.get("version") != 1:
        raise ValueError(
            "config_v2.py: expected cfg['version'] == 1, got %r" % cfg.get("version")
        )

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process top-level keys
    for key in list(cfg.keys()):
        value = cfg[key]

        # Drop keys whose value is None
        if value is None:
            continue

        if key == "dir":
            result["directory"] = value
        elif key == "host":
            result["hostname"] = value
        elif key == "port":
            # port moves into storage sub-dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["port"] = value
        elif key == "workers":
            # workers moves into storage sub-dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["workers"] = value
        elif key == "timeout_ms":
            # Convert milliseconds to seconds (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value

    return result
