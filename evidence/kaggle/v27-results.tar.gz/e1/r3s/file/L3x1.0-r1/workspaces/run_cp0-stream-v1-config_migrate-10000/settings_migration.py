def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "max_conn" -> "max_connections"
      "dir" -> "directory"
      "host" -> "hostname"
    Moves "cache_size" and "region" into a sub-dict "limits" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError(
            "upgrade_config requires cfg['version'] == 1; "
            f"got {cfg.get('version')}"
        )

    # Work on a copy so the input is never modified
    out = {}
    out["version"] = 2

    # Process known old keys
    if "max_conn" in cfg and cfg["max_conn"] is not None:
        out["max_connections"] = cfg["max_conn"]

    if "dir" in cfg and cfg["dir"] is not None:
        out["directory"] = cfg["dir"]

    if "host" in cfg and cfg["host"] is not None:
        out["hostname"] = cfg["host"]

    # Move cache_size and region into limits
    limits = {}
    if "cache_size" in cfg and cfg["cache_size"] is not None:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg and cfg["region"] is not None:
        limits["region"] = cfg["region"]
    out["limits"] = limits

    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg and cfg["timeout_ms"] is not None:
        out["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged (but drop None values)
    for key, value in cfg.items():
        if key in ("max_conn", "dir", "host", "cache_size", "region", "timeout_ms"):
            continue
        if value is None:
            continue
        out[key] = value

    return out
