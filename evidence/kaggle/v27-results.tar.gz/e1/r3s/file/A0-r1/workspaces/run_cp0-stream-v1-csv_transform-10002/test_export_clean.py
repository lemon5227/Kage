#!/usr/bin/env python3
"""Test script for export_clean.py"""

from export_clean import normalize_table

# Test 1: Basic functionality
test_input = """name,team,city,id,score
Alice,TeamA,City1,1,A
Bob,TeamB,City2,2,B
Charlie,TeamC,City3,3,C
"""
result = normalize_table(test_input)
print("Test 1 - Basic:")
print(result)

# Test 2: With duplicates and empty name
test_input2 = """name,team,city,id,score
Alice,TeamA,City1,1,A
Bob,TeamB,City2,2,B

Charlie,TeamC,City3,3,C
Alice,TeamA,City1,1,A
"""
result2 = normalize_table(test_input2)
print("\nTest 2 - Duplicates and empty name:")
print(result2)

# Test 3: Header-only input
test_input3 = """name,team,city,id,score
"""
result3 = normalize_table(test_input3)
print("\nTest 3 - Header only:")
print(repr(result3))

# Test 4: Whitespace stripping
test_input4 = """ name , team , city , id , score 
 Alice , TeamA , City1 , 1 , A 
 Bob , TeamB , City2 , 2 , B 
"""
result4 = normalize_table(test_input4)
print("\nTest 4 - Whitespace stripping:")
print(result4)

# Test 5: Empty input
test_input5 = ""
result5 = normalize_table(test_input5)
print("\nTest 5 - Empty input:")
print(repr(result5))
