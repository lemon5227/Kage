def label_id(text):
    """Build a URL slug from text.
    
    Applies unicodedata NFKD normalization, drops non-ASCII characters,
    lower-cases, replaces every run of characters outside [a-z0-9] with a single "-",
    and strips leading and trailing "-".
    
    Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to split on any character that is not a-z or 0-9
    slug = []
    previous_was_separator = False
    
    for char in lowercased:
        if char.isalnum():  # a-z and 0-9
            if not previous_was_separator:
                slug.append(char)
            previous_was_separator = False
        else:
            if not previous_was_separator:
                slug.append('-')
            previous_was_separator = True
    
    result = ''.join(slug)
    
    # Strip leading and trailing "-"
    result = result.strip('-')
    
    return result
