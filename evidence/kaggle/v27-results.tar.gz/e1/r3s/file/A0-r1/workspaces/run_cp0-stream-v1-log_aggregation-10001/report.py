def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per service for levels ERROR, WARN only, case-insensitive."""
    
    result = {}
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service:
        if len(parts) < 3:
            continue
        
        level = parts[1].upper()
        # parts[2] should be "service:"
        service_part = parts[2]
        if not service_part.endswith(':'):
            # Malformed, skip
            continue
        service = service_part.rstrip(':')
        
        # Check if level is ERROR or WARN
        if level not in ('ERROR', 'WARN'):
            continue
        
        result[service] = result.get(service, 0) + 1
    
    return result
