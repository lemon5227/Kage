from crm_clean import clean_rows

# Test 1: duplicate scores, should keep first and sort by name
test1 = "team,name,city,id,score\nA,B,C,D,10\nE,F,G,H,10"
result1 = clean_rows(test1)
print("Test 1 (duplicates):")
print(result1)
print()

# Test 2: single row
test2 = "team,name,city,id,score\nA,B,C,D,10"
result2 = clean_rows(test2)
print("Test 2 (single row):")
print(result2)
print()

# Test 3: header only
test3 = "team,name,city,id,score"
result3 = clean_rows(test3)
print("Test 3 (header only):")
print(result3)
print()

# Test 4: empty score row
test4 = "team,name,city,id,score\nA,B,C,D,\nE,F,G,H,10"
result4 = clean_rows(test4)
print("Test 4 (empty score):")
print(result4)
print()

# Test 5: whitespace stripping
test5 = " team , name , city , id , score \n A , B , C , D , 10 "
result5 = clean_rows(test5)
print("Test 5 (whitespace):")
print(result5)
print()

# Test 6: multiple duplicates, sort by name
test6 = "team,name,city,id,score\nZ,A,B,C,D,10\nM,N,O,P,20\nA,B,C,D,10"
result6 = clean_rows(test6)
print("Test 6 (sort by name):")
print(result6)
