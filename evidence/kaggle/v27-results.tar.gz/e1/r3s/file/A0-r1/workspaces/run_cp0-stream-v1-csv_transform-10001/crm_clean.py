import csv
import io


def clean_rows(text):
    """
    Clean CSV text with header row (columns: team, name, city, id, score).
    
    Operations:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "name" ascending as strings (stable)
    
    Returns cleaned CSV text with the same header.
    """
    # Parse the input text into a list of lines
    lines = text.strip().split('\n')
    
    if len(lines) == 0:
        return ''
    
    # Extract header and data rows
    header = lines[0]
    data_lines = lines[1:]
    
    # If only header, return just the header
    if len(data_lines) == 0:
        return header
    
    # Parse each row into a list of cells
    rows = []
    for line in data_lines:
        # Skip empty lines
        if not line.strip():
            continue
        # Split by comma
        cells = line.split(',')
        # Strip whitespace from each cell
        cells = [cell.strip() for cell in cells]
        rows.append(cells)
    
    # Drop rows whose "score" cell is empty (index 4)
    filtered_rows = []
    for row in rows:
        if len(row) < 5:
            continue
        if row[4] == '':
            continue
        filtered_rows.append(row)
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in filtered_rows:
        score = row[4]
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    # Use a stable sort - Python's sorted is stable
    sorted_rows = sorted(unique_rows, key=lambda row: row[1])
    
    # Build the output CSV text
    output_lines = [header]
    for row in sorted_rows:
        output_lines.append(','.join(row))
    
    # Join with '\n' line endings
    return '\n'.join(output_lines)


if __name__ == '__main__':
    # Test examples
    test1 = "team,name,city,id,score\nA,B,C,D,10\nE,F,G,H,10"
    print("Test 1:", clean_rows(test1))
    
    test2 = "team,name,city,id,score\nA,B,C,D,10"
    print("Test 2:", clean_rows(test2))
    
    test3 = "team,name,city,id,score"
    print("Test 3:", clean_rows(test3))
    
    test4 = "team,name,city,id,score\nA,B,C,D,\nE,F,G,H,10"
    print("Test 4:", clean_rows(test4))
