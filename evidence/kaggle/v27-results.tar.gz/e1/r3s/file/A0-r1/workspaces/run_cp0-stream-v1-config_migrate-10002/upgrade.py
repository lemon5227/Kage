def upgrade_config(cfg):
    # Check version - must be 1 to proceed
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1 for upgrade")
    
    # Create a new dict without modifying the input
    new_cfg = {"version": 2}
    
    # Rename top-level keys
    if "dir" in cfg:
        new_cfg["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        new_cfg["max_connections"] = cfg["max_conn"]
    
    # Move "region" and "retries" into a sub-dict "network"
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    new_cfg["network"] = network
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key not in ["dir", "pwd_file", "max_conn", "region", "retries", "timeout_ms"]:
            if value is not None:
                new_cfg[key] = value
    
    return new_cfg
