def summarize(lines):
    """
    Process lines in format: <timestamp> <LEVEL> <service>: <message>
    Returns a dict mapping each service for levels WARN only to count.
    Levels are case-insensitive (reported upper-case). Skip malformed lines.
    Omit keys with zero count.
    """
    service_counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report upper-case
        service = parts[2]
        
        # Only process WARN level
        if level != 'WARN':
            continue
        
        # Increment count for this service
        service_counts[service] = service_counts.get(service, 0) + 1
    
    return service_counts
