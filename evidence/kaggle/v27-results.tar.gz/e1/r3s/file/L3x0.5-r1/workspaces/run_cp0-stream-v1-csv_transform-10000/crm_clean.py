import csv
import io


def normalize_table(text):
    if text.strip() == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = rows[0]
    # columns: score, id, email, name
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned_data = []
    for row in data:
        stripped_row = [cell.strip() for cell in row]
        cleaned_data.append(stripped_row)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name")
    cleaned_data = [row for row in cleaned_data if row[name_idx] != "" and row[name_idx] is not None]

    # lower-case the "email" column
    email_idx = header.index("email")
    for row in cleaned_data:
        row[email_idx] = row[email_idx].lower()

    # remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped_data = []
    for row in cleaned_data:
        name = row[name_idx]
        if name in seen:
            continue
        seen.add(name)
        deduped_data.append(row)

    # sort rows by "email" ascending as strings (stable)
    deduped_data.sort(key=lambda row: row[email_idx])

    # write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_data:
        writer.writerow(row)

    return output.getvalue()
