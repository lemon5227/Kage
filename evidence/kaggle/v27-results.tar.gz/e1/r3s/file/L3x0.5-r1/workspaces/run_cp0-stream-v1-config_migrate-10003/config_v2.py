def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.
    
    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Renames top-level keys "dir" -> "directory", "host" -> "hostname".
    Moves "port" and "workers" into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")

    # Make a copy to avoid modifying the input
    result = {}
    result["version"] = 2

    # Process keys
    for key, value in cfg.items():
        if key == "dir":
            result["directory"] = value
        elif key == "host":
            result["hostname"] = value
        elif key == "port":
            # Move into storage dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["port"] = value
        elif key == "workers":
            # Move into storage dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["workers"] = value
        elif key == "timeout_ms":
            if value is not None:
                result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged, but skip if value is None
            if value is not None:
                result[key] = value

    return result
