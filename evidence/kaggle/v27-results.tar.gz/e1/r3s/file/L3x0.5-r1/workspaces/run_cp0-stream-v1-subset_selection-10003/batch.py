def pick_jobs(items, capacity):
    """Choose parcels to maximize total score while total size stays <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    Does not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("size must be positive")

    if not items:
        return []

    # Create a list of (id, size, score) tuples
    entries = [(item["id"], item["size"], item["score"]) for item in items]

    n = len(entries)
    # dp[i][w] = best score using first i items with total size <= w
    # We also need to track the lexicographically smallest id list among ties.
    # We'll store (score, id_list) in the DP table.
    # Initialize dp[0][w] = (0, []) for all w.
    dp = [[(0, []) for _ in range(capacity + 1)] for _ in range(n + 1)]

    for i in range(1, n + 1):
        item_id, size, score = entries[i - 1]
        for w in range(capacity + 1):
            # Option 1: don't include item i
            best = dp[i - 1][w]
            # Option 2: include item i if size <= w
            if size <= w:
                new_score = dp[i - 1][w - size][1] + score
                new_id_list = dp[i - 1][w - size][1] + [item_id]
                # Compare: prefer higher score, then lexicographically smaller id list
                if new_score > best[0] or (new_score == best[0] and new_id_list < best[1]):
                    best = (new_score, new_id_list)
            dp[i][w] = best

    # Find the best score across all capacities <= capacity
    best_score = 0
    best_id_list = []
    for w in range(capacity + 1):
        score, id_list = dp[n][w]
        if score > best_score or (score == best_score and id_list < best_id_list):
            best_score = score
            best_id_list = id_list

    return best_id_list
