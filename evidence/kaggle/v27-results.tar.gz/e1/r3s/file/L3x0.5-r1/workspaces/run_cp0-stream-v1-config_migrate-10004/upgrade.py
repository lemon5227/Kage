def migrate(cfg):
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1")

    # Create new dict with version 2
    new_cfg = {"version": 2}

    # Rename top-level keys
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    if "user" in cfg:
        new_cfg["username"] = cfg["user"]

    # Handle timeout_ms if present
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    new_cfg["network"] = network

    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key in ("version", "pwd_file", "user", "timeout_ms", "cache_size", "workers"):
            continue
        if value is None:
            continue
        new_cfg[key] = value

    return new_cfg
