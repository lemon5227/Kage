import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = rows[0]
    data = rows[1:]

    # Strip leading/trailing whitespace from every cell
    cleaned_data = []
    for row in data:
        stripped_row = [cell.strip() for cell in row]
        cleaned_data.append(stripped_row)

    # Drop rows whose "score" cell is empty
    score_idx = header.index("score") if "score" in header else -1
    if score_idx >= 0:
        cleaned_data = [row for row in cleaned_data if row[score_idx] != "" and row[score_idx] != " "]

    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_data = []
    for row in cleaned_data:
        score = row[score_idx] if score_idx >= 0 else ""
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped_data.append(row)

    # Sort rows by "name" ascending as strings (stable)
    name_idx = header.index("name") if "name" in header else -1
    if name_idx >= 0:
        deduped_data.sort(key=lambda row: row[name_idx])

    # Write output with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(deduped_data)
    return output.getvalue()
