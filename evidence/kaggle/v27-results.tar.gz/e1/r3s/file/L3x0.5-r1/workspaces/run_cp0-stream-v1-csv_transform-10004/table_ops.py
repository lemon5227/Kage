import csv
import io


def clean_rows(text):
    if text.strip() == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = rows[0]
    # columns: id, team, score
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned_data = []
    for row in data:
        stripped_row = [cell.strip() for cell in row]
        cleaned_data.append(stripped_row)

    # drop rows whose "score" cell is empty
    score_idx = header.index("score")
    cleaned_data = [row for row in cleaned_data if row[score_idx] != "" and row[score_idx] is not None]

    # remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    deduped_data = []
    for row in cleaned_data:
        team = row[header.index("team")]
        if team in seen_teams:
            continue
        seen_teams.add(team)
        deduped_data.append(row)

    # sort rows by "score" ascending as strings (stable)
    score_idx = header.index("score")
    deduped_data.sort(key=lambda row: row[score_idx])

    # write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(deduped_data)
    return output.getvalue()
