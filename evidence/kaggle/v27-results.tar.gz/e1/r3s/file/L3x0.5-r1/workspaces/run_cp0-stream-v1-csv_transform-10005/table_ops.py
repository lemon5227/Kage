import csv
import io

def normalize_table(text):
    if text.strip() == "":
        return ""
    
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ""
    
    header = rows[0]
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "id" cell is empty
    id_idx = header.index("id")
    filtered_rows = []
    for row in cleaned_rows:
        if row[id_idx] == "":
            continue
        filtered_rows.append(row)
    
    # Lower-case the "email" column
    email_idx = header.index("email")
    for row in filtered_rows:
        row[email_idx] = row[email_idx].lower()
    
    # Remove duplicate rows by "email", keeping the first occurrence
    seen_emails = set()
    deduped_rows = []
    for row in filtered_rows:
        email = row[email_idx]
        if email in seen_emails:
            continue
        seen_emails.add(email)
        deduped_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    deduped_rows.sort(key=lambda row: row[email_idx])
    
    # Write output with '\n' line endings using csv module
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()
