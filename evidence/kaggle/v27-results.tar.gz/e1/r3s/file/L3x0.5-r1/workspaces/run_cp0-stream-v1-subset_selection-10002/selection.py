def select_tasks(items, capacity):
    """Select a subset of tasks to maximize total score while keeping total size <= capacity.

    Each item is a dict with keys:
      - "id": unique string identifier
      - "size": positive integer
      - "score": non-negative integer

    Returns a sorted list of ids whose total score is as large as possible
    while total size stays <= capacity. If several selections tie on total score,
    return the lexicographically smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for item in items:
        if "size" not in item or "score" not in item or "id" not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if not isinstance(item["size"], int) or item["size"] <= 0:
            raise ValueError("size must be a positive integer")
        if not isinstance(item["score"], int) or item["score"] < 0:
            raise ValueError("score must be a non-negative integer")

    # Handle empty items list
    if not items:
        return []

    # Use dynamic programming for the 0/1 knapsack problem
    # dp[i][w] = maximum score using first i items with total size <= w
    n = len(items)
    # We'll track which items were selected to reconstruct the solution
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    parent = [[None] * (capacity + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        prev = dp[i - 1]
        curr = dp[i]
        size = items[i - 1]["size"]
        score = items[i - 1]["score"]
        for w in range(capacity + 1):
            # Option 1: don't include item i-1
            val1 = prev[w]
            # Option 2: include item i-1 if it fits
            val2 = prev[w - size] + score if w >= size else -1
            if val2 > val1:
                curr[w] = val2
                parent[i][w] = (i - 1, w - size)
            else:
                curr[w] = val1
                parent[i][w] = (i - 1, w)

    # Find the maximum score and the capacity at which it occurs
    max_score = dp[n][capacity]
    best_w = capacity
    for w in range(capacity):
        if dp[n][w] > max_score:
            max_score = dp[n][w]
            best_w = w

    # Reconstruct the selected items
    selected = []
    i, w = n, best_w
    while i > 0:
        prev_i, prev_w = parent[i][w]
        if prev_i == i - 1 and prev_w == w - items[i - 1]["size"]:
            selected.append(items[i - 1]["id"])
        i -= 1

    return sorted(selected)
