def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Rename top-level keys:
      "host" -> "hostname"
      "max_conn" -> "max_connections"
      "pwd_file" -> "password_file"
    Move "port" and "retries" into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keep other keys unchanged and drop keys whose value is None.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(f"Expected version 1, got {version}")

    # Make a copy to avoid modifying the input
    result = {}
    result["version"] = 2

    # Process top-level keys
    for key, value in cfg.items():
        if key == "host":
            result["hostname"] = value
        elif key == "max_conn":
            result["max_connections"] = value
        elif key == "pwd_file":
            result["password_file"] = value
        elif key == "port":
            # Move into storage dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["port"] = value
        elif key == "retries":
            # Move into storage dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["retries"] = value
        elif key == "timeout_ms":
            # Convert to timeout_s (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value

    # Drop keys whose value is None (already handled by not copying them)
    # But ensure storage exists even if empty
    if "storage" not in result:
        result["storage"] = {}

    return result
