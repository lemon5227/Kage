def digest_lines(lines):
    """Parse log lines in format "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping level name (upper-case) to count, dropping malformed lines.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        # Validate that the level is a known log level (optional, but safe)
        if not level.isalpha():
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
