def allocate(items, capacity):
    """Select jobs under a capacity limit to maximize total gain.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    Does not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")

    # Handle empty items list
    if not items:
        return []

    # Create a list of (id, cost, gain) tuples
    jobs = [(item["id"], item["cost"], item["gain"]) for item in items]

    n = len(jobs)
    # dp[i][c] = best total gain using a subset of the first i jobs with total cost <= c
    # We'll track the actual selected ids to handle tie-breaking.
    # dp[c] = (max_gain, sorted_id_list) for capacity c
    dp = [([None], 0)] * (capacity + 1)

    for idx in range(n):
        job_id, cost, gain = jobs[idx]
        # Iterate capacities downward to avoid using the same item twice
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            new_gain = prev_gain + gain
            new_ids = sorted(prev_ids + [job_id])
            # Compare with current dp[c]
            curr_gain, curr_ids = dp[c]
            if new_gain > curr_gain:
                dp[c] = (new_gain, new_ids)
            elif new_gain == curr_gain and new_ids < curr_ids:
                dp[c] = (new_gain, new_ids)

    # The answer is the best result across all capacities <= capacity
    max_gain = 0
    best_ids = []
    for c in range(capacity + 1):
        gain, ids = dp[c]
        if gain > max_gain:
            max_gain = gain
            best_ids = ids
        elif gain == max_gain and ids < best_ids:
            best_ids = ids

    return best_ids
