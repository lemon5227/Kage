import csv
import io

def tidy_csv(text):
    if text == "":
        return ""
    
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ""
    
    header = rows[0]
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "name" cell is empty
    name_idx = 0  # columns: name, city, score, team
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) > name_idx and row[name_idx] != "":
            filtered_rows.append(row)
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    deduped_rows = []
    for row in filtered_rows:
        name = row[name_idx]
        if name not in seen_names:
            seen_names.add(name)
            deduped_rows.append(row)
    
    # Sort rows by "city" ascending as strings (stable)
    def city_key(row):
        city_idx = 1  # columns: name, city, score, team
        if len(row) > city_idx:
            return row[city_idx]
        return ""
    
    deduped_rows.sort(key=city_key)
    
    # Write output with '\n' line endings using csv module
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()
