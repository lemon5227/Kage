def count_entries(lines):
    """Count lines by level. Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines. Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        timestamp = parts[0]
        level = parts[1].upper()
        # Validate timestamp format (basic check)
        try:
            int(timestamp)
        except ValueError:
            continue
        # Check for service marker
        if len(parts) < 4 or parts[2] != ":":
            continue
        # Count this line
        counts[level] = counts.get(level, 0) + 1
    return counts
