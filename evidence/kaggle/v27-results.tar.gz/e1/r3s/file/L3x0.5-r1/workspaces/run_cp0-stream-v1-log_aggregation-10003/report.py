def aggregate_log(lines):
    """Aggregate log lines into {service: count} for ERROR and WARN levels.
    
    Each line is formatted as "<timestamp> <LEVEL> <service>: <message>".
    Only counts lines with level ERROR or WARN (case-insensitive).
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        service = parts[2]
        if level not in ("ERROR", "WARN"):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
