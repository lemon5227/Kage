import csv
import io

def normalize_table(text):
    if text.strip() == "":
        return ""
    
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ""
    
    header = rows[0]
    # Ensure header has the expected columns
    expected_cols = ['name', 'team', 'city', 'id', 'score']
    if len(header) != len(expected_cols):
        # If header doesn't match, just use what we have
        pass
    
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "name" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) > 0 and row[0] == "":
            continue
        filtered_rows.append(row)
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in filtered_rows:
        if len(row) < 5:
            continue
        score = row[4]
        if score in seen_scores:
            continue
        seen_scores.add(score)
        deduped_rows.append(row)
    
    # Sort rows by "id" ascending as strings (stable)
    def id_key(row):
        return row[3] if len(row) > 3 else ""
    
    deduped_rows.sort(key=id_key)
    
    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()
