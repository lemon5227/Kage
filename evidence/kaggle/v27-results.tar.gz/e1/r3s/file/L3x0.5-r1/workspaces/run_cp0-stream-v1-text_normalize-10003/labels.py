import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = "".join(c for c in normalized if ord(c) < 128)

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    current = ""
    for c in ascii_only:
        if c.isalnum():
            current += c
        else:
            if current:
                segments.append(current)
                current = ""
            segments.append("-")
    if current:
        segments.append(current)

    # strip leading and trailing "-"
    handle = "".join(segments).strip("-")

    return handle
