import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters
    text = "".join(char for char in text if ord(char) < 128)

    # Lower-case
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    parts = []
    current = ""
    for char in text:
        if char.isalnum():
            current += char
        else:
            if current:
                parts.append(current)
                current = ""
            parts.append("-")
    if current:
        parts.append(current)

    # Strip leading and trailing "-"
    slug = "".join(parts)
    while slug.startswith("-"):
        slug = slug[1:]
    while slug.endswith("-"):
        slug = slug[:-1]

    return slug
