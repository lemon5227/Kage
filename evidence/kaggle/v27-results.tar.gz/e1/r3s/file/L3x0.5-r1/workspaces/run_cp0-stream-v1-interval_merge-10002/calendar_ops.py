def coalesce(intervals):
    """Merge overlapping intervals. Each interval is a dict {"start": s, "end": e} with integer values.
    Return merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged. Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
        normalized.append((start, end))

    # Sort by start
    normalized.sort(key=lambda x: x[0])

    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching: extend the last interval
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))

    # Convert back to dicts
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})

    return result
