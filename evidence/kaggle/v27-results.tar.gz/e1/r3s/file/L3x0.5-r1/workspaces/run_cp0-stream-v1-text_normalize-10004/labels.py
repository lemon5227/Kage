import unicodedata


def label_id(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters
    ascii_only = "".join(char for char in normalized if ord(char) < 128)

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    prev_is_non_alnum = False
    for char in lower:
        if char.isalnum():  # a-z0-9
            slug.append(char)
            prev_is_non_alnum = False
        else:
            if not prev_is_non_alnum:
                slug.append("-")
                prev_is_non_alnum = True
    result = "".join(slug)

    # Strip leading and trailing "-"
    return result.strip("-")
