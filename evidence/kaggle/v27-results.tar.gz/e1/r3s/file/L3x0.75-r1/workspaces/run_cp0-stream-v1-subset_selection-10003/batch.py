def pick_jobs(items, capacity):
    """Choose parcels to maximize total score while total size stays <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible, breaking ties by lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and normalize items
    validated = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        validated.append((item["id"], size, score))

    # 0/1 knapsack over sorted items by id (for tie-breaking)
    n = len(validated)
    if n == 0:
        return []

    # dp[w] = best (score, id_list) achievable with capacity w
    # We track the lexicographically smallest id list among those with equal score.
    NEG = None  # represents no selection
    dp = [None] * (capacity + 1)  # each entry: (score, tuple_of_ids) or None

    for idx in range(n):
        item_id, size, score = validated[idx]
        # Iterate capacities downward (0/1 knapsack)
        for w in range(capacity, size - 1, -1):
            prev = dp[w - size]
            if prev is None:
                continue
            cand_score = prev[0] + score
            cand_ids = prev[1] + (item_id,)
            cur = dp[w]
            if cur is None or cand_score > cur[0] or (cand_score == cur[0] and cand_ids < cur[1]):
                dp[w] = (cand_score, cand_ids)

    # Find the best score across all capacities
    best_score = 0
    best_ids = ()
    for w in range(capacity + 1):
        entry = dp[w]
        if entry is None:
            continue
        score, ids = entry
        if score > best_score or (score == best_score and ids < best_ids):
            best_score = score
            best_ids = ids

    return list(best_ids)
