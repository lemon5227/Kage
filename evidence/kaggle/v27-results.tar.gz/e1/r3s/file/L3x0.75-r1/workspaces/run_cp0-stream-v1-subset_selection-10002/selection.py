def select_tasks(items, capacity):
    """Select a subset of items maximizing total score with total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and normalize items
    validated = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        validated.append((item["id"], size, score))

    n = len(validated)
    if n == 0:
        return []

    # dp[w] = (max_score, sorted_id_list) for capacity w
    # We track the best (score, id_list) for each capacity.
    # Initialize with (0, []) for capacity 0.
    dp = [(0, []) for _ in range(capacity + 1)]

    for item_id, size, score in validated:
        # Iterate capacities downward to avoid using the same item twice.
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[w - size]
            cand_score = prev_score + score
            cand_ids = sorted(prev_ids + [item_id])
            if cand_score > dp[w][0]:
                dp[w] = (cand_score, cand_ids)
            elif cand_score == dp[w][0]:
                # Tie: choose lexicographically smallest sorted id list.
                if cand_ids < dp[w][1]:
                    dp[w] = (cand_score, cand_ids)

    best_score, best_ids = dp[capacity]
    return best_ids
