def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "max_conn" -> "max_connections"
      "dir" -> "directory"
      "host" -> "hostname"
    Moves "cache_size" and "region" into a sub-dict "limits" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")

    # Make a copy so we don't modify the input
    result = {}
    result["version"] = 2

    # Process top-level keys
    for key, value in cfg.items():
        if key == "max_conn":
            result["max_connections"] = value
        elif key == "dir":
            result["directory"] = value
        elif key == "host":
            result["hostname"] = value
        elif key == "cache_size":
            # Move into limits sub-dict
            if "limits" not in result:
                result["limits"] = {}
            result["limits"]["cache_size"] = value
        elif key == "region":
            # Move into limits sub-dict
            if "limits" not in result:
                result["limits"] = {}
            result["limits"]["region"] = value
        elif key == "timeout_ms":
            # Convert to timeout_s (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged, but drop None values
            if value is not None:
                result[key] = value

    # Ensure limits exists (even if empty)
    if "limits" not in result:
        result["limits"] = {}

    return result
