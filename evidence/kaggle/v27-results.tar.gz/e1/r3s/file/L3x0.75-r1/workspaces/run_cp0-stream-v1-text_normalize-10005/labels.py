import unicodedata


def to_key(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters
    text = "".join(c for c in text if ord(c) < 128)

    # Lower-case
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    normalized = []
    prev_char = None
    for c in text:
        if c.isalnum():
            normalized.append(c)
        else:
            if prev_char is not None:
                normalized.append("_")
            prev_char = None

    # Append any trailing non-alnum run as "_"
    if prev_char is not None:
        normalized.append("_")

    text = "".join(normalized)

    # Strip leading and trailing "_"
    return text.strip("_")
