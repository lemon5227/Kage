def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Rename top-level keys:
      "dir" -> "directory"
      "pwd_file" -> "password_file"
      "max_conn" -> "max_connections"
    Move "region" and "retries" into a sub-dict "network" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keep other keys unchanged and drop keys whose value is None.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")

    # Make a copy so we don't modify the input
    result = {}
    result["version"] = 2

    # Process keys in a deterministic order
    for key in sorted(cfg.keys()):
        value = cfg[key]

        # Drop keys with None values
        if value is None:
            continue

        # Handle specific key renames/migrations
        if key == "dir":
            result["directory"] = value
        elif key == "pwd_file":
            result["password_file"] = value
        elif key == "max_conn":
            result["max_connections"] = value
        elif key == "timeout_ms":
            result["timeout_s"] = float(value) / 1000.0
        elif key in ("region", "retries"):
            # Move into network sub-dict
            if "network" not in result:
                result["network"] = {}
            if key == "region":
                result["network"]["region"] = value
            if key == "retries":
                result["network"]["retries"] = value

    # Ensure network is always present (even if empty)
    if "network" not in result:
        result["network"] = {}

    return result
