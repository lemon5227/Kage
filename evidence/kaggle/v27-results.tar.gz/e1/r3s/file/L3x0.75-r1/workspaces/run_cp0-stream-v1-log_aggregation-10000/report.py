def count_entries(lines):
    """Count lines by log level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (reported upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        # Validate that the level is a known log level (e.g., DEBUG, INFO, WARN, ERROR, FATAL)
        if not level in ("DEBUG", "INFO", "WARN", "WARNING", "ERROR", "FATAL"):
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
