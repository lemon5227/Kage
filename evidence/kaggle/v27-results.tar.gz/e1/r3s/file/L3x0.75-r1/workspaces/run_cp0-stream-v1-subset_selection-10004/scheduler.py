def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Return the sorted list of ids whose
    total value is as large as possible while total weight stays <= capacity.
    If several selections tie on total value, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raise ValueError if capacity is negative or any weight is <= 0.
    Do not modify the input.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy items without modifying the original dicts
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = (max_value, sorted_id_list) for capacity w
    # We track the best (value, id_list) for each weight.
    # Use a dict keyed by weight to avoid iterating over all capacities.
    best = {}
    best[0] = (0, [])

    for idx in range(n):
        item_id, weight, value = entries[idx]
        # Iterate weights descending to avoid using the same item twice
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = best.get(w - weight, (None, None))
            if prev_value is None:
                continue
            cand_value = prev_value + value
            cand_ids = sorted(prev_ids + [item_id])
            entry = best.get(w)
            if entry is None or cand_value > entry[0] or (cand_value == entry[0] and cand_ids < entry[1]):
                best[w] = (cand_value, cand_ids)

    return best.get(capacity, (0, []))[1]
