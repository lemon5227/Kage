import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = rows[0]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned_data = []
    for row in data:
        stripped_row = [cell.strip() for cell in row]
        cleaned_data.append(stripped_row)

    # drop rows whose "score" cell is empty
    score_idx = header.index("score") if "score" in header else -1
    if score_idx >= 0:
        cleaned_data = [row for row in cleaned_data if row[score_idx] != "" and row[score_idx] != " "]

    # remove duplicate rows by "score", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned_data:
        score = row[score_idx] if score_idx >= 0 else ""
        if score in seen:
            continue
        seen.add(score)
        deduped.append(row)

    # sort rows by "name" ascending as strings (stable)
    name_idx = header.index("name") if "name" in header else -1
    if name_idx >= 0:
        deduped.sort(key=lambda row: row[name_idx])

    # write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
