def tally_events(lines):
    """Tally log lines by service for ERROR and WARN levels.

    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"

    Only levels ERROR and WARN are counted (case-insensitive).
    Malformed lines are dropped.
    Returns a dict mapping service name (upper-case key) to count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        service = parts[2]
        if level not in ("ERROR", "WARN"):
            continue
        # The service token must end with a colon in the format, but we take the token.
        # If the token doesn't end with ':', it's malformed and dropped.
        if not service.endswith(":"):
            continue
        service_name = service[:-1]  # drop the trailing colon
        if not service_name:
            continue
        counts[service_name] = counts.get(service_name, 0) + 1
    return counts
