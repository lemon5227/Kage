import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned_data = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned_data.append(cells)

    # drop rows whose "score" cell is empty
    score_idx = header.index("score") if "score" in header else -1
    if score_idx >= 0:
        cleaned_data = [row for row in cleaned_data if len(row) > score_idx and row[score_idx] != ""]

    # remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned_data:
        team = row[header.index("team") if "team" in header else 0] if len(row) > 0 else ""
        if team in seen:
            continue
        seen.add(team)
        deduped.append(row)

    # sort rows by "score" ascending as strings (stable)
    score_idx = header.index("score") if "score" in header else 0
    deduped.sort(key=lambda row: row[score_idx] if len(row) > score_idx else "")

    # write output with '\n' line endings using csv module
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()
