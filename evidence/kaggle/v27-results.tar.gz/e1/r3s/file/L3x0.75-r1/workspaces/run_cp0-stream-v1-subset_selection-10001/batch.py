def allocate(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    Does not modify the input.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and normalize items
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    n = len(entries)
    if n == 0:
        return []

    # Sort by id for deterministic tie-breaking later
    entries.sort(key=lambda e: e[0])

    # dp[i][c] = best (gain, selected_ids) using a subset of the first i items
    # with total cost <= c. We track the lexicographically smallest id list
    # among those achieving the same gain.
    # Using a dict mapping cost -> (gain, tuple_of_ids)
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for idx in range(n):
        item_id, cost, gain = entries[idx]
        # Iterate costs descending to avoid reusing the same item
        for c in range(capacity, cost - 1, -1):
            prev = dp[c - cost]
            if prev is None:
                continue
            new_gain = prev[0] + gain
            new_ids = prev[1] + (item_id,)
            cur = dp[c]
            if cur is None or new_gain > cur[0] or (new_gain == cur[0] and new_ids < cur[1]):
                dp[c] = (new_gain, new_ids)

    # Find the best gain across all capacities, then lexicographically smallest ids
    best_gain = 0
    best_ids = ()
    for c in range(capacity + 1):
        val = dp[c]
        if val is None:
            continue
        gain, ids = val
        if gain > best_gain or (gain == best_gain and ids < best_ids):
            best_gain = gain
            best_ids = ids

    return list(best_ids)
