def digest_lines(lines):
    """Count log lines by level.

    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"

    Returns a dict mapping the upper-case level name to the number of occurrences.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        if not level.isalpha():
            continue
        counts[level.upper()] = counts.get(level.upper(), 0) + 1
    return counts
