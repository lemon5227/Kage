def summarize(lines):
    """Count WARN lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each service (for levels WARN only) to how many lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines. Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # split into timestamp, level, service:, message
        if len(parts) < 3:
            continue
        timestamp, level, rest = parts[0], parts[1], parts[2]
        if not rest.startswith(':'):
            continue
        service = rest[1:]
        if not service:
            continue
        level_upper = level.upper()
        if level_upper != "WARN":
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
