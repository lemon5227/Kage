import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "id" cell is empty
    id_idx = header.index("id")
    cleaned = [row for row in cleaned if row[id_idx] != "" and row[id_idx] is not None]

    # lower-case the "email" column
    email_idx = header.index("email")
    for row in cleaned:
        row[email_idx] = row[email_idx].lower()

    # remove duplicate rows by "email", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        key = row[email_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    # sort rows by "email" ascending as strings (stable)
    deduped.sort(key=lambda row: row[email_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()
