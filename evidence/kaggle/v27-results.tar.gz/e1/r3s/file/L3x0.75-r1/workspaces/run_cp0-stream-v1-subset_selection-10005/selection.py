def allocate(items, capacity):
    """Select a subset of items maximizing total score with total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and normalize items
    validated = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        validated.append((item["id"], size, score))

    # 0/1 knapsack via DP over capacity
    # dp[c] = (best_score, best_id_list) for capacity c
    # We track the lexicographically smallest id list among those with best_score.
    dp = [(0, []) for _ in range(capacity + 1)]

    for item_id, size, score in validated:
        # Iterate capacity descending to avoid using the same item twice
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[c - size]
            cand_score = prev_score + score
            cand_ids = prev_ids + [item_id]
            if cand_score > dp[c][0]:
                dp[c] = (cand_score, cand_ids)
            elif cand_score == dp[c][0]:
                # Choose lexicographically smallest sorted id list
                if sorted(cand_ids) < sorted(dp[c][1]):
                    dp[c] = (cand_score, cand_ids)

    best_score, best_ids = dp[capacity]
    return sorted(best_ids)
