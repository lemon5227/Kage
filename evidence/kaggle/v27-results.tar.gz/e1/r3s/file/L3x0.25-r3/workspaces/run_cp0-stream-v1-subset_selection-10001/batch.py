def allocate(items, capacity):
    """Select jobs under a capacity limit to maximize total gain.
    
    Each item is a dict with a unique string "id", a positive integer "cost" 
    and a non-negative integer "gain". Return the sorted list of ids whose 
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically 
    smallest sorted id list. An empty selection is allowed.
    
    Raise ValueError if capacity is negative or any cost is <= 0.
    Do not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")
    
    if not items:
        return []
    
    # Create a list of (gain, cost, id) tuples
    items_list = [(item["gain"], item["cost"], item["id"]) for item in items]
    
    # Sort by gain descending, then by cost ascending for tie-breaking
    # This helps with the knapsack algorithm
    items_list.sort(key=lambda x: (-x[0], x[1]))
    
    # Dynamic programming for 0/1 knapsack
    # dp[i][w] = maximum gain using first i items with weight <= w
    n = len(items_list)
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        gain, cost, item_id = items_list[i - 1]
        for w in range(capacity + 1):
            # Don't include this item
            dp[i][w] = dp[i - 1][w]
            # Include this item if it fits
            if cost <= w:
                dp[i][w] = max(dp[i][w], dp[i - 1][w - cost] + gain)
    
    # Find the maximum gain achievable
    max_gain = dp[n][capacity]
    
    # Now reconstruct the solution that achieves max_gain with lexicographically smallest id list
    # We need to find all combinations that achieve max_gain and pick the lexicographically smallest
    
    # Build a set of (gain, cost) pairs for each item
    # Use recursion to find all valid selections that achieve max_gain
    
    def find_all_solutions():
        """Find all selections that achieve max_gain."""
        solutions = []
        
        def backtrack(idx, current_gain, current_cost, current_ids):
            if idx == n:
                if current_gain == max_gain:
                    solutions.append(sorted(current_ids))
                return
            
            gain, cost, item_id = items_list[idx]
            
            # Option 1: Skip this item
            backtrack(idx + 1, current_gain, current_cost, current_ids)
            
            # Option 2: Include this item if it fits
            if current_cost + cost <= capacity:
                backtrack(idx + 1, current_gain + gain, current_cost + cost, current_ids + [item_id])
        
        backtrack(0, 0, 0, [])
        return solutions
    
    # Find all solutions that achieve max_gain
    all_solutions = find_all_solutions()
    
    if not all_solutions:
        return []
    
    # Return the lexicographically smallest sorted id list
    return min(all_solutions)
