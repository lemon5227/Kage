import unicodedata


def to_key(text):
    """Normalize labels into identifiers.
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with a single underscore,
    and strips leading/trailing underscores.
    
    Raises TypeError if text is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we replace any sequence of non-alphanumeric characters with "_"
    identifier = ""
    for char in lowercased:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            identifier += char
        else:
            # If we encounter a non-alphanumeric character, add "_" only once
            if not identifier.endswith('_'):
                identifier += '_'
    
    # Strip leading and trailing "_"
    return identifier.strip('_')
