def pick_jobs(items, capacity):
    """Choose parcels to maximize total score while total size stays <= capacity.
    
    Each item is a dict with a unique string "id", a positive integer "size" 
    and a non-negative integer "score". Return the sorted list of ids whose 
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically 
    smallest sorted id list. An empty selection is allowed.
    
    Raise ValueError if capacity is negative or any size is <= 0.
    Do not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        item_id = item.get("id")
        size = item.get("size")
        score = item.get("score")
        
        if item_id is None or size is None or score is None:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        
        if not isinstance(item_id, str):
            raise ValueError("Item id must be a string")
        
        if size <= 0:
            raise ValueError("Item size must be positive")
        
        if not isinstance(score, int) or score < 0:
            raise ValueError("Item score must be a non-negative integer")
    
    # If no items, return empty list
    if not items:
        return []
    
    n = len(items)
    
    # dp[i][w] = (max_score, chosen_ids) for first i items with capacity w
    # We'll store the best score and the lexicographically smallest id list for that score
    dp = [[(0, [])] * (capacity + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        item = items[i - 1]
        item_id = item["id"]
        size = item["size"]
        score = item["score"]
        
        for w in range(capacity + 1):
            # Option 1: don't include item i
            score1, ids1 = dp[i - 1][w]
            
            # Option 2: include item i if it fits
            score2 = -float('inf')
            ids2 = []
            if w >= size:
                score2 = dp[i - 1][w - size][0] + score
                ids2 = dp[i - 1][w - size][1] + [item_id]
            
            # Choose the better option (higher score, then lexicographically smaller ids)
            if score2 > score1:
                dp[i][w] = (score2, ids2)
            elif score2 == score1 and ids2 < ids1:
                dp[i][w] = (score2, ids2)
    
    # Find the maximum score across all capacities
    max_score = 0
    best_ids = []
    for w in range(capacity + 1):
        score, ids = dp[n][w]
        if score > max_score:
            max_score = score
            best_ids = ids
        elif score == max_score and ids < best_ids:
            best_ids = ids
    
    return sorted(best_ids)
