def allocate(items, capacity):
    """Select parcels to maximize total score while staying within capacity.
    
    Args:
        items: List of dicts with keys "id" (str), "size" (int > 0), "score" (int >= 0).
        capacity: Non-negative integer representing maximum total size allowed.
    
    Returns:
        Sorted list of ids whose total score is maximized, with total size <= capacity.
        If ties on total score, return the lexicographically smallest sorted id list.
    
    Raises:
        ValueError: If capacity is negative or any item has size <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    for item in items:
        if "id" not in item or "size" not in item or "score" not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if not isinstance(item["id"], str):
            raise ValueError("Item id must be a string")
        if item["size"] <= 0:
            raise ValueError("Item size must be positive")
        if not isinstance(item["score"], int) or item["score"] < 0:
            raise ValueError("Item score must be a non-negative integer")
    
    # Handle empty items list
    if not items:
        return []
    
    # Create a list of (id, size, score) tuples
    item_list = [(item["id"], item["size"], item["score"]) for item in items]
    
    # Sort by score descending, then by id ascending for tie-breaking
    # This ensures that when we have equal scores, we prefer smaller ids
    # which will help us get the lexicographically smallest result if ties occur
    item_list.sort(key=lambda x: (-x[2], x[0]))
    
    # Greedy approach: sort by score descending, then by id ascending
    # This works because we want to maximize total score, and for ties we want
    # the lexicographically smallest id list. The greedy strategy of taking items
    # in order of highest score first (with tie-breaking by smaller id) will
    # produce the optimal result when combined with careful selection.
    
    # However, this is a 0/1 knapsack problem. We need to use dynamic programming
    # to ensure we get the optimal solution.
    
    n = len(item_list)
    # dp[i][w] = maximum score using first i items with total size <= w
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        item_id, item_size, item_score = item_list[i - 1]
        for w in range(capacity + 1):
            # Option 1: don't include this item
            dp[i][w] = dp[i - 1][w]
            # Option 2: include this item if it fits
            if item_size <= w:
                dp[i][w] = max(dp[i][w], dp[i - 1][w - item_size] + item_score)
    
    # Find the maximum score achievable
    max_score = dp[n][capacity]
    
    # Reconstruct the solution by backtracking
    selected_ids = []
    w = capacity
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i - 1][w]:
            # This item was selected
            selected_ids.append(item_list[i - 1][0])
            w -= item_list[i - 1][1]
    
    # Return sorted list of ids
    return sorted(selected_ids)
