def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Check version requirement
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")
    
    # Create a new dict without modifying input
    result = {"version": 2}
    
    # Process keys
    for key, value in cfg.items():
        # Skip None values
        if value is None:
            continue
        
        # Handle specific key transformations
        if key == "dir":
            result["directory"] = value
        elif key == "host":
            result["hostname"] = value
        elif key == "port":
            # Move to storage sub-dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["port"] = value
        elif key == "workers":
            # Move to storage sub-dict
            if "storage" not in result:
                result["storage"] = {}
            result["storage"]["workers"] = value
        elif key == "timeout_ms":
            # Convert to timeout_s (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value
    
    return result
