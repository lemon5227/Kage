import csv
import io

def normalize_table(text):
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Handle header-only input
    if len(rows) == 1:
        return '\n'.join(header)
    
    # Process data rows
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "id" cell is empty
    id_index = header.index('id')
    filtered_rows = []
    for row in cleaned_rows:
        if row[id_index] == '':
            continue
        filtered_rows.append(row)
    
    # Lower-case the "email" column
    email_index = header.index('email')
    for row in filtered_rows:
        row[email_index] = row[email_index].lower()
    
    # Remove duplicate rows by "email", keeping the first occurrence
    seen_emails = set()
    deduped_rows = []
    for row in filtered_rows:
        email = row[email_index]
        if email not in seen_emails:
            seen_emails.add(email)
            deduped_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    deduped_rows.sort(key=lambda row: row[email_index])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()
