import unicodedata

def slugify(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization to decompose characters
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we want to replace any sequence of non-alphanumeric characters with a single hyphen
    slug = ""
    previous_char_was_alnum = False
    
    for char in lower_text:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            if not previous_char_was_alnum:
                slug += char
            previous_char_was_alnum = True
        else:
            if previous_char_was_alnum:
                slug += "-"
            previous_char_was_alnum = False
    
    # Strip leading and trailing "-"
    slug = slug.strip("-")
    
    return slug
