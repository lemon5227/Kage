def tally_events(lines):
    """Tally events per service for ERROR and WARN levels only.
    
    Log format: "<timestamp> <LEVEL> <service>: <message>"
    Returns: {service_name: count} with uppercase keys.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) < 3:
            continue  # Malformed line
        
        # Extract level (second part) and service (third part before colon)
        level = parts[1].upper()
        service_part = parts[2]
        
        # Check for colon in service part to extract service name
        if ':' not in service_part:
            continue  # Malformed line
        
        service = service_part.split(':')[0]
        
        # Only count ERROR and WARN levels
        if level not in ('ERROR', 'WARN'):
            continue
        
        counts[service] = counts.get(service, 0) + 1
    
    return counts
