def choose(items, capacity):
    """Select jobs under a capacity limit.
    
    Each item is a dict with a unique string "id", a positive integer "weight" 
    and a non-negative integer "value". Return the sorted list of ids whose 
    total value is as large as possible while total weight stays <= capacity.
    If several selections tie on total value, return the lexicographically 
    smallest sorted id list. An empty selection is allowed.
    Raise ValueError if capacity is negative or any weight is <= 0.
    Do not modify the input.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "id" not in item or not isinstance(item["id"], str):
            raise ValueError("Each item must have a unique string 'id'")
        weight = item.get("weight")
        if weight is None or weight <= 0:
            raise ValueError("Each item must have a positive integer 'weight'")
        value = item.get("value")
        if value is None or value < 0:
            raise ValueError("Each item must have a non-negative integer 'value'")
    
    # Handle empty items list
    if not items:
        return []
    
    n = len(items)
    # dp[i][w] = (max_value, selected_ids) for first i items with weight <= w
    # We'll use a dictionary to store the best value for each weight, along with the selection
    # Since we need lexicographically smallest id list when values tie, we need to be careful
    
    # Initialize: dp[w] = (max_value, selected_ids) for weight exactly w
    # But we need to consider all weights up to capacity
    # Let's use a list where index is weight, value is (max_value, selected_ids)
    
    dp = [(-float('inf'), []) for _ in range(capacity + 1)]
    dp[0] = (0, [])
    
    for i in range(n):
        item = items[i]
        weight = item["weight"]
        value = item["value"]
        # Iterate backwards to avoid using the same item multiple times
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            new_value = prev_value + value
            new_ids = prev_ids + [item["id"]]
            # Compare with current dp[w]
            if new_value > dp[w][0]:
                dp[w] = (new_value, new_ids)
            elif new_value == dp[w][0]:
                # Choose lexicographically smallest sorted id list
                # Both lists are already sorted (we append at end, but need to sort)
                # Actually we should keep them sorted for comparison
                # Let's ensure we always store sorted lists
                if sorted(new_ids) < sorted(dp[w][1]):
                    dp[w] = (new_value, new_ids)
    
    # Find the maximum value among all weights <= capacity
    max_value = -float('inf')
    best_ids = []
    for w in range(capacity + 1):
        if dp[w][0] > max_value:
            max_value = dp[w][0]
            best_ids = dp[w][1]
        elif dp[w][0] == max_value:
            # Choose lexicographically smallest sorted id list
            if sorted(best_ids) > sorted(dp[w][1]):
                best_ids = dp[w][1]
    
    return sorted(best_ids)
