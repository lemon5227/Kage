def coalesce(intervals):
    """Merge overlapping intervals. Each interval is a dict {"start": s, "end": e} with integer values.
    Return merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged. Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate and normalize intervals
    validated = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
        validated.append(interval)
    
    # Sort by start
    validated.sort(key=lambda x: x["start"])
    
    # Merge overlapping intervals
    merged = []
    for interval in validated:
        start = interval["start"]
        end = interval["end"]
        if merged and start <= merged[-1]["end"]:
            # Overlapping or touching - merge
            merged[-1]["end"] = max(merged[-1]["end"], end)
        else:
            merged.append({"start": start, "end": end})
    
    return merged
