import csv
import io

def clean_rows(text):
    # Parse CSV text into list of dicts
    reader = csv.reader(io.StringIO(text))
    rows = []
    for row in reader:
        rows.append(dict(zip(row, ['team', 'name', 'city', 'id', 'score'])))
    
    if not rows:
        return ''
    
    # Extract header from first row
    header = rows[0].keys()
    
    # Process remaining rows
    cleaned_rows = []
    seen_scores = set()
    
    for i in range(1, len(rows)):
        row = rows[i]
        
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Drop rows whose "score" cell is empty
        if not cleaned_row[4].strip():
            continue
        
        score = cleaned_row[4].strip()
        
        # Remove duplicate rows by "score", keeping the first occurrence
        if score in seen_scores:
            continue
        seen_scores.add(score)
        
        cleaned_rows.append(cleaned_row)
    
    # Sort rows by "name" ascending as strings (stable)
    cleaned_rows.sort(key=lambda row: row[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write cleaned rows
    for row in cleaned_rows:
        writer.writerow(row)
    
    return output.getvalue()
