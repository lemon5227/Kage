def aggregate_log(lines):
    """Aggregate log strings into {service: count} for ERROR and WARN levels only.
    
    Log format: "<timestamp> <LEVEL> <service>: <message>"
    - Only counts lines with ERROR or WARN levels (case-insensitive)
    - Service names are stored as uppercase keys
    - Malformed lines are dropped
    """
    counts = {}
    for line in lines:
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) < 3:
            continue
        
        # Check level (parts[1]) - must be ERROR or WARN (case-insensitive)
        level = parts[1].upper()
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Service is parts[2] followed by colon
        service_part = parts[2]
        if not service_part.endswith(':'):
            continue
        
        service = service_part[:-1].upper()
        
        counts[service] = counts.get(service, 0) + 1
    
    return counts
