def digest_lines(lines):
    """Process log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns a dictionary {name: count} per level, treating level names case-insensitively
    (upper-case keys), dropping malformed input lines.
    """
    counts = {}
    for line in lines:
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) < 3:
            continue
        
        # Format: <timestamp> <LEVEL> <service>: <message>
        # First two parts are timestamp and level
        level = parts[1].upper()
        
        # Validate that the level is not empty
        if not level:
            continue
        
        counts[level] = counts.get(level, 0) + 1
    
    return counts
