import csv
import io

def normalize_table(text):
    # Parse CSV text into a list of lists
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Header row
    header = rows[0]
    
    # Process data rows
    data_rows = []
    for row in rows[1:]:
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip rows where "name" cell is empty
        if len(cleaned_row) > 3 and cleaned_row[3] == '':
            continue
        
        data_rows.append(cleaned_row)
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in data_rows:
        if len(row) > 3 and row[3] not in seen_names:
            seen_names.add(row[3])
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    # Email is at index 2
    unique_rows.sort(key=lambda row: row[2])
    
    # Write output with '\n' line endings using csv module
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
