def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Raise ValueError unless version is 1
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")
    
    # Create a new dict for the upgraded configuration
    upgraded = {"version": 2}
    
    # Rename top-level keys
    if "dir" in cfg:
        upgraded["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        upgraded["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        upgraded["max_connections"] = cfg["max_conn"]
    
    # Move "region" and "retries" into a sub-dict "network"
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    upgraded["network"] = network
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        upgraded["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key not in ["dir", "pwd_file", "max_conn", "region", "retries", "timeout_ms"]:
            if value is not None:
                upgraded[key] = value
    
    return upgraded
