def summarize(lines):
    """
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Return a dict mapping each service for levels WARN only to how many lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines.
    Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        if not line or not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # First part is timestamp (may contain spaces? assume single token)
        # Second part is LEVEL
        # Third part is "service:"
        level = parts[1].upper()
        if level != 'WARN':
            continue
        service_part = parts[2]
        if not service_part.endswith(':'):
            continue
        service = service_part[:-1]
        counts[service] = counts.get(service, 0) + 1
    return counts
