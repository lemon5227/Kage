def merge_slots(intervals):
    """Combine overlapping time ranges.
    
    Each interval is a dict {"start": s, "end": e} with integer values.
    Return merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Convert to list of tuples for sorting
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    if not sorted_intervals:
        return []
    
    merged = [sorted_intervals[0].copy()]
    
    for current in sorted_intervals[1:]:
        prev = merged[-1]
        # Check if intervals overlap or touch (end == start)
        if current["start"] <= prev["end"]:
            # Merge by updating the end to the maximum of both ends
            prev["end"] = max(prev["end"], current["end"])
        else:
            merged.append(current.copy())
    
    return merged
