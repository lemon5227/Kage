def allocate(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    If several selections tie on total gain, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and normalize items
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    n = len(entries)
    if n == 0:
        return []

    # Sort by id for deterministic tie-breaking later
    entries.sort(key=lambda e: e[0])

    # dp[i][c] = best (gain, selected_ids) using a subset of the first i items
    # with total cost <= c. We track the chosen ids to resolve ties.
    # Using a dict keyed by cost for the best gain and the lexicographically
    # smallest id list achieving that gain.
    prev = {}  # cost -> (gain, tuple_of_ids)
    prev[0] = (0, ())

    for i in range(n):
        item_id, cost, gain = entries[i]
        cur = dict(prev)  # copy of previous row
        for c in range(cost, capacity + 1):
            if c in prev:
                old_gain, old_ids = prev[c]
                new_gain = old_gain + gain
                new_ids = old_ids + (item_id,)
                if c in cur:
                    cur_gain, cur_ids = cur[c]
                    if new_gain > cur_gain or (new_gain == cur_gain and new_ids < cur_ids):
                        cur[c] = (new_gain, new_ids)
                else:
                    cur[c] = (new_gain, new_ids)
        prev = cur

    # Find the best gain across all feasible costs, then the lexicographically
    # smallest id list among those achieving that gain.
    best_gain = None
    best_ids = None
    for c in range(capacity + 1):
        if c in prev:
            gain, ids = prev[c]
            if best_gain is None or gain > best_gain or (gain == best_gain and ids < best_ids):
                best_gain = gain
                best_ids = ids

    return list(best_ids)
