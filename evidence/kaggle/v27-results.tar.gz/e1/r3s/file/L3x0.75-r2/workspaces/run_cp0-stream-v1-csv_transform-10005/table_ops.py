import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cleaned_row = [cell.strip() for cell in row]
        cleaned.append(cleaned_row)
    data = cleaned

    # drop rows whose "id" cell is empty
    id_idx = header.index("id")
    data = [row for row in data if row[id_idx] != "" and row[id_idx].strip() != ""]

    # lower-case the "email" column
    email_idx = header.index("email")
    for row in data:
        row[email_idx] = row[email_idx].lower()

    # remove duplicate rows by "email", keeping the first occurrence
    seen = set()
    deduped = []
    for row in data:
        key = row[email_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    data = deduped

    # sort rows by "email" ascending as strings (stable)
    data.sort(key=lambda row: row[email_idx])

    # write output with '\n' line endings using csv module
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in data:
        writer.writerow(row)
    return out.getvalue()
