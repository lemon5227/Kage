import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned_data = []
    for row in data:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_data.append(cleaned_row)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name")
    cleaned_data = [row for row in cleaned_data if row[name_idx] != ""]

    # remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned_data:
        name = row[name_idx]
        if name in seen:
            continue
        seen.add(name)
        deduped.append(row)

    # sort rows by "city" ascending as strings (stable)
    city_idx = header.index("city")
    deduped.sort(key=lambda row: row[city_idx])

    # write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
