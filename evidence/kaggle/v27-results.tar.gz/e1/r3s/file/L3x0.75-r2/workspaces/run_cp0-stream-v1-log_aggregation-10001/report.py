def tally_events(lines):
    """Tally log lines by service for ERROR and WARN levels.

    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"

    Only levels ERROR and WARN are counted (case-insensitive).
    Malformed lines are dropped.
    Returns a dict mapping service name (upper-case key) to count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # split into timestamp, level, service:, message
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service = parts[2]
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
