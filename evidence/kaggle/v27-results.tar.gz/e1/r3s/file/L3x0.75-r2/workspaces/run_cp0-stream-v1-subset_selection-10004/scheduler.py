def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Return the sorted list of ids whose
    total value is as large as possible while total weight stays <= capacity.
    If several selections tie on total value, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raise ValueError if capacity is negative or any weight is <= 0.
    Do not modify the input.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy items without modifying the original dicts
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = (max_value, sorted_id_list) for capacity w
    # We track the best (value, id_list) for each weight.
    # Use a dict mapping weight -> (value, tuple_of_ids)
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for idx in range(n):
        item_id, weight, value = entries[idx]
        # Iterate capacities downward so each item is used at most once
        for w in range(capacity, weight - 1, -1):
            prev = dp[w - weight]
            if prev is None:
                continue
            cand_value = prev[0] + value
            cand_ids = prev[1] + (item_id,)
            # Compare with current dp[w]: prefer larger value, then lexicographically smaller id list
            cur = dp[w]
            if cur is None:
                dp[w] = (cand_value, cand_ids)
            else:
                if cand_value > cur[0]:
                    dp[w] = (cand_value, cand_ids)
                elif cand_value == cur[0]:
                    # Compare lexicographically: smaller tuple wins
                    if cand_ids < cur[1]:
                        dp[w] = (cand_value, cand_ids)

    # The answer is the best value across all capacities <= capacity
    best_value = 0
    best_ids = ()
    for w in range(capacity + 1):
        entry = dp[w]
        if entry is None:
            continue
        val, ids = entry
        if val > best_value:
            best_value = val
            best_ids = ids
        elif val == best_value:
            if ids < best_ids:
                best_ids = ids

    return sorted(best_ids)
