import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name")
    cleaned = [r for r in cleaned if r[name_idx] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    score_idx = header.index("score")
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[score_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    # sort rows by "id" ascending as strings (stable)
    id_idx = header.index("id")
    deduped.sort(key=lambda r: r[id_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
