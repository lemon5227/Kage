import unicodedata


def to_key(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    segments = []
    current = ""
    for ch in ascii_only:
        if ch.isalnum():
            current += ch
        else:
            if current:
                segments.append(current)
                current = ""
            segments.append("_")
    if current:
        segments.append(current)

    # strip leading and trailing "_"
    return "".join(segments).strip("_")
