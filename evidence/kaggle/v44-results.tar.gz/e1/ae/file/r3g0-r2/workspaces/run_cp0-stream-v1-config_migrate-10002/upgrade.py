def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            f"expected version 1, got {version!r} (or missing)"
        )

    # Work on a copy so the input is never modified
    out = {}
    out["version"] = 2

    # Rename top-level keys
    if "dir" in cfg:
        out["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        out["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        out["max_connections"] = cfg["max_conn"]

    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        out["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Move region and retries into a sub-dict "network"
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    out["network"] = network

    # Keep other keys unchanged (but drop keys whose value is None)
    for key in cfg:
        if key in ("version", "dir", "pwd_file", "max_conn", "timeout_ms",
                   "region", "retries"):
            continue
        if cfg[key] is None:
            continue
        out[key] = cfg[key]

    return out
