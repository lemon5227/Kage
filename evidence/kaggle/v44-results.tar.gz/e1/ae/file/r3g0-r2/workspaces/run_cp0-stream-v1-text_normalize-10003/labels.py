import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    runs = []
    for char in ascii_only:
        if char in "abcdefghijklmnopqrstuvwxyz0123456789":
            runs.append(char)
        else:
            runs.append("-")

    result = "".join(runs)

    # strip leading and trailing "-"
    result = result.strip("-")

    return result
