import unicodedata


def to_key(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    normalized = "".join(c for c in normalized if ord(c) < 128)

    # lower-case and replace every run of characters outside [a-z0-9] with a single "_"
    tokens = normalized.lower()
    result = []
    last_was_sep = False
    for c in tokens:
        if not c.isalnum():
            if not last_was_sep:
                result.append("_")
                last_was_sep = True
        else:
            result.append(c)
            last_was_sep = False
    return "".join(result).strip("_")
