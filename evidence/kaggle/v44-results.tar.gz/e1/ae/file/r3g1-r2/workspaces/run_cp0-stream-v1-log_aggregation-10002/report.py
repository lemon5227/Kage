def digest_lines(lines):
    """Count log lines by level.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Level names are matched case-insensitively and stored as uppercase keys.
    Malformed lines are silently dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service: (with optional message)
        if len(parts) < 3:
            continue
        level = parts[1]
        service_token = parts[2]
        # The service token must end with a colon (e.g. "auth:")
        if not service_token.endswith(":"):
            continue
        # Level must be a non-empty alphabetic token
        if not level.isalpha():
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
