def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys "dir" -> "directory", "host" -> "hostname".
    Moves "port" and "workers" into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 configuration")

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process top-level keys
    for key, value in cfg.items():
        if key == "dir":
            result["directory"] = value
        elif key == "host":
            result["hostname"] = value
        elif key == "port":
            # Move into storage sub-dict
            storage = result.get("storage", {})
            storage["port"] = value
            if "port" not in result:
                result["storage"] = {}
        elif key == "workers":
            storage = result.get("storage", {})
            storage["workers"] = value
            if "workers" not in result:
                result["storage"] = {}
        elif key == "timeout_ms":
            if value is None:
                continue
            result["timeout_s"] = float(value) / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value

    # Ensure storage exists (even if empty)
    if "storage" not in result:
        result["storage"] = {}

    return result
