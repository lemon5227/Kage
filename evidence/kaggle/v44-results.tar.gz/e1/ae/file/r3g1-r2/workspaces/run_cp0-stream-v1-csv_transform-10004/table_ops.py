import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "score" cell is empty
    score_idx = header.index("score") if "score" in header else -1
    if score_idx >= 0:
        cleaned = [r for r in cleaned if score_idx < len(r) and r[score_idx] != ""]

    # remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        team = r[header.index("team") if "team" in header else 1] if len(header) > 1 else ""
        if team in seen:
            continue
        seen.add(team)
        deduped.append(r)

    # sort rows by "score" ascending as strings (stable)
    score_idx = header.index("score") if "score" in header else -1
    if score_idx >= 0:
        deduped.sort(key=lambda r: r[score_idx] if score_idx < len(r) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for r in deduped:
        writer.writerow(r)
    return out.getvalue()
