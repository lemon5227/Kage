def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Top-level keys "user" -> "username", "dir" -> "directory".
    Move "cache_size" and "retries" into a sub-dict "limits" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keep other keys unchanged and drop keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 configuration")

    # Start with the required "version" field
    result = {"version": 2}

    # Process top-level keys
    username = cfg.get("user")
    if username is not None:
        result["username"] = username

    directory = cfg.get("dir")
    if directory is not None:
        result["directory"] = directory

    # Move cache_size and retries into "limits"
    limits = {}
    cache_size = cfg.get("cache_size")
    if cache_size is not None:
        limits["cache_size"] = cache_size
    retries = cfg.get("retries")
    if retries is not None:
        limits["retries"] = retries
    result["limits"] = limits

    # Handle timeout_ms -> timeout_s conversion
    timeout_ms = cfg.get("timeout_ms")
    if timeout_ms is not None:
        result["timeout_s"] = timeout_ms / 1000.0

    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key in ("user", "dir", "cache_size", "retries", "timeout_ms"):
            continue
        if value is None:
            continue
        result[key] = value

    return result
