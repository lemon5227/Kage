def count_entries(lines):
    """Count lines by log level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (reported upper-case). Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 3:
            continue
        _timestamp, level, rest = parts[0], parts[1], parts[2]
        if not rest.startswith(":"):
            continue
        # service and message are in rest[1:], but we only need the level.
        if len(parts) == 3:
            service = ""
        else:
            service = rest[1:]
        if not service.endswith("):"):
            continue
        message = service[:-1]
        if not message:
            continue
        # Level is the second token (index 1) after splitting by whitespace.
        level = parts[1].strip()
        if not level:
            continue
        counts[level.upper()] = counts.get(level.upper(), 0) + 1
    return counts
