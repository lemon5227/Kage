import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    runs = []
    prev_char = None
    for char in ascii_only:
        if char in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev_char is not None and prev_char not in "abcdefghijklmnopqrstuvwxyz0123456789":
                runs.append("-")
            prev_char = char
        else:
            if prev_char is not None and prev_char not in "abcdefghijklmnopqrstuvwxyz0123456789":
                runs.append("-")
            prev_char = None

    result = []
    for char in ascii_only:
        if char in "abcdefghijklmnopqrstuvwxyz0123456789":
            result.append(char)
        else:
            if prev_char is not None and prev_char not in "abcdefghijklmnopqrstuvwxyz0123456789":
                result.append("-")
            prev_char = None

    # simpler approach: use regex
    import re
    result = re.sub(r"[^a-z0-9]+", "-", ascii_only).lower()

    # strip leading and trailing "-"
    result = result.strip("-")

    # if longer than 23, cut to 23 and then strip trailing "-"
    if len(result) > 23:
        result = result[:23].strip("-")

    return result
