def allocate(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "cost" and a non-negative integer "gain".  Returns the sorted list of
    ids whose total gain is as large as possible while total cost stays
    <= capacity.  Ties on total gain are broken by choosing the
    lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_gain, sorted_id_list) achievable with cost exactly c.
    best = [(0, []) for _ in range(capacity + 1)]

    for item_id, cost, gain in entries:
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = best[c - cost]
            cand_gain = prev_gain + gain
            cand_ids = sorted(prev_ids + [item_id])
            cur_gain, cur_ids = best[c]
            if cand_gain > cur_gain or (cand_gain == cur_gain and cand_ids < cur_ids):
                best[c] = (cand_gain, cand_ids)

    # The optimal gain is the maximum over all capacities <= capacity.
    max_gain = 0
    max_ids = []
    for c in range(capacity + 1):
        gain, ids = best[c]
        if gain > max_gain or (gain == max_gain and ids < max_ids):
            max_gain = gain
            max_ids = ids

    return max_ids
