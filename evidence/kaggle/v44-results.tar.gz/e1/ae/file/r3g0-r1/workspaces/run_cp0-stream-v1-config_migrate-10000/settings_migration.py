def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "max_conn" -> "max_connections"
      "dir" -> "directory"
      "host" -> "hostname"
    Moves "cache_size" and "region" into a sub-dict "limits".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError("Unsupported configuration version: expected 1")

    # Work on a copy so the input is never modified.
    out = {"version": 2}

    # Process top-level keys in a deterministic order.
    for key in sorted(cfg.keys()):
        value = cfg[key]
        if value is None:
            continue  # drop keys with None value

        if key == "max_conn":
            out["max_connections"] = value
        elif key == "dir":
            out["directory"] = value
        elif key == "host":
            out["hostname"] = value
        elif key == "cache_size":
            out["limits"] = out.get("limits", {})
            out["limits"]["cache_size"] = value
        elif key == "region":
            out["limits"] = out.get("limits", {})
            out["limits"]["region"] = value
        elif key == "timeout_ms":
            out["timeout_s"] = value / 1000.0
        else:
            out[key] = value

    return out
