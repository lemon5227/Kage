def merge_slots(intervals):
    """Combine overlapping time ranges.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Touching intervals (e.g. [1,3] and [3,5])
    are merged. Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        normalized.append((start, end))

    normalized.sort(key=lambda pair: pair[0])

    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching intervals are merged.
            if end > merged[-1][1]:
                merged[-1] = [merged[-1][0], end]
        else:
            merged.append([start, end])

    return [{"start": start, "end": end} for start, end in merged]
