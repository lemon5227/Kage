import unicodedata


def to_key(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    normalized = normalized.encode("ascii", "ignore").decode("ascii")

    # lower-case
    normalized = normalized.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    segments = []
    for ch in normalized:
        if ch.isalnum():
            segments.append(ch)
        else:
            if segments and segments[-1] != "_":
                segments.append("_")
    result = "".join(segments)

    # strip leading and trailing "_"
    return result.strip("_")
