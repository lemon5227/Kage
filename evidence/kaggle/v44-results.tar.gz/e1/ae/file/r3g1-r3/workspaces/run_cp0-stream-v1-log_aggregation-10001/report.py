def tally_events(lines):
    """Tally log lines by service for ERROR and WARN levels.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Only counts lines with level ERROR or WARN (case-insensitive).
    Returns a dict mapping the service name (upper-cased) to the number of
    occurrences. Malformed lines are silently dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        _timestamp, level, service, message = parts
        if not service.endswith(':'):
            continue
        service = service[:-1]
        if not service:
            continue
        if level.upper() not in ("ERROR", "WARN"):
            continue
        key = service.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
