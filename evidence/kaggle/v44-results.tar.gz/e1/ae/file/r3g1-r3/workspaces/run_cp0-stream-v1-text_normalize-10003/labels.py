import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    for ch in ascii_only:
        if ch.isalnum():
            segments.append(ch)
        else:
            if segments and segments[-1] != "-":
                segments.append("-")
                # reset the "last segment" so that consecutive non-alnum runs don't merge
                # but we need to handle runs correctly. Let's do it properly:
                # Actually, simpler: split on non-alnum and join with single hyphen.
    # Simpler approach: split on non-alnum and join with single hyphen
    parts = [ch for ch in ascii_only if ch.isalnum()]
    slug = "-".join(parts)

    # strip leading and trailing "-"
    return slug.strip("-")
