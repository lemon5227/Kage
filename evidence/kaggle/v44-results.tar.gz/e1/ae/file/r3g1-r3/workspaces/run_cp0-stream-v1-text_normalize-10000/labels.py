import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    parts = []
    for ch in ascii_only:
        if ch in "abcdefghijklmnopqrstuvwxyz0123456789":
            parts.append(ch)
        else:
            if parts and parts[-1] != ch:
                parts.append("-")
                # skip non-ASCII chars (they are already filtered out)
    result = "".join(parts)

    # strip leading and trailing "-"
    result = result.strip("-")

    # if longer than 23, cut to 23 and then strip a trailing "-"
    if len(result) > 23:
        result = result[:23]
        result = result.rstrip("-")

    return result
