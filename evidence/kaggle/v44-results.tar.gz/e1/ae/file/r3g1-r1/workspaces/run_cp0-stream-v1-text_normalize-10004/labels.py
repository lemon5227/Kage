import unicodedata


def label_id(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    for char in ascii_only:
        if char.isalnum():
            segments.append(char)
        else:
            if segments and not segments[-1].isalnum():
                segments[-1] += "-"
            else:
                segments.append("-")

    result = "".join(segments)

    # strip leading and trailing "-"
    return result.strip("-")
