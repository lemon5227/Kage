def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys:
      "dir" -> "directory"
      "pwd_file" -> "password_file"
      "max_conn" -> "max_connections"
    Moves "region" and "retries" into a sub-dict "network".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            f"expected version 1, got {version!r} (type {type(version).__name__})"
        )

    # Work on a copy so the input is never modified
    out = {}
    out["version"] = 2

    # Process top-level keys
    for key in ["dir", "pwd_file", "max_conn"]:
        value = cfg.get(key)
        if value is None:
            continue
        new_key = key.replace("_conn", "_connections") if key == "max_conn" else key.replace("_file", "_file")
        out[new_key] = value

    # Move region and retries into network
    network = {}
    for key in ["region", "retries"]:
        value = cfg.get(key)
        if value is None:
            continue
        network[key] = value
    out["network"] = network

    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        ms = cfg["timeout_ms"]
        out["timeout_s"] = float(ms) / 1000.0

    # Drop any keys whose value is None (already handled above, but ensure no None values remain)
    # Keep other keys unchanged
    for key in list(cfg.keys()):
        if key in ["dir", "pwd_file", "max_conn", "region", "retries", "timeout_ms"]:
            continue
        value = cfg[key]
        if value is None:
            continue
        out[key] = value

    return out
