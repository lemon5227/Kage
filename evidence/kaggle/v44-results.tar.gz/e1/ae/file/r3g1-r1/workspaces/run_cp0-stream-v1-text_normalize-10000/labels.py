import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    for ch in ascii_only:
        if ch in "abcdefghijklmnopqrstuvwxyz0123456789":
            segments.append(ch)
        else:
            if segments and segments[-1] != "-":
                segments.append("-")
                # reset the last segment to avoid multiple consecutive hyphens
                # but we need to handle runs properly
    # Actually, let's do it more carefully: replace runs of non-alnum with a single "-"
    result = []
    prev = None
    for ch in ascii_only:
        if ch in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev is not None and prev != "-":
                result.append(ch)
            else:
                result.append(ch)
        else:
            if prev is not None and prev != "-":
                result.append("-")
                prev = "-"
            else:
                # keep the hyphen if it's already there, but we need to avoid multiple hyphens
                # Actually, we want to replace every run of non-alnum with a single "-"
                # So if we see a non-alnum, we add "-" only if the previous char was not "-"
                # But we also need to handle the case where we have consecutive non-alnum chars
                # Let's just build the result properly:
                pass
    # Let's do it correctly: iterate and build runs
    result = []
    prev = None
    for ch in ascii_only:
        if ch in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev is not None and prev != "-":
                result.append(ch)
            else:
                result.append(ch)
        else:
            if prev is not None and prev != "-":
                result.append("-")
                prev = "-"
            else:
                # If we already have a hyphen, skip this non-alnum char
                pass
    # Now strip leading and trailing "-"
    while result and result[0] == "-":
        result.pop(0)
    while result and result[-1] == "-":
        result.pop()
    handle = "".join(result)

    # If the result is longer than 23 characters, cut it to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        if handle.endswith("-"):
            handle = handle[:-1]

    return handle
