import unicodedata


def to_key(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    normalized = normalized.encode("ascii").decode("ascii", "ignore")

    # lower-case
    normalized = normalized.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    segments = []
    for ch in normalized:
        if ch.isalnum():
            if segments and not segments[-1].isalnum():
                segments.append("")
            segments.append(ch)
        else:
            if segments and not segments[-1].isalnum():
                segments.append("")
    result = "".join(segments)

    # strip leading and trailing "_"
    return result.strip("_")
