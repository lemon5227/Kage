import re

def digest_lines(lines):
    counts = {}
    # Pattern: timestamp (anything) space LEVEL space service: message
    pattern = r'^\S+\s+(\w+)\s+\S+:\s*.+$'
    for line in lines:
        match = re.match(pattern, line.strip())
        if match:
            level = match.group(1).upper()
            counts[level] = counts.get(level, 0) + 1
    return counts
