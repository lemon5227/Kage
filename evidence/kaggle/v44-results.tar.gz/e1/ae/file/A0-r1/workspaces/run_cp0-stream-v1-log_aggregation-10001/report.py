def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per service for levels ERROR, WARN only, case-insensitive (upper-case keys).
    Drops malformed input lines."""
    result = {}
    for line in lines:
        # Strip whitespace and check if line is empty
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Malformed - skip
            continue
        
        # Extract level (second part) and service (third part before colon)
        level = parts[1].upper()
        service_part = parts[2]
        
        # Check if service part contains a colon
        if ':' not in service_part:
            # Malformed - skip
            continue
        
        service = service_part.split(':')[0]
        
        # Only count ERROR and WARN levels
        if level in ('ERROR', 'WARN'):
            result[service] = result.get(service, 0) + 1
    
    return result
