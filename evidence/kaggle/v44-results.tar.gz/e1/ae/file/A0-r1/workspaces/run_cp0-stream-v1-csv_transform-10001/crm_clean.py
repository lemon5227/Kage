import csv
import io


def clean_rows(text):
    """
    Clean CSV text with header row (columns: team, name, city, id, score).
    
    Returns cleaned CSV text with the same header.
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "name" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Check if there's a header row
    if not rows:
        return ''
    
    header = rows[0]
    # Validate header columns
    expected_columns = ['team', 'name', 'city', 'id', 'score']
    if len(header) != len(expected_columns):
        return ''
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        if len(row) != len(expected_columns):
            continue
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Step 2: Drop rows whose "score" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if not row[4]:  # score is at index 4
            continue
        filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in filtered_rows:
        score = row[4]
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Step 4: Sort rows by "name" ascending as strings (stable)
    # Use stable sort - Python's sort is stable, so we just sort by name
    sorted_rows = sorted(unique_rows, key=lambda row: row[1])
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in sorted_rows:
        writer.writerow(row)
    
    return output.getvalue()
