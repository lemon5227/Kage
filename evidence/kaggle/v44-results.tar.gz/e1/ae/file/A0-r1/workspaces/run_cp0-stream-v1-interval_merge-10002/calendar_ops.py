def coalesce(intervals):
    # Validate all intervals first
    for interval in intervals:
        if "start" not in interval or "end" not in interval:
            raise ValueError("Each interval must have 'start' and 'end' keys")
        if interval["start"] > interval["end"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort intervals by start
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start = interval["start"]
        end = interval["end"]
        
        # If merged list is empty or current interval doesn't overlap with the last one
        if not merged or merged[-1]["end"] < start:
            merged.append({"start": start, "end": end})
        else:
            # Overlapping or touching - merge by extending the end
            merged[-1]["end"] = max(merged[-1]["end"], end)
    
    return merged
