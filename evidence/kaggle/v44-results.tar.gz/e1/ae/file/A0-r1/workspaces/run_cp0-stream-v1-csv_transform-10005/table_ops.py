import csv
import io

def normalize_table(text):
    """Clean an exported table from CSV text."""
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines and check for header-only
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Check if it's header-only (only one line)
    if len(lines) == 1:
        # Strip whitespace from the header line
        header_line = lines[0].strip()
        return header_line
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # The first row is the header
    header = rows[0]
    # Expected columns: id, email, city, name
    # Validate header structure
    expected_headers = ['id', 'email', 'city', 'name']
    if len(header) != len(expected_headers):
        # If header doesn't match, still process what we have
        pass
    
    # Process data rows (skip header)
    data_rows = []
    for row in rows[1:]:
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Drop rows whose "id" cell is empty
        if not cleaned_row[0].strip():  # id is at index 0
            continue
        
        data_rows.append(cleaned_row)
    
    # Lower-case the "email" column (index 1)
    for row in data_rows:
        row[1] = row[1].lower()
    
    # Remove duplicate rows by "email", keeping the first occurrence
    seen_emails = set()
    unique_rows = []
    for row in data_rows:
        email = row[1]
        if email not in seen_emails:
            seen_emails.add(email)
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row[1])
    
    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
