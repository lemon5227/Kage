#!/usr/bin/env python3
"""Clean exported CSV tables."""

import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with header row (columns: name, team, city, id, score)
    Output: Cleaned CSV text with the same header.
    
    Cleaning steps:
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "name" cell is empty
    - Remove duplicate rows by "score", keeping the first occurrence
    - Sort rows by "id" ascending as strings (stable)
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ''
    
    # Validate header columns
    expected_cols = ['name', 'team', 'city', 'id', 'score']
    if len(header) != len(expected_cols):
        # If header doesn't match, still process what we have
        pass
    
    # Process rows
    rows = []
    seen_scores = set()
    
    for row in reader:
        # Strip whitespace from each cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip if name is empty
        if not cleaned_row[0]:
            continue
        
        # Check for duplicate by score (keep first occurrence)
        score = cleaned_row[-1] if len(cleaned_row) > 4 else ''
        if score in seen_scores:
            continue
        seen_scores.add(score)
        
        rows.append(cleaned_row)
    
    # Sort by id ascending as strings (stable sort)
    # We need to keep the original order for equal ids, so use stable sort
    rows.sort(key=lambda row: row[3] if len(row) > 3 else '')
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write rows
    for row in rows:
        writer.writerow(row)
    
    return output.getvalue()


if __name__ == '__main__':
    # Test examples
    test1 = "name,team,city,id,score\nAlice,TeamA,City1,1,A\nBob,TeamB,City2,2,B"
    print("Test 1:", repr(normalize_table(test1)))
    
    test2 = "name,team,city,id,score\nAlice,TeamA,City1,1,A\nBob,TeamB,City2,2,A"
    print("Test 2 (duplicate):", repr(normalize_table(test2)))
    
    test3 = "name,team,city,id,score\n ,TeamA,City1,1,A"
    print("Test 3 (empty name):", repr(normalize_table(test3)))
    
    test4 = "name,team,city,id,score"
    print("Test 4 (header only):", repr(normalize_table(test4)))
    
    test5 = ""
    print("Test 5 (empty):", repr(normalize_table(test5)))
