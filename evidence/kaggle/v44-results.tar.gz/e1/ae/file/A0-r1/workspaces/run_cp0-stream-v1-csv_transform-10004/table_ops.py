import csv
import io


def clean_rows(text):
    """Clean an exported table CSV text.
    
    Input: CSV text with header row (columns: id, team, score)
    Output: Cleaned CSV text with the same header
    
    Processing steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Remove duplicate rows by "team", keeping the first occurrence
    4. Sort rows by "score" ascending as strings (stable)
    
    Returns:
        Empty string returns ''
        Header-only input returns just the header line
    """
    # Parse CSV text
    lines = text.strip().split('\n')
    
    if not lines:
        return ''
    
    # Check if header-only input
    if len(lines) == 1:
        return lines[0]
    
    # Extract header
    header = lines[0].strip()
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        # Parse CSV line
        reader = csv.reader(io.StringIO(line))
        try:
            cell = next(reader)
        except StopIteration:
            continue
        
        # Strip whitespace from each cell
        cell = [cell.strip() for cell in cell]
        
        if len(cell) < 3:
            continue
        
        id_val, team_val, score_val = cell[0], cell[1], cell[2]
        
        # Drop rows whose "score" cell is empty
        if not score_val:
            continue
        
        rows.append((id_val, team_val, score_val))
    
    # Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    unique_rows = []
    for row in rows:
        team_val = row[1]
        if team_val not in seen_teams:
            seen_teams.add(team_val)
            unique_rows.append(row)
    
    # Sort rows by "score" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x[2])
    
    # Build output CSV text
    output_lines = [header]
    for row in unique_rows:
        output_lines.append(','.join(row))
    
    return '\n'.join(output_lines)
