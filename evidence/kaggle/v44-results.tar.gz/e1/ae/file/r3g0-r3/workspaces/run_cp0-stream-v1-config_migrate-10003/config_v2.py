def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Top-level keys are renamed: "dir" -> "directory", "host" -> "hostname".
    "port" and "workers" are moved into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Other keys are kept unchanged; keys whose value is None are dropped.
    """
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 configuration")

    # Start with the required "version" field
    result = {"version": 2}

    # Process top-level keys, skipping None values
    for key, value in cfg.items():
        if value is None:
            continue

        if key == "dir":
            result["directory"] = value
        elif key == "host":
            result["hostname"] = value
        elif key == "port":
            # Move into storage sub-dict
            storage = result.setdefault("storage", {})
            storage["port"] = value
        elif key == "workers":
            storage = result.setdefault("storage", {})
            storage["workers"] = value
        elif key == "timeout_ms":
            if not isinstance(value, (int, float)):
                raise ValueError("timeout_ms must be a number")
            result["timeout_s"] = float(value) / 1000.0
        else:
            # Keep other keys unchanged
            result[key] = value

    return result
