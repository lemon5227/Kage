def count_entries(lines):
    """Count lines by log level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (reported upper-case). Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 3:
            continue
        _timestamp, level, rest = parts[0], parts[1], parts[2]
        if not rest.startswith(":"):
            continue
        # service and message are in rest[1:], but we only need the level.
        if len(parts) == 3:
            service = ""
        else:
            service = rest[1:]
        if not service.endswith("):"):
            continue
        message = service[:-1]
        if not message:
            continue
        # The level is the second token (parts[1]).
        if not level:
            continue
        level_upper = level.upper()
        counts[level_upper] = counts.get(level_upper, 0) + 1
    return counts
