import unicodedata


def label_id(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = "".join(c for c in normalized if ord(c) < 128)

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    for c in ascii_only:
        if c.isalnum():
            segments.append(c)
        else:
            if segments and segments[-1] != "-":
                segments.append("-")
                # skip non-alnum chars until next alnum or end
                continue
    result = "".join(segments)

    # strip leading and trailing "-"
    return result.strip("-")
