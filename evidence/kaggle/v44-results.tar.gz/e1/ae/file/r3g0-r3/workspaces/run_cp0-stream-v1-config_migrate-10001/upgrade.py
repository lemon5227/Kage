def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            f"expected version 1, got {version!r} (or missing)"
        )

    # Work on a copy so the input is never modified
    out = {}
    out["version"] = 2

    # Rename top-level keys
    if "host" in cfg:
        out["hostname"] = cfg["host"]
    if "max_conn" in cfg:
        out["max_connections"] = cfg["max_conn"]
    if "pwd_file" in cfg:
        out["password_file"] = cfg["pwd_file"]

    # Build storage sub-dict
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "retries" in cfg:
        storage["retries"] = cfg["retries"]
    out["storage"] = storage

    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        out["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key in ("version", "host", "max_conn", "pwd_file", "port", "retries", "timeout_ms"):
            continue
        if value is None:
            continue
        out[key] = value

    return out
