def aggregate_log(lines):
    """Aggregate log lines into {service: count} for ERROR and WARN levels.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    - Level names are matched case-insensitively (only ERROR and WARN counted).
    - Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # split into [timestamp, level, service:, message]
        if len(parts) < 3:
            continue
        _timestamp, level, service_part = parts[0], parts[1], parts[2]
        if not service_part.endswith(':'):
            continue
        service = service_part[:-1]
        if not service:
            continue
        if level.upper() not in ("ERROR", "WARN"):
            continue
        counts[service.upper()] = counts.get(service, 0) + 1
    return counts
