def upgrade_config(cfg):
    # Must not modify the input dict; return a new dict.
    # Raise ValueError unless cfg.get("version") == 1.
    # Output has "version": 2.
    # Rename top-level keys: "dir" -> "directory", "pwd_file" -> "password_file", "max_conn" -> "max_connections".
    # Move "region" and "retries" into a sub-dict "network" (always present, possibly empty).
    # If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    # Keep other keys unchanged and drop keys whose value is None.

    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 configuration")

    result = {"version": 2}

    # Copy all keys except those that will be transformed or dropped.
    for key in list(cfg.keys()):
        value = cfg[key]
        if value is None:
            continue  # drop keys with None value

        if key == "dir":
            result["directory"] = value
        elif key == "pwd_file":
            result["password_file"] = value
        elif key == "max_conn":
            result["max_connections"] = value
        elif key == "timeout_ms":
            result["timeout_s"] = value / 1000.0
        else:
            result[key] = value

    # Always include a "network" sub-dict, even if empty.
    result["network"] = {}

    # Move "region" and "retries" into the network dict if present.
    if "region" in cfg:
        result["network"]["region"] = cfg["region"]
    if "retries" in cfg:
        result["network"]["retries"] = cfg["retries"]

    return result
