import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = "".join(c for c in normalized if ord(c) < 128)

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    def replace_runs(s):
        parts = []
        current = []
        for c in s:
            if c.isalnum():
                current.append(c)
            else:
                if current:
                    parts.append("".join(current))
                    current = []
                parts.append("-")
        if current:
            parts.append("".join(current))
        return "".join(parts)

    ascii_only = replace_runs(ascii_only)

    # strip leading and trailing "-"
    ascii_only = ascii_only.strip("-")

    # if longer than 23 characters, cut to 23 and then strip a trailing "-"
    if len(ascii_only) > 23:
        ascii_only = ascii_only[:23]
        ascii_only = ascii_only.rstrip("-")

    return ascii_only
