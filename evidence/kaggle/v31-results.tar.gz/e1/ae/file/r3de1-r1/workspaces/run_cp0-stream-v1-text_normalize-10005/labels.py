import unicodedata


def to_key(text):
    """Normalize labels into identifiers.

    Apply NFKD normalization, drop non-ASCII characters, lower-case,
    replace every run of characters outside [a-z0-9] with a single "_",
    and strip leading and trailing "_". Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks.
    normalized = unicodedata.normalize("NFKD", text)

    # Keep only ASCII characters (0-127). This drops non-ASCII.
    ascii_only = []
    for ch in normalized:
        if ord(ch) < 128:
            ascii_only.append(ch)
    normalized = "".join(ascii_only)

    # Lower-case.
    normalized = normalized.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_".
    parts = []
    current = []
    for ch in normalized:
        if ch.isalnum():  # a-z and 0-9 only (since we're lowercase ASCII)
            current.append(ch)
        else:
            if current:
                parts.append("".join(current))
                current = []
            parts.append("_")
    if current:
        parts.append("".join(current))

    key = "".join(parts)

    # Strip leading and trailing "_".
    return key.strip("_")
