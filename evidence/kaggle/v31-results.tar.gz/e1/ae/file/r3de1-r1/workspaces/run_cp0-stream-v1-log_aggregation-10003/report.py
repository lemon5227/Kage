def aggregate_log(lines):
    """Aggregate log lines into {name: count} for ERROR and WARN levels only.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Level names are matched case-insensitively; keys in the result are upper-case.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        service = parts[2]
        if not service.endswith(':'):
            continue
        service = service[:-1]
        if not service:
            continue
        if level not in ('ERROR', 'WARN'):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
