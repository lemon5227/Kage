def allocate(items, capacity):
    """Select a subset of items maximizing total score with total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    Ties on total score are broken by returning the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by id so that we can reason about lexicographic tie-breaking.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = best (score, chosen_ids) achievable with total size exactly w.
    # We track the chosen ids to resolve ties lexicographically.
    # Using a dict keyed by weight for the best score, and a separate dict for
    # the id list that achieves it.
    best_score = [None] * (capacity + 1)
    best_ids = [None] * (capacity + 1)
    best_score[0] = 0
    best_ids[0] = []

    for idx in range(n):
        item_id, size, score = entries[idx]
        # Iterate weights descending so each item is used at most once.
        for w in range(capacity, size - 1, -1):
            prev_score = best_score[w - size]
            if prev_score is None:
                continue
            cand_score = prev_score + score
            cand_ids = best_ids[w - size] + [item_id]
            if w <= capacity and (best_score[w] is None or cand_score > best_score[w] or
                    (cand_score == best_score[w] and cand_ids < best_ids[w])):
                best_score[w] = cand_score
                best_ids[w] = cand_ids

    # Find the weight that gives the maximum score.
    max_score = 0
    best_weight = 0
    for w in range(capacity + 1):
        if best_score[w] is not None and best_score[w] > max_score:
            max_score = best_score[w]
            best_weight = w

    return best_ids[best_weight]
