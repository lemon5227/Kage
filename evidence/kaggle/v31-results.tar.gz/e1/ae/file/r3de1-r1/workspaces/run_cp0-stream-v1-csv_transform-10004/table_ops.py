import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "score" cell is empty
    score_idx = header.index("score") if "score" in header else -1
    if score_idx >= 0:
        cleaned = [row for row in cleaned if score_idx < len(row) and row[score_idx] != ""]

    # remove duplicate rows by "team", keeping the first occurrence
    team_idx = header.index("team") if "team" in header else -1
    if team_idx >= 0:
        seen = set()
        deduped = []
        for row in cleaned:
            key = row[team_idx] if team_idx < len(row) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(row)
        cleaned = deduped

    # sort rows by "score" ascending as strings (stable)
    score_idx = header.index("score") if "score" in header else -1
    if score_idx >= 0:
        cleaned.sort(key=lambda row: row[score_idx] if score_idx < len(row) else "")

    # write output with csv module using '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
