import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization then drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    parts = []
    current = ""
    for ch in ascii_only:
        if ch.isalnum():
            current += ch
        else:
            if current:
                parts.append(current)
                current = ""
            parts.append("-")
    if current:
        parts.append(current)

    # strip leading and trailing "-"
    handle = "".join(parts)
    while handle.startswith("-"):
        handle = handle[1:]
    while handle.endswith("-"):
        handle = handle[:-1]

    return handle
