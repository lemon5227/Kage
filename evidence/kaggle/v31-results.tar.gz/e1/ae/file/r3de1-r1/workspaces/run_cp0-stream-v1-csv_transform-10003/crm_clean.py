import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name")
    cleaned = [row for row in cleaned if len(row) > name_idx and row[name_idx] != ""]

    # remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        key = row[name_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    # sort rows by "city" ascending as strings (stable)
    city_idx = header.index("city")
    deduped.sort(key=lambda row: row[city_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
