def select_tasks(items, capacity):
    """Select a subset of items maximizing total gain under capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by returning the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # Sort by gain descending, then by cost ascending for the knapsack DP.
    entries.sort(key=lambda e: (e[2], -e[1]))

    # dp[w] = best (gain, sorted_id_list) achievable with cost exactly w.
    # We track the best gain for each possible cost, and also the lexicographically
    # smallest id list among those achieving that gain.
    # Using a dict mapping cost -> (gain, tuple_of_ids).
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for item_id, cost, gain in entries:
        # Iterate costs descending so each item is used at most once.
        for w in range(capacity, cost - 1, -1):
            prev = dp[w - cost]
            if prev is None:
                continue
            new_gain = prev[0] + gain
            new_ids = prev[1] + (item_id,)
            cur = dp[w]
            if cur is None or new_gain > cur[0] or (new_gain == cur[0] and new_ids < cur[1]):
                dp[w] = (new_gain, new_ids)

    # Find the best gain across all costs <= capacity.
    best_gain = 0
    best_ids = ()
    for w in range(capacity + 1):
        entry = dp[w]
        if entry is None:
            continue
        gain, ids = entry
        if gain > best_gain or (gain == best_gain and ids < best_ids):
            best_gain = gain
            best_ids = ids

    return list(best_ids)
