def digest_lines(lines):
    """Count log lines per level.

    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # Check that the second token looks like a log level (e.g. INFO, WARN, ERROR)
        level = parts[1]
        if not level.isalpha():
            continue
        # Validate it's a known log level pattern (letters only, length 3-8)
        if len(level) < 3 or len(level) > 8:
            continue
        # Ensure it's actually a log level by checking common patterns
        if not any(l in level for l in ['INFO', 'WARN', 'WARNING', 'ERROR', 'DEBUG', 'TRACE', 'FATAL', 'CRITICAL']):
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
