def digest_lines(lines):
    """Count log lines by level.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Returns a dict mapping the upper-cased level name to the number of
    occurrences. Malformed lines are silently dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service (with colon), and message
        if len(parts) < 3:
            continue
        level = parts[1]
        service = parts[2]
        # The service token must end with a colon (e.g. "auth:")
        if not service.endswith(':'):
            continue
        # After the colon, there should be at least one token for the message
        if len(parts) < 4:
            continue
        # Validate that the level is a non-empty string of alphabetic characters
        if not level.isalpha():
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
