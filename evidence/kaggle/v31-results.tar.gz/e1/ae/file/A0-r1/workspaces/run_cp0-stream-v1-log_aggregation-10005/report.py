def summarize(lines):
    """
    Summarize log lines into a dict mapping services (for WARN level only) to counts.
    
    Each line format: "<timestamp> <LEVEL> <service>: <message>"
    - Levels are case-insensitive (reported as upper-case)
    - Malformed lines are skipped
    - Only WARN level services are included
    - Keys with zero count are omitted
    """
    service_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Check if level is WARN
        if level != 'WARN':
            continue
        
        # Count the service
        service_counts[service] = service_counts.get(service, 0) + 1
    
    return service_counts
