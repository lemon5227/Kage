import unicodedata

def make_handle(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace sequences of non-alphanumeric chars with a single hyphen
    slug = []
    prev_char = None
    for char in lower:
        if char.isalnum():
            slug.append(char)
        else:
            if prev_char is not None:
                slug.append('-')
            prev_char = None
    
    # If we ended with a non-alphanumeric, add a hyphen
    if prev_char is not None:
        slug.append('-')
    
    # Strip leading and trailing "-"
    slug = '-'.join(slug).strip('-')
    
    return slug
