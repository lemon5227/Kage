def convert_settings(cfg):
    """Convert old configuration dict to v2 layout."""
    # Check if version is 1, otherwise raise ValueError
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")
    
    # Create a new dictionary for the result
    result = {"version": 2}
    
    # Rename top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    
    # Move "port" and "workers" into a sub-dict "storage"
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    result["storage"] = storage
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key not in ["version", "dir", "host", "port", "workers", "timeout_ms"]:
            if value is not None:
                result[key] = value
    
    return result
