import csv
import io


def tidy_csv(text):
    """Clean an exported CSV table with columns: name, city, score, team."""
    
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines and check if header-only
    lines = text.strip().split('\n')
    if len(lines) == 1:
        # Header-only input
        return lines[0]
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    header = next(reader)
    
    # Validate header columns
    expected_columns = ['name', 'city', 'score', 'team']
    if header != expected_columns:
        raise ValueError(f"Expected header {expected_columns}, got {header}")
    
    # Process rows
    rows = []
    seen_names = set()
    
    for row in reader:
        # Strip whitespace from each cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip if name is empty
        if not cleaned_row[0]:
            continue
        
        # Remove duplicates by name, keep first occurrence
        if cleaned_row[0] in seen_names:
            continue
        seen_names.add(cleaned_row[0])
        
        rows.append(cleaned_row)
    
    # Sort by city (ascending as strings, stable sort)
    rows.sort(key=lambda row: row[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(rows)
    
    return output.getvalue()
