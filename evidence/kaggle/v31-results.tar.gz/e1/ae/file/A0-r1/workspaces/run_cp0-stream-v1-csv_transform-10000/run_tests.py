from crm_clean import normalize_table

# Test 1: Basic functionality
test1 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,other@example.com,Jane"
result1 = normalize_table(test1)
print("Test 1:")
print(result1)
print()

# Test 2: Empty name should be dropped
test2 = "score,id,email,name\n1,abc,test@example.com,\n2,def,other@example.com,Jane"
result2 = normalize_table(test2)
print("Test 2:")
print(result2)
print()

# Test 3: Header only
test3 = "score,id,email,name"
result3 = normalize_table(test3)
print("Test 3:")
print(result3)
print()

# Test 4: Empty input
test4 = ""
result4 = normalize_table(test4)
print("Test 4:")
print(repr(result4))
print()

# Test 5: Duplicates by name
test5 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,test@example.com,John"
result5 = normalize_table(test5)
print("Test 5:")
print(result5)
print()

# Test 6: Sorting by email
test6 = "score,id,email,name\n1,abc,zebra@example.com,Alpha\n2,def,alpha@example.com,Beta"
result6 = normalize_table(test6)
print("Test 6:")
print(result6)
