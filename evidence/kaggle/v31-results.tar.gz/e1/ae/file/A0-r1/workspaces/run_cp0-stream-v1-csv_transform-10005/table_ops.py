import csv
import io

def normalize_table(text):
    """Clean an exported table from CSV text."""
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines and handle line endings
    lines = text.split('\n')
    
    # If only header, return it as is (but ensure proper line ending)
    if len(lines) == 1:
        return lines[0] + '\n'
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = []
    seen_emails = set()
    
    for row in rows[1:]:
        # Strip whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip if id is empty
        if not cleaned_row[0]:  # id is first column
            continue
        
        # Lower-case the email column (second column)
        email = cleaned_row[1].lower()
        
        # Skip duplicate emails (keep first occurrence)
        if email in seen_emails:
            continue
        seen_emails.add(email)
        
        data_rows.append(cleaned_row)
    
    # Sort by email ascending as strings (stable sort)
    # We need to sort by the email column (index 1)
    data_rows.sort(key=lambda row: row[1])
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in data_rows:
        writer.writerow(row)
    
    return output.getvalue()
