def digest_lines(lines):
    """Count log lines by level.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Returns a dict mapping the upper-case level name to the number of
    occurrences. Malformed lines are silently dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service (with colon), message
        if len(parts) < 3:
            continue
        level = parts[1]
        # Validate that the third token starts with a colon (service:)
        if len(parts) < 3 or not parts[2].startswith(':'):
            continue
        # Level must be non-empty and alphabetic
        if not level.isalpha():
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
