def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Renames top-level keys:
      "dir" -> "directory"
      "pwd_file" -> "password_file"
      "max_conn" -> "max_connections"
    Moves "region" and "retries" into a sub-dict "network".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            "upgrade_config requires cfg['version'] == 1, got %r" % version
        )

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process each key in the original dict (excluding 'version')
    for key in list(cfg.keys()):
        if key == "version":
            continue  # already handled

        value = cfg[key]

        # Drop keys whose value is None
        if value is None:
            continue

        # Handle special key renames and transformations
        if key == "dir":
            result["directory"] = value
        elif key == "pwd_file":
            result["password_file"] = value
        elif key == "max_conn":
            result["max_connections"] = value
        elif key == "timeout_ms":
            # Convert milliseconds to seconds (float)
            result["timeout_s"] = float(value) / 1000.0
        elif key in ("region", "retries"):
            # Move these into the "network" sub-dict
            network = result.get("network")
            if network is None:
                result["network"] = {}
            network[key] = value
        else:
            # Keep other keys unchanged
            result[key] = value

    return result
