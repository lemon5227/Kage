import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization to decompose characters
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    text = "".join(c for c in text if ord(c) < 128)

    # Lower-case
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    normalized = []
    prev_char = None
    for c in text:
        if c.isalnum():
            normalized.append(c)
        else:
            if prev_char is not None and prev_char != "-":
                normalized.append("-")
            prev_char = "-"

    text = "".join(normalized)

    # Strip leading and trailing "-"
    text = text.strip("-")

    return text
