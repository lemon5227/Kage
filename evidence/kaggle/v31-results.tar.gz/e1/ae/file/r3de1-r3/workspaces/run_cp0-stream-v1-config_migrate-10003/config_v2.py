def convert_settings(cfg):
    # Validate version requirement
    if cfg.get("version") != 1:
        raise ValueError("cfg must have version == 1")

    # Copy input to avoid modifying original
    result = {}
    result["version"] = 2

    # Rename top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]

    # Build storage sub-dict with port and workers
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    result["storage"] = storage

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged (non-None values)
    for key, value in cfg.items():
        if key not in ("dir", "host", "port", "workers", "timeout_ms") and value is not None:
            result[key] = value

    return result
