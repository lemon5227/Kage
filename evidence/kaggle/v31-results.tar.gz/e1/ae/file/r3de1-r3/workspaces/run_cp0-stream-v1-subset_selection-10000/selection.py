def select_tasks(items, capacity):
    """Select a subset of items whose total cost is <= capacity and total gain is maximized.
    Ties on total gain are broken by choosing the lexicographically smallest sorted list of ids.
    Raises ValueError if capacity is negative or any cost is <= 0.
    Returns the sorted list of selected item ids.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and normalize items: each must have a unique string id, positive cost, non-negative gain.
    entries = []
    seen_ids = set()
    for item in items:
        item_id = item["id"]
        cost = item["cost"]
        gain = item["gain"]

        if not isinstance(item_id, str):
            raise ValueError("item id must be a string")
        if item_id in seen_ids:
            raise ValueError("duplicate item id")
        seen_ids.add(item_id)

        if cost <= 0:
            raise ValueError("cost must be positive")
        if gain < 0:
            raise ValueError("gain must be non-negative")

        entries.append((item_id, cost, gain))

    # Sort by cost then gain so that we can process items in a deterministic order.
    # This ensures consistent tie-breaking when total gains are equal.
    entries.sort(key=lambda e: (e[1], e[2]))

    # Dynamic programming over capacity.
    # best[c] = (max_gain, selected_ids) for capacity c.
    # We track the selected ids to allow lexicographic tie-breaking.
    # Using a dict keyed by capacity; we'll iterate capacity from 0..capacity_limit.
    best = [None] * (capacity + 1)
    best[0] = ([], 0)

    for item_id, cost, gain in entries:
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = best[c - cost]
            new_gain = prev_gain + gain
            new_ids = sorted(prev_ids + [item_id])
            cur_gain, cur_ids = best[c]
            if new_gain > cur_gain:
                best[c] = (new_gain, new_ids)
            elif new_gain == cur_gain and new_ids < cur_ids:
                best[c] = (new_gain, new_ids)

    return best[capacity][1]
