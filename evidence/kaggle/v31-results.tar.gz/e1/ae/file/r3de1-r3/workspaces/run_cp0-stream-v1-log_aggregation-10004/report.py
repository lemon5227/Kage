def digest_lines(lines):
    """Count log lines per level.

    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased; ignore lines that do not match.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        # Valid levels are those that look like log levels (e.g., DEBUG, INFO, WARN, ERROR)
        if not level.isalpha():
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
