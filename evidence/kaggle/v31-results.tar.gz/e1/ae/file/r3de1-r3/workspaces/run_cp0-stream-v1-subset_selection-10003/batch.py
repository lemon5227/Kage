def pick_jobs(items, capacity):
    """Choose parcels to maximize total score while total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    Does not modify the input.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and normalize items
    validated = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        validated.append((item["id"], size, score))

    # dp[w] = best (score, id_list) for capacity w
    # We track the lexicographically smallest id list among those with max score.
    NEG = None  # represents no selection yet
    dp = [None] * (capacity + 1)  # dp[w] = (score, tuple_of_ids) or None

    dp[0] = (0, ())

    for item_id, size, score in validated:
        # Iterate capacities descending to avoid using same item twice
        for w in range(capacity, size - 1, -1):
            prev = dp[w - size]
            if prev is None:
                continue
            cand_score = prev[0] + score
            cand_ids = prev[1] + (item_id,)
            cur = dp[w]
            if cur is None or cand_score > cur[0]:
                dp[w] = (cand_score, cand_ids)
            elif cand_score == cur[0] and cand_ids < cur[1]:
                dp[w] = (cand_score, cand_ids)

    # Find the best score across all capacities <= capacity
    best_score = 0
    best_ids = ()
    for w in range(capacity + 1):
        entry = dp[w]
        if entry is None:
            continue
        score, ids = entry
        if score > best_score or (score == best_score and ids < best_ids):
            best_score = score
            best_ids = ids

    return sorted(best_ids)
