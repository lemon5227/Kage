def allocate(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by returning the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # Sort by gain descending, then by cost ascending for the initial DP order.
    entries.sort(key=lambda e: (e[2], e[1]))

    # dp[c] = best (gain, sorted_id_list) achievable with cost exactly c.
    # We track the sorted id list to resolve ties lexicographically.
    dp = [(0, [])]  # cost 0 -> gain 0, empty id list
    for idx in range(len(entries)):
        item_id, cost, gain = entries[idx]
        # Iterate costs descending so each item is used at most once.
        new_dp = dp[:]  # copy the previous row
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            cand_gain = prev_gain + gain
            cand_ids = sorted(prev_ids + [item_id])
            if cand_gain > new_dp[c][0]:
                new_dp[c] = (cand_gain, cand_ids)
            elif cand_gain == new_dp[c][0]:
                if cand_ids < new_dp[c][1]:
                    new_dp[c] = (cand_gain, cand_ids)
        dp = new_dp

    # Find the best gain across all feasible costs.
    best_gain = 0
    best_ids = []
    for c in range(capacity + 1):
        gain, ids = dp[c]
        if gain > best_gain:
            best_gain = gain
            best_ids = ids
        elif gain == best_gain:
            if ids < best_ids:
                best_ids = ids

    return best_ids
