def digest_lines(lines):
    """Aggregate log lines into {name: count} per level.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Level names are matched case-insensitively and stored as uppercase keys.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        _timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service.isalnum():
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
