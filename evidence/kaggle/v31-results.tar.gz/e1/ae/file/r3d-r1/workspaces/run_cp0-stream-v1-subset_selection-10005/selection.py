def allocate(items, capacity):
    """Select a subset of items maximizing total score with total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    Ties on total score are broken by choosing the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by id so that we can reason about lexicographic tie-breaking.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = best (score, chosen_ids) achievable with capacity exactly w,
    # where chosen_ids is the lexicographically smallest sorted list among
    # those achieving the best score for that capacity. We track the id list
    # to resolve ties.
    NEG = None
    dp = [None] * (capacity + 1)  # dp[w] = (score, tuple_of_ids) or None
    dp[0] = (0, ())

    for idx in range(n):
        item_id, size, score = entries[idx]
        # Iterate capacities descending so each item is used at most once.
        for w in range(capacity, size - 1, -1):
            prev = dp[w - size]
            if prev is None:
                continue
            cand_score = prev[0] + score
            cand_ids = prev[1] + (item_id,)
            cur = dp[w]
            if cur is None or cand_score > cur[0]:
                dp[w] = (cand_score, cand_ids)
            elif cand_score == cur[0] and cand_ids < cur[1]:
                dp[w] = (cand_score, cand_ids)

    # Find the best score across all capacities, then the lexicographically
    # smallest id list among those achieving that score.
    best_score = None
    best_ids = None
    for w in range(capacity + 1):
        entry = dp[w]
        if entry is None:
            continue
        score, ids = entry
        if best_score is None or score > best_score:
            best_score = score
            best_ids = ids
        elif score == best_score and (ids if isinstance(ids, tuple) else ()) < (best_ids if best_ids else ()):
            best_ids = ids

    if best_ids is None:
        return []
    return sorted(best_ids)
