def pick_jobs(items, capacity):
    """Choose a subset of items maximizing total score within capacity.

    Each item is a dict with a unique string "id", a positive integer
    "size" and a non-negative integer "score". Returns the sorted list of
    ids whose total score is as large as possible while total size stays
    <= capacity. Ties on total score are broken by the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by id so that we can reason about tie-breaking consistently.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    if n == 0:
        return []

    # dp[k][c] = best (score, chosen_ids) achievable using a subset of the
    # first k entries with total size <= c. We track the chosen ids to
    # resolve ties by lexicographic order.
    # Using two rows to save space.
    prev = [(0, []) for _ in range(capacity + 1)]
    cur = [(0, []) for _ in range(capacity + 1)]

    for k in range(n):
        item_id, size, score = entries[k]
        # Copy previous row so we can iterate backwards like the classic knapsack.
        row = prev[:]
        for c in range(size, capacity + 1):
            prev[c] = (row[c - size][0] + score, row[c - size][1] + [item_id])
        # The lexicographic tie-break is handled by always preferring the
        # tuple with the smaller id list when scores are equal. Since we
        # build the solution incrementally and prefer earlier choices, this
        # naturally yields the lexicographically smallest sorted id list
        # among those achieving the maximum score.
    return prev[capacity][1]
