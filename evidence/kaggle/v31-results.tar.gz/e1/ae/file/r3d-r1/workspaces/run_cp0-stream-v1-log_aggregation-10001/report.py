def tally_events(lines):
    """Tally log lines by service for ERROR and WARN levels only.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Returns a dict mapping service name -> count, considering only
    ERROR and WARN levels (case-insensitive), and dropping malformed lines.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        _timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        # The service token must end with a colon (e.g. "auth:")
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service:
            continue
        if level not in ("ERROR", "WARN"):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
