import unicodedata


def to_key(text):
    """Normalize text into a safe identifier.

    - NFKD normalization, then drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "_".
    - Strip leading and trailing "_".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    # Keep only ASCII characters (a-z, 0-9) and non-ASCII that are in the range 0x0080-0x07FF
    ascii_only = ""
    for ch in normalized:
        if ord(ch) < 128:
            ascii_only += ch
    # Lower-case
    ascii_only = ascii_only.lower()
    # Replace every run of characters outside [a-z0-9] with a single "_"
    parts = ascii_only.split("_")
    result = []
    for part in parts:
        if part.strip() == "":
            continue
        result.append(part)
    return "_".join(result)
