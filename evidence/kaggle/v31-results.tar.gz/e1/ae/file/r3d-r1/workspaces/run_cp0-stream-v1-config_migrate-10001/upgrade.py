def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Renames top-level keys:
      "host" -> "hostname"
      "max_conn" -> "max_connections"
      "pwd_file" -> "password_file"
    Moves "port" and "retries" into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            "convert_settings requires a v1 configuration dict; "
            f"got version={version!r}"
        )

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process top-level keys
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]

    # Move port and retries into storage
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "retries" in cfg:
        storage["retries"] = cfg["retries"]
    result["storage"] = storage

    # Handle timeout_ms -> timeout_s conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Copy other keys unchanged (excluding None values)
    for key, value in cfg.items():
        if key in ("host", "max_conn", "pwd_file", "port", "retries", "timeout_ms"):
            continue  # already handled above
        if value is None:
            continue  # drop keys with None value
        result[key] = value

    return result
