def summarize(lines):
    """Count WARN lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each service for levels WARN only to how many lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines.
    Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        _timestamp, level, service, message = parts
        if service.startswith(':'):
            continue
        if level.upper() != "WARN":
            continue
        key = service.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
