def convert_settings(cfg):
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported")

    # Make a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Rename top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]

    # Move port and workers into a sub-dict storage
    result["storage"] = {}
    if "port" in cfg:
        result["storage"]["port"] = cfg["port"]
    if "workers" in cfg:
        result["storage"]["workers"] = cfg["workers"]

    # Handle timeout_ms -> timeout_s conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged
    for key in cfg:
        if key not in ("dir", "host", "port", "workers", "timeout_ms") and cfg[key] is not None:
            result[key] = cfg[key]

    return result
