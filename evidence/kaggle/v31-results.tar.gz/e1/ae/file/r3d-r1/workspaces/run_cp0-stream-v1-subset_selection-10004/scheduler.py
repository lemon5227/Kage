def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity. Ties on total value are broken by the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = best (value, chosen_ids) achievable with weight exactly <= w.
    # We track the chosen ids to resolve ties lexicographically.
    # Using a dict keyed by weight for the best value, plus the id list.
    # Since capacity can be large, we iterate over items and maintain the best
    # choice for each possible weight up to capacity.
    # This is the 0/1 knapsack with tie-breaking.

    # dp[w] = (max_value, sorted_id_list) for weight <= w
    # We'll use a list where index is weight, and value is (max_value, id_list)
    # Initialize with (0, []) for weight 0.
    dp = [(0, [])] * (capacity + 1)

    for idx in range(n):
        item_id, weight, value = entries[idx]
        # Iterate weights descending for 0/1 knapsack.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = sorted(prev_ids + [item_id])
            if cand_value > dp[w][0]:
                dp[w] = (cand_value, cand_ids)
            elif cand_value == dp[w][0]:
                # Tie on value: choose lexicographically smallest sorted id list.
                if cand_ids < dp[w][1]:
                    dp[w] = (cand_value, cand_ids)

    # The answer is the best value across all weights <= capacity, with the
    # lexicographically smallest id list among those achieving it.
    best_value = 0
    best_ids = []
    for w in range(capacity + 1):
        val, ids = dp[w]
        if val > best_value:
            best_value = val
            best_ids = ids
        elif val == best_value:
            if ids < best_ids:
                best_ids = ids

    return best_ids
