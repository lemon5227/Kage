def pick_jobs(items, capacity):
    """Choose a subset of items maximizing total score within capacity.

    Each item is a dict with a unique string "id", a positive integer
    "size" and a non-negative integer "score". Returns the sorted list of
    ids whose total score is as large as possible while total size stays
    <= capacity. Ties on total score are broken by the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by id so that we can reason about tie-breaking consistently.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    if n == 0:
        return []

    # dp[k] = best (score, chosen_ids) achievable using a subset of the first k items.
    # We track the chosen ids to resolve ties lexicographically.
    # Using a dict keyed by capacity used so far is not enough because we need
    # to compare full selections on tie-break. Instead we do the standard
    # knapsack over capacities and keep the best selection for each capacity.
    # Since n is typically modest in these tasks, we can afford O(n^2) space.

    # best[c] = (total_score, sorted_id_list) for capacity c.
    best = [(0, []) for _ in range(capacity + 1)]

    for idx in range(n):
        item_id, size, score = entries[idx]
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = best[c - size]
            cand_score = prev_score + score
            cand_ids = sorted(prev_ids + [item_id])
            cur_score, cur_ids = best[c]
            if cand_score > cur_score:
                best[c] = (cand_score, cand_ids)
            elif cand_score == cur_score and cand_ids < cur_ids:
                best[c] = (cand_score, cand_ids)

    # The answer is the best selection across all capacities.
    final_score, final_ids = max(best, key=lambda entry: entry[0])
    return final_ids
