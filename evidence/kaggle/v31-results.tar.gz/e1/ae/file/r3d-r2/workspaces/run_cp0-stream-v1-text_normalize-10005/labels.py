import unicodedata


def to_key(text):
    """Normalize text into a safe identifier.

    - NFKD normalization, then drop non-ASCII characters.
    - Lower-case the result.
    - Replace every run of characters outside [a-z0-9] with a single "_".
    - Strip leading and trailing "_".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected str, not {type(text).__name__}")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    # Keep only ASCII characters (a-z, 0-9) and non-ASCII is dropped
    ascii_only = normalized.encode("ascii").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    parts = []
    current = []
    for ch in lower:
        if ch.isalnum():
            current.append(ch)
        else:
            if current:
                parts.append("".join(current))
                current = []
            parts.append("_")
    if current:
        parts.append("".join(current))

    # Strip leading and trailing "_"
    key = "".join(parts).strip("_")

    return key
