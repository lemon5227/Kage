import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization separates characters into base + decomposition
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    text = "".join(c for c in text if ord(c) < 128)

    # Lower-case
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    normalized = []
    prev_is_sep = False
    for c in text:
        is_sep = not (c.isalpha() or c.isdigit())
        if is_sep and not prev_is_sep:
            normalized.append("-")
        elif is_sep:
            # continue emitting the same separator
            pass
        else:
            normalized.append(c)
        prev_is_sep = is_sep
    text = "".join(normalized)

    # Strip leading and trailing "-"
    text = text.strip("-")

    return text
