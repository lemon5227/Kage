def count_entries(lines):
    """Count lines by log level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (reported upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        _timestamp, level, rest = parts[0], parts[1], " ".join(parts[2:])
        if not rest.startswith(":"):
            continue
        # The service name is after the colon; we just need to verify it exists.
        service = rest[1:]  # skip the leading ':'
        if not service:
            continue
        # Level must be a non-empty alphabetic token.
        if not level.isalpha():
            continue
        counts[level.upper()] = counts.get(level.upper(), 0) + 1
    return counts
