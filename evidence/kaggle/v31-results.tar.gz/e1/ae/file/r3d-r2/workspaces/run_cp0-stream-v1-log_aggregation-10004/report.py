def digest_lines(lines):
    """Count log lines per level.

    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # Check that the third token starts with a service name (alphanumeric + underscore)
        # and contains a colon after it (e.g. "service: message")
        if not parts[2].endswith(':'):
            continue
        # The level is the second token; it must be a non-empty string.
        level = parts[1]
        if not level:
            continue
        counts[level.upper()] = counts.get(level.upper(), 0) + 1
    return counts
