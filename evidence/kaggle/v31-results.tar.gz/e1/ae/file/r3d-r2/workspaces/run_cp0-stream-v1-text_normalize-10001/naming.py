import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    parts = []
    current = ""
    for ch in ascii_only:
        if ch.isalnum():
            current += ch
        else:
            if current:
                parts.append(current)
                current = ""
            # non-alnum runs become a single underscore
            parts.append("_")
    if current:
        parts.append(current)

    slug = "".join(parts)

    # strip leading and trailing "_"
    return slug.strip("_")
