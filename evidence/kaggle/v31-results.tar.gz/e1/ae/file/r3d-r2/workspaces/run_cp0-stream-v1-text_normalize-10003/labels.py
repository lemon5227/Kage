import unicodedata


def make_handle(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    normalized = unicodedata.normalize("NFKD", text)
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # Lower-case
    ascii_only = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    parts = []
    current = ""
    for ch in ascii_only:
        if ch.isalnum():  # a-z and 0-9
            current += ch
        else:
            if current:
                parts.append(current)
                current = ""
            parts.append("-")
    if current:
        parts.append(current)

    # Join and strip leading/trailing "-"
    slug = "".join(parts)
    return slug.strip("-")
