def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    """
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported for upgrade")

    # Work on a copy so the input is never modified
    result = {"version": 2}

    # Rename top-level keys
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]

    # Move port and retries into a sub-dict "storage"
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "retries" in cfg:
        storage["retries"] = cfg["retries"]
    result["storage"] = storage

    # Handle timeout_ms -> timeout_s conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged (copy them)
    for key in cfg:
        if key not in ("host", "max_conn", "pwd_file", "port", "retries", "timeout_ms"):
            result[key] = cfg[key]

    # Drop keys whose value is None
    for key in list(result.keys()):
        if result[key] is None:
            del result[key]

    return result
