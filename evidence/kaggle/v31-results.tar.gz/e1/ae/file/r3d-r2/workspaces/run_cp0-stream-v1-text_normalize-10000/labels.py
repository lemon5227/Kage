import unicodedata


def make_handle(text):
    """Turn a title into a handle.

    Apply NFKD normalization and drop non-ASCII characters; lower-case;
    replace every run of characters outside [a-z0-9] with a single "-";
    strip leading and trailing "-". If the result is longer than 23
    characters, cut it to 23 and then strip a trailing "-".
    Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = "".join(c for c in normalized if ord(c) < 128)

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    parts = []
    current = []
    for c in ascii_only:
        if c.isalnum():
            current.append(c)
        else:
            if current:
                parts.append("".join(current))
                current = []
            parts.append("-")
    if current:
        parts.append("".join(current))

    handle = "".join(parts)

    # strip leading and trailing "-"
    while handle.startswith("-"):
        handle = handle[1:]
    while handle.endswith("-"):
        handle = handle[:-1]

    # if longer than 23 characters, cut to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        while handle.endswith("-"):
            handle = handle[:-1]

    return handle
