import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name")
    cleaned = [r for r in cleaned if name_idx < len(r) and r[name_idx] != ""]

    # remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[name_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)
    cleaned = deduped

    # sort rows by "city" ascending as strings (stable)
    city_idx = header.index("city")
    cleaned.sort(key=lambda r: r[city_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()


if __name__ == "__main__":
    # Example usage
    sample = "name,city,score,team\nAlice,New York,85,Team A\nBob,Los Angeles,90,Team B\nAlice,New York,85,Team A"
    result = tidy_csv(sample)
    print(result)
