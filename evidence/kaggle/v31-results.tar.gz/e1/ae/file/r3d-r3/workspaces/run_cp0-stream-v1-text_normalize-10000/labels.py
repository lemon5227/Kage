import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = "".join(c for c in normalized if ord(c) < 128)
    lower = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    parts = []
    current = ""
    for c in lower:
        if c.isalnum():
            current += c
        else:
            if current:
                parts.append(current)
                current = ""
            parts.append("-")
    if current:
        parts.append(current)

    handle = "".join(parts)

    # strip leading and trailing "-"
    while handle.startswith("-"):
        handle = handle[1:]
    while handle.endswith("-"):
        handle = handle[:-1]

    # if longer than 23, cut to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        while handle.endswith("-"):
            handle = handle[:-1]

    return handle
