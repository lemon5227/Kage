def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Renames top-level keys "user" -> "username", "dir" -> "directory".
    Moves "cache_size" and "retries" into a sub-dict "limits".
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float).
    Keeps other keys unchanged and drops keys whose value is None.
    """
    if cfg.get("version") != 1:
        raise ValueError(
            "Only version 1 configurations are supported for conversion."
        )

    # Work on a copy so the input is never modified.
    result = {}
    result["version"] = 2

    # Process top-level keys in a deterministic order.
    for key in sorted(cfg.keys()):
        value = cfg[key]

        # Drop keys whose value is None.
        if value is None:
            continue

        if key == "user":
            result["username"] = value
        elif key == "dir":
            result["directory"] = value
        elif key == "cache_size":
            result["limits"] = {}
            result["limits"]["cache_size"] = value
        elif key == "retries":
            result["limits"] = {}
            result["limits"]["retries"] = value
        elif key == "timeout_ms":
            # Convert milliseconds to seconds (float).
            result["timeout_s"] = float(value) / 1000.0
        else:
            # Keep other keys unchanged.
            result[key] = value

    return result
