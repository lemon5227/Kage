import unicodedata


def to_key(text):
    """Normalize text into a safe identifier.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case the result.
    - Replace every run of characters outside [a-z0-9] with a single "_".
    - Strip leading and trailing "_".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization + drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    # Keep only ASCII characters (0–127)
    ascii_only = "".join(ch for ch in normalized if ord(ch) < 128)

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of non-alphanumeric with a single "_"
    parts = ascii_only.split("_")
    cleaned_parts = [part for part in parts if part]
    result = "_".join(cleaned_parts)

    # strip leading and trailing "_"
    return result.strip("_")
