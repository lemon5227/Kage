def allocate(items, capacity):
    """Select a subset of items whose total cost is at most capacity and total gain is maximized.

    Each item is a dict with a unique string "id", a positive integer "cost" and a non-negative integer "gain".
    Returns the sorted list of ids of the selected items. Ties on total gain are broken by choosing the
    lexicographically smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        cost = item["cost"]
        if cost <= 0:
            raise ValueError("cost must be positive")

    # Work on a copy so the input is never modified
    entries = []
    for item in items:
        entries.append((item["id"], item["cost"], item["gain"]))

    n = len(entries)
    if n == 0:
        return []

    # Sort by id so that we can reason about lexicographic tie-breaking consistently.
    entries.sort(key=lambda e: e[0])

    # dp[c] = best (gain, chosen_ids) achievable with cost exactly c, or None if impossible.
    # We track the chosen ids to resolve ties lexicographically.
    # Using a dict keyed by cost for efficiency; costs can be up to capacity.
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for idx in range(n):
        item_id, cost, gain = entries[idx]
        # Iterate costs descending so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev = dp[c - cost]
            if prev is None:
                continue
            new_gain = prev[0] + gain
            new_ids = list(prev[1]) + [item_id]
            cur = dp[c]
            if cur is None or new_gain > cur[0]:
                dp[c] = (new_gain, new_ids)
            elif new_gain == cur[0] and new_ids < cur[1]:
                dp[c] = (new_gain, new_ids)

    # Find the best gain across all feasible costs, then the lexicographically smallest id list.
    best_gain = None
    best_ids = None
    for c in range(capacity + 1):
        entry = dp[c]
        if entry is None:
            continue
        gain, ids = entry
        if best_gain is None or gain > best_gain:
            best_gain = gain
            best_ids = ids
        elif gain == best_gain and (best_ids is None or ids < best_ids):
            best_ids = ids

    return best_ids if best_ids is not None else []
