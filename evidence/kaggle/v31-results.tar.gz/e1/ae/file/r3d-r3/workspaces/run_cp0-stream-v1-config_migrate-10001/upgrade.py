def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Renames top-level keys:
      "host" -> "hostname"
      "max_conn" -> "max_connections"
      "pwd_file" -> "password_file"
    Moves "port" and "retries" into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, outputs "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keeps other keys unchanged and drops keys whose value is None.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError(
            "convert_settings only supports configuration with version 1; "
            f"got version {cfg.get('version')}"
        )

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process known v1 keys
    if "host" in cfg and cfg["host"] is not None:
        result["hostname"] = cfg["host"]
    if "max_conn" in cfg and cfg["max_conn"] is not None:
        result["max_connections"] = cfg["max_conn"]
    if "pwd_file" in cfg and cfg["pwd_file"] is not None:
        result["password_file"] = cfg["pwd_file"]

    # Move port and retries into storage
    storage = {}
    if "port" in cfg and cfg["port"] is not None:
        storage["port"] = cfg["port"]
    if "retries" in cfg and cfg["retries"] is not None:
        storage["retries"] = cfg["retries"]
    result["storage"] = storage

    # Handle timeout_ms if present
    if "timeout_ms" in cfg and cfg["timeout_ms"] is not None:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Copy over any other keys that are not None
    for key, value in cfg.items():
        if key not in (
            "host",
            "max_conn",
            "pwd_file",
            "port",
            "retries",
            "timeout_ms",
            "version",
        ):
            if value is not None:
                result[key] = value

    return result
