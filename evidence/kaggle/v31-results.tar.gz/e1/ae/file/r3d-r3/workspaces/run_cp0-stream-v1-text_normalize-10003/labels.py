import unicodedata


def make_handle(text):
    """Build a URL slug from text.

    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces every run of characters outside [a-z0-9] with a single "-",
    and strips leading and trailing "-". Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    normalized = unicodedata.normalize("NFKD", text)
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # Lowercase
    ascii_only = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    parts = []
    current = ""
    for ch in ascii_only:
        if ch.isalnum():
            current += ch
        else:
            if current:
                parts.append(current)
                current = ""
            # Use a single hyphen for each run of non-alphanumeric chars
            parts.append("-")
    if current:
        parts.append(current)

    result = "".join(parts)

    # Strip leading and trailing "-"
    return result.strip("-")
