def tally_events(lines):
    """Tally log lines by service for ERROR and WARN levels only.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Level names are matched case-insensitively and stored as uppercase keys.
    Malformed lines are dropped.
    Returns a dict mapping service name -> count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        _timestamp, level, service_part = parts[0], parts[1], parts[2]
        # The service token must end with a colon (e.g. "auth:")
        if not service_part.endswith(":"):
            continue
        service = service_part[:-1]
        if not service:
            continue
        level_upper = level.upper()
        if level_upper not in ("ERROR", "WARN"):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
