def summarize(lines):
    """Count WARN lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each service (for levels WARN only) to the number of lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines. Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        _timestamp, level, service = parts[0], parts[1], parts[2]
        if not service.endswith(':'):
            continue
        service = service[:-1]
        if not service:
            continue
        if level.upper() != "WARN":
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
