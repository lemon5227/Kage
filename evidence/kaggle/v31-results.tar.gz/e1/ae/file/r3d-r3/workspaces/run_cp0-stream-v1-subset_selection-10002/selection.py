def select_tasks(items, capacity):
    """Pick a subset of items maximizing total score with total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    Ties on total score are broken by choosing the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant fields so the input is never mutated.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_score, chosen_ids) for capacity c.
    # We track the chosen ids so we can reconstruct the solution.
    best = [(0, []) for _ in range(capacity + 1)]

    for item_id, size, score in entries:
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = best[c - size]
            cand_score = prev_score + score
            cand_ids = prev_ids + [item_id]
            cur_score, cur_ids = best[c]
            if cand_score > cur_score:
                best[c] = (cand_score, cand_ids)
            elif cand_score == cur_score and cand_ids < cur_ids:
                # Tie on score: prefer lexicographically smaller sorted id list.
                best[c] = (cand_score, sorted(cand_ids))

    max_score, chosen = best[capacity]
    return sorted(chosen)
