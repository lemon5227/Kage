def pick_jobs(items, capacity):
    """Choose a subset of items maximizing total score within capacity.

    Each item is a dict with a unique string "id", a positive integer
    "size" and a non-negative integer "score". Returns the sorted list of
    ids whose total score is as large as possible while total size stays
    <= capacity. Ties on total score are broken by the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by id so that we can reason about tie-breaking consistently.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = best (score, chosen_ids) achievable with capacity exactly w,
    # where chosen_ids is the sorted list of ids for that choice.
    # We track the chosen ids to enable tie-breaking on lexicographic order.
    # Using a dict keyed by capacity for the best score, and storing the id
    # list for that choice. We'll iterate capacities from 0..capacity.
    # Since we need to compare lexicographically when scores tie, we store
    # the chosen ids along with the score.

    # dp[w] = (score, tuple_of_ids) for capacity w
    dp = [(0, ()) for _ in range(capacity + 1)]

    for idx in range(n):
        item_id, size, score = entries[idx]
        # Iterate capacities downward so each item is used at most once.
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[w - size]
            cand_score = prev_score + score
            cand_ids = tuple(sorted(prev_ids + (item_id,)))
            if cand_score > dp[w][0]:
                dp[w] = (cand_score, cand_ids)
            elif cand_score == dp[w][0]:
                # Tie on score: prefer lexicographically smallest sorted id list.
                if cand_ids < dp[w][1]:
                    dp[w] = (cand_score, cand_ids)

    # Find the best score across all capacities, then the lexicographically
    # smallest id list among those achieving that best score.
    best_score = 0
    best_ids = ()
    for w in range(capacity + 1):
        score, ids = dp[w]
        if score > best_score:
            best_score = score
            best_ids = ids
        elif score == best_score:
            if ids < best_ids:
                best_ids = ids

    return list(best_ids)
