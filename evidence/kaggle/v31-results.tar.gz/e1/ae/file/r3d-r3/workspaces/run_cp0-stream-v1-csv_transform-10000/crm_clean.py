import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name") if "name" in header else 0
    cleaned = [r for r in cleaned if name_idx < len(r) and r[name_idx] != ""]

    # lower-case the "email" column
    email_idx = header.index("email") if "email" in header else 0
    for r in cleaned:
        if email_idx < len(r):
            r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        name = r[name_idx] if name_idx < len(r) else ""
        if name in seen:
            continue
        seen.add(name)
        deduped.append(r)
    cleaned = deduped

    # sort rows by "email" ascending as strings (stable)
    email_idx = header.index("email") if "email" in header else 0
    cleaned.sort(key=lambda r: r[email_idx] if email_idx < len(r) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()


if __name__ == "__main__":
    # Example usage
    sample_text = "score,id,email,name\n1,A,test@example.com,John\n2,B,other@example.com,Jane\n3,C,duplicate@example.com,John"
    result = normalize_table(sample_text)
    print(result)
