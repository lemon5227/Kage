def allocate(items, capacity):
    """Select a subset of items maximizing total score with total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    Ties on total score are broken by choosing the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by id so that we can reason about lexicographic tie-breaking.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = best (score, chosen_ids) achievable with total size exactly w.
    # We track the chosen ids to resolve ties lexicographically.
    # Using a dict keyed by weight for the best score, and storing the id list.
    # Initialize with weight 0 having score 0 and empty id list.
    dp = [(0, [])]  # weight -> (score, chosen_ids)
    # We'll iterate over items and update dp for each possible weight.
    # Since capacities can be large, we need to handle this carefully.
    # The maximum possible weight is capacity.
    max_weight = capacity

    # dp[w] = best (score, chosen_ids) for total size exactly w.
    # We'll use a dict for sparse updates, but since capacity may be large,
    # we can also use an array if capacity is not too big. Let's use a dict.
    dp = {(0,): (0, [])}  # weight -> (score, chosen_ids)

    for item_id, size, score in entries:
        # Iterate weights descending to avoid using the same item twice.
        new_dp = dp.copy()
        for w in list(range(capacity, size - 1, -1)):
            if w - size in dp:
                prev_score, prev_ids = dp[w - size]
                cand_score = prev_score + score
                cand_ids = sorted(prev_ids + [item_id])
                # Check if this candidate improves the score at weight w,
                # or ties on score but is lexicographically smaller.
                if w in new_dp:
                    cur_score, cur_ids = new_dp[w]
                    if cand_score > cur_score:
                        new_dp[w] = (cand_score, cand_ids)
                    elif cand_score == cur_score:
                        if cand_ids < cur_ids:
                            new_dp[w] = (cand_score, cand_ids)
                else:
                    new_dp[w] = (cand_score, cand_ids)
        dp = new_dp

    # Find the best score among all weights <= capacity.
    best_score = 0
    best_ids = []
    for w in range(capacity + 1):
        if w in dp:
            score, ids = dp[w]
            if score > best_score:
                best_score = score
                best_ids = ids
            elif score == best_score:
                if ids < best_ids:
                    best_ids = ids

    return best_ids
