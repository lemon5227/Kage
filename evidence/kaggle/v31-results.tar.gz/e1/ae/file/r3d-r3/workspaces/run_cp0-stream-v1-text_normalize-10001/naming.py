import unicodedata


def slugify(text):
    """Turn a title into a handle.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "_".
    - Strip leading and trailing "_".
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    # NFKD normalization + drop non-ASCII
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    parts = []
    current = ""
    for ch in ascii_only:
        if ch.isalnum():
            current += ch
        else:
            if current:
                parts.append(current)
                current = ""
            # use a single underscore for any run of non-alnum chars
            parts.append("_")
    if current:
        parts.append(current)

    slug = "".join(parts)

    # strip leading and trailing "_"
    return slug.strip("_")
