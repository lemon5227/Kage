def coalesce(intervals):
    """Merge overlapping or touching intervals.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Intervals that overlap or merely touch (e.g. [1, 3] and [3, 5]) are merged.
    Returns a new list of dicts with the same "start"/"end" keys, sorted by start ascending.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        normalized.append((start, end))

    # Sort by start, then by end
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    # Merge overlapping or touching intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlap or touch: extend the current interval if needed
            if end > merged[-1][1]:
                merged[-1] = (merged[-1][0], end)
        else:
            merged.append([start, end])

    # Convert back to dicts with "start" and "end" keys
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})

    return result
