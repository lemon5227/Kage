def allocate(items, capacity):
    """Select a subset of items maximizing total score with total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    Ties on total score are broken by returning the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by id so that we can reason about lexicographic tie-breaking.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    if n == 0:
        return []

    # dp[w] = best (score, chosen_ids) achievable with total size exactly w.
    # We track the chosen ids to resolve ties lexicographically.
    # Using a dict keyed by weight for the best score, and storing the id list.
    # Initialize with weight 0 having score 0 and empty id list.
    dp = [(0, [])]  # (score, chosen_ids) for weight 0
    # We'll iterate over items and update dp for each possible weight.
    # Since we need to keep track of the best score for each weight, and then
    # choose the lexicographically smallest id list among those with equal score,
    # we can maintain a dict mapping weight -> (score, chosen_ids).
    best = [None] * (capacity + 1)
    best[0] = (0, [])

    for idx in range(n):
        item_id, size, score = entries[idx]
        # Iterate weights descending to avoid using the same item twice.
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = best[w - size]
            cand_score = prev_score + score
            cand_ids = prev_ids + [item_id]
            if w <= capacity:
                if best[w] is None or cand_score > best[w][0]:
                    best[w] = (cand_score, cand_ids)
                elif cand_score == best[w][0]:
                    # Tie on score: choose lexicographically smallest sorted id list.
                    if sorted(cand_ids) < sorted(best[w][1]):
                        best[w] = (cand_score, cand_ids)

    # Find the maximum score among all weights <= capacity.
    max_score = 0
    best_ids = []
    for w in range(capacity + 1):
        score, ids = best[w]
        if score > max_score:
            max_score = score
            best_ids = ids
        elif score == max_score:
            # Tie on score: choose lexicographically smallest sorted id list.
            if sorted(ids) < sorted(best_ids):
                best_ids = ids

    return best_ids
