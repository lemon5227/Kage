def digest_lines(lines):
    """Count log lines per level.

    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # Check that the second token looks like a log level (e.g. INFO, WARN, ERROR)
        level = parts[1]
        if not level.isalpha():
            continue
        # Validate it's a known log level pattern (letters only, at least 2 chars)
        if len(level) < 2:
            continue
        # Accept any alphabetic token as a level for now (case-insensitive)
        counts[level.upper()] = counts.get(level.upper(), 0) + 1
    return counts
