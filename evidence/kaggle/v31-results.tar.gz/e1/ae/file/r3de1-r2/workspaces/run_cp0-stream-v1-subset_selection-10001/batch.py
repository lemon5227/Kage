def allocate(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # Sort by gain descending, then by cost ascending for the knapsack DP.
    entries.sort(key=lambda e: (e[2], -e[1]))

    # dp[c] = best (gain, sorted_id_list) achievable with cost <= c.
    # We track the chosen ids so we can reconstruct the lexicographically
    # smallest tie-breaker.
    dp = [(0, []) for _ in range(capacity + 1)]

    for item_id, cost, gain in entries:
        # Iterate costs descending so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            cand_gain = prev_gain + gain
            cand_ids = sorted(prev_ids + [item_id])
            if cand_gain > dp[c][0]:
                dp[c] = (cand_gain, cand_ids)
            elif cand_gain == dp[c][0]:
                # Tie on gain: keep the lexicographically smallest sorted id list.
                if cand_ids < dp[c][1]:
                    dp[c] = (cand_gain, cand_ids)

    best_gain, best_ids = dp[capacity]
    return best_ids
