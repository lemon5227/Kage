import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name") if "name" in header else -1
    if name_idx >= 0:
        cleaned = [row for row in cleaned if name_idx < len(row) and row[name_idx] != ""]

    # lower-case the "email" column
    email_idx = header.index("email") if "email" in header else -1
    if email_idx >= 0:
        for row in cleaned:
            if email_idx < len(row):
                row[email_idx] = row[email_idx].lower()

    # remove duplicate rows by "name", keeping the first occurrence
    if name_idx >= 0:
        seen = set()
        deduped = []
        for row in cleaned:
            key = row[name_idx] if name_idx < len(row) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(row)
        cleaned = deduped

    # sort rows by "email" ascending as strings (stable)
    if email_idx >= 0:
        cleaned.sort(key=lambda row: row[email_idx] if email_idx < len(row) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
