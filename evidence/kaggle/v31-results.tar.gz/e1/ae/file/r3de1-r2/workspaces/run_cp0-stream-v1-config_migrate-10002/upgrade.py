def upgrade_config(cfg):
    # Validate version requirement
    if cfg.get("version") != 1:
        raise ValueError("cfg must have version == 1")

    # Copy the input dict to avoid modifying it
    result = {}
    result["version"] = 2

    # Process keys according to v2 layout rules
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]

    # Build network sub-dict for region and retries
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    result["network"] = network

    # Handle timeout_ms conversion to timeout_s
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Drop keys whose value is None
    for key in list(result.keys()):
        if result[key] is None:
            del result[key]

    return result
