def aggregate_log(lines):
    """Aggregate log lines into a dict of service names -> counts.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Only counts lines where the level is ERROR or WARN (case-insensitive).
    Malformed lines are dropped.
    Returns {service_name: count} with upper-case keys.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        service = parts[2]
        if not service.endswith(':'):
            continue
        service = service[:-1]
        if not service:
            continue
        if level not in ('ERROR', 'WARN'):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
