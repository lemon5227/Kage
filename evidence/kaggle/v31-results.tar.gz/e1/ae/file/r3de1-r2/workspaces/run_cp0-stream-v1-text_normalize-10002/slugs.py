import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization to decompose characters
    text = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    text = text.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    text = text.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    normalized = []
    for char in text:
        if char.isalnum():
            normalized.append(char)
        else:
            normalized.append("-")

    text = "".join(normalized)

    # Strip leading and trailing "-"
    text = text.strip("-")

    return text
