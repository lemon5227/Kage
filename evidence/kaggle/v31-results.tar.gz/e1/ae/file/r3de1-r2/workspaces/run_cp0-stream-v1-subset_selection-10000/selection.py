def select_tasks(items, capacity):
    """Select a subset of items maximizing total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by returning the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # Sort by gain descending, then by cost ascending for the initial DP order.
    entries.sort(key=lambda e: (e[2], -e[1]))

    # dp[c] = best (gain, sorted_id_list) achievable with cost exactly c.
    # We track the best gain for each possible cost, and reconstruct the id list.
    # Using a dict mapping cost -> (gain, tuple_of_ids)
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for item_id, cost, gain in entries:
        # Iterate costs descending to avoid reusing the same item.
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            cand_gain = prev_gain + gain
            cand_ids = prev_ids + (item_id,)
            if dp[c] is None or cand_gain > prev_gain:
                dp[c] = (cand_gain, tuple(sorted(cand_ids)))

    # Find the maximum gain among all costs <= capacity.
    best_gain = 0
    best_ids = ()
    for c in range(capacity + 1):
        gain, ids = dp[c]
        if gain > best_gain:
            best_gain = gain
            best_ids = ids
        elif gain == best_gain and ids < best_ids:
            best_ids = ids

    return list(best_ids)
