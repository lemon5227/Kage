def choose(items, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    # Validate items: each must have unique id, positive weight, non-negative value
    used_ids = set()
    for item in items:
        if "id" not in item:
            raise ValueError("each item must have an 'id' field")
        if "weight" not in item or "value" not in item:
            raise ValueError("each item must have 'weight' and 'value' fields")
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        if value < 0:
            raise ValueError("value must be non-negative")
        if item["id"] in used_ids:
            raise ValueError("item ids must be unique")
        used_ids.add(item["id"])
    
    # Knapsack DP over capacity, tracking best (value, sorted_id_list) per capacity
    # best[c] = (max_value, sorted_id_list) for capacity c
    best = [(0, [])] * (capacity + 1)
    for item in items:
        weight = item["weight"]
        value = item["value"]
        item_id = item["id"]
        # Iterate capacities downward so each item is used at most once
        for c in range(capacity, weight - 1, -1):
            prev_value, prev_ids = best[c - weight]
            cand_value = prev_value + value
            cand_ids = sorted(prev_ids + [item_id])
            if cand_value > best[c][0]:
                best[c] = (cand_value, cand_ids)
            elif cand_value == best[c][0] and cand_ids < best[c][1]:
                best[c] = (cand_value, cand_ids)
    
    return best[capacity][1]
