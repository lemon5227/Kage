def pick_jobs(items, capacity):
    """Choose parcels with total score as large as possible while total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is maximized, breaking ties by lexicographically smallest sorted
    id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    for item in items:
        size = item["size"]
        if size <= 0:
            raise ValueError("item size must be positive")

    # Copy the list of items so we don't mutate the input
    candidates = []
    for item in items:
        candidates.append((item["id"], item["size"], item["score"]))

    # Sort by (score descending, id ascending) to handle tie-breaking cleanly
    candidates.sort(key=lambda entry: (-entry[2], entry[0]))

    # Greedy selection by score (works because items are sorted optimally)
    chosen = []
    remaining_capacity = capacity
    for item_id, size, score in candidates:
        if size <= remaining_capacity:
            chosen.append(item_id)
            remaining_capacity -= size

    return sorted(chosen)
