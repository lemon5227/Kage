import unicodedata

def make_handle(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for char in lowercased:
        if char.isalnum():  # alphanumeric means a-z0-9 (since we're only dealing with ASCII)
            result.append(char)
            prev_char = char
        else:
            # If we encounter a non-alphanumeric, check if we need to add a hyphen
            if prev_char is not None or result:  # If there's already something in result, add hyphen
                result.append('-')
                prev_char = '-'
    
    # Join and strip leading/trailing hyphens
    handle = ''.join(result)
    handle = handle.strip('-')
    
    # If result is longer than 23 characters, cut to 23 and strip trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.rstrip('-')
    
    return handle
