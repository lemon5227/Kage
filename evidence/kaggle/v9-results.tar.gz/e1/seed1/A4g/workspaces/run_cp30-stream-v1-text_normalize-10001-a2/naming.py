import unicodedata


def slugify(text):
    """Convert a title into a handle (slug).
    
    - Apply unicodedata NFKD normalization
    - Drop non-ASCII characters
    - Lower-case
    - Replace every run of characters outside [a-z0-9] with a single "_"
    - Strip leading and trailing "_"
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we need to replace any sequence of non-alphanumeric characters with a single underscore
    slug = ''
    previous_char_was_alnum = False
    
    for char in lowercased:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            if not previous_char_was_alnum:
                slug += '_'
            slug += char
            previous_char_was_alnum = True
        else:
            if not previous_char_was_alnum:
                previous_char_was_alnum = True
            # Skip non-alphanumeric characters
    
    # Strip leading and trailing "_"
    slug = slug.strip('_')
    
    return slug
