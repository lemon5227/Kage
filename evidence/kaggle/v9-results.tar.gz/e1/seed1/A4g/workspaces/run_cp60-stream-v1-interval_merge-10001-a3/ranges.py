def merge_slots(intervals):
    """Merge overlapping intervals, treating touching intervals as overlapping.
    
    Args:
        intervals: List of dicts {"from": s, "to": e} with integer values.
    
    Returns:
        List of merged dicts {"from": s, "to": e}, sorted by start ascending.
    
    Raises:
        ValueError: If any interval has start > end.
    """
    # Convert to list of [start, end] pairs for processing
    normalized = []
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(f"invalid interval: start {start} is greater than end {end}")
        normalized.append([start, end])
    
    # Sort by start (and then by end for stability)
    normalized.sort(key=lambda pair: (pair[0], pair[1]))
    
    # Merge overlapping/touching intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching - merge by extending the end
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    
    # Convert back to dicts with "from" and "to" keys
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})
    
    return result
