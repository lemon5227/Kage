def coalesce(intervals):
    items = []
    for iv in intervals:
        s = iv["from"]
        e = iv["to"]
        if s > e:
            raise ValueError("invalid interval: start %r > end %r" % (s, e))
        items.append([s, e])
    items.sort(key=lambda x: (x[0], x[1]))
    merged = []
    for s, e in items:
        if merged and s < merged[-1][1]:
            if e > merged[-1][1]:
                merged[-1][1] = e
        else:
            merged.append([s, e])
    # Convert back to dicts with "from"/"to" keys
    result = []
    for s, e in merged:
        result.append({"from": s, "to": e})
    return result
