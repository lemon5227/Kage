def coalesce(intervals):
    """Merge overlapping intervals, including touching intervals.
    
    Args:
        intervals: List of dicts with "start" and "end" keys
        
    Returns:
        List of merged dicts with "start" and "end" keys, sorted by start ascending
        
    Raises:
        ValueError: If any interval has start > end
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"invalid interval: start {start} is greater than end {end}")
        normalized.append([start, end])
    
    # Sort by start (and end for stability)
    normalized.sort(key=lambda pair: (pair[0], pair[1]))
    
    # Merge overlapping intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    
    # Convert back to dicts
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})
    
    return result
