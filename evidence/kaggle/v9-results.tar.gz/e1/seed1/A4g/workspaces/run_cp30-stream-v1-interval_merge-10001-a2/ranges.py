def merge_slots(intervals):
    normalized = []
    for interval in intervals:
        start, end = interval["from"], interval["to"]
        if start > end:
            raise ValueError("invalid interval: start %r is greater than end %r" % (start, end))
        normalized.append([start, end])
    normalized.sort(key=lambda pair: (pair[0], pair[1]))
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    # Convert lists to dicts with 'from' and 'to' keys
    return [{"from": start, "to": end} for start, end in merged]
