def convert_settings(cfg):
    # Check version
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported")
    
    # Create new dict with v2 layout
    result = {
        "version": 2,
        "directory": cfg.get("dir"),
        "hostname": cfg.get("host"),
        "storage": {}
    }
    
    # Add port to storage if exists
    if "port" in cfg:
        result["storage"]["port"] = cfg["port"]
    
    # Add workers to storage if exists
    if "workers" in cfg:
        result["storage"]["workers"] = cfg["workers"]
    
    # Add timeout_s to storage if timeout_ms exists
    if "timeout_ms" in cfg:
        result["storage"]["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Keep other keys unchanged, but drop keys whose value is None
    for key, value in cfg.items():
        if key not in ["dir", "host", "port", "workers", "timeout_ms", "version"]:
            if value is not None:
                result[key] = value
    
    return result
