def merge_slots(intervals):
    """Merge overlapping time ranges, returning dicts with 'start' and 'end' keys."""
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"invalid interval: start {start} is greater than end {end}")
        normalized.append([start, end])
    
    # Sort by start ascending
    normalized.sort(key=lambda pair: (pair[0], pair[1]))
    
    # Merge overlapping intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    
    # Convert to dicts with 'start' and 'end' keys
    return [{"start": start, "end": end} for start, end in merged]
