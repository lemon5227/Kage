def combine_ranges(intervals):
    """Merge overlapping intervals, each represented as a dict with 'start' and 'end' keys."""
    # Validate and convert to list format
    items = []
    for iv in intervals:
        s = iv["start"]
        e = iv["end"]
        if s > e:
            raise ValueError(f"invalid interval: start {s} > end {e}")
        items.append([s, e])
    
    # Sort by start ascending
    items.sort(key=lambda x: (x[0], x[1]))
    
    # Merge overlapping intervals
    merged = []
    for s, e in items:
        if merged and s < merged[-1][1]:
            if e > merged[-1][1]:
                merged[-1][1] = e
        else:
            merged.append([s, e])
    
    # Convert back to dicts with 'start' and 'end' keys
    result = []
    for s, e in merged:
        result.append({"start": s, "end": e})
    
    return result
