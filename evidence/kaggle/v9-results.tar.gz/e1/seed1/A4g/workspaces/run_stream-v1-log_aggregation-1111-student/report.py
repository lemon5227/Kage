def count_entries(lines):
    """Count occurrences of each level in log lines.
    
    Each line format: <timestamp> <LEVEL> <service>: <message>
    Returns dict mapping level (uppercase) to count.
    Skips malformed lines. Omits keys with zero count.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed line
        
        # Check that level is not empty
        if parts[1].strip() == '':
            continue  # malformed line
        
        # Check that the third part contains "service:"
        if parts[2].strip().startswith('service:'):
            level = parts[1].upper()
            counts[level] = counts.get(level, 0) + 1
    
    return counts
