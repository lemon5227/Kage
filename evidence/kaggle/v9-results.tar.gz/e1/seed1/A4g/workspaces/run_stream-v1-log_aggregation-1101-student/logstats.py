def summarize(lines):
    """Summarize log lines to count per service for ERROR and WARN levels."""
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ('ERROR', 'WARN'):
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
