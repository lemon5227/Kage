def aggregate_log(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        if True:
            level = level.upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
