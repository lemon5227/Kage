import unicodedata


def slugify(text):
    """Build a URL slug from text.
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with a single "-", and
    strips leading/trailing "-".
    
    Raises TypeError if input is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    previous_char_is_alnum = False
    for char in lower_text:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            if not previous_char_is_alnum:
                slug.append(char)
            previous_char_is_alnum = True
        else:
            if not previous_char_is_alnum:
                slug.append('-')
                previous_char_is_alnum = False
            # else: skip consecutive non-alnum characters
    
    result = ''.join(slug)
    
    # Strip leading and trailing "-"
    result = result.strip('-')
    
    return result
