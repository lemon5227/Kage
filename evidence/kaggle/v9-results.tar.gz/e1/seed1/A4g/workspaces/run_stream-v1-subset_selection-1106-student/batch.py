def allocate(items, capacity):
    """
    Select projects to maximize total value while total weight <= capacity.
    
    Args:
        items: List of dicts with keys "id", "weight", "value"
        capacity: Maximum total weight allowed
    
    Returns:
        Sorted list of ids of selected items
    
    Raises:
        ValueError: If capacity is negative or any weight <= 0
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "id" not in item or "weight" not in item or "value" not in item:
            raise ValueError("Each item must have 'id', 'weight', and 'value' keys")
        if item["weight"] <= 0:
            raise ValueError("Weight must be positive")
    
    n = len(items)
    if n == 0:
        return []
    
    # Create a list of (id, weight, value) tuples for easier handling
    items_list = [(item["id"], item["weight"], item["value"]) for item in items]
    
    # DP approach: dp[w] = (max_value, set of ids achieving that value)
    # We'll track all possible (value, id_set) pairs for each weight
    # Since we need lexicographically smallest id list on tie, we need to be careful
    
    # Initialize: dp[0] = (0, []) - zero value with empty set
    # For other weights, start with negative infinity to indicate unreachable
    dp = {}  # weight -> (max_value, id_set)
    dp[0] = (0, [])
    
    # Process each item
    for item_id, weight, value in items_list:
        # Create a new dict to avoid modifying current state during iteration
        new_dp = dp.copy()
        
        # For each weight we can achieve, try adding this item
        for w in range(weight, capacity + 1):
            if w in dp:
                prev_value, prev_ids = dp[w]
                new_value = prev_value + value
                new_ids = prev_ids + [item_id]
                
                # Check if this gives a better value, or same value but lexicographically smaller
                if w not in new_dp:
                    new_dp[w] = (new_value, new_ids)
                else:
                    existing_value, existing_ids = new_dp[w]
                    # Compare values first
                    if new_value > existing_value:
                        new_dp[w] = (new_value, new_ids)
                    elif new_value == existing_value:
                        # Compare lexicographically - we want smaller sorted list
                        # Both lists are already sorted, so compare directly
                        if new_ids < existing_ids:
                            new_dp[w] = (new_value, new_ids)
        
        dp = new_dp
    
    # Find the maximum value among all achievable weights <= capacity
    max_value = 0
    best_ids = []
    
    for w in range(capacity + 1):
        if w in dp:
            value, ids = dp[w]
            if value > max_value:
                max_value = value
                best_ids = ids
            elif value == max_value:
                # Compare lexicographically
                if ids < best_ids:
                    best_ids = ids
    
    return sorted(best_ids)
