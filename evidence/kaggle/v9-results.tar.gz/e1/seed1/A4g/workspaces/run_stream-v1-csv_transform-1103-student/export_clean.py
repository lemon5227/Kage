import csv
import io

def tidy_csv(text):
    # Parse CSV text into a list of rows
    if not text.strip():
        return ''
    
    # Split by newlines and process
    lines = text.strip().split('\n')
    
    if len(lines) < 1:
        return ''
    
    # First line is header
    header = lines[0]
    
    # Parse header columns
    header_cols = header.split(',')
    
    # Process data rows
    rows = []
    for i in range(1, len(lines)):
        line = lines[i].strip()
        if not line:
            continue
        
        # Split the row into cells
        cells = line.split(',')
        
        # Ensure we have enough columns (pad with empty strings if needed)
        while len(cells) < len(header_cols):
            cells.append('')
        
        # Strip whitespace from each cell
        cells = [cell.strip() for cell in cells]
        
        # Check if "name" cell is empty
        name_idx = header_cols.index('name')
        if name_idx >= len(cells) or not cells[name_idx]:
            continue
        
        rows.append(cells)
    
    # Remove duplicate rows by "name", keeping first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        name_idx = header_cols.index('name')
        if name_idx < len(row):
            name = row[name_idx]
            if name not in seen_names:
                seen_names.add(name)
                unique_rows.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    def sort_key(row):
        name_idx = header_cols.index('name')
        if name_idx < len(row):
            return row[name_idx]
        return ''
    
    sorted_rows = sorted(unique_rows, key=sort_key)
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header_cols)
    
    # Write data rows
    for row in sorted_rows:
        writer.writerow(row)
    
    return output.getvalue()
