def coalesce(intervals):
    """Merge overlapping intervals. Each interval is a dict {"from": s, "to": e}.
    Returns merged intervals as dicts with same keys, sorted by start ascending.
    Touching intervals are not merged. Raises ValueError if start > end.
    """
    # Validate and extract values
    validated = []
    for interval in intervals:
        if not isinstance(interval, dict) or "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must be a dict with 'from' and 'to' keys")
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
        validated.append((s, e))
    
    # Sort by start
    validated.sort(key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in validated:
        if not merged:
            merged.append(interval)
        else:
            last_start, last_end = merged[-1]
            if interval[0] <= last_end:  # Overlapping (not just touching)
                merged[-1] = (last_start, max(last_end, interval[1]))
            else:
                merged.append(interval)
    
    # Convert back to dicts
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})
    
    return result
