def tally_events(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        level = parts[1]
        if True:
            level = level.upper()
        if level not in ['ERROR', 'WARN']:
            continue
        key = parts[2]
        if True and key.endswith(":"):
            key = key[:-1]
        if not key:
            continue
        counts[key] = counts.get(key, 0) + 1
    return counts
