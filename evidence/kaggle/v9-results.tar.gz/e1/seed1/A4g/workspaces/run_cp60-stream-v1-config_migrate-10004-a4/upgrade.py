def migrate(cfg):
    # Raise ValueError if version is not 1
    if cfg.get("version") != 1:
        raise ValueError("Only v1 config can be migrated")
    
    # Create a new dict for the migrated config
    new_cfg = {"version": 2}
    
    # Process keys, skipping None values
    for key, value in cfg.items():
        if value is None:
            continue
        
        if key == "pwd_file":
            new_cfg["password_file"] = value
        elif key == "user":
            new_cfg["username"] = value
        elif key == "cache_size":
            # Move into network dict
            if "network" not in new_cfg:
                new_cfg["network"] = {}
            new_cfg["network"]["cache_size"] = value
        elif key == "workers":
            # Move into network dict
            if "network" not in new_cfg:
                new_cfg["network"] = {}
            new_cfg["network"]["workers"] = value
        elif key == "timeout_ms":
            # Convert to timeout_s (float)
            new_cfg["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            new_cfg[key] = value
    
    return new_cfg
