def convert_settings(cfg):
    # Check version
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported")
    
    # Create new dict with version 2
    result = {"version": 2}
    
    # Rename top-level keys
    if "user" in cfg:
        result["username"] = cfg["user"]
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    
    # Handle timeout_ms if exists
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Move cache_size and retries into limits sub-dict
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "retries" in cfg:
        limits["retries"] = cfg["retries"]
    result["limits"] = limits
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["user", "dir", "cache_size", "retries", "timeout_ms"] and value is not None:
            result[key] = value
    
    return result
