import csv
import io


def tidy_csv(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    try:
        ki = header.index('score')
    except ValueError:
        ki = 0
    try:
        si = header.index('city')
    except ValueError:
        si = 0
    cleaned = []
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        if len(cells) <= ki or cells[ki] == "":
            continue
        cleaned.append(cells)
    seen = set()
    deduped = []
    for row in cleaned:
        k = row[ki]
        if k in seen:
            continue
        seen.add(k)
        deduped.append(row)
    deduped.sort(key=lambda r: r[si] if len(r) > si else "")
    out = io.StringIO()
    w = csv.writer(out, lineterminator="\n")
    w.writerow(header)
    for row in deduped:
        w.writerow(row)
    return out.getvalue()
