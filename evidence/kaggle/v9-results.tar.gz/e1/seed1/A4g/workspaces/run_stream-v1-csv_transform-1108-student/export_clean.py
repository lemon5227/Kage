import csv
import io


def normalize_table(text):
    if text == '':
        return ''
    
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ''
    
    # Parse header and find column indices
    header = [c.strip() for c in rows[0]]
    team_idx = header.index('team')
    name_idx = header.index('name')
    
    # Process data rows
    out_rows = []
    seen_teams = set()
    
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        
        # Get team and name values
        team = cells[team_idx] if team_idx < len(cells) else ''
        name = cells[name_idx] if name_idx < len(cells) else ''
        
        # Drop rows with empty team
        if team == '':
            continue
        
        # Remove duplicates by team, keeping first occurrence
        if team in seen_teams:
            continue
        seen_teams.add(team)
        
        out_rows.append(cells)
    
    # Sort by name ascending (stable sort)
    out_rows.sort(key=lambda r: r[name_idx] if name_idx < len(r) else '', stable=True)
    
    # Write output with csv module using '\n' line endings
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\n')
    w.writerow(header)
    w.writerows(out_rows)
    
    return buf.getvalue()
