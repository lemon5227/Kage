def merge_slots(intervals):
    """Merge overlapping time ranges, returning dicts with 'start' and 'end' keys."""
    normalized = []
    for interval in intervals:
        start, end = interval['start'], interval['end']
        if start > end:
            raise ValueError(f"invalid interval: start {start!r} is greater than end {end!r}")
        normalized.append([start, end])
    normalized.sort(key=lambda pair: (pair[0], pair[1]))
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    # Convert to dicts with 'start' and 'end' keys
    return [{'start': start, 'end': end} for start, end in merged]
