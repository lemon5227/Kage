def digest_lines(lines):
    """Parse log lines of the form '<timestamp> <LEVEL> <service>: <message>'
    and return a dict mapping each level (case-insensitive, upper-case keys)
    to the number of matching lines, skipping malformed lines."""
    
    result = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip malformed lines
        
        # parts[0] = timestamp, parts[1] = level, parts[2] = service
        level = parts[1].upper()  # Normalize to upper-case
        result[level] = result.get(level, 0) + 1
    
    return result
