def count_entries(lines):
    """Count log lines per level.
    
    Line format: '<timestamp> <LEVEL> <service>: <message>'
    - Level is case-insensitive and normalized to upper-case
    - Lines that don't match the format are ignored
    - Returns a plain dict of level -> count
    """
    counts = {}
    for line in lines:
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        # Check if the third part starts with ':' (service:)
        if not parts[2].startswith(':'):
            continue
        # Extract the level (second token)
        level = parts[1]
        # Normalize to upper-case
        level = level.upper()
        # Count
        counts[level] = counts.get(level, 0) + 1
    return counts
