def coalesce(intervals):
    """Merge overlapping bookings, returning sorted intervals as dicts."""
    normalized = []
    for interval in intervals:
        start, end = interval["from"], interval["to"]
        if start > end:
            raise ValueError(f"invalid interval: start {start!r} is greater than end {end!r}")
        normalized.append([start, end])
    normalized.sort(key=lambda pair: (pair[0], pair[1]))
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    # Convert back to dicts with "from"/"to" keys
    return [{"from": start, "to": end} for start, end in merged]
