def combine_ranges(intervals):
    """Merge overlapping intervals, handling touching intervals as mergeable.
    
    Args:
        intervals: List of dicts with "begin" and "finish" keys
        
    Returns:
        List of merged dicts with "begin" and "finish" keys, sorted by begin ascending
        
    Raises:
        ValueError: If any interval has start > end
    """
    # Normalize to list format for processing
    normalized = []
    for interval in intervals:
        start = interval["begin"]
        end = interval["finish"]
        if start > end:
            raise ValueError(f"invalid interval: start {start} is greater than end {end}")
        normalized.append([start, end])
    
    # Sort by start (and finish for stability)
    normalized.sort(key=lambda pair: (pair[0], pair[1]))
    
    # Merge overlapping/touching intervals
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching - merge
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    
    # Convert back to dict format
    result = []
    for start, end in merged:
        result.append({"begin": start, "finish": end})
    
    return result
