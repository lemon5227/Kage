def count_entries(lines):
    return {}
