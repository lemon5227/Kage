import csv
import io


def dedupe_export(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = [[c.strip() for c in r] for r in rows[1:]]

    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None

    di = idx('name')
    if di is not None:
        data = [r for r in data if di < len(r) and r[di] != ""]

    li = idx('email')
    if li is not None:
        for r in data:
            if li < len(r):
                r[li] = r[li].lower()

    ki = idx('team')
    if ki is not None:
        seen = set()
        out = []
        for r in data:
            k = r[ki] if ki < len(r) else ""
            if k in seen:
                continue
            seen.add(k)
            out.append(r)
        data = out

    si = idx('id')
    if si is not None:
        data.sort(key=lambda r: r[si] if si < len(r) else "")

    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
