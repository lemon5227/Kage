def upgrade_config(cfg):
    """Upgrade old configuration dict to v2 layout."""
    # Check version requirement
    if cfg.get("version") != 1:
        raise ValueError(f"Expected version 1, got {cfg.get('version')}")
    
    # Create new config dict
    new_cfg = {"version": 2}
    
    # Process keys
    for key, value in cfg.items():
        # Skip None values
        if value is None:
            continue
        
        # Handle specific key transformations
        if key == "max_conn":
            new_cfg["max_connections"] = value
        elif key == "dir":
            new_cfg["directory"] = value
        elif key == "host":
            new_cfg["hostname"] = value
        elif key == "cache_size":
            new_cfg["limits"] = new_cfg.get("limits", {})
            new_cfg["limits"]["cache_size"] = value
        elif key == "region":
            new_cfg["limits"] = new_cfg.get("limits", {})
            new_cfg["limits"]["region"] = value
        elif key == "timeout_ms":
            new_cfg["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            new_cfg[key] = value
    
    return new_cfg
