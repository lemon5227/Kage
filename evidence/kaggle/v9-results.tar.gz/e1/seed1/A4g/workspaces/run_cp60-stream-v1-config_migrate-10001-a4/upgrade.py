def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Check version
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported for upgrade")
    
    # Create new dict with version 2
    result = {"version": 2}
    
    # Process keys
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    
    # Move port and retries into storage sub-dict
    if "port" in cfg:
        result["storage"] = {}
        result["storage"]["port"] = cfg["port"]
    if "retries" in cfg:
        result["storage"].setdefault("retries", cfg["retries"])
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Keep other keys unchanged (but drop keys with None values)
    for key, value in cfg.items():
        if key not in ["host", "max_conn", "pwd_file", "port", "retries", "timeout_ms"]:
            if value is not None:
                result[key] = value
    
    return result
