def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    li = arguments['level_index']
    gi = arguments['group_index']
    mp = arguments['min_parts']
    allowed = arguments['allowed_levels']
    up = arguments['uppercase_levels']
    strip = arguments['strip_trailing_colon']
    allowed_norm = [a.upper() if up else a for a in allowed]
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + repr(mp) + ':\n'
        '            continue\n'
        '        level = parts[' + repr(li) + ']\n'
        '        if ' + repr(up) + ':\n'
        '            level = level.upper()\n'
        '        if level not in ' + repr(allowed_norm) + ':\n'
        '            continue\n'
        '        key = parts[' + repr(gi) + ']\n'
        '        if ' + repr(strip) + ' and key.endswith(":"):\n'
        '            key = key[:-1]\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
