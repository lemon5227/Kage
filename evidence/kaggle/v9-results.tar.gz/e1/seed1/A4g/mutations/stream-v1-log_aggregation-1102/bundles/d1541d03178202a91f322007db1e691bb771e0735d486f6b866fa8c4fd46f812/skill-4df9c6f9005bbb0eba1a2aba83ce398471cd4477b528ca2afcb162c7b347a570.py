def run(arguments, context):
    import os
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    level_index = int(arguments['level_index'])
    min_parts = int(arguments['min_parts'])
    uppercase = bool(arguments['uppercase'])
    workspace = context.get('workspace_dir', '.')
    path = target_file if os.path.isabs(target_file) else os.path.join(workspace, target_file)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    norm = 'level = level.upper()' if uppercase else 'pass'
    code = '''def {fn}(lines):
    counts = {{}}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < {min_parts}:
            continue
        level = parts[{level_index}]
        {norm}
        counts[level] = counts.get(level, 0) + 1
    return counts
'''.format(fn=function_name, min_parts=min_parts, level_index=level_index, norm=norm)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(code)
    return {'success': True, 'path': path, 'bytes_written': len(code.encode('utf-8'))}