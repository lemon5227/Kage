def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    idx = int(arguments['level_index'])
    min_parts = int(arguments['min_parts'])
    upper = bool(arguments['uppercase'])
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + repr(min_parts) + ':\n'
        '            continue\n'
        '        key = parts[' + repr(idx) + ']\n'
        '        if not key:\n'
        '            continue\n'
        + ('        key = key.upper()\n' if upper else '')
        + '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
