import os


def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    level_index = int(arguments['level_index'])
    min_parts = int(arguments['min_parts'])
    uppercase = bool(arguments['uppercase'])

    norm = 'level.upper()' if uppercase else 'level'
    src = (
        'def {fn}(lines):\n'
        '    counts = {{}}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < {mp}:\n'
        '            continue\n'
        '        level = parts[{li}]\n'
        '        if not level:\n'
        '            continue\n'
        '        level = {norm}\n'
        '        counts[level] = counts.get(level, 0) + 1\n'
        '    return counts\n'
    ).format(fn=function_name, mp=min_parts, li=level_index, norm=norm)

    path = target_file
    if not os.path.isabs(path):
        path = os.path.join(context['workspace_dir'], path)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': target_file, 'function_name': function_name}
