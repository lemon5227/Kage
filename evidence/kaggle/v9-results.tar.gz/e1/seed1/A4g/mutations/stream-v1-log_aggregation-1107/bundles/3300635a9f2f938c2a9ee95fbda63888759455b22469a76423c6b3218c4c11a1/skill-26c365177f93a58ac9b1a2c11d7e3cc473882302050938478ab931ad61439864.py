def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    idx = int(arguments['level_index'])
    min_parts = int(arguments['min_parts'])
    up = bool(arguments['uppercase'])
    src = (
        "def " + fn + "(lines):\n"
        "    counts = {}\n"
        "    for line in lines:\n"
        "        parts = line.split()\n"
        "        if len(parts) < " + repr(min_parts) + ":\n"
        "            continue\n"
        "        level = parts[" + repr(idx) + "]\n"
        + ("        level = level.upper()\n" if up else "")
        + "        counts[level] = counts.get(level, 0) + 1\n"
        "    return counts\n"
    )
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'target_file': target, 'function_name': fn, 'bytes_written': len(src)}
