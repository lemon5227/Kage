def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    touch = bool(arguments['merge_touching'])
    cmp = 'start <= merged[-1][1]' if touch else 'start < merged[-1][1]'
    src = (
        'def ' + fn + '(intervals):\n'
        '    normalized = []\n'
        '    for interval in intervals:\n'
        '        start, end = interval[0], interval[1]\n'
        '        if start > end:\n'
        '            raise ValueError("invalid interval: start %r is greater than end %r" % (start, end))\n'
        '        normalized.append([start, end])\n'
        '    normalized.sort(key=lambda pair: (pair[0], pair[1]))\n'
        '    merged = []\n'
        '    for start, end in normalized:\n'
        '        if merged and ' + cmp + ':\n'
        '            if end > merged[-1][1]:\n'
        '                merged[-1][1] = end\n'
        '        else:\n'
        '            merged.append([start, end])\n'
        '    return merged\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
