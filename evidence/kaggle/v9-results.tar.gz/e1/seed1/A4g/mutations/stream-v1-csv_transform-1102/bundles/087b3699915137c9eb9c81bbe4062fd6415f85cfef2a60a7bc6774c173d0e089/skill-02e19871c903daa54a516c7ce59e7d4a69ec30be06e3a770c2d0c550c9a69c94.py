import json


def run(arguments, context):
    target = arguments["target_file"]
    fn = arguments["function_name"]
    key = arguments["key_column"]
    cols = arguments["header_columns"]
    src = (
        "import csv\nimport io\n\n\n"
        "def " + fn + "(text):\n"
        "    if text == '':\n"
        "        return ''\n"
        "    rows = list(csv.reader(io.StringIO(text)))\n"
        "    if not rows:\n"
        "        return ''\n"
        "    header = [c.strip() for c in rows[0]]\n"
        "    try:\n"
        "        ki = header.index(" + json.dumps(key) + ")\n"
        "    except ValueError:\n"
        "        ki = None\n"
        "    out_rows = []\n"
        "    seen = set()\n"
        "    for row in rows[1:]:\n"
        "        cells = [c.strip() for c in row]\n"
        "        name = cells[ki] if ki is not None and ki < len(cells) else ''\n"
        "        if name == '' or name in seen:\n"
        "            continue\n"
        "        seen.add(name)\n"
        "        out_rows.append(cells)\n"
        "    out_rows.sort(key=lambda r: r[ki] if ki is not None and ki < len(r) else '')\n"
        "    buf = io.StringIO()\n"
        "    w = csv.writer(buf, lineterminator='\\n')\n"
        "    w.writerow(header)\n"
        "    w.writerows(out_rows)\n"
        "    return buf.getvalue()\n"
    )
    path = context["workspace_dir"] + "/" + target
    with open(path, "w") as f:
        f.write(src)
    return {"success": True, "path": target, "bytes_written": len(src)}
