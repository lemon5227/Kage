def run(arguments, context):
    import os
    tf = arguments['target_file']
    fn = arguments['function_name']
    idf = arguments['id_field']
    wf = arguments['weight_field']
    vf = arguments['value_field']
    src = 'def %s(items, capacity):\n    if capacity < 0:\n        raise ValueError("capacity must be non-negative")\n    entries = []\n    for it in items:\n        w = it["%s"]\n        v = it["%s"]\n        if w <= 0:\n            raise ValueError("weight must be positive")\n        entries.append((it["%s"], w, v))\n    best = [(0, []) for _ in range(capacity + 1)]\n    for iid, w, v in entries:\n        for c in range(capacity, w - 1, -1):\n            pv, pi = best[c - w]\n            cv = pv + v\n            ci = sorted(pi + [iid])\n            bv, bi = best[c]\n            if cv > bv or (cv == bv and ci < bi):\n                best[c] = (cv, ci)\n    return best[capacity][1]\n' % (fn, wf, vf, idf)
    path = os.path.join(context['workspace_dir'], tf)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': tf, 'function': fn}
