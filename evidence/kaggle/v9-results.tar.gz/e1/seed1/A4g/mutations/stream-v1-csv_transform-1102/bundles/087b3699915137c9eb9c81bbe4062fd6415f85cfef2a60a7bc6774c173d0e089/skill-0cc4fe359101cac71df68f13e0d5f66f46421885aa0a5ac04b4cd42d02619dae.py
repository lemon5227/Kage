import json, os

def run(arguments, context):
    ws = context['workspace_dir']
    path = os.path.join(ws, arguments['target_file'])
    fn = arguments['function_name']
    header = arguments['header_columns']
    drop_col = arguments['drop_if_empty_column']
    lower_col = arguments.get('lowercase_column', '')
    dedup_col = arguments['dedup_key_column']
    sort_col = arguments['sort_column']
    src = '''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = [[c.strip() for c in r] for r in rows[1:]]

    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None

    di = idx({drop!r})
    if di is not None:
        data = [r for r in data if di < len(r) and r[di] != ""]

    li = idx({lower!r})
    if li is not None:
        for r in data:
            if li < len(r):
                r[li] = r[li].lower()

    ki = idx({dedup!r})
    if ki is not None:
        seen = set()
        out = []
        for r in data:
            k = r[ki] if ki < len(r) else ""
            if k in seen:
                continue
            seen.add(k)
            out.append(r)
        data = out

    si = idx({sort!r})
    if si is not None:
        data.sort(key=lambda r: r[si] if si < len(r) else "")

    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\\n")
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
'''.format(fn=fn, drop=drop_col, lower=lower_col, dedup=dedup_col, sort=sort_col)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': arguments['target_file'], 'bytes_written': len(src)}
