def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    idx = int(arguments['level_index'])
    min_parts = int(arguments['min_parts'])
    up = bool(arguments['uppercase'])
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + str(min_parts) + ':\n'
        '            continue\n'
        '        level = parts[' + str(idx) + ']\n'
        '        if ' + ('True' if up else 'False') + ':\n'
        '            level = level.upper()\n'
        '        counts[level] = counts.get(level, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
