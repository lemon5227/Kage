import csv, io

def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    key_column = arguments['key_column']
    sort_column = arguments['sort_column']
    header_columns = arguments['header_columns']
    src = '''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    try:
        ki = header.index({key!r})
    except ValueError:
        ki = 0
    try:
        si = header.index({sort!r})
    except ValueError:
        si = 0
    cleaned = []
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        if len(cells) <= ki or cells[ki] == "":
            continue
        cleaned.append(cells)
    seen = set()
    deduped = []
    for row in cleaned:
        k = row[ki]
        if k in seen:
            continue
        seen.add(k)
        deduped.append(row)
    deduped.sort(key=lambda r: r[si] if len(r) > si else "")
    out = io.StringIO()
    w = csv.writer(out, lineterminator="\\n")
    w.writerow(header)
    for row in deduped:
        w.writerow(row)
    return out.getvalue()
'''.format(fn=function_name, key=key_column, sort=sort_column)
    path = target_file
    if not path.startswith('/') and context.get('workspace_dir'):
        import os
        path = os.path.join(context['workspace_dir'], path)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target_file, 'function': function_name}