def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    li = arguments['level_index']
    gi = arguments['group_index']
    mp = arguments['min_parts']
    allowed = [a.upper() if arguments['uppercase_levels'] else a for a in arguments['allowed_levels']]
    up = arguments['uppercase_levels']
    strip_colon = arguments['strip_trailing_colon']
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + repr(mp) + ':\n'
        '            continue\n'
        '        level = parts[' + repr(li) + ']\n'
        '        if ' + repr(up) + ':\n'
        '            level = level.upper()\n'
        '        if level not in ' + repr(allowed) + ':\n'
        '            continue\n'
        '        key = parts[' + repr(gi) + ']\n'
        '        if ' + repr(strip_colon) + ' and key.endswith(":"):\n'
        '            key = key[:-1]\n'
        '        if not key:\n'
        '            continue\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
