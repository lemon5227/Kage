def run(arguments, context):
    import os
    path = os.path.join(context['workspace_dir'], arguments['target_file'])
    fn = arguments['function_name']
    sf = arguments['start_field']
    ef = arguments['end_field']
    mt = arguments['merge_touching']
    src = (
        "def {fn}(intervals):\n"
        "    norm = []\n"
        "    for iv in intervals:\n"
        "        s = iv[{sf!r}]\n"
        "        e = iv[{ef!r}]\n"
        "        if s > e:\n"
        "            raise ValueError('start > end')\n"
        "        norm.append((s, e))\n"
        "    norm.sort(key=lambda p: p[0])\n"
        "    merged = []\n"
        "    for s, e in norm:\n"
        "        if merged and (s < merged[-1][1] or ({mt} and s == merged[-1][1])):\n"
        "            if e > merged[-1][1]:\n"
        "                merged[-1][1] = e\n"
        "        else:\n"
        "            merged.append([s, e])\n"
        "    return [{{{sf!r}: s, {ef!r}: e}} for s, e in merged]\n"
    ).format(fn=fn, sf=sf, ef=ef, mt=mt)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': arguments['target_file']}
