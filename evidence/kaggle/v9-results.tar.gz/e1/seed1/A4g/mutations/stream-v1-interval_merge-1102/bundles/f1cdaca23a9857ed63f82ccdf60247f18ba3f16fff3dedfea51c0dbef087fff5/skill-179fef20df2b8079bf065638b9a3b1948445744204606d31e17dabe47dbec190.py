def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    src = '''def {fn}(intervals):
    items = []
    for iv in intervals:
        s, e = iv[0], iv[1]
        if s > e:
            raise ValueError("invalid interval: start %r > end %r" % (s, e))
        items.append([s, e])
    items.sort(key=lambda x: (x[0], x[1]))
    merged = []
    for s, e in items:
        if merged and s < merged[-1][1]:
            if e > merged[-1][1]:
                merged[-1][1] = e
        else:
            merged.append([s, e])
    return merged
'''.format(fn=fn)
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'function_name': fn}
