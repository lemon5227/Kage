def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    idx = int(arguments.get('group_field_index', 1))
    upper = bool(arguments.get('uppercase_keys', True))
    minf = int(arguments.get('min_fields', 3))
    colon = bool(arguments.get('require_colon_field', True))
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + str(minf) + ':\n'
        '            continue\n'
        '        if ' + str(idx) + ' >= len(parts):\n'
        '            continue\n'
        '        key = parts[' + str(idx) + ']\n'
        '        if not key:\n'
        '            continue\n'
        '        if ' + ('True' if colon else 'False') + ':\n'
        '            nxt = ' + str(idx + 1) + '\n'
        '            if nxt >= len(parts) or not parts[nxt].endswith(":"):\n'
        '                continue\n'
        '        if ' + ('True' if upper else 'False') + ':\n'
        '            key = key.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
