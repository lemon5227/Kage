def run(arguments, context):
    import os
    target = arguments['target_file']
    fname = arguments['function_name']
    idf = arguments.get('id_field', 'id')
    wf = arguments.get('weight_field', 'weight')
    vf = arguments.get('value_field', 'value')
    code = f'''def {fname}(items, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    entries = []
    for item in items:
        w = item["{wf}"]
        v = item["{vf}"]
        if w <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["{idf}"], w, v))
    best = [(0, []) for _ in range(capacity + 1)]
    for iid, w, v in entries:
        for c in range(capacity, w - 1, -1):
            pv, pi = best[c - w]
            cv = pv + v
            ci = sorted(pi + [iid])
            bv, bi = best[c]
            if cv > bv or (cv == bv and ci < bi):
                best[c] = (cv, ci)
    return best[capacity][1]
'''
    path = os.path.join(context['workspace_dir'], target)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': target}
