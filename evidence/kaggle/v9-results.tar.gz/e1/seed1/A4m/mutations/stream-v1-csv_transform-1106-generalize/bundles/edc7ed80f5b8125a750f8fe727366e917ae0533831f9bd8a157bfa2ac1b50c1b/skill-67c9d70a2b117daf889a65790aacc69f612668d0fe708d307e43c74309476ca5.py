def run(arguments, context):
    import os
    target = arguments['target_file']
    fname = arguments['function_name']
    merge_touching = bool(arguments.get('merge_touching', False))
    err = arguments.get('error_type', 'ValueError')
    cmp = '<=' if merge_touching else '<'
    src = (
        'def ' + fname + '(intervals):\n'
        '    normalized = []\n'
        '    for interval in intervals:\n'
        '        start, end = interval[0], interval[1]\n'
        '        if start > end:\n'
        '            raise ' + err + '(\'invalid interval: start %r > end %r\' % (start, end))\n'
        '        normalized.append([start, end])\n'
        '    normalized.sort(key=lambda pair: (pair[0], pair[1]))\n'
        '    merged = []\n'
        '    for start, end in normalized:\n'
        '        if merged and start ' + cmp + ' merged[-1][1]:\n'
        '            if end > merged[-1][1]:\n'
        '                merged[-1][1] = end\n'
        '        else:\n'
        '            merged.append([start, end])\n'
        '    return merged\n'
    )
    path = target if os.path.isabs(target) else os.path.join(context['workspace_dir'], target)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
