import json, os

def run(arguments, context):
    ws = context['workspace_dir']
    path = os.path.join(ws, arguments['target_file'])
    fn = arguments['function_name']
    drop_col = arguments['drop_empty_column']
    key_col = arguments['dedupe_key_column']
    sort_col = arguments['sort_column']
    lower_col = arguments.get('lowercase_column', '')
    term = arguments.get('line_terminator', '\n')
    code = '''import csv
import io

def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = []
    for row in rows[1:]:
        row = [c.strip() for c in row]
        if len(row) < len(header):
            row += [""] * (len(header) - len(row))
        data.append(row)
    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None
    di = idx({drop!r})
    if di is not None:
        data = [r for r in data if r[di] != ""]
    li = idx({lower!r})
    if li is not None:
        for r in data:
            r[li] = r[li].lower()
    ki = idx({key!r})
    if ki is not None:
        seen = set()
        out = []
        for r in data:
            if r[ki] in seen:
                continue
            seen.add(r[ki])
            out.append(r)
        data = out
    si = idx({sort!r})
    if si is not None:
        data.sort(key=lambda r: r[si])
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator={term!r})
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
'''.format(fn=fn, drop=drop_col, key=key_col, sort=sort_col, lower=lower_col, term=term)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(code)
    return {'success': True, 'path': arguments['target_file'], 'bytes_written': len(code.encode('utf-8'))}
