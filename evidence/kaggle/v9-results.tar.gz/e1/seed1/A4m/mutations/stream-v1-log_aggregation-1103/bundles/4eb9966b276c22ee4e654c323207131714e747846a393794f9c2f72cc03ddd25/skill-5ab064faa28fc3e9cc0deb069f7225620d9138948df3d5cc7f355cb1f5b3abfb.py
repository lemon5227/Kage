import re

def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    level_field_index = arguments.get('level_field_index', 1)
    uppercase_level = arguments.get('uppercase_level', True)
    min_fields = arguments.get('min_fields', 3)

    lines = []
    lines.append('def ' + function_name + '(lines):')
    lines.append('    counts = {}')
    lines.append('    for line in lines:')
    lines.append('        parts = line.split()')
    lines.append('        if len(parts) < ' + str(min_fields) + ':')
    lines.append('            continue')
    lines.append('        level = parts[' + str(level_field_index) + ']')
    if uppercase_level:
        lines.append('        level = level.upper()')
    lines.append('        counts[level] = counts.get(level, 0) + 1')
    lines.append('    return counts')
    code = '\n'.join(lines) + '\n'

    import os
    path = os.path.join(context['workspace_dir'], target_file)
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': target_file, 'bytes_written': len(code)}
