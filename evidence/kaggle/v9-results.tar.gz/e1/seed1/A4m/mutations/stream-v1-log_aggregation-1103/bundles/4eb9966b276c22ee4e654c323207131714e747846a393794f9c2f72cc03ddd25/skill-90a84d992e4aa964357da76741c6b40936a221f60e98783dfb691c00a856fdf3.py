def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    levels = arguments.get('levels', ['ERROR', 'WARN'])
    min_fields = arguments.get('min_fields', 3)
    require_colon = arguments.get('require_colon', True)
    levels_repr = repr([str(l).upper() for l in levels])
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    allowed = set(' + levels_repr + ')\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + str(min_fields) + ':\n'
        '            continue\n'
        '        level = parts[1].upper()\n'
        '        if level not in allowed:\n'
        '            continue\n'
        '        rest = line.split(None, 2)[2]\n'
        '        if ' + ('":" not in rest' if require_colon else 'False') + ':\n'
        '            continue\n'
        '        service = rest.split(":", 1)[0].strip()\n'
        '        if not service:\n'
        '            continue\n'
        '        counts[service] = counts.get(service, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
