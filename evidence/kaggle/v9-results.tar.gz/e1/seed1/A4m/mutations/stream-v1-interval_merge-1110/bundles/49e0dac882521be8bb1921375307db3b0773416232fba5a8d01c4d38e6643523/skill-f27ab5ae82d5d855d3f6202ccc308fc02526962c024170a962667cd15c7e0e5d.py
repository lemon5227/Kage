def run(arguments, context):
    import os
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    start_key = arguments.get('start_key', 'from')
    end_key = arguments.get('end_key', 'to')
    merge_touching = arguments.get('merge_touching', True)
    error_type = arguments.get('error_type', 'ValueError')
    lines = []
    lines.append('def %s(intervals):' % function_name)
    lines.append('    normalized = []')
    lines.append('    for interval in intervals:')
    lines.append('        start = interval[%r]' % start_key)
    lines.append('        end = interval[%r]' % end_key)
    lines.append('        if start > end:')
    lines.append('            raise %s("invalid interval: start %%r is greater than end %%r" %% (start, end))' % error_type)
    lines.append('        normalized.append((start, end))')
    lines.append('    normalized.sort(key=lambda pair: (pair[0], pair[1]))')
    lines.append('    merged = []')
    lines.append('    for start, end in normalized:')
    if merge_touching:
        lines.append('        if merged and start <= merged[-1][1]:')
    else:
        lines.append('        if merged and start < merged[-1][1]:')
    lines.append('            if end > merged[-1][1]:')
    lines.append('                merged[-1][1] = end')
    lines.append('        else:')
    lines.append('            merged.append([start, end])')
    lines.append('    return [{%r: start, %r: end} for start, end in merged]' % (start_key, end_key))
    code = '\n'.join(lines) + '\n'
    path = os.path.join(context['workspace_dir'], target_file)
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': target_file, 'bytes_written': len(code)}
