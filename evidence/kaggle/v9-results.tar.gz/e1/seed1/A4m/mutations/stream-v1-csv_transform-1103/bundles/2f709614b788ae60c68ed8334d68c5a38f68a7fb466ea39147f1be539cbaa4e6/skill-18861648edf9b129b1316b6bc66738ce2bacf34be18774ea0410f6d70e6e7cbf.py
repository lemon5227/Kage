import json

def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    key_column = arguments['key_column']
    line_terminator = arguments.get('line_terminator', '\n')
    code = '''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    try:
        key_idx = header.index({key!r})
    except ValueError:
        key_idx = None
    cleaned = []
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        key = cells[key_idx] if key_idx is not None and key_idx < len(cells) else ""
        if key == "":
            continue
        cleaned.append((key, cells))
    seen = set()
    deduped = []
    for key, cells in cleaned:
        if key in seen:
            continue
        seen.add(key)
        deduped.append((key, cells))
    deduped.sort(key=lambda pair: pair[0])
    out = io.StringIO()
    writer = csv.writer(out, lineterminator={lt!r})
    writer.writerow(header)
    writer.writerows(cells for _, cells in deduped)
    return out.getvalue()
'''.format(fn=function_name, key=key_column, lt=line_terminator)
    path = context['workspace_dir'].rstrip('/') + '/' + target_file
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': target_file, 'bytes_written': len(code)}