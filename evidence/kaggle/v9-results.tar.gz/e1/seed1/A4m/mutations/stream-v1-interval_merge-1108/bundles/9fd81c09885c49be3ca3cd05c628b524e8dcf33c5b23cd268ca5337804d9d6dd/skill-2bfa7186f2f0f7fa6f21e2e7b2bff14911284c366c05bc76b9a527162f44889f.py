def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    sk = arguments.get('start_key', 'from')
    ek = arguments.get('end_key', 'to')
    mt = arguments.get('merge_touching', False)
    et = arguments.get('error_type', 'ValueError')
    src = '''def {fn}(intervals):
    norm = []
    for iv in intervals:
        s = iv[{sk!r}]
        e = iv[{ek!r}]
        if s > e:
            raise {et}("invalid interval: start %r > end %r" % (s, e))
        norm.append((s, e))
    norm.sort(key=lambda p: p[0])
    merged = []
    for s, e in norm:
        if merged and (s < merged[-1][1] or ({mt} and s == merged[-1][1])):
            if e > merged[-1][1]:
                merged[-1][1] = e
        else:
            merged.append([s, e])
    return [{{{sk!r}: s, {ek!r}: e}} for s, e in merged]
'''.format(fn=fn, sk=sk, ek=ek, mt=mt, et=et)
    path = target if os.path.isabs(target) else os.path.join(context['workspace_dir'], target)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
