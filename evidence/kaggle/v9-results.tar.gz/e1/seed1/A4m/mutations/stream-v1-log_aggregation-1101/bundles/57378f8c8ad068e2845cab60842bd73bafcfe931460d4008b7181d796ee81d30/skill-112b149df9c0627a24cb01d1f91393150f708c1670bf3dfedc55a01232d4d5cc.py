def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    gidx = int(arguments.get('group_field_index', 2))
    lidx = int(arguments.get('level_field_index', 1))
    allowed = [str(x).upper() for x in arguments.get('allowed_levels', ['ERROR', 'WARN'])]
    minf = int(arguments.get('min_fields', 3))
    colon = bool(arguments.get('require_colon_field', True))
    up = bool(arguments.get('uppercase_keys', True))
    lines = []
    lines.append('def %s(lines):' % fn)
    lines.append('    counts = {}')
    lines.append('    allowed = %r' % (allowed,))
    lines.append('    for line in lines:')
    lines.append('        if not isinstance(line, str):')
    lines.append('            continue')
    lines.append('        parts = line.split()')
    lines.append('        if len(parts) < %d:' % minf)
    lines.append('            continue')
    lines.append('        if %d >= len(parts) or %d >= len(parts):' % (lidx, gidx))
    lines.append('            continue')
    lines.append('        if parts[%d].upper() not in allowed:' % lidx)
    lines.append('            continue')
    lines.append('        key = parts[%d]' % gidx)
    if colon:
        lines.append('        if not key.endswith(":"):')
        lines.append('            continue')
        lines.append('        key = key[:-1]')
    lines.append('        if not key:')
    lines.append('            continue')
    if up:
        lines.append('        key = key.upper()')
    lines.append('        counts[key] = counts.get(key, 0) + 1')
    lines.append('    return counts')
    code = '\n'.join(lines) + '\n'
    path = target if os.path.isabs(target) else os.path.join(context['workspace_dir'], target)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': target, 'bytes_written': len(code)}
