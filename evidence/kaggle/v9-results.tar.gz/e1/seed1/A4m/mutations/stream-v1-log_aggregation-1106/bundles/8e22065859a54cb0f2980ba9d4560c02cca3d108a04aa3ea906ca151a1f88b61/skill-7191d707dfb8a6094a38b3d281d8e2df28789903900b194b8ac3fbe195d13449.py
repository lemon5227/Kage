def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    idx = int(arguments.get('group_field_index', 1))
    minf = int(arguments.get('min_fields', 3))
    colon = bool(arguments.get('require_colon_field', True))
    upper = bool(arguments.get('uppercase_keys', True))
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + repr(minf) + ':\n'
        '            continue\n'
        '        if ' + repr(idx) + ' >= len(parts):\n'
        '            continue\n'
        '        key = parts[' + repr(idx) + ']\n'
        '        if ' + repr(colon) + ' and not parts[' + repr(idx + 1) + '].endswith(":"):\n'
        '            continue\n'
        '        if ' + repr(upper) + ':\n'
        '            key = key.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = target if os.path.isabs(target) else os.path.join(context['workspace_dir'], target)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src.encode('utf-8'))}
