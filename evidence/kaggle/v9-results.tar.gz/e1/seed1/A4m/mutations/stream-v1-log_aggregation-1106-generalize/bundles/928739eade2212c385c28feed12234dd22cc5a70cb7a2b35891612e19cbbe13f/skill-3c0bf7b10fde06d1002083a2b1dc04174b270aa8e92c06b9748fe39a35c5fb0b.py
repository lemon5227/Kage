def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    gidx = int(arguments.get('group_field_index', 1))
    lidx = int(arguments.get('level_field_index', 1))
    allowed = [str(x).upper() for x in arguments.get('allowed_levels', [])]
    minf = int(arguments.get('min_fields', 3))
    req_colon = bool(arguments.get('require_colon_field', True))
    up = bool(arguments.get('uppercase_keys', True))
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + repr(minf) + ':\n'
        '            continue\n'
        '        if ' + repr(lidx) + ' >= len(parts) or ' + repr(gidx) + ' >= len(parts):\n'
        '            continue\n'
        '        level = parts[' + repr(lidx) + '].upper()\n'
        '        if not level.isalpha():\n'
        '            continue\n'
        '        allowed = ' + repr(allowed) + '\n'
        '        if allowed and level not in allowed:\n'
        '            continue\n'
        '        if ' + repr(req_colon) + ' and not parts[' + repr(gidx) + '].endswith(":"):\n'
        '            continue\n'
        '        key = parts[' + repr(gidx) + ']\n'
        '        if ' + repr(up) + ':\n'
        '            key = key.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = target if os.path.isabs(target) else os.path.join(context['workspace_dir'], target)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
