import csv, io

def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    filter_column = arguments['filter_column']
    dedup_column = arguments['dedup_column']
    sort_column = arguments['sort_column']
    line_terminator = arguments.get('line_terminator', '\n')

    code = '''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = rows[1:]
    cleaned = []
    for row in data:
        row = [c.strip() for c in row]
        if len(row) < len(header):
            row = row + [""] * (len(header) - len(row))
        cleaned.append(row)
    try:
        fi = header.index({fc!r})
    except ValueError:
        fi = None
    if fi is not None:
        cleaned = [r for r in cleaned if r[fi] != ""]
    try:
        di = header.index({dc!r})
    except ValueError:
        di = None
    if di is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            k = r[di]
            if k in seen:
                continue
            seen.add(k)
            deduped.append(r)
        cleaned = deduped
    try:
        si = header.index({sc!r})
    except ValueError:
        si = None
    if si is not None:
        cleaned.sort(key=lambda r: r[si])
    out = io.StringIO()
    w = csv.writer(out, lineterminator={lt!r})
    w.writerow(header)
    w.writerows(cleaned)
    return out.getvalue()
'''.format(fn=function_name, fc=filter_column, dc=dedup_column, sc=sort_column, lt=line_terminator)

    path = target_file
    if not path.startswith('/') and context.get('workspace_dir'):
        import os
        path = os.path.join(context['workspace_dir'], path)
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': target_file, 'bytes_written': len(code)}
