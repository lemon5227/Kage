def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    level = arguments['target_level']
    min_fields = int(arguments.get('min_fields', 3))
    require_colon = bool(arguments.get('require_colon', True))
    upper = bool(arguments.get('uppercase_keys', False))
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split(None, ' + str(min_fields - 1) + ')\n'
        '        if len(parts) < ' + str(min_fields) + ':\n'
        '            continue\n'
        '        _ts, lvl, rest = parts[0], parts[1], parts[2]\n'
        + ('        if ":" not in rest:\n            continue\n' if require_colon else '')
        + '        service = rest.split(":", 1)[0].strip()\n'
        '        if not service:\n'
        '            continue\n'
        '        if lvl.upper() != ' + repr(level.upper()) + ':\n'
        '            continue\n'
        + ('        service = service.upper()\n' if upper else '')
        + '        counts[service] = counts.get(service, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
