def coalesce(intervals):
    """Merge overlapping intervals from a list of dicts with 'start' and 'end' keys.

    Each interval is a dict {"start": s, "end": e} where s and e are integers.
    Returns merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals (e.g., [1,3] and [3,5]) are merged.
    Raises ValueError if any interval has start > end.
    The input list is not modified.
    """
    # Validate and convert to [start, end] lists
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                f"invalid interval: start {start} > end {end}"
            )
        normalized.append([start, end])

    # Sort by start (and then by end for stability)
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    # Merge overlapping intervals (including touching ones)
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlap or touching: extend the current interval if needed
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    # Convert back to dicts
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})

    return result
