import unicodedata


def slugify(text):
    """Convert a title into a handle (slug)."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    previous_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if previous_char is None or previous_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                result.append('_')
            previous_char = char
        else:
            previous_char = None
    
    slug = ''.join(result)
    
    # Strip leading and trailing "_"
    slug = slug.strip('_')
    
    return slug
