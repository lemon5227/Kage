import csv
import io


def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    try:
        team_idx = header.index('team')
        name_idx = header.index('name')
    except ValueError:
        team_idx = None
        name_idx = None

    cleaned = []
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        team = cells[team_idx] if team_idx is not None and team_idx < len(cells) else ""
        if team == "":
            continue
        cleaned.append((team, cells))

    seen = set()
    deduped = []
    for team, cells in cleaned:
        if team in seen:
            continue
        seen.add(team)
        deduped.append((team, cells))

    # Sort by name ascending as strings (stable)
    def sort_key(pair):
        team, cells = pair
        if name_idx is not None and name_idx < len(cells):
            return cells[name_idx]
        return ""
    deduped.sort(key=sort_key)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(cells for _, cells in deduped)
    return out.getvalue()
