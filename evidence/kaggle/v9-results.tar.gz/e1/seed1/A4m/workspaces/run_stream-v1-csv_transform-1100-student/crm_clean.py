import csv
import io


def dedupe_export(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    
    # Process header: strip whitespace from all columns
    header = [c.strip() for c in rows[0]]
    
    # Find indices for 'email' and 'score' columns
    try:
        email_idx = header.index('email')
    except ValueError:
        return ""  # No email column, cannot proceed
    
    try:
        score_idx = header.index('score')
    except ValueError:
        score_idx = None
    
    # Process data rows
    cleaned = []
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        
        # Ensure row has enough columns
        if len(cells) < email_idx + 1:
            continue
            
        # Check if score is empty (drop such rows)
        if score_idx is not None and score_idx < len(cells):
            if cells[score_idx] == "":
                continue
        
        # Lower-case the email column
        if email_idx < len(cells):
            cells[email_idx] = cells[email_idx].lower()
        
        cleaned.append(cells)
    
    # Remove duplicates by email, keeping first occurrence
    seen = set()
    deduped = []
    for cells in cleaned:
        if cells[email_idx] in seen:
            continue
        seen.add(cells[email_idx])
        deduped.append(cells)
    
    # Sort by score ascending as strings (stable sort)
    # Need to handle cases where score might be empty or non-numeric
    def sort_key(cell):
        score_val = cell[score_idx] if score_idx is not None and score_idx < len(cell) else ""
        return score_val
    
    deduped.sort(key=sort_key)
    
    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(deduped)
    
    return out.getvalue()
