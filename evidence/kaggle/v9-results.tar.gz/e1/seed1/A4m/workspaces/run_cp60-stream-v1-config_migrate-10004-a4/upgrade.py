def migrate(cfg):
    """Migrate a v1 config dict to v2. Return a new dict and do not modify the input.
    Raise ValueError unless cfg.get("version") == 1. The output has "version": 2.
    Rename top-level keys "pwd_file" -> "password_file", "user" -> "username".
    Move "cache_size" and "workers" into a sub-dict "network" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keep other keys unchanged and drop keys whose value is None.
    """
    # Check version
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1, got version " + str(cfg.get("version")))

    # Make a copy to avoid modifying input
    new_cfg = dict(cfg)

    # Rename keys
    if "pwd_file" in new_cfg:
        new_cfg["password_file"] = new_cfg.pop("pwd_file")
    if "user" in new_cfg:
        new_cfg["username"] = new_cfg.pop("user")

    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in new_cfg:
        network["cache_size"] = new_cfg.pop("cache_size")
    if "workers" in new_cfg:
        network["workers"] = new_cfg.pop("workers")

    # Ensure network is always present
    new_cfg["network"] = network

    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in new_cfg:
        new_cfg["timeout_s"] = new_cfg["timeout_ms"] / 1000.0
        new_cfg.pop("timeout_ms", None)

    # Drop keys whose value is None
    keys_to_drop = [k for k, v in new_cfg.items() if v is None]
    for k in keys_to_drop:
        del new_cfg[k]

    return new_cfg
