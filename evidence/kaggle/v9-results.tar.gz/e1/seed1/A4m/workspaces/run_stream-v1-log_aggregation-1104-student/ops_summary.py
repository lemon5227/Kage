def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns a dictionary {name: count} per level, with level names in uppercase.
    Malformed input lines are dropped.
    """
    counts = {}
    for line in lines:
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Malformed: need at least timestamp, level, and service
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, store as uppercase
        rest = ' '.join(parts[2:])
        
        # Check if the format is correct: <service>: <message>
        # The service should be followed by a colon
        if not rest.startswith(':'):
            # Malformed: expected service: message format
            continue
        
        # Extract service name (everything before the colon)
        service_part = rest.split(':', 1)[0]
        if not service_part.strip():
            # Malformed: empty service name
            continue
        
        # Count by level (service name is the key)
        counts[service_part.strip()] = counts.get(service_part.strip(), 0) + 1
    
    return counts
