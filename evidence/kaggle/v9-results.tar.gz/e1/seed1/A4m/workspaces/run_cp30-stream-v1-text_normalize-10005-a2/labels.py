import unicodedata

def to_key(text):
    """Normalize text into a key identifier."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    last_was_alnum = False
    for char in lowercased:
        if char.isalnum():  # a-z and 0-9
            result.append(char)
            last_was_alnum = True
        else:
            if not last_was_alnum:
                result.append('_')
                last_was_alnum = False
    
    # Strip leading and trailing "_"
    key = ''.join(result).strip('_')
    
    return key
