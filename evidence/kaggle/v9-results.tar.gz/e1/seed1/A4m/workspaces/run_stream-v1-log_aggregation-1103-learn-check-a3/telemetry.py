def summarize(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        level = level.upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
