def merge_slots(intervals):
    """Merge overlapping intervals where each interval is a dict {"from": s, "to": e}.
    
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals (end == next start) are merged.
    Raises ValueError if any interval has start > end.
    """
    # Convert dicts to tuples for sorting and merging
    normalized = []
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(f'invalid interval: start {start} > end {end}')
        normalized.append((start, end))
    
    # Sort by start, then by end
    normalized.sort(key=lambda pair: (pair[0], pair[1]))
    
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))
    
    # Convert back to dicts
    result = []
    for start, end in merged:
        result.append({"from": start, "to": end})
    
    return result
