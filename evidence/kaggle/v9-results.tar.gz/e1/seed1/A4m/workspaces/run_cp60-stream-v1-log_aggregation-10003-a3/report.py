def aggregate_log(lines):
    counts = {}
    allowed = set(['ERROR', 'WARN'])
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in allowed:
            continue
        rest = line.split(None, 2)[2]
        if ":" not in rest:
            continue
        service = rest.split(":", 1)[0].strip()
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
