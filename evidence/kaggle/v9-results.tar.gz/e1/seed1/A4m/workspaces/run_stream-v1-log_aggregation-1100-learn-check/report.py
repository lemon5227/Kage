def tally_events(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        _ts, lvl, rest = parts[0], parts[1], parts[2]
        if ":" not in rest:
            continue
        service = rest.split(":", 1)[0].strip()
        if not service:
            continue
        if lvl.upper() != 'WARN':
            continue
        service = service.upper()
        counts[service] = counts.get(service, 0) + 1
    return counts
