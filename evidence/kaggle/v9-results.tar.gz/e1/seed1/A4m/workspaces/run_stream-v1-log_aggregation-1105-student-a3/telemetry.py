def summarize(lines):
    """Summarize log lines into a dict mapping service to count for ERROR and WARN levels."""
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least 3 fields: timestamp, level, service
        if len(parts) < 3:
            continue
        # Check that the service field (index 2) ends with ':'
        if len(parts) > 2 and not parts[2].endswith(':'):
            continue
        level = parts[1].upper()
        service = parts[2]
        # Only count ERROR and WARN levels
        if level not in ('ERROR', 'WARN'):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
