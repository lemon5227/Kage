def coalesce(intervals):
    """Combine overlapping time ranges.
    
    Args:
        intervals: List of two-element lists [start, end] of integers.
        
    Returns:
        List of merged intervals sorted by start ascending.
        
    Raises:
        ValueError: If any interval has start > end.
    """
    # Validate all intervals
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Interval [{start}, {end}] has start > end")
    
    # Sort by start first
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            # Only merge if there is an overlap (end > last_end)
            # Touching intervals (end == last_end) do NOT merge
            if end > last_end:
                merged[-1][1] = end
            else:
                merged.append([start, end])
    
    return merged
