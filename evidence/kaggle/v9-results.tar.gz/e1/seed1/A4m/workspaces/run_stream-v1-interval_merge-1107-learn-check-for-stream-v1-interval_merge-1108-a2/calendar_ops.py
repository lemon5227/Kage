def combine_ranges(intervals):
    normalized = []
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError('invalid interval: start %r > end %r' % (start, end))
        normalized.append([start, end])
    normalized.sort(key=lambda pair: (pair[0], pair[1]))
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    return merged
