def tally_events(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        # Check level is WARN (case-insensitive)
        if parts[1].upper() != "WARN":
            continue
        key = parts[2]
        if not key:
            continue
        counts[key] = counts.get(key, 0) + 1
    return counts
