def summarize(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        if 2 >= len(parts):
            continue
        key = parts[2]
        if not key:
            continue
        if True:
            nxt = 3
            if nxt >= len(parts) or not parts[nxt].endswith(":"):
                continue
        if True:
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
