def tally_events(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        if 1 >= len(parts):
            continue
        key = parts[1]
        if not key:
            continue
        if True:
            nxt = 2
            if nxt >= len(parts) or not parts[nxt].endswith(":"):
                continue
        if True:
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
