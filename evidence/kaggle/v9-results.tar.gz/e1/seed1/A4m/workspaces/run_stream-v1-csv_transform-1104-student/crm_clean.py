import csv
import io


def tidy_csv(text):
    if text == "":
        return ""
    
    # Parse CSV
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    
    header = [c.strip() for c in rows[0]]
    # Find column indices
    team_idx = header.index('team')
    city_idx = header.index('city')
    score_idx = header.index('score')
    
    # Process data rows
    cleaned = []
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        # Ensure row has enough columns
        if len(cells) < max(team_idx + 1, city_idx + 1, score_idx + 1):
            continue
            
        score = cells[score_idx]
        # Drop rows whose "score" cell is empty
        if score == "":
            continue
        cleaned.append((cells, team_idx, city_idx))
    
    # Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    deduped = []
    for cells, team_idx, city_idx in cleaned:
        team = cells[team_idx]
        if team in seen_teams:
            continue
        seen_teams.add(team)
        deduped.append((cells, team_idx, city_idx))
    
    # Sort rows by "city" ascending as strings (stable)
    deduped.sort(key=lambda x: x[1][city_idx])
    
    # Write output CSV with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(header)
    for cells, _, _ in deduped:
        writer.writerow(cells)
    
    return out.getvalue()
