def tally_events(lines):
    """Tally log lines formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns a dict mapping each service for levels WARN only to how many lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines.
    Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip malformed lines
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Check if level is WARN (case-insensitive)
        if level == 'WARN':
            counts[service] = counts.get(service, 0) + 1
    
    # Omit keys with zero count (already handled by not adding them)
    return counts
