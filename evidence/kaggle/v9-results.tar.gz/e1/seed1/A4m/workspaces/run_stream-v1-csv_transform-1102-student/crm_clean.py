import csv
import io


def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    
    # Find column indices
    try:
        id_idx = header.index('id')
    except ValueError:
        return ""  # No id column, can't deduplicate
    
    try:
        name_idx = header.index('name')
    except ValueError:
        name_idx = None
    
    try:
        email_idx = header.index('email')
    except ValueError:
        email_idx = None
    
    cleaned = []
    for row in rows[1:]:
        cells = [c.strip() for c in row]
        
        # Skip if key (id) is empty
        if id_idx is not None and id_idx < len(cells):
            key = cells[id_idx]
            if key == "":
                continue
        
        # Skip if name is empty
        if name_idx is not None and name_idx < len(cells):
            name = cells[name_idx]
            if name == "":
                continue
        
        # Lower-case the email column
        if email_idx is not None and email_idx < len(cells):
            cells[email_idx] = cells[email_idx].lower()
        
        cleaned.append((key, cells))
    
    # Remove duplicates by id, keeping first occurrence
    seen = set()
    deduped = []
    for key, cells in cleaned:
        if key in seen:
            continue
        seen.add(key)
        deduped.append((key, cells))
    
    # Sort by id ascending as strings (stable)
    deduped.sort(key=lambda pair: pair[0])
    
    # Write output with csv module using '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(cells for _, cells in deduped)
    
    return out.getvalue()
