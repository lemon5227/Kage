import csv
import io

def dedupe_export(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = []
    for row in rows[1:]:
        row = [c.strip() for c in row]
        if len(row) < len(header):
            row += [""] * (len(header) - len(row))
        data.append(row)
    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None
    di = idx('name')
    if di is not None:
        data = [r for r in data if r[di] != ""]
    li = idx('email')
    if li is not None:
        for r in data:
            r[li] = r[li].lower()
    ki = idx('team')
    if ki is not None:
        seen = set()
        out = []
        for r in data:
            if r[ki] in seen:
                continue
            seen.add(r[ki])
            out.append(r)
        data = out
    si = idx('id')
    if si is not None:
        data.sort(key=lambda r: r[si])
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\n')
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
