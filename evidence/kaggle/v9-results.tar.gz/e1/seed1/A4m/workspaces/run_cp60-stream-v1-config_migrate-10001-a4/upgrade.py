def convert_settings(cfg):
    """Convert old configuration dict to v2 layout.

    - Raise ValueError unless cfg.get("version") == 1.
    - Output has "version": 2.
    - Rename top-level keys:
        "host" -> "hostname"
        "max_conn" -> "max_connections"
        "pwd_file" -> "password_file"
    - Move "port" and "retries" into a sub-dict "storage" (always present, possibly empty).
    - If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    - Keep other keys unchanged and drop keys whose value is None.
    """
    # Check version
    version = cfg.get("version")
    if version != 1:
        raise ValueError("Expected configuration version 1, got %r" % version)

    # Build new dict
    result = {"version": 2}

    # Rename top-level keys
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]

    # Move port and retries into storage
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "retries" in cfg:
        storage["retries"] = cfg["retries"]
    result["storage"] = storage

    # Handle timeout_ms
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged, but drop keys whose value is None
    for key, value in cfg.items():
        if key not in ("host", "max_conn", "pwd_file", "port", "retries", "timeout_ms", "version"):
            if value is not None:
                result[key] = value

    return result
