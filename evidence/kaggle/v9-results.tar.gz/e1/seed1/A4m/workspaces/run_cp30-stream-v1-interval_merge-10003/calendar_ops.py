def merge_slots(intervals):
    """Merge overlapping time ranges from a list of dicts with 'start' and 'end' keys.
    
    Args:
        intervals: List of dicts {"start": s, "end": e} with integer values.
    
    Returns:
        List of merged dicts {"start": s, "end": e}, sorted by start ascending.
    
    Raises:
        ValueError: If any interval has start > end.
    """
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError('invalid interval: start %r > end %r' % (start, end))
        normalized.append([start, end])
    
    # Sort by start, then by end
    normalized.sort(key=lambda pair: (pair[0], pair[1]))
    
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    
    # Convert back to dicts with 'start' and 'end' keys
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})
    
    return result
