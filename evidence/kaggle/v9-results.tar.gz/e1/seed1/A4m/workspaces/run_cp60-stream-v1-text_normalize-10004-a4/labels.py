import unicodedata

def label_id(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    prev_char_is_alnum = False
    for char in lowercased:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            slug.append(char)
            prev_char_is_alnum = True
        else:
            if not prev_char_is_alnum:
                slug.append('-')
                prev_char_is_alnum = False
    
    result = ''.join(slug)
    
    # Strip leading and trailing "-"
    result = result.strip('-')
    
    return result
