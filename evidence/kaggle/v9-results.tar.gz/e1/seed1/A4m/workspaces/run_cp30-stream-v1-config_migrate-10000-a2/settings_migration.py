def upgrade_config(cfg):
    """Upgrade old configuration dict to v2 layout."""
    # Check version
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1 configuration")
    
    # Create new config with version 2
    new_cfg = {"version": 2}
    
    # Rename top-level keys
    if "max_conn" in cfg:
        new_cfg["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        new_cfg["directory"] = cfg["dir"]
    if "host" in cfg:
        new_cfg["hostname"] = cfg["host"]
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Move cache_size and region into limits sub-dict
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    new_cfg["limits"] = limits
    
    # Keep other keys unchanged
    for key, value in cfg.items():
        if key not in ["max_conn", "dir", "host", "timeout_ms", "cache_size", "region", "version"]:
            new_cfg[key] = value
    
    # Drop keys whose value is None
    for key in list(new_cfg.keys()):
        if new_cfg[key] is None:
            del new_cfg[key]
    
    return new_cfg
