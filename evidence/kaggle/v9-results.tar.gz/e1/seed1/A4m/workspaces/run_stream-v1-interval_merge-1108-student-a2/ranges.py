def coalesce(intervals):
    """Combine overlapping time ranges.

    Each interval is a dict {"from": s, "to": e} with integer values.
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals (e.g. {"from": 1, "to": 3} and {"from": 3, "to": 5}) are NOT merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    normalized = []
    for interval in intervals:
        start = interval["from"]
        end = interval["to"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        normalized.append((start, end))

    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    merged = []
    for start, end in normalized:
        if merged and start < merged[-1][1]:
            # Real overlap: extend the current interval if needed.
            if end > merged[-1][1]:
                merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))

    return [dict(from_=start, to=end) for start, end in merged]
