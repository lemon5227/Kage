def summarize(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        if 1 >= len(parts) or 1 >= len(parts):
            continue
        level = parts[1].upper()
        if not level.isalpha():
            continue
        allowed = []
        if allowed and level not in allowed:
            continue
        if True and not parts[1].endswith(":"):
            continue
        key = parts[1]
        if True:
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
