def combine_ranges(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"begin": s, "finish": e} with integer values.
    Returns merged intervals as dicts with the same "begin"/"finish" keys,
    sorted by start ascending. Touching intervals (e.g., [1,3] and [3,5])
    are merged. Raises ValueError if any interval has begin > finish.
    The input is not modified.
    """
    # Convert dicts to tuples for processing
    normalized = []
    for interval in intervals:
        begin = interval["begin"]
        finish = interval["finish"]
        if begin > finish:
            raise ValueError(
                "invalid interval: begin %r > finish %r" % (begin, finish)
            )
        normalized.append((begin, finish))

    # Sort by begin, then by finish
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    merged = []
    for begin, finish in normalized:
        if merged and begin < merged[-1][1]:
            # Real overlap: extend the current interval if needed.
            if finish > merged[-1][1]:
                merged[-1] = (merged[-1][0], finish)
        else:
            # Touching intervals are merged: begin == merged[-1][1] also merges.
            merged.append((begin, finish))

    # Convert back to dicts
    result = []
    for begin, finish in merged:
        result.append({"begin": begin, "finish": finish})

    return result
