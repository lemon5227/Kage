import unicodedata


def slugify(text):
    """
    Build a URL slug from text.
    
    - Apply unicodedata NFKD normalization
    - Drop non-ASCII characters
    - Lower-case
    - Replace every run of characters outside [a-z0-9] with a single "-"
    - Strip leading and trailing "-"
    - Raise TypeError for non-string input
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we want to keep only alphanumeric characters and replace other runs with a single hyphen
    slug = []
    previous_char = None
    for char in lower_text:
        if char.isalnum():  # a-z0-9
            slug.append(char)
        else:
            if previous_char is not None:
                # We're starting a new run of non-alphanumeric characters
                slug.append('-')
            previous_char = char
    
    result = ''.join(slug)
    
    # Strip leading and trailing "-"
    result = result.strip('-')
    
    return result
