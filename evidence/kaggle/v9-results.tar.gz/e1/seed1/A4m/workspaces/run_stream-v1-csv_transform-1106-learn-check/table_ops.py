import csv
import io


def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = rows[1:]
    cleaned = []
    for row in data:
        row = [c.strip() for c in row]
        if len(row) < len(header):
            row = row + [""] * (len(header) - len(row))
        cleaned.append(row)
    try:
        fi = header.index('team')
    except ValueError:
        fi = None
    if fi is not None:
        cleaned = [r for r in cleaned if r[fi] != ""]
    try:
        di = header.index('id')
    except ValueError:
        di = None
    if di is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            k = r[di]
            if k in seen:
                continue
            seen.add(k)
            deduped.append(r)
        cleaned = deduped
    try:
        si = header.index('city')
    except ValueError:
        si = None
    if si is not None:
        cleaned.sort(key=lambda r: r[si])
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    w.writerows(cleaned)
    return out.getvalue()
