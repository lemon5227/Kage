def coalesce(intervals):
    """Merge overlapping or touching intervals.

    Each interval is a two-element list [start, end] of integers.
    Returns a list of merged intervals sorted by start ascending.
    Touching intervals like [1,3] and [3,5] are merged into [1,5].
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and normalize intervals
    if not intervals:
        return []

    # Check for invalid intervals and sort by start
    valid_intervals = []
    for interval in intervals:
        start, end = interval
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
        valid_intervals.append(interval)

    # Sort by start (and by end for stability)
    valid_intervals.sort(key=lambda x: (x[0], x[1]))

    # Merge intervals
    merged = []
    if not valid_intervals:
        return []

    current_start, current_end = valid_intervals[0]

    for next_interval in valid_intervals[1:]:
        next_start, next_end = next_interval
        # If the next interval starts at or before the current end, they overlap or touch
        if next_start <= current_end:
            # Merge by extending the end if needed
            current_end = max(current_end, next_end)
        else:
            # No overlap, push current and start new
            merged.append([current_start, current_end])
            current_start, current_end = next_start, next_end

    # Add the last interval
    merged.append([current_start, current_end])

    return merged
