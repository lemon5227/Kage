import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "name" cell is empty
    try:
        name_idx = header.index("name")
    except ValueError:
        name_idx = None

    if name_idx is not None:
        cleaned = [r for r in cleaned if name_idx < len(r) and r[name_idx] != ""]

    # remove duplicate rows by "name", keeping the first occurrence
    if name_idx is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            key = r[name_idx] if name_idx < len(r) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(r)
        cleaned = deduped

    # sort rows by "city" ascending as strings (stable)
    try:
        city_idx = header.index("city")
    except ValueError:
        city_idx = None

    if city_idx is not None:
        cleaned.sort(key=lambda r: r[city_idx] if city_idx < len(r) else "", stable=True)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        print(tidy_csv(sys.argv[1]))
