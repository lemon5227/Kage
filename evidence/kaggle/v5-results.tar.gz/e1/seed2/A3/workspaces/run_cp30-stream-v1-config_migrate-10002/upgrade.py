def upgrade_config(cfg):
    """Convert old configuration dict to v2 layout.
    
    Raises ValueError if cfg.get("version") != 1.
    Returns a new dict with version: 2 and updated keys.
    """
    # Check version
    version = cfg.get("version")
    if version != 1:
        raise ValueError("Configuration must have version 1")
    
    # Make a copy to avoid modifying input
    result = {}
    result["version"] = 2
    
    # Process top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    
    # Handle other keys - keep them unchanged but drop None values
    for key, value in cfg.items():
        if key not in ["dir", "pwd_file", "max_conn", "version"]:
            if value is not None:
                result[key] = value
    
    # Handle network sub-dict
    if "region" in cfg or "retries" in cfg:
        network = {}
        if "region" in cfg:
            network["region"] = cfg["region"]
        if "retries" in cfg:
            network["retries"] = cfg["retries"]
        result["network"] = network
    
    return result
