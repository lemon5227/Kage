def merge_slots(intervals):
    """Merge overlapping intervals.

    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals in the same [start, end] list form,
    sorted by start ascending. Touching intervals like [1,3] and [3,5]
    are NOT merged; only real overlaps merge.

    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start, end = interval
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")

    if len(intervals) == 0:
        return []

    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])

    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start < last_end:  # Real overlap (touching is not overlap)
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])

    return merged
