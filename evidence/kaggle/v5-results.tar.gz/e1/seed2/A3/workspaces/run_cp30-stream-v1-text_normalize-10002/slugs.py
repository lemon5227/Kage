def slugify(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization to decompose characters
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    prev_char = None
    for char in lower_text:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char != '-':
                slug.append('-')
                prev_char = '-'
        else:
            prev_char = char
            slug.append(char)
    
    # Strip leading and trailing "-"
    slug = slug.lstrip('-').rstrip('-')
    
    return ''.join(slug)
