def summarize(lines):
    """
    Process log lines in format: <timestamp> <LEVEL> <service>: <message>
    Returns a dict mapping services with WARN level to their line counts.
    """
    warn_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Extract level (case-insensitive)
        level = parts[1].upper()
        
        # Check if it's WARN level
        if level != 'WARN':
            continue
        
        # Extract service name (parts[2])
        service = parts[2]
        
        # Count the line for this service
        warn_counts[service] = warn_counts.get(service, 0) + 1
    
    return warn_counts
