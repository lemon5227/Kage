def make_handle(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace sequences of non-alphanumeric chars with a single hyphen
    slug = []
    prev_char = None
    for char in lower_text:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char != '-':
                slug.append('-')
                prev_char = '-'
        else:
            prev_char = char
    
    result = ''.join(slug)
    
    # Strip leading and trailing "-"
    result = result.strip('-')
    
    return result
