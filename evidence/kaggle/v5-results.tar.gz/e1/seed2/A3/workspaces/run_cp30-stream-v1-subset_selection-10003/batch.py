def pick_jobs(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "size" and a non-negative integer "score".  Returns the sorted list
    of ids whose total score is as large as possible while the total
    size stays <= capacity.  Ties on total score are broken by choosing
    the lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on a copy so the input is never modified.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("size must be positive")
        entries.append((item["id"], size, score))

    n = len(entries)
    if n == 0:
        return []

    # Sort by id so that we can reason about lexicographic tie-breaking.
    entries.sort(key=lambda e: e[0])

    # dp[w] = best (score, chosen_ids) achievable with size exactly <= w.
    # We track the chosen id list to resolve ties lexicographically.
    # Using a dict keyed by weight for the best value, plus the id list.
    NEG = None
    dp = [None] * (capacity + 1)  # dp[w] = (score, tuple_of_ids) or None
    dp[0] = (0, ())

    for idx in range(n):
        item_id, size, score = entries[idx]
        # Iterate sizes descending for 0/1 knapsack.
        for w in range(capacity, size - 1, -1):
            prev = dp[w - size]
            if prev is None:
                continue
            cand_score = prev[0] + score
            cand_ids = prev[1] + (item_id,)
            cur = dp[w]
            if cur is None or cand_score > cur[0]:
                dp[w] = (cand_score, cand_ids)
            elif cand_score == cur[0]:
                # Tie on score: prefer lexicographically smallest sorted id list.
                if sorted(cand_ids) < sorted(cur[1]):
                    dp[w] = (cand_score, cand_ids)

    # Find the best score across all capacities, then the lexicographically
    # smallest sorted id list among those achieving it.
    best_score = None
    best_ids = None
    for w in range(capacity + 1):
        entry = dp[w]
        if entry is None:
            continue
        score, ids = entry
        sorted_ids = sorted(ids)
        if best_score is None or score > best_score:
            best_score = score
            best_ids = sorted_ids
        elif score == best_score:
            if sorted_ids < best_ids:
                best_ids = sorted_ids

    return best_ids if best_ids is not None else []
