def upgrade_config(cfg):
    """Upgrade old configuration dicts to the v2 layout.
    
    Args:
        cfg: dict with version 1 or other keys.
        
    Returns:
        New dict with version 2 layout.
        
    Raises:
        ValueError if cfg.get("version") != 1.
    """
    version = cfg.get("version")
    if version != 1:
        raise ValueError("Configuration must have version 1")
    
    # Make a copy to avoid modifying the input
    result = {}
    result["version"] = 2
    
    # Handle top-level keys
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    
    # Handle cache_size and region - move into limits sub-dict
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    result["limits"] = limits
    
    # Handle timeout_ms - convert to timeout_s
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["version", "max_conn", "dir", "host", "cache_size", "region", "timeout_ms"]:
            if value is not None:
                result[key] = value
    
    return result
