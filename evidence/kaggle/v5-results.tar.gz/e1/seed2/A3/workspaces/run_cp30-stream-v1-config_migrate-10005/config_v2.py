def convert_settings(cfg):
    """Convert old configuration dict to v2 layout.
    
    Raises ValueError if cfg.get("version") != 1.
    Returns a new dict with version: 2, renamed keys, and moved sub-dicts.
    """
    # Check version
    version = cfg.get("version")
    if version != 1:
        raise ValueError("cfg must have version == 1")
    
    # Make a copy to avoid modifying input
    result = {}
    result["version"] = 2
    
    # Rename top-level keys
    if "user" in cfg:
        result["username"] = cfg["user"]
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    
    # Move cache_size and retries into limits sub-dict
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "retries" in cfg:
        limits["retries"] = cfg["retries"]
    result["limits"] = limits
    
    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key in ["version", "user", "dir", "cache_size", "retries", "timeout_ms"]:
            continue
        if value is None:
            continue
        result[key] = value
    
    return result
