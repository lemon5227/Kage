def coalesce(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Touching intervals like [1,3] and [3,5]
    should be merged. Raises ValueError if any interval has start > end.
    Does not modify the input.

    Args:
        intervals: List of dicts with "start" and "end" keys.

    Returns:
        List of merged interval dicts sorted by start.

    Raises:
        ValueError: If any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")

    if not intervals:
        return []

    # Sort by start, then by end for deterministic ordering
    sorted_intervals = sorted(intervals, key=lambda i: (i["start"], i["end"]))

    merged = []
    current_start = sorted_intervals[0]["start"]
    current_end = sorted_intervals[0]["end"]

    for interval in sorted_intervals[1:]:
        start = interval["start"]
        end = interval["end"]

        # If intervals touch or overlap, merge them
        if start <= current_end:
            # Extend the current interval's end if needed
            if end > current_end:
                current_end = end
        else:
            # No overlap, push the current interval and start a new one
            merged.append({"start": current_start, "end": current_end})
            current_start = start
            current_end = end

    # Append the last interval
    merged.append({"start": current_start, "end": current_end})

    return merged
