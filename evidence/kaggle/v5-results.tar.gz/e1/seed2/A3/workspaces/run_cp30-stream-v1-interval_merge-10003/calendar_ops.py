def merge_slots(intervals):
    """Merge overlapping or touching time intervals.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns a list of merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Touching intervals like [1,3] and [3,5] are merged.

    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate and collect intervals
    validated = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
        validated.append((start, end))

    if not validated:
        return []

    # Sort by start time
    validated.sort(key=lambda x: x[0])

    merged = []
    current_start, current_end = validated[0]

    for next_start, next_end in validated[1:]:
        # If intervals overlap or touch (next_start <= current_end + 1? Actually touching means next_start == current_end)
        # The problem says "touching intervals like [1,3] and [3,5] should be merged."
        # So if next_start <= current_end, they can be merged.
        if next_start <= current_end:
            # Merge by extending the end if needed
            current_end = max(current_end, next_end)
        else:
            # No overlap, push current and start new
            merged.append({"start": current_start, "end": current_end})
            current_start, current_end = next_start, next_end

    # Add the last interval
    merged.append({"start": current_start, "end": current_end})

    return merged
