import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "name" cell is empty
    try:
        name_idx = header.index("name")
    except ValueError:
        name_idx = None

    if name_idx is not None:
        cleaned = [r for r in cleaned if name_idx < len(r) and r[name_idx] != ""]

    # lower-case the "email" column
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    if email_idx is not None:
        for r in cleaned:
            if email_idx < len(r):
                r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "name", keeping the first occurrence
    try:
        name_idx = header.index("name")
    except ValueError:
        name_idx = None

    if name_idx is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            key = r[name_idx] if name_idx < len(r) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(r)
        cleaned = deduped

    # sort rows by "email" ascending as strings (stable)
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    if email_idx is not None:
        cleaned.sort(key=lambda r: r[email_idx] if email_idx < len(r) else "", stable=True)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
