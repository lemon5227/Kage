def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns a dictionary {name: count} per service for levels ERROR and WARN only,
    treating level names case-insensitively (upper-case keys), dropping malformed input lines.
    """
    counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Check if it's ERROR or WARN
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Extract service (third part, after the colon)
        # Format: <timestamp> <LEVEL> <service>: <message>
        # The service is the third token, but we need to handle the colon
        # Let's check if there's a colon in the line
        if ':' not in parts[2]:
            continue
        
        # Find the service name - it's the part before the colon
        service_part = parts[2]
        if ':' not in service_part:
            continue
        
        service = service_part.split(':')[0].strip()
        
        # Increment count for this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
