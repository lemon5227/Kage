import unicodedata


def make_handle(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)

    # Drop non-ASCII characters
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    def replace_runs(s):
        result = []
        current_run = []
        for char in s:
            if char.isalnum():
                current_run.append(char)
            else:
                if current_run:
                    result.append(''.join(current_run))
                    current_run = []
                result.append('-')
        if current_run:
            result.append(''.join(current_run))
        return ''.join(result)

    replaced = replace_runs(lower)

    # Strip leading and trailing "-"
    stripped = stripped.lstrip('-').rstrip('-')

    # If the result is longer than 23 characters, cut it to 23 and then strip a trailing "-"
    if len(stripped) > 23:
        truncated = stripped[:23]
        truncated = truncated.rstrip('-')
    else:
        truncated = stripped

    return truncated
