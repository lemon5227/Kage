def merge_slots(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"from": s, "to": e} with integer values.
    Returns merged intervals as dicts with the same "from"/"to" keys,
    sorted by start ascending. Touching intervals like [1,3] and [3,5]
    should be merged. Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate and convert to a list of (start, end) tuples.
    original = []
    for interval in intervals:
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError("Interval start > end")
        original.append((s, e))

    # Sort by start time.
    original.sort()

    # Merge overlapping or touching intervals.
    merged = []
    if not original:
        return []

    start, end = original[0]
    for next_start, next_end in original[1:]:
        if next_start <= end + 1:  # Touching or overlapping
            end = max(end, next_end)
        else:
            merged.append((start, end))
            start, end = next_start, next_end
    merged.append((start, end))

    # Convert back to dicts.
    result = []
    for s, e in merged:
        result.append({"from": s, "to": e})

    return result
