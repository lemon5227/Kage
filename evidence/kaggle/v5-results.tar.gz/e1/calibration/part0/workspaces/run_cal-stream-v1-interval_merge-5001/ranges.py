def combine_ranges(intervals):
    """
    Combines overlapping time ranges. Each interval is a dict {"from": s, "to": e} with integer values.
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort intervals by start time
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping or touching intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            # Check if current interval overlaps or touches the last interval
            if interval["from"] <= last["to"]:
                # Merge by updating the last interval's end to the maximum of both ends
                last["to"] = max(last["to"], interval["to"])
            else:
                # No overlap, add the current interval
                merged.append(interval.copy())
    
    return merged
