def merge_bookings(intervals):
    # Validate intervals: start must not be greater than end
    for interval in intervals:
        if interval["begin"] > interval["finish"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by begin time
    sorted_intervals = sorted(intervals, key=lambda x: x["begin"])
    
    # Merge overlapping intervals
    merged = []
    if not sorted_intervals:
        return merged
    
    current = sorted_intervals[0].copy()
    
    for i in range(1, len(sorted_intervals)):
        next_interval = sorted_intervals[i]
        
        # Check for real overlap: current finish < next begin means no overlap
        # Overlap occurs when current finish >= next begin (but not equal if touching)
        # Actually, the requirement says touching intervals like [1,3] and [3,5] should NOT be merged
        # So we merge only when current finish > next begin (strictly greater)
        if current["finish"] > next_interval["begin"]:
            # Merge: update current's finish to max of both
            current["finish"] = max(current["finish"], next_interval["finish"])
        else:
            # No overlap, add current and move to next
            merged.append(current)
            current = next_interval.copy()
    
    # Add the last interval
    merged.append(current)
    
    return merged
