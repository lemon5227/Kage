def merge_slots(intervals):
    # Validate all intervals first
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        if interval["from"] > interval["to"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start (from)
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            # Check if current interval overlaps with the last one
            # Overlap means: current["from"] < last["to"]
            if interval["from"] < last["to"]:
                # Merge by updating the last interval's end to max
                last["to"] = max(last["to"], interval["to"])
            else:
                merged.append(interval.copy())
    
    return merged
