def allocate(items, capacity):
    """
    Select projects under a capacity limit to maximize total score.
    
    Args:
        items: List of dicts with keys 'id', 'size', 'score'
        capacity: Maximum total size allowed
    
    Returns:
        Sorted list of ids of selected items
    
    Raises:
        ValueError: If capacity is negative or any item has size <= 0
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "id" not in item or "size" not in item or "score" not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if not isinstance(item["id"], str):
            raise ValueError("Item id must be a string")
        if item["size"] <= 0:
            raise ValueError("Item size must be positive")
        if not isinstance(item["score"], int) or item["score"] < 0:
            raise ValueError("Item score must be a non-negative integer")
    
    if not items:
        return []
    
    n = len(items)
    
    # dp[i][w] = (max_score, selected_ids) for first i items with total size <= w
    # We'll store the best (score, id_list) for each capacity
    # Since we need lexicographically smallest id list on tie, we need to be careful
    
    # Initialize: dp[w] = (max_score, best_id_list) for capacity w
    dp = [(0, []) for _ in range(capacity + 1)]
    
    for i in range(n):
        item = items[i]
        size = item["size"]
        score = item["score"]
        item_id = item["id"]
        
        # Iterate backwards to avoid using the same item multiple times
        for w in range(capacity, size - 1, -1):
            # Option 1: Don't include this item
            score1, ids1 = dp[w]
            
            # Option 2: Include this item (if we have enough capacity)
            score2, ids2 = dp[w - size]
            new_score = score2 + score
            new_ids = ids2 + [item_id]
            
            # Choose the better option: higher score, or same score with lexicographically smaller id list
            if new_score > score1:
                dp[w] = (new_score, new_ids)
            elif new_score == score1:
                # Compare lexicographically
                if new_ids < ids1:
                    dp[w] = (new_score, new_ids)
    
    # Find the maximum score across all capacities
    max_score = 0
    best_ids = []
    for w in range(capacity + 1):
        score, ids = dp[w]
        if score > max_score:
            max_score = score
            best_ids = ids
    
    # Return sorted list of ids
    return sorted(best_ids)
