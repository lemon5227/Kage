def to_v2(cfg):
    # Raise ValueError if version is not 1
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1, got: " + str(cfg.get("version")))
    
    # Create new dict with version 2
    new_cfg = {"version": 2}
    
    # Process keys
    # Rename top-level keys
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    if "host" in cfg:
        new_cfg["hostname"] = cfg["host"]
    
    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    new_cfg["network"] = network
    
    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["version", "pwd_file", "host", "cache_size", "workers", "timeout_ms"]:
            if value is not None:
                new_cfg[key] = value
    
    return new_cfg
