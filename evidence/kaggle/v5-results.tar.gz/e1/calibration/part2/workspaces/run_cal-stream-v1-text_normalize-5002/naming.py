import unicodedata
import re

def make_handle(text):
    """Turn a title into a handle according to specified rules."""
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply unicodedata NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = re.sub(r'[^a-z0-9]+', '_', lowercased)
    
    # Strip leading and trailing "_"
    result = result.strip('_')
    
    # If the result is longer than 23 characters, cut it to 23 and then strip a trailing "_"
    if len(result) > 23:
        result = result[:23]
        result = result.rstrip('_')
    
    return result
