def convert_settings(cfg):
    # Check version
    if cfg.get("version") != 1:
        raise ValueError("Only v1 config is supported for migration")
    
    # Create new dict
    new_cfg = {}
    
    # Set version to 2
    new_cfg["version"] = 2
    
    # Process keys
    if "host" in cfg:
        new_cfg["hostname"] = cfg["host"]
    
    if "dir" in cfg:
        new_cfg["directory"] = cfg["dir"]
    
    # Move cache_size and retries into limits
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "retries" in cfg:
        limits["retries"] = cfg["retries"]
    new_cfg["limits"] = limits
    
    # Handle timeout_ms
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Keep other keys unchanged (but drop None values)
    for key, value in cfg.items():
        if key not in ["host", "dir", "cache_size", "retries", "timeout_ms"] and value is not None:
            new_cfg[key] = value
    
    return new_cfg
