#!/usr/bin/env python3
from naming import make_handle

# Test cases
test_cases = [
    ("John Doe", "john doe"),
    ("José García", "jose garcia"),  # NFKD normalization + ASCII only
    ("Test@123!", "test123"),
    ("   Leading and trailing   ", "leadingandtrailing"),
    ("A" * 15, "a" * 12),  # Should be cut to 12
    ("A" * 20, "a" * 12),  # Should be cut to 12
    (None, None),  # Should raise TypeError
    (123, None),  # Should raise TypeError
]

print("Testing make_handle function:")
for input_val, expected in test_cases:
    try:
        result = make_handle(input_val) if input_val is not None else None
        status = "PASS" if result == expected else f"FAIL (got {result})"
        print(f"Input: {repr(input_val)} -> Output: {repr(result)} [{status}]")
    except Exception as e:
        if expected is None:
            print(f"Input: {repr(input_val)} -> Exception: {e} [PASS]")
        else:
            print(f"Input: {repr(input_val)} -> Unexpected exception: {e} [FAIL]")
