def make_handle(text):
    """Turn a title into a handle according to specified rules."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                result.append('_')
            prev_char = char
        else:
            prev_char = char
    
    handle = ''.join(result)
    
    # Strip leading and trailing "_"
    handle = handle.strip('_')
    
    # If result is longer than 12 characters, cut to 12 and then strip a trailing "_"
    if len(handle) > 12:
        handle = handle[:12].strip('_')
    
    return handle
