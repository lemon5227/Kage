def upgrade_config(cfg):
    """Upgrade old configuration dicts to the v2 layout."""
    # Raise ValueError if version is not 1
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")
    
    # Create a new dict for the upgraded configuration
    new_cfg = {
        "version": 2,
        "username": cfg.get("user"),
        "max_connections": cfg.get("max_conn"),
        "directory": cfg.get("dir"),
        "network": {}
    }
    
    # Add region and workers to network if they exist
    if "region" in cfg:
        new_cfg["network"]["region"] = cfg["region"]
    if "workers" in cfg:
        new_cfg["network"]["workers"] = cfg["workers"]
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged
    for key in cfg:
        if key not in ["user", "max_conn", "dir", "region", "workers", "timeout_ms"]:
            # Only keep keys with non-None values
            if cfg[key] is not None:
                new_cfg[key] = cfg[key]
    
    return new_cfg
