def slugify(text):
    """Build a URL slug from text.
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with single '_', and strips
    leading/trailing underscores.
    
    Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    text = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    text = text.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    text = text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single '_'
    result = []
    prev_char = None
    for char in text:
        if not char.isalnum():
            if prev_char is not None:
                result.append('_')
        else:
            result.append(char)
        prev_char = char
    
    slug = ''.join(result)
    
    # Strip leading and trailing '_'
    slug = slug.strip('_')
    
    return slug
