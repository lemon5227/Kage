def normalize_table(text):
    """
    Normalize CSV text with header row (columns: id, name, city).
    
    Process:
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "id" cell is empty
    - Remove duplicate rows by "id", keeping the first occurrence
    - Sort rows by "city" ascending as strings (stable)
    
    Returns cleaned CSV text with same header, using '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    if not text or not text.strip():
        return ''
    
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Parse header
    header = lines[0].split(',')
    if len(header) != 3 or header[0] != 'id' or header[1] != 'name' or header[2] != 'city':
        return ''
    
    # Process data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) != 3:
            continue
        
        id_val, name_val, city_val = cells[0].strip(), cells[1].strip(), cells[2].strip()
        
        # Drop rows whose "id" cell is empty
        if not id_val:
            continue
        
        rows.append((id_val, name_val, city_val))
    
    # Remove duplicate rows by "id", keeping the first occurrence
    seen_ids = set()
    unique_rows = []
    for row in rows:
        if row[0] not in seen_ids:
            seen_ids.add(row[0])
            unique_rows.append(row)
    
    # Sort rows by "city" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x[2])
    
    # Build output CSV
    output_lines = [','.join(header)]
    for row in unique_rows:
        output_lines.append(','.join(row))
    
    return '\n'.join(output_lines)
