import csv
import io

def clean_rows(text):
    # Handle empty string
    if not text or not text.strip():
        return ''
    
    # Parse CSV text
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Check if first line is header
    header_line = lines[0].strip()
    # Expected header: id, team, name, score
    if not header_line.startswith('id,team,name,score'):
        # If it doesn't match expected format, try to parse as CSV
        pass
    
    # Parse header
    header_cells = [cell.strip() for cell in header_line.split(',')]
    
    # Parse data rows
    rows = []
    for i, line in enumerate(lines[1:], 1):
        if not line.strip():
            continue
        cells = [cell.strip() for cell in line.split(',')]
        if len(cells) < 4:
            continue
        row = {
            'id': cells[0],
            'team': cells[1],
            'name': cells[2],
            'score': cells[3]
        }
        # Drop rows whose "team" cell is empty
        if not row['team'].strip():
            continue
        rows.append(row)
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in rows:
        score = row['score'].strip()
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort rows by "score" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row['score'], stable=True)
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header_cells)
    
    # Write data rows
    for row in unique_rows:
        writer.writerow([row['id'], row['team'], row['name'], row['score']])
    
    return output.getvalue()
