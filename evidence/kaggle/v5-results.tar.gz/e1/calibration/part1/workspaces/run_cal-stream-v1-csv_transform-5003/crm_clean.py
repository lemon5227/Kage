import csv
import io

def normalize_table(text):
    """Clean an exported CSV table with specified transformations."""
    
    # Parse the input text into a list of lines
    lines = text.strip().split('\n')
    
    # Handle empty or header-only input
    if not lines:
        return ''
    
    # Extract header
    header = lines[0].strip()
    
    # Check if it's just a header (no data rows)
    if len(lines) == 1:
        return header
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        # Split by comma, but handle potential quoted fields
        parts = line.split(',')
        if len(parts) < 5:
            continue
        row = parts[:5]
        # Strip leading/trailing whitespace from every cell
        row = [cell.strip() for cell in row]
        rows.append(row)
    
    # Drop rows whose "email" cell is empty (index 4)
    cleaned_rows = []
    for row in rows:
        if row[4] == '':  # email is at index 4
            continue
        cleaned_rows.append(row)
    
    # Lower-case the "email" column (index 4)
    for row in cleaned_rows:
        row[4] = row[4].lower()
    
    # Remove duplicate rows by "city", keeping the first occurrence
    seen_cities = set()
    unique_rows = []
    for row in cleaned_rows:
        city = row[1]
        if city not in seen_cities:
            seen_cities.add(city)
            unique_rows.append(row)
    
    # Sort rows by "score" ascending as strings (stable)
    # Using string comparison for score
    unique_rows.sort(key=lambda row: row[0], reverse=False)
    
    # Build output CSV text with header and data rows
    output_lines = [header]
    for row in unique_rows:
        output_lines.append(','.join(row))
    
    # Join with '\n' line endings
    return '\n'.join(output_lines)

# Test the function
if __name__ == '__main__':
    # Example test
    test_input = """score,city,team,id,email
10,New York,Team A,1,user@example.com
5,Los Angeles,Team B,2,another@example.com
10,New York,Team A,3,duplicate@example.com
"""
    result = normalize_table(test_input)
    print(result)
