def summarize(lines):
    """
    Summarize log lines by service for WARN level only.
    
    Each line format: "<timestamp> <LEVEL> <service>: <message>"
    Returns a dict mapping each service (for WARN level) to count of lines.
    Levels are case-insensitive (reported as upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Only process WARN level
        if level != 'WARN':
            continue
        
        # Count this line for the service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
