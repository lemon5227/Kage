def aggregate_log(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service:
        if len(parts) < 3:
            continue
        
        # Extract level (second part) and upper-case it
        level = parts[1].upper()
        
        # Count the level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
