def aggregate_log(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    
    Returns a plain dict of counts.
    """
    level_counts = {}
    
    for line in lines:
        # Split the line into tokens
        parts = line.split()
        
        # Check if line has at least 3 parts (timestamp, level, service)
        if len(parts) < 3:
            continue
        
        # Extract the level (second token, index 1)
        level = parts[1].upper()
        
        # Only count if the level is not empty
        if level:
            level_counts[level] = level_counts.get(level, 0) + 1
    
    return level_counts
