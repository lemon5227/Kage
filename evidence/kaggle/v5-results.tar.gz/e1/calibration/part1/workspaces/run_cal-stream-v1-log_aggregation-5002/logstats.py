def aggregate_log(lines):
    """Aggregate log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per service for levels ERROR only, treating level names case-insensitively (upper-case keys), dropping malformed input lines.
    """
    service_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service:
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()  # Treat case-insensitively
        
        # Check if it's ERROR
        if level != "ERROR":
            continue
        
        # Extract service name (third part, before the colon)
        service_part = parts[2]
        
        # Validate that service part ends with colon
        if not service_part.endswith(':'):
            continue
        
        # Get service name
        service_name = service_part[:-1]
        
        # Count the service
        service_counts[service_name] = service_counts.get(service_name, 0) + 1
    
    return service_counts
