import csv
import io

def clean_rows(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with header row (columns: id, city, score, team, name)
    Output: Cleaned CSV text with the same header.
    """
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines and parse
    lines = text.strip().split('\n')
    
    # Check if header-only input
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    # Expected columns: id, city, score, team, name
    # Find indices
    try:
        id_idx = header.index('id')
        city_idx = header.index('city')
        score_idx = header.index('score')
        team_idx = header.index('team')
        name_idx = header.index('name')
    except ValueError as e:
        # If headers don't match, return empty or handle gracefully
        return ''
    
    # Process data rows
    rows = []
    seen_ids = set()
    
    for line in lines[1:]:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line
        cells = line.split(',')
        
        # Strip whitespace from each cell
        cells = [cell.strip() for cell in cells]
        
        # Check if city is empty, skip such rows
        if not cells[city_idx]:
            continue
        
        # Check for duplicate by id
        row_id = cells[id_idx]
        if row_id in seen_ids:
            continue
        seen_ids.add(row_id)
        
        # Store the row with indices
        rows.append((cells, id_idx, city_idx, score_idx, team_idx, name_idx))
    
    # Sort by team ascending as strings (stable sort)
    # We need to sort by the team column value
    sorted_rows = sorted(rows, key=lambda x: x[team_idx])
    
    # Build output CSV
    output_lines = [header]
    for cells, _, _, _, _, _ in sorted_rows:
        output_lines.append(','.join(cells))
    
    return '\n'.join(output_lines)
