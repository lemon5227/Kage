#!/usr/bin/env python3
from table_ops import clean_rows

# Test 1: Basic functionality
text1 = """id,city,score,team,name
1,New York,85,Team A,Player 1
2,Los Angeles,90,Team B,Player 2
3,New York,88,Team A,Player 3
4,,75,Team C,Player 4
5,Chicago,92,Team A,Player 5"""

result1 = clean_rows(text1)
print("Test 1:")
print(result1)
print()

# Test 2: Empty input
result2 = clean_rows('')
print("Test 2 (empty):")
print(repr(result2))
print()

# Test 3: Header-only input
text3 = "id,city,score,team,name"
result3 = clean_rows(text3)
print("Test 3 (header-only):")
print(result3)
print()

# Test 4: All duplicates
text4 = """id,city,score,team,name
1,New York,85,Team A,Player 1
1,Los Angeles,90,Team B,Player 2"""
result4 = clean_rows(text4)
print("Test 4 (duplicates):")
print(result4)
