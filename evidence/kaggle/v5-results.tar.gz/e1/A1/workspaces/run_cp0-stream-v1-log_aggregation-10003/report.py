def aggregate_log(lines):
    result = {}
    for line in lines:
        parts = line.strip().split()
        if len(parts) < 4:
            continue
        timestamp, level, service_part = parts[0], parts[1], parts[2]
        # Extract service name from "service: message"
        if ':' in service_part:
            service = service_part.split(':')[0]
        else:
            continue
        # Check if level is ERROR or WARN (case-insensitive)
        if level.upper() not in ('ERROR', 'WARN'):
            continue
        # Add to result with uppercase key
        result[service.upper()] = result.get(service.upper(), 0) + 1
    return result
