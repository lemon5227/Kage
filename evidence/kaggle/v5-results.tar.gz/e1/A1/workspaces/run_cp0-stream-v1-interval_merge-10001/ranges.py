def merge_slots(intervals):
    # Validate and sort intervals
    if not intervals:
        return []
    
    # Check for invalid intervals (start > end)
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        if interval["from"] > interval["to"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Convert to list of tuples for sorting
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals
    merged = []
    current_start = sorted_intervals[0]["from"]
    current_end = sorted_intervals[0]["to"]
    
    for interval in sorted_intervals[1:]:
        start = interval["from"]
        end = interval["to"]
        
        # If touching or overlapping, merge
        if start <= current_end:
            current_end = max(current_end, end)
        else:
            # No overlap, add current interval and start new one
            merged.append({"from": current_start, "to": current_end})
            current_start = start
            current_end = end
    
    # Add the last interval
    merged.append({"from": current_start, "to": current_end})
    
    return merged
