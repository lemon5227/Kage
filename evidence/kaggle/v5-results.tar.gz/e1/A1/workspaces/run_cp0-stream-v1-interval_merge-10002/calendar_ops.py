def coalesce(intervals):
    """Merge overlapping intervals. Each interval is a dict {"start": s, "end": e} with integer values.
    Return merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Raise ValueError if any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        if interval["start"] > interval["end"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping/touching intervals
    merged = []
    if not sorted_intervals:
        return merged
    
    current_start = sorted_intervals[0]["start"]
    current_end = sorted_intervals[0]["end"]
    
    for interval in sorted_intervals[1:]:
        start = interval["start"]
        end = interval["end"]
        
        # If intervals overlap or touch (current_end >= start - 1 means they can be merged)
        if current_end >= start - 1:
            # Merge them
            current_end = max(current_end, end)
        else:
            # No overlap, add current interval and start new one
            merged.append({"start": current_start, "end": current_end})
            current_start = start
            current_end = end
    
    # Add the last interval
    merged.append({"start": current_start, "end": current_end})
    
    return merged
