def convert_settings(cfg):
    # Check version requirement
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")
    
    # Create new dict with v2 layout
    result = {
        "version": 2,
        "username": cfg.get("user"),
        "directory": cfg.get("dir"),
        "limits": {}
    }
    
    # Handle cache_size and retries
    if "cache_size" in cfg:
        result["limits"]["cache_size"] = cfg["cache_size"]
    if "retries" in cfg:
        result["limits"]["retries"] = cfg["retries"]
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["user", "dir", "cache_size", "retries", "timeout_ms"]:
            if value is not None:
                result[key] = value
    
    return result
