def select_tasks(items, capacity):
    """
    Select tasks to maximize total score while keeping total size <= capacity.
    
    Args:
        items: List of dicts with keys 'id', 'size', 'score'
        capacity: Maximum total size allowed
    
    Returns:
        Sorted list of ids of selected tasks
    
    Raises:
        ValueError: If capacity is negative or any size is <= 0
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if 'size' not in item or 'score' not in item or 'id' not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if item['size'] <= 0:
            raise ValueError("Size must be positive")
    
    if not items:
        return []
    
    # Create a list of (id, size, score) tuples
    n = len(items)
    items_list = [(item['id'], item['size'], item['score']) for item in items]
    
    # Dynamic programming for 0/1 knapsack
    # dp[i][w] = maximum score using first i items with total size <= w
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        item_id, item_size, item_score = items_list[i - 1]
        for w in range(capacity + 1):
            # Don't include item i
            dp[i][w] = dp[i - 1][w]
            # Include item i if it fits
            if item_size <= w:
                dp[i][w] = max(dp[i][w], dp[i - 1][w - item_size] + item_score)
    
    # Reconstruct the solution
    selected_ids = []
    w = capacity
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i - 1][w]:
            # Item i was included
            selected_ids.append(items_list[i - 1][0])
            w -= items_list[i - 1][1]
    
    # Sort the selected ids lexicographically
    selected_ids.sort()
    
    return selected_ids
