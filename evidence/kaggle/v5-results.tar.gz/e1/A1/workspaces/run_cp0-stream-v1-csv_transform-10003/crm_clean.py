import csv
import io

def tidy_csv(text):
    """Clean an exported CSV table with header: name, city, score, team."""
    
    # Handle empty input
    if not text.strip():
        return ''
    
    # Split into lines and parse header
    lines = text.strip().split('\n')
    if not lines:
        return ''
    
    # Parse header
    header = lines[0].strip().split(',')
    if len(header) != 4 or header[0] != 'name' or header[1] != 'city' or header[2] != 'score' or header[3] != 'team':
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) != 4:
            continue
        name, city, score, team = cells
        
        # Strip leading/trailing whitespace from every cell
        name = name.strip()
        city = city.strip()
        score = score.strip()
        team = team.strip()
        
        # Drop rows whose "name" cell is empty
        if not name:
            continue
        
        rows.append((name, city, score, team))
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    unique_rows = []
    for row in rows:
        if row[0] not in seen:
            seen.add(row[0])
            unique_rows.append(row)
    
    # Sort rows by "city" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
