def allocate(items, capacity):
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "cost" not in item or "gain" not in item or "id" not in item:
            raise ValueError("Each item must have 'id', 'cost', and 'gain' keys")
        if not isinstance(item["cost"], int) or item["cost"] <= 0:
            raise ValueError("Cost must be a positive integer")
        if not isinstance(item["gain"], int) or item["gain"] < 0:
            raise ValueError("Gain must be a non-negative integer")
    
    # Handle empty items list
    if not items:
        return []
    
    # Create a list of (cost, gain, id) tuples
    items_list = [(item["cost"], item["gain"], item["id"]) for item in items]
    
    # Use dynamic programming for 0/1 knapsack
    # dp[i][j] = maximum gain using first i items with capacity j
    n = len(items_list)
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        cost, gain, item_id = items_list[i - 1]
        for j in range(capacity + 1):
            # Don't include current item
            dp[i][j] = dp[i - 1][j]
            # Include current item if it fits
            if j >= cost:
                dp[i][j] = max(dp[i][j], dp[i - 1][j - cost] + gain)
    
    # Find the maximum gain achievable
    max_gain = dp[n][capacity]
    
    # Reconstruct the solution by backtracking
    selected_ids = []
    j = capacity
    for i in range(n, 0, -1):
        if dp[i][j] != dp[i - 1][j]:
            # This item was selected
            selected_ids.append(items_list[i - 1][2])
            j -= items_list[i - 1][0]
    
    # Sort the selected ids lexicographically
    selected_ids.sort()
    
    return selected_ids
