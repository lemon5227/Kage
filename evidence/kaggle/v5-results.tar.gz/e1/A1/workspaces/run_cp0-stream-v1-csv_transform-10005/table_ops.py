import csv
import io

def normalize_table(text):
    # Parse CSV text into a list of rows
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = []
    seen_emails = set()
    
    for row in rows[1:]:
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip if id is empty
        if not cleaned_row[0]:
            continue
        
        # Lower-case the email column (index 1)
        email = cleaned_row[1].lower()
        
        # Skip duplicate emails (keep first occurrence)
        if email in seen_emails:
            continue
        seen_emails.add(email)
        
        data_rows.append(cleaned_row)
    
    # Sort by email ascending as strings (stable)
    data_rows.sort(key=lambda row: row[1])
    
    # Write output using csv module with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in data_rows:
        writer.writerow(row)
    
    return output.getvalue()
