def summarize(lines):
    service_counts = {}
    
    for line in lines:
        parts = line.strip().split()
        if len(parts) < 3:
            continue
            
        timestamp, level, rest = parts[0], parts[1], ' '.join(parts[2:])
        
        # Check if format is "<timestamp> <LEVEL> <service>: <message>"
        if not rest.startswith(':'):
            continue
            
        service = rest.split(':')[0]
        
        # Normalize level to uppercase and check if it's WARN
        level_upper = level.upper()
        if level_upper != 'WARN':
            continue
            
        service_counts[service] = service_counts.get(service, 0) + 1
    
    return service_counts
