#!/usr/bin/env python3
"""Clean exported CSV table text."""

import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with header row (columns: name, team, city, id, score)
    Output: Cleaned CSV text with the same header.
    
    Cleaning steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "id" ascending as strings (stable)
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ''
    
    # Validate header columns
    expected_cols = ['name', 'team', 'city', 'id', 'score']
    if len(header) != len(expected_cols):
        # If header doesn't match, still process what we have
        pass
    
    # Process rows
    rows = []
    for row in reader:
        # Strip whitespace from each cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip if name is empty
        if not cleaned_row[0]:
            continue
        
        rows.append(cleaned_row)
    
    # Remove duplicates by "score" (column index 4), keeping first occurrence
    seen_scores = set()
    unique_rows = []
    for row in rows:
        score = row[4]
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort by "id" (column index 3) ascending as strings (stable)
    unique_rows.sort(key=lambda row: row[3])
    
    # Write output CSV with \n line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(unique_rows[0] if unique_rows else header)
    for row in unique_rows[1:]:
        writer.writerow(row)
    
    return output.getvalue()


if __name__ == '__main__':
    # Test with sample input
    sample = """name,team,city,id,score
Alice,TeamA,City1,100,95
Bob,TeamB,City2,200,87
Charlie,TeamC,City3,300,95
David,TeamD,City4,400,87
"""
    result = normalize_table(sample)
    print(result)
