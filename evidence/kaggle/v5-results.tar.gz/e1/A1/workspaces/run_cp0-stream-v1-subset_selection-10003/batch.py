def pick_jobs(items, capacity):
    """
    Choose parcels to maximize total score while total size stays <= capacity.
    If several selections tie on total score, return the lexicographically smallest sorted id list.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "id" not in item or "size" not in item or "score" not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if not isinstance(item["id"], str):
            raise ValueError("Item id must be a string")
        if item["size"] <= 0:
            raise ValueError("Item size must be positive")
        if item["score"] < 0:
            raise ValueError("Item score must be non-negative")
    
    if not items:
        return []
    
    n = len(items)
    # dp[w] = (max_score, selected_ids) for capacity w
    # We'll use a dictionary to track the best selection for each weight
    
    # Initialize: dp[0] = (0, [])
    dp = {}
    dp[0] = (0, [])
    
    # Process items one by one
    for i in range(n):
        item_id = items[i]["id"]
        size = items[i]["size"]
        score = items[i]["score"]
        
        # Create a new dictionary for the updated dp state
        new_dp = dp.copy()
        
        # For each weight w that we can reach, try adding this item
        for w in list(dp.keys()):
            if w + size <= capacity:
                current_score, current_ids = dp[w]
                new_score = current_score + score
                new_ids = current_ids + [item_id]
                
                # Check if this gives a better score, or same score but lexicographically smaller
                if w not in new_dp:
                    new_dp[w] = (new_score, new_ids)
                else:
                    existing_score, existing_ids = new_dp[w]
                    # Compare scores first
                    if new_score > existing_score:
                        new_dp[w] = (new_score, new_ids)
                    elif new_score == existing_score:
                        # Compare lexicographically - we want the smaller list
                        # Both lists are sorted, so we can compare directly
                        if new_ids < existing_ids:
                            new_dp[w] = (new_score, new_ids)
        
        dp = new_dp
    
    # Find the maximum score among all reachable weights
    max_score = 0
    best_ids = []
    
    for w in dp:
        score, ids = dp[w]
        if score > max_score:
            max_score = score
            best_ids = ids
        elif score == max_score:
            # Compare lexicographically
            if ids < best_ids:
                best_ids = ids
    
    return sorted(best_ids)
