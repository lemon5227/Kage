def digest_lines(lines):
    result = {}
    for line in lines:
        parts = line.strip().split()
        if len(parts) < 3:
            continue
        timestamp, level, service = parts[0], parts[1], parts[2]
        if not service.startswith(':'):
            continue
        message = ' '.join(parts[3:])
        # Extract level name from "LEVEL" part
        level_name = level.upper()
        result[level_name] = result.get(level_name, 0) + 1
    return result
