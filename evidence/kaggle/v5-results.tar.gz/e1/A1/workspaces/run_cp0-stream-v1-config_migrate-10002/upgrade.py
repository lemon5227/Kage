def upgrade_config(cfg):
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")

    # Create new v2 layout
    new_cfg = {
        "version": 2,
        "network": {}
    }

    # Rename top-level keys
    if "dir" in cfg:
        new_cfg["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        new_cfg["max_connections"] = cfg["max_conn"]

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Move region and retries into network sub-dict
    if "region" in cfg:
        new_cfg["network"]["region"] = cfg["region"]
    if "retries" in cfg:
        new_cfg["network"]["retries"] = cfg["retries"]

    # Keep other keys unchanged
    for key, value in cfg.items():
        if key not in ["dir", "pwd_file", "max_conn", "timeout_ms", "region", "retries", "version"]:
            # Drop keys whose value is None
            if value is not None:
                new_cfg[key] = value

    return new_cfg
