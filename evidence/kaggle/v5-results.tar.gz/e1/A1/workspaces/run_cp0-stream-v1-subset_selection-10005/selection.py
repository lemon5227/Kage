def allocate(items, capacity):
    """
    Select which parcels to take from a list of items.
    
    Each item is a dict with:
        - "id": unique string identifier
        - "size": positive integer
        - "score": non-negative integer
    
    Returns sorted list of ids whose total score is maximized
    while total size stays <= capacity.
    If several selections tie on total score, return the 
    lexicographically smallest sorted id list.
    
    Raises ValueError if capacity is negative or any size is <= 0.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "size" not in item or "score" not in item or "id" not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if item["size"] <= 0:
            raise ValueError("Size must be positive")
        if item["score"] < 0:
            raise ValueError("Score must be non-negative")
    
    if not items:
        return []
    
    n = len(items)
    
    # dp[i][w] = maximum score using first i items with total size <= w
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    
    # Track which items were selected for each state to handle tie-breaking
    # We'll store the actual selection for each state
    selections = [[[] for _ in range(capacity + 1)] for _ in range(n + 1)]
    
    # Build the DP table
    for i in range(1, n + 1):
        item = items[i - 1]
        size = item["size"]
        score = item["score"]
        prev_id = item["id"]
        
        for w in range(capacity + 1):
            # Option 1: Don't include item i
            dp[i][w] = dp[i-1][w]
            selections[i][w] = selections[i-1][w].copy()
            
            # Option 2: Include item i (if size <= w)
            if size <= w:
                new_score = dp[i-1][w - size] + score
                # Choose the better option, with tie-breaking by lexicographic order
                if new_score > dp[i-1][w]:
                    dp[i][w] = new_score
                    selections[i][w] = selections[i-1][w - size].copy() + [prev_id]
                elif new_score == dp[i-1][w]:
                    # Tie-breaking: choose lexicographically smaller selection
                    current_selection = selections[i][w]
                    other_selection = selections[i-1][w - size].copy() + [prev_id]
                    if current_selection > other_selection:
                        selections[i][w] = other_selection
    
    # The maximum score is in dp[n][capacity]
    max_score = dp[n][capacity]
    
    # Find the lexicographically smallest selection that achieves max_score
    best_selection = None
    for w in range(capacity + 1):
        if dp[n][w] == max_score:
            current_selection = selections[n][w]
            if best_selection is None or current_selection < best_selection:
                best_selection = current_selection
    
    # Return sorted list of ids
    return sorted(best_selection)
