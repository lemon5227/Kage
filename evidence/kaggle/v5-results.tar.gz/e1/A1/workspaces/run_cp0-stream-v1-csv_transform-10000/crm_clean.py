import csv
import io


def normalize_table(text):
    """
    Process CSV text with header row (columns: score, id, email, name).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "name", keeping the first occurrence
    5. Sort rows by "email" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Check if first line is header
    header = lines[0].strip()
    if ',' not in header:
        return ''
    
    # Parse header columns
    header_cols = [col.strip() for col in header.split(',')]
    if len(header_cols) != 4 or header_cols != ['score', 'id', 'email', 'name']:
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        cells = [cell.strip() for cell in line.split(',')]
        if len(cells) != 4:
            continue
        score, id_val, email, name = cells
        
        # Drop rows whose "name" cell is empty
        if not name:
            continue
        
        # Lower-case the "email" column
        email = email.lower()
        
        rows.append({
            'score': score,
            'id': id_val,
            'email': email,
            'name': name
        })
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        if row['name'] not in seen_names:
            seen_names.add(row['name'])
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    unique_rows.sort(key=lambda r: r['email'])
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(['score', 'id', 'email', 'name'])
    for row in unique_rows:
        writer.writerow([row['score'], row['id'], row['email'], row['name']])
    
    return output.getvalue()
