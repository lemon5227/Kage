def count_entries(lines):
    counts = {}
    for line in lines:
        parts = line.strip().split()
        if len(parts) < 3:
            continue
        timestamp, level, rest = parts[0], parts[1], ' '.join(parts[2:])
        if not rest.startswith(':'):
            continue
        # Extract service and message from rest
        service_part = rest.split(':', 1)[0]
        message = rest.split(':', 1)[1] if ':' in rest else ''
        # Check if the line has the expected format: timestamp level service: message
        # We need to ensure that level is a valid log level
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # So we need to check that parts[2] starts with ':'
        if len(parts) < 3 or not rest.startswith(':'):
            continue
        # Extract the level (case-insensitive)
        level_upper = level.upper()
        counts[level_upper] = counts.get(level_upper, 0) + 1
    return counts
