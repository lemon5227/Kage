def convert_settings(cfg):
    # Check version requirement
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")
    
    # Create new dict with v2 layout
    result = {
        "version": 2,
        "directory": cfg.get("dir"),
        "hostname": cfg.get("host"),
        "storage": {}
    }
    
    # Handle timeout_ms if present
    if "timeout_ms" in cfg:
        result["storage"]["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Handle port and workers - they should be in storage
    if "port" in cfg:
        result["storage"]["port"] = cfg["port"]
    if "workers" in cfg:
        result["storage"]["workers"] = cfg["workers"]
    
    # Keep other keys unchanged (but drop keys with None values)
    for key, value in cfg.items():
        if key not in ["dir", "host", "port", "workers", "timeout_ms", "version"]:
            if value is not None:
                result[key] = value
    
    return result
