def tally_events(lines):
    result = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        service = parts[2]
        if level in ('ERROR', 'WARN'):
            result[service] = result.get(service, 0) + 1
    return result
