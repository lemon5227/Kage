def convert_settings(cfg):
    # Check version requirement
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")

    # Create new v2 layout
    new_cfg = {
        "version": 2,
        "hostname": cfg.get("host"),
        "max_connections": cfg.get("max_conn"),
        "password_file": cfg.get("pwd_file"),
        "storage": {}
    }

    # Move port and retries into storage
    if "port" in cfg:
        new_cfg["storage"]["port"] = cfg["port"]
    if "retries" in cfg:
        new_cfg["storage"]["retries"] = cfg["retries"]

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        new_cfg["storage"]["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged (but drop keys with None values)
    for key, value in cfg.items():
        if key not in ["host", "max_conn", "pwd_file", "port", "retries", "timeout_ms", "version"]:
            if value is not None:
                new_cfg[key] = value

    return new_cfg
