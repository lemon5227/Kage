import unicodedata

def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # NFKD normalization
    text = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters
    text = ''.join(char for char in text if ord(char) < 128)
    
    # Lower-case
    text = text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for char in text:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char != '-':
                result.append('-')
                prev_char = '-'
        else:
            result.append(char)
            prev_char = char
    
    # Strip leading and trailing "-"
    slug = ''.join(result).strip('-')
    
    return slug
