def migrate(cfg):
    # Check version
    if cfg.get("version") != 1:
        raise ValueError("Only v1 config is supported for migration")
    
    # Create new dict
    new_cfg = {}
    
    # Handle version
    new_cfg["version"] = 2
    
    # Rename top-level keys
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    if "user" in cfg:
        new_cfg["username"] = cfg["user"]
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    
    new_cfg["network"] = network
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["pwd_file", "user", "cache_size", "workers", "timeout_ms", "version"]:
            if value is not None:
                new_cfg[key] = value
    
    return new_cfg
