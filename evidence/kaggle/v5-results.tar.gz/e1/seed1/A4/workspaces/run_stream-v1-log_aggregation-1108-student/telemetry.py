def summarize(lines):
    """
    Process telemetry lines and count ERROR level messages per service.
    
    Each line format: <timestamp> <LEVEL> <service>: <message>
    Returns a dict mapping each service for levels ERROR only to count.
    Levels are case-insensitive (reported as upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    error_counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Only count ERROR level
        if level == "ERROR":
            error_counts[service] = error_counts.get(service, 0) + 1
    
    return error_counts
