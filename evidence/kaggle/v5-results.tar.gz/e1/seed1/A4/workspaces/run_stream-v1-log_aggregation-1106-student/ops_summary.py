def summarize(lines):
    """
    Process lines in format: <timestamp> <LEVEL> <service>: <message>
    Return a dict mapping each level to how many lines it has.
    Levels are case-insensitive (report them upper-case).
    Skip malformed lines. Omit keys with zero count.
    """
    level_counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service: message
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report as uppercase
        rest = ' '.join(parts[2:])
        
        # Check if the format is correct: service: message
        # The third part should start with a service name followed by colon
        if not rest.startswith(':'):
            continue
        
        # If there's only one part after the colon, it's still valid
        # (service: message where message might be empty or single word)
        # We just need to ensure the line has the expected structure
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # So we need at least 3 tokens, and the third token should contain a colon
        
        # Let's re-check: parts[2] should be "service:" or "service: message"
        # Actually, the split() splits by whitespace, so "service: message" becomes two parts
        # We need to ensure that parts[2] starts with something and contains ':'
        
        # Check if parts[2] contains a colon
        if ':' not in parts[2]:
            continue
        
        # Valid line - count the level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    # Return only non-zero counts (already filtered by dict construction)
    return level_counts
