import csv
import io


def clean_rows(text):
    """
    Clean CSV text with a header row (columns: city, team, score, name, id).
    
    Returns cleaned CSV text with the same header.
    In order:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "city" cell is empty
    3. Remove duplicate rows by "city", keeping the first occurrence
    4. Sort rows by "score" ascending as strings (stable)
    
    Write the output with the csv module using '\n' line endings.
    An empty string returns ''; a header-only input returns just the header line.
    """
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = []
    seen_cities = set()
    
    for row in rows[1:]:
        # Strip whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        if len(cleaned_row) < 5:
            continue
            
        city, team, score, name, id_val = cleaned_row[0], cleaned_row[1], cleaned_row[2], cleaned_row[3], cleaned_row[4]
        
        # Drop rows whose "city" cell is empty
        if not city:
            continue
        
        # Remove duplicate rows by "city", keeping the first occurrence
        if city in seen_cities:
            continue
        seen_cities.add(city)
        
        data_rows.append(cleaned_row)
    
    # Sort rows by "score" ascending as strings (stable)
    # Use a stable sort - Python's sort is stable
    data_rows.sort(key=lambda row: row[2])
    
    # Build output CSV text
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for row in data_rows:
        writer.writerow(row)
    
    return output.getvalue()
