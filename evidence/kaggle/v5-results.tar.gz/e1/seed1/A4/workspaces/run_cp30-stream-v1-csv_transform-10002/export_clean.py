import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text."""
    # Handle empty string input
    if not text or not text.strip():
        return ''
    
    # Parse the CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Check if we have at least one row (header)
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Validate header columns: name, team, city, id, score
    expected_columns = ['name', 'team', 'city', 'id', 'score']
    if len(header) != len(expected_columns):
        # If header doesn't match, return empty or handle gracefully
        return ''
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        if len(row) != len(header):
            continue  # Skip rows with wrong number of columns
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "name" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if not row[0]:  # name is at index 0
            continue
        filtered_rows.append(row)
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in filtered_rows:
        score = row[4]  # score is at index 4
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort rows by "id" ascending as strings (stable)
    # id is at index 3
    sorted_rows = sorted(unique_rows, key=lambda row: row[3])
    
    # Build output CSV text
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for row in sorted_rows:
        writer.writerow(row)
    
    return output.getvalue()


if __name__ == '__main__':
    # Test example
    test_input = """name,team,city,id,score
Alice,TeamA,City1,001,100
Bob,TeamB,City2,002,100
Charlie,TeamC,City3,003,200
"""
    result = normalize_table(test_input)
    print(result)
