#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')
from export_clean import normalize_table

# Test 1: Basic functionality
test_input = """name,team,city,id,score
Alice,TeamA,City1,001,100
Bob,TeamB,City2,002,100
Charlie,TeamC,City3,003,200
"""
result = normalize_table(test_input)
print("Test 1 - Basic functionality:")
print(result)
print()

# Test 2: Empty string input
result2 = normalize_table('')
print("Test 2 - Empty string input:")
print(repr(result2))
print()

# Test 3: Header-only input
test3 = "name,team,city,id,score"
result3 = normalize_table(test3)
print("Test 3 - Header-only input:")
print(result3)
print()

# Test 4: Row with empty name
test4 = """name,team,city,id,score
Alice,TeamA,City1,001,100

Bob,TeamB,City2,002,200
"""
result4 = normalize_table(test4)
print("Test 4 - Row with empty name:")
print(result4)
print()

# Test 5: Duplicate scores
test5 = """name,team,city,id,score
Alice,TeamA,City1,001,100
Bob,TeamB,City2,002,100
Charlie,TeamC,City3,003,100
"""
result5 = normalize_table(test5)
print("Test 5 - Duplicate scores (keep first):")
print(result5)
