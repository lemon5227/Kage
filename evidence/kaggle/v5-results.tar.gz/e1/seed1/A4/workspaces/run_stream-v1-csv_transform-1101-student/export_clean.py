import csv
import io


def clean_rows(text):
    """
    Clean CSV text with a header row (columns: team, name, city, id).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "team" cell is empty
    3. Remove duplicate rows by "city", keeping the first occurrence
    4. Sort rows by "id" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Check if there's only a header row
    if len(rows) == 1:
        # Return just the header line
        return rows[0][0] + ',' + rows[0][1] + ',' + rows[0][2] + ',' + rows[0][3]
    
    # Extract header
    header = rows[0]
    # Expected columns: team, name, city, id
    if len(header) != 4:
        return ''
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        if len(row) != 4:
            continue
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Step 2: Drop rows whose "team" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if row[0] == '':
            continue
        filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "city", keeping the first occurrence
    seen_cities = set()
    unique_rows = []
    for row in filtered_rows:
        city = row[2]
        if city not in seen_cities:
            seen_cities.add(city)
            unique_rows.append(row)
    
    # Step 4: Sort rows by "id" ascending as strings (stable)
    # Since we need stable sort, we can use a key that preserves order for equal ids
    # But the requirement says "sort rows by 'id' ascending as strings (stable)"
    # This means if two rows have the same id string, their relative order should be preserved
    # We can achieve this by using a tuple (id, original_index) for sorting
    indexed_rows = list(enumerate(unique_rows))
    sorted_indices = sorted(indexed_rows, key=lambda x: (x[1][3], x[0]))
    sorted_rows = [row for _, row in sorted_indices]
    
    # Build output CSV
    output_lines = []
    # Header
    output_lines.append(','.join(header))
    # Data rows
    for row in sorted_rows:
        output_lines.append(','.join(row))
    
    return '\n'.join(output_lines)


if __name__ == '__main__':
    # Test cases
    test1 = "team,name,city,id\nA,B,C,1\nD,E,F,2"
    print("Test 1:", clean_rows(test1))
    
    test2 = "team,name,city,id\nA,B,C,1\nB,D,C,2"
    print("Test 2:", clean_rows(test2))
    
    test3 = "team,name,city,id"
    print("Test 3:", clean_rows(test3))
    
    test4 = ""
    print("Test 4:", clean_rows(test4))
