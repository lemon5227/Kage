def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout."""
    version = cfg.get("version")
    if version != 1:
        raise ValueError(f"Expected version 1, got {version}")
    
    # Create new config dict
    new_cfg = {"version": 2}
    
    # Rename top-level keys
    if "dir" in cfg:
        new_cfg["directory"] = cfg["dir"]
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    if "max_conn" in cfg:
        new_cfg["max_connections"] = cfg["max_conn"]
    
    # Move region and retries into network sub-dict
    network = {}
    if "region" in cfg:
        network["region"] = cfg["region"]
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    new_cfg["network"] = network
    
    # Handle timeout_ms
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["dir", "pwd_file", "max_conn", "region", "retries", "timeout_ms"]:
            if value is not None:
                new_cfg[key] = value
    
    return new_cfg
