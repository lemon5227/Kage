import csv
import io

def tidy_csv(text):
    """Clean an exported CSV table with header row (columns: name, city, score, team)."""
    
    # Handle empty string input
    if not text or not text.strip():
        return ''
    
    # Split into lines and handle line endings
    lines = text.split('\n')
    
    # If only header exists, return it as is
    if len(lines) == 1:
        return lines[0]
    
    # Parse the CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # The first row is the header
    header = rows[0]
    
    # Validate header columns
    expected_columns = ['name', 'city', 'score', 'team']
    if len(header) != len(expected_columns):
        # If header doesn't match, use first column as name
        header = header[:4]
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        if len(row) < 4:
            continue  # Skip rows with insufficient columns
        cleaned_row = [cell.strip() for cell in row[:4]]
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "name" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if not row[0]:  # name is empty
            continue
        filtered_rows.append(row)
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in filtered_rows:
        name = row[0]
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Sort rows by "city" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row[1])
    
    # Build output CSV text
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
