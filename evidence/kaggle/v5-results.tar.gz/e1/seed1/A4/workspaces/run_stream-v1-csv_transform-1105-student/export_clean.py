import csv
import io

def dedupe_export(text):
    """
    Process CSV text with header row (columns: city, email, name, id, team).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "team", keeping the first occurrence
    5. Sort rows by "id" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    # Validate expected columns
    expected_cols = ['city', 'email', 'name', 'id', 'team']
    if header != expected_cols:
        raise ValueError(f"Expected header {expected_cols}, got {header}")
    
    # Process data rows
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    processed_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        processed_rows.append(stripped_row)
    
    # Step 2: Drop rows whose "name" cell is empty
    filtered_rows = []
    for row in processed_rows:
        if not row[2]:  # name is at index 2
            continue
        filtered_rows.append(row)
    
    # Step 3: Lower-case the "email" column (index 1)
    lowercased_rows = []
    for row in filtered_rows:
        new_row = list(row)
        new_row[1] = new_row[1].lower()
        lowercased_rows.append(new_row)
    
    # Step 4: Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    deduped_rows = []
    for row in lowercased_rows:
        team = row[4]  # team is at index 4
        if team not in seen_teams:
            seen_teams.add(team)
            deduped_rows.append(row)
    
    # Step 5: Sort rows by "id" ascending as strings (stable)
    # id is at index 3
    sorted_rows = sorted(deduped_rows, key=lambda row: row[3])
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in sorted_rows:
        writer.writerow(row)
    
    return output.getvalue()
