import csv
import io


def normalize_table(text):
    """
    Normalize a CSV table with columns: city, id, name, team.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "team" cell is empty
    3. Remove duplicate rows by "id", keeping the first occurrence
    4. Sort rows by "city" ascending as strings (stable)
    
    Returns:
        str: Cleaned CSV text with '\n' line endings
    """
    # Parse the CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Check if input is empty or header-only
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Check if header has the expected columns
    expected_columns = ['city', 'id', 'name', 'team']
    if header != expected_columns:
        # If header doesn't match, we still process but may not be able to filter by team
        pass
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)
    
    # Step 2: Drop rows whose "team" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) >= 4 and row[3] == '':
            continue
        filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "id", keeping the first occurrence
    seen_ids = set()
    deduped_rows = []
    for row in filtered_rows:
        if len(row) < 2:
            continue
        row_id = row[1]
        if row_id not in seen_ids:
            seen_ids.add(row_id)
            deduped_rows.append(row)
    
    # Step 4: Sort rows by "city" ascending as strings (stable)
    # Stable sort means we preserve order for equal keys
    deduped_rows.sort(key=lambda row: row[0])
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()
