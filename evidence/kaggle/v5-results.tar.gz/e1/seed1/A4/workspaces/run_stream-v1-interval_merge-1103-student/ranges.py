def combine_ranges(intervals):
    """Merge overlapping intervals. Each interval is a dict {"start": s, "end": e} with integer values.
    
    Returns merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        if "start" not in interval or "end" not in interval:
            raise ValueError("Each interval must have 'start' and 'end' keys")
        if interval["start"] > interval["end"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    if not intervals:
        return []
    
    # Sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping intervals
    merged = [sorted_intervals[0].copy()]
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # Check if current overlaps with last (current start < last end)
        if current["start"] < last["end"]:
            # Merge by updating last's end to max of both ends
            last["end"] = max(last["end"], current["end"])
        else:
            # No overlap, add current interval
            merged.append(current.copy())
    
    return merged
