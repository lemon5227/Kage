def combine_ranges(intervals):
    """Merge overlapping or touching intervals, sorted by start ascending."""
    # Validate all intervals
    for start, end in intervals:
        if start > end:
            raise ValueError("Interval start must not be greater than end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping/touching intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last_start, last_end = merged[-1]
            if interval[0] <= last_end + 1:  # Overlapping or touching (touching means interval[0] == last_end)
                # Merge by extending the end
                merged[-1] = [last_start, max(last_end, interval[1])]
            else:
                merged.append(interval)
    
    return merged
