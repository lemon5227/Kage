def tally_events(lines):
    """
    Process log lines in format: <timestamp> <LEVEL> <service>: <message>
    Count occurrences of WARN level per service.
    Returns dict mapping service to count (only for WARN, case-insensitive).
    Skips malformed lines.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part) and service (third part)
        level = parts[1].upper()
        service = parts[2]
        
        # Only count WARN level
        if level == 'WARN':
            counts[service] = counts.get(service, 0) + 1
    
    return counts
