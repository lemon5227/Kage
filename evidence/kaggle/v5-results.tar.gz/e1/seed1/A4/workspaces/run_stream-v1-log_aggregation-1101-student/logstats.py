def summarize(lines):
    """
    Process log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    Returns {name: count} per service for levels ERROR, WARN only.
    Level names are treated case-insensitively (output keys are uppercase).
    Malformed input lines are dropped.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) < 3:
            # Malformed: need at least timestamp, level, service
            continue
        
        # parts[0] = timestamp, parts[1] = LEVEL, parts[2] = service (before colon)
        level = parts[1].upper()
        service = parts[2].split(':')[0]  # Handle case where service might have colon
        
        if level in ('ERROR', 'WARN'):
            counts[service] = counts.get(service, 0) + 1
    
    return counts
