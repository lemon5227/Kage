def digest_lines(lines):
    """Process log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per level, treating level names case-insensitively (upper-case keys),
    dropping malformed input lines."""
    counts = {}
    for line in lines:
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Malformed: need at least timestamp, level, and service
            continue
        
        # Check format: <timestamp> <LEVEL> <service>: <message>
        # The third part should contain a colon after the service name
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, use uppercase key
        rest = ' '.join(parts[2:])
        
        # Verify the format: service should be followed by colon
        if not rest.startswith(':'):
            continue
        
        # Extract service name (everything before the colon)
        service_part = rest.split(':', 1)[0]
        # The message is everything after the colon
        message = rest.split(':', 1)[1] if ':' in rest else ''
        
        # We count by level, not by service. The problem says "per level"
        # So we just increment the count for this level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
