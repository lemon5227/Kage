def coalesce(intervals):
    """Merge overlapping and touching intervals.
    
    Each interval is a dict {"from": s, "to": e} with integer values.
    Returns merged intervals as dicts with the same "from"/"to" keys,
    sorted by start ascending. Raises ValueError if any interval has start > end.
    """
    # Check for invalid intervals (start > end)
    for interval in intervals:
        if interval["from"] > interval["to"]:
            raise ValueError("Interval start > end")
    
    # Sort intervals by start (from)
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping or touching intervals
    merged = []
    if not sorted_intervals:
        return merged
    
    current = sorted_intervals[0].copy()
    
    for i in range(1, len(sorted_intervals)):
        next_interval = sorted_intervals[i]
        
        # Check if intervals overlap or touch
        if current["to"] >= next_interval["from"]:
            # Merge by updating the end to the maximum of both ends
            current["to"] = max(current["to"], next_interval["to"])
        else:
            # No overlap, add current interval and start a new one
            merged.append(current)
            current = next_interval.copy()
    
    # Add the last interval
    merged.append(current)
    
    return merged
