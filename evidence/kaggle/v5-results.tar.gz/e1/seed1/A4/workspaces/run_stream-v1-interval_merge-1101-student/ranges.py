def coalesce(intervals):
    """Merge overlapping intervals, including touching ones."""
    # Check for invalid intervals (start > end)
    for start, end in intervals:
        if start > end:
            raise ValueError("Interval start must not be greater than end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if merged and start <= merged[-1][1]:
            # Overlapping or touching - merge
            merged[-1] = [merged[-1][0], max(merged[-1][1], end)]
        else:
            merged.append(interval)
    
    return merged
