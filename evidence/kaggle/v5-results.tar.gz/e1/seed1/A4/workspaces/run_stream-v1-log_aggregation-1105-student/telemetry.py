def summarize(lines):
    """
    Summarize telemetry lines.
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each service for levels ERROR, WARN only to how many lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines. Omit keys with zero count.
    """
    counts = {}
    
    for line in lines:
        # Split the line into parts
        parts = line.split()
        
        # Need at least 4 parts: timestamp, level, service, and message (at least one word)
        if len(parts) < 4:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Only count ERROR and WARN levels
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Increment count for this service
        counts[service] = counts.get(service, 0) + 1
    
    # Return only services with non-zero count
    return {k: v for k, v in counts.items() if v > 0}
