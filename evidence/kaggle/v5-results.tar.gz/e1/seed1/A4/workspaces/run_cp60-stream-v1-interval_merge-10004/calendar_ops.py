def merge_slots(intervals):
    """
    Merge overlapping intervals. Each interval is a two-element list [start, end] of integers.
    Return merged intervals in the same [start, end] list form, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # If no intervals, return empty list
    if not intervals:
        return []
    
    # Sort by start time first
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            # Only merge if there is a real overlap (end > last_end, not >=)
            if end > last_end:
                merged[-1][1] = end
            else:
                merged.append([start, end])
    
    return merged
