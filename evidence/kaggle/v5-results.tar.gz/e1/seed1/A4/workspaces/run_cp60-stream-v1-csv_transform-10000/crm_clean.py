import csv
import io


def normalize_table(text):
    """
    Process CSV text with header row (columns: score, id, email, name).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "name", keeping the first occurrence
    5. Sort rows by "email" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Parse CSV text
    lines = text.strip().split('\n')
    
    if not lines:
        return ''
    
    # Check if it's header-only
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    if 'name' not in header or 'email' not in header:
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) < len(header):
            continue
        
        # Strip whitespace from each cell
        cells = [cell.strip() for cell in cells]
        
        # Build row dict
        row = {}
        for i, col in enumerate(header):
            if i < len(cells):
                row[col] = cells[i]
            else:
                row[col] = ''
        
        rows.append(row)
    
    # Drop rows whose "name" cell is empty
    rows = [row for row in rows if row.get('name', '').strip() != '']
    
    # Lower-case the "email" column
    for row in rows:
        row['email'] = row['email'].lower()
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        name = row['name']
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row['email'])
    
    # Build output CSV text
    output_lines = [','.join(header)]
    for row in unique_rows:
        # Only include columns that exist in header
        values = []
        for col in header:
            values.append(row.get(col, ''))
        output_lines.append(','.join(values))
    
    return '\n'.join(output_lines)
