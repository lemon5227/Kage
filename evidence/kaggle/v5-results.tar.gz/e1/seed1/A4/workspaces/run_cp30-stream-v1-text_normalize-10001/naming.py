import unicodedata


def slugify(text):
    """Turn a title into a handle.
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces every run of characters outside [a-z0-9] with a single "_",
    and strips leading and trailing "_".
    
    Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    slug = []
    previous_char = None
    for char in lowercased:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            slug.append(char)
        else:
            if previous_char is not None:
                # Skip consecutive non-alphanumeric characters
                continue
            else:
                slug.append('_')
            previous_char = char
    
    result = ''.join(slug)
    
    # Strip leading and trailing "_"
    return result.strip('_')
