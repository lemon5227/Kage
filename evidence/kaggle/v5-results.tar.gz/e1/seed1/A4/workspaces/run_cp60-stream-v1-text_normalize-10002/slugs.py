import unicodedata


def slugify(text):
    """Build a URL slug from text.
    
    Args:
        text: Input string to convert to slug
        
    Returns:
        A URL-friendly slug
        
    Raises:
        TypeError: If input is not a string
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single '-'
    slug = []
    previous_char = None
    for char in lower_text:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if previous_char is not None:
                slug.append('-')
            previous_char = None
        else:
            previous_char = char
    
    # Join the parts
    slug = ''.join(slug)
    
    # Strip leading and trailing '-'
    slug = slug.strip('-')
    
    return slug
