def tally_events(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, and service: message
        if len(parts) < 3:
            continue
        
        # Check if the third part starts with "service:"
        if not parts[2].startswith(":"):
            continue
        
        # Extract the level from parts[1]
        level = parts[1].upper()
        
        # Only count if level is a valid log level (non-empty string)
        if level:
            counts[level] = counts.get(level, 0) + 1
    
    return counts
