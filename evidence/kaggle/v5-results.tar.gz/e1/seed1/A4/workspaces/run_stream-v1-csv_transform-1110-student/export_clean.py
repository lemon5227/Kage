import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with a header row (columns: score, team, name, email)
    Output: Cleaned CSV text with the same header
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "team" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "team", keeping the first occurrence
    5. Sort rows by "email" ascending as strings (stable)
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Parse header
    header = lines[0].split(',')
    if 'team' not in header or 'email' not in header:
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) < len(header):
            continue
        
        # Strip whitespace from each cell
        cleaned_cells = [cell.strip() for cell in cells]
        
        # Create a dict for easier access
        row_dict = {}
        for i, col in enumerate(header):
            if i < len(cleaned_cells):
                row_dict[col] = cleaned_cells[i]
            else:
                row_dict[col] = ''
        
        # Skip rows with empty team
        if row_dict.get('team', '').strip() == '':
            continue
        
        # Lower-case the email column
        row_dict['email'] = row_dict['email'].lower()
        
        rows.append(row_dict)
    
    # Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    unique_rows = []
    for row in rows:
        team = row.get('team', '').strip()
        if team not in seen_teams:
            seen_teams.add(team)
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row.get('email', ''), stable=True)
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for row in unique_rows:
        # Reconstruct the row in the original column order
        values = []
        for col in header:
            values.append(row.get(col, ''))
        writer.writerow(values)
    
    return output.getvalue()
