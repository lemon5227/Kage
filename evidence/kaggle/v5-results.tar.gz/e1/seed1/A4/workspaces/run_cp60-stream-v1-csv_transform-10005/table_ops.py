import csv
import io

def normalize_table(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with header row (columns: id, email, city, name)
    Output: Cleaned CSV text with the same header
    
    Rules:
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "id" cell is empty
    - Lower-case the "email" column
    - Remove duplicate rows by "email", keeping the first occurrence
    - Sort rows by "email" ascending as strings (stable)
    """
    # Parse CSV text into a list of rows
    lines = text.strip().split('\n')
    
    if len(lines) == 0:
        return ''
    
    # Parse header
    header = lines[0].split(',')
    # Ensure we have the expected columns
    expected_columns = ['id', 'email', 'city', 'name']
    if set(header) != set(expected_columns):
        raise ValueError(f"Expected columns {expected_columns}, got {header}")
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) != len(header):
            continue
        row = dict(zip(header, cells))
        # Strip whitespace from all cells
        row = {k: v.strip() for k, v in row.items()}
        # Drop rows whose "id" cell is empty
        if not row['id']:
            continue
        rows.append(row)
    
    # Lower-case the "email" column
    for row in rows:
        row['email'] = row['email'].lower()
    
    # Remove duplicate rows by "email", keeping the first occurrence
    seen_emails = set()
    unique_rows = []
    for row in rows:
        email = row['email']
        if email not in seen_emails:
            seen_emails.add(email)
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    unique_rows.sort(key=lambda r: r['email'])
    
    # Build output CSV text
    output_lines = [','.join(header)]
    for row in unique_rows:
        output_lines.append(','.join([row[col] for col in header]))
    
    return '\n'.join(output_lines)
