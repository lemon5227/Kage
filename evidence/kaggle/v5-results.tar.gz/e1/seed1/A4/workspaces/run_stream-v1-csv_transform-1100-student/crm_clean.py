import csv
import io


def dedupe_export(text):
    """
    Process CSV text with header row (columns: id, email, score, team, city).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "email", keeping the first occurrence
    5. Sort rows by "score" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    # Validate expected columns
    expected_cols = ['id', 'email', 'score', 'team', 'city']
    if header != expected_cols:
        raise ValueError(f"Expected header {expected_cols}, got {header}")
    
    # Process data rows
    data_rows = []
    seen_emails = set()
    
    for row in rows[1:]:
        if len(row) != 5:
            continue  # Skip malformed rows
        
        id_val, email, score, team, city = row
        
        # Step 1: Strip leading/trailing whitespace from every cell
        id_val = id_val.strip()
        email = email.strip()
        score = score.strip()
        team = team.strip()
        city = city.strip()
        
        # Step 2: Drop rows whose "score" cell is empty
        if not score:
            continue
        
        # Step 3: Lower-case the "email" column
        email = email.lower()
        
        # Step 4: Remove duplicate rows by "email", keeping the first occurrence
        if email in seen_emails:
            continue
        seen_emails.add(email)
        
        data_rows.append({
            'id': id_val,
            'email': email,
            'score': score,
            'team': team,
            'city': city
        })
    
    # Step 5: Sort rows by "score" ascending as strings (stable)
    # Using stable sort: Python's sorted is stable, so we just sort by score string
    data_rows.sort(key=lambda x: x['score'])
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in data_rows:
        writer.writerow([row['id'], row['email'], row['score'], row['team'], row['city']])
    
    return output.getvalue()
