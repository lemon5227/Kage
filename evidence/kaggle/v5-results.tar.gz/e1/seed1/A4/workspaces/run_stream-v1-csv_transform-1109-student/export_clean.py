import csv
import io

def clean_rows(text):
    """Clean CSV text according to specified rules."""
    
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines and parse header
    lines = text.strip().split('\n')
    if not lines:
        return ''
    
    # Parse header
    header = lines[0].strip().split(',')
    # Expected columns: name, score, city, email, id
    # We'll use these as the column names
    
    # Parse all rows
    rows = []
    for i, line in enumerate(lines[1:], 1):
        if not line.strip():
            continue
        cells = line.strip().split(',')
        if len(cells) < len(header):
            continue  # Skip malformed rows
        
        row = {}
        for j, col in enumerate(header):
            if j < len(cells):
                row[col] = cells[j].strip()
            else:
                row[col] = ''
        rows.append(row)
    
    # Drop rows whose "id" cell is empty
    rows = [row for row in rows if row.get('id', '').strip() != '']
    
    # Lower-case the "email" column
    for row in rows:
        row['email'] = row['email'].lower()
    
    # Remove duplicate rows by "email", keeping the first occurrence
    seen_emails = set()
    unique_rows = []
    for row in rows:
        email = row.get('email', '')
        if email not in seen_emails:
            seen_emails.add(email)
            unique_rows.append(row)
    
    # Sort rows by "score" ascending as strings (stable)
    # Using str comparison for score as strings
    unique_rows.sort(key=lambda row: row.get('score', ''), stable=True)
    
    # Build output CSV text
    output_lines = [','.join(header)]
    for row in unique_rows:
        # Only include columns that exist in header
        values = []
        for col in header:
            val = row.get(col, '')
            values.append(val)
        output_lines.append(','.join(values))
    
    # Join with '\n' line endings
    return '\n'.join(output_lines)
