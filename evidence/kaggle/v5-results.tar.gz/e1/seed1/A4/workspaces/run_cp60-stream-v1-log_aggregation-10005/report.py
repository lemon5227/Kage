def summarize(lines):
    """
    Process log lines in format: <timestamp> <LEVEL> <service>: <message>
    Return a dict mapping each service for levels WARN only to count.
    Levels are case-insensitive (reported upper-case). Skip malformed lines.
    Omit keys with zero count.
    """
    service_counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 4 parts: timestamp, level, service, and message starts after colon
        if len(parts) < 4:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Check if level is WARN
        if level != 'WARN':
            continue
        
        # Extract service (third part, before the colon)
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # So parts[2] should be the service name
        service = parts[2]
        
        # Count this service
        service_counts[service] = service_counts.get(service, 0) + 1
    
    # Return only non-zero counts (already filtered by WARN check)
    return service_counts
