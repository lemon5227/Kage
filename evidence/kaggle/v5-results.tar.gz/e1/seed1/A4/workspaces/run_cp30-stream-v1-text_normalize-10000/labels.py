import unicodedata


def make_handle(text):
    """Convert a title into a handle according to the specified rules."""
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we replace any sequence of non-alphanumeric characters with a single hyphen
    result = []
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                result.append('-')
                prev_char = '-'
            else:
                prev_char = '-'
        else:
            result.append(char)
            prev_char = char
    
    # Join and strip leading and trailing "-"
    handle = ''.join(result).strip('-')
    
    # If the result is longer than 23 characters, cut it to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23].strip('-')
    
    return handle
