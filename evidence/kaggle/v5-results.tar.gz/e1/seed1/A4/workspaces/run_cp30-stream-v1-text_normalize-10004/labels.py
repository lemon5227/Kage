import unicodedata

def label_id(text):
    """Build a URL slug from text.
    
    Applies unicodedata NFKD normalization, drops non-ASCII characters,
    lower-cases, replaces every run of characters outside [a-z0-9] with a single "-",
    and strips leading and trailing "-".
    
    Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to split on any character that is not alphanumeric
    slug = []
    previous_char = None
    for char in lower:
        if char.isalnum():
            slug.append(char)
        else:
            if previous_char is not None:
                # Add separator only if there was a previous character
                slug.append('-')
            previous_char = None
    
    # Join and strip leading/trailing "-"
    result = ''.join(slug).strip('-')
    
    return result
