import csv
import io

def tidy_csv(text):
    # Handle empty string
    if not text or not text.strip():
        return ''
    
    # Parse the CSV text
    lines = text.strip().split('\n')
    
    # Check if header-only input
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    # Expected columns: score, id, team, name
    if len(header) != 4:
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) != 4:
            continue
        # Strip whitespace from each cell
        cells = [cell.strip() for cell in cells]
        score, id_val, team, name = cells
        # Drop rows where name is empty
        if not name:
            continue
        rows.append((score, id_val, team, name))
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        name = row[3]
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row[3])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
