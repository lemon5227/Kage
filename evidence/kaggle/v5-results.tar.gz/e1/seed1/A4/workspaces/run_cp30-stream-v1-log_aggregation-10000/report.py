def count_entries(lines):
    """Count occurrences of each log level in lines.
    
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level (uppercase) to its count.
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    level_counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, and the rest (service: message)
        if len(parts) < 3:
            continue
        
        # The second part is the level (index 1)
        level = parts[1].upper()
        
        # Validate that the level is not empty
        if not level:
            continue
        
        # Increment count for this level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    # Return only levels with non-zero counts (already handled by dict)
    return level_counts
