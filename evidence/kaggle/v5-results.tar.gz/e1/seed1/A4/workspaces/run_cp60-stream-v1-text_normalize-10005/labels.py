import unicodedata


def to_key(text):
    """Normalize labels into identifiers.
    
    - Apply unicodedata NFKD normalization
    - Drop non-ASCII characters
    - Lower-case
    - Replace every run of characters outside [a-z0-9] with a single "_"
    - Strip leading and trailing "_"
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for char in lower:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                result.append('_')
            prev_char = char
        else:
            prev_char = None
    
    key = ''.join(result)
    
    # Strip leading and trailing "_"
    key = key.strip('_')
    
    return key
