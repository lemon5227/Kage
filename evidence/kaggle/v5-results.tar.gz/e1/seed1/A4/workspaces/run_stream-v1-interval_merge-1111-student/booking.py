def coalesce(intervals):
    """Combine overlapping time ranges in intervals.
    
    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals sorted by start ascending.
    Touching intervals like [1,3] and [3,5] are NOT merged.
    Raises ValueError if any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        start, end = interval
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    if not intervals:
        return []
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    merged = [sorted_intervals[0][:]]
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # Check if intervals overlap (current start < last end)
        if current[0] < last[1]:
            # Merge them: new end is max of both ends
            merged[-1][1] = max(last[1], current[1])
        else:
            # No overlap, add this interval
            merged.append(current[:])
    
    return merged
