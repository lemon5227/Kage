import unicodedata
import re


def slugify(text):
    """Convert a title into a handle (slug).
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with a single underscore,
    and strips leading/trailing underscores.
    
    Args:
        text: A string to convert
        
    Returns:
        A slugified string
        
    Raises:
        TypeError: If text is not a string
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    slugified = re.sub(r'[^a-z0-9]+', '_', lowercased)
    
    # Strip leading and trailing "_"
    result = slugified.strip('_')
    
    return result
