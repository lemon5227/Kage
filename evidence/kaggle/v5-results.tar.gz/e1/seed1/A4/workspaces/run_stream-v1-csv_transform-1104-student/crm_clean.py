import csv
import io

def tidy_csv(text):
    # Handle empty string
    if not text or not text.strip():
        return ''
    
    # Split into lines
    lines = text.strip().split('\n')
    
    # Check if header-only input
    if len(lines) == 1:
        return lines[0]
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    header = next(reader)
    
    # Expected columns: team, city, id, score
    expected_columns = ['team', 'city', 'id', 'score']
    
    # Validate header
    if header != expected_columns:
        raise ValueError(f"Expected header {expected_columns}, got {header}")
    
    # Process rows
    rows = []
    seen_teams = set()
    
    for row in reader:
        # Strip whitespace from each cell
        row = [cell.strip() for cell in row]
        
        # Skip if fewer columns than expected
        if len(row) < 4:
            continue
        
        team, city, id_val, score = row[0], row[1], row[2], row[3]
        
        # Drop rows whose "score" cell is empty
        if not score:
            continue
        
        # Remove duplicate rows by "team", keeping the first occurrence
        if team in seen_teams:
            continue
        seen_teams.add(team)
        
        rows.append(row)
    
    # Sort rows by "city" ascending as strings (stable)
    rows.sort(key=lambda r: r[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in rows:
        writer.writerow(row)
    
    return output.getvalue()
