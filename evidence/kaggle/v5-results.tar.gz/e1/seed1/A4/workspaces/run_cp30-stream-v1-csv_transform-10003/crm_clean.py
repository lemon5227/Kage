import csv
import io

def tidy_csv(text):
    """Clean an exported CSV table.
    
    Input: CSV text with a header row (columns: name, city, score, team)
    Output: Cleaned CSV text with the same header
    
    Cleaning steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Remove duplicate rows by "name", keeping the first occurrence
    4. Sort rows by "city" ascending as strings (stable)
    
    Returns empty string for empty input, header-only input returns just the header line.
    """
    # Parse the CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Check if header-only input
    if len(rows) == 1:
        return '\n'.join(header)
    
    # Process data rows (starting from index 1)
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)
    
    # Step 2: Drop rows whose "name" cell is empty
    # Assuming columns are: name, city, score, team (index 0, 1, 2, 3)
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) < 4:
            continue
        if row[0] == '':
            continue
        filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in filtered_rows:
        if len(row) < 4:
            continue
        name = row[0]
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Step 4: Sort rows by "city" ascending as strings (stable)
    # city is at index 1
    unique_rows.sort(key=lambda row: row[1])
    
    # Build output CSV text with '\n' line endings
    output = []
    output.append(','.join(header))
    for row in unique_rows:
        output.append(','.join(row))
    
    return '\n'.join(output)
