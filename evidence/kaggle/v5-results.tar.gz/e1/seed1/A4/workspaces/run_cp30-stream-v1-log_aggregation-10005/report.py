def summarize(lines):
    """
    Process log lines in format: <timestamp> <LEVEL> <service>: <message>
    Return dict mapping each service (for WARN level only) to count of lines.
    Levels are case-insensitive (reported upper-case). Skip malformed lines.
    Omit keys with zero count.
    """
    counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report upper-case
        service_part = parts[2]
        
        # Check if the service part contains a colon (service: message)
        if ':' not in service_part:
            continue
        
        # Extract service name (before the colon)
        service = service_part.split(':')[0]
        
        # Only count WARN level
        if level == 'WARN':
            counts[service] = counts.get(service, 0) + 1
    
    # Omit keys with zero count (already handled by not adding them)
    return counts
