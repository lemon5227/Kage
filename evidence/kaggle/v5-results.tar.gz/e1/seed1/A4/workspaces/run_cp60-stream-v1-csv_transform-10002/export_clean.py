import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text."""
    # Parse the CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Check if input is empty or header-only
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # If header-only input, return just the header line
    if len(rows) == 1:
        return '\n'.join(header)
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)
    
    # Step 2: Drop rows whose "name" cell is empty
    # Assuming columns: name, team, city, id, score
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) < 1 or row[0] == '':
            continue
        filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in filtered_rows:
        if len(row) < 5 or row[4] in seen_scores:
            continue
        seen_scores.add(row[4])
        unique_rows.append(row)
    
    # Step 4: Sort rows by "id" ascending as strings (stable)
    # Assuming columns: name, team, city, id, score
    sorted_rows = sorted(unique_rows, key=lambda row: row[3], reverse=False)
    
    # Step 5: Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in sorted_rows:
        writer.writerow(row)
    
    return output.getvalue()
