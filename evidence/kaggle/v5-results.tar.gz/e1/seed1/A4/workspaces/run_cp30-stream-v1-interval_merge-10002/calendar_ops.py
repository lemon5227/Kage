def coalesce(intervals):
    """Merge overlapping intervals.
    
    Args:
        intervals: List of dicts {"start": s, "end": e} with integer values.
        
    Returns:
        List of merged intervals sorted by start ascending.
        
    Raises:
        ValueError: If any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        if interval["start"] > interval["end"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last = merged[-1]
            # Check if intervals overlap or touch (end == start)
            if interval["start"] <= last["end"]:
                # Merge by updating the end to the maximum
                last["end"] = max(last["end"], interval["end"])
            else:
                merged.append(interval)
    
    return merged
