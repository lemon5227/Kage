import csv
import io


def clean_rows(text):
    """Clean an exported CSV table with specified rules."""
    # Parse the input text into a list of lines
    lines = text.strip().split('\n')
    
    if len(lines) == 0:
        return ''
    
    # Check if it's header-only
    if len(lines) == 1:
        # Strip whitespace from the header line
        header_line = lines[0].strip()
        if not header_line:
            return ''
        return header_line
    
    # Parse header
    header = lines[0].split(',')
    # Expected columns: score, id, city, team, name
    # We'll use these column names for processing
    
    # Parse data rows
    rows = []
    for i, line in enumerate(lines[1:], start=1):
        if not line.strip():
            continue
        cells = line.split(',')
        # Ensure we have enough columns
        if len(cells) < 5:
            continue
        row = {
            'score': cells[0].strip(),
            'id': cells[1].strip(),
            'city': cells[2].strip(),
            'team': cells[3].strip(),
            'name': cells[4].strip()
        }
        # Drop rows where team is empty
        if not row['team']:
            continue
        rows.append(row)
    
    # Remove duplicate rows by "city", keeping first occurrence
    seen_cities = set()
    unique_rows = []
    for row in rows:
        if row['city'] not in seen_cities:
            seen_cities.add(row['city'])
            unique_rows.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x['name'])
    
    # Write output using csv module with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for row in unique_rows:
        writer.writerow([
            row['score'],
            row['id'],
            row['city'],
            row['team'],
            row['name']
        ])
    
    return output.getvalue()
