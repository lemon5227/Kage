import csv
import io

def clean_rows(text):
    """
    Clean CSV text with a header row (columns: team, name, city, id, score).
    Returns cleaned CSV text with the same header.
    
    Operations in order:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "name" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = []
    for row in rows[1:]:
        # Strip whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Check if score is empty (drop such rows)
        if not cleaned_row[-1]:  # score is the last column
            continue
        
        data_rows.append(cleaned_row)
    
    # Remove duplicate rows by "score", keeping first occurrence
    seen_scores = set()
    unique_rows = []
    for row in data_rows:
        score = row[-1]
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    # name is at index 1
    unique_rows.sort(key=lambda row: row[1])
    
    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
