def coalesce(intervals):
    """Merge overlapping intervals.
    
    Each interval is a dict {"start": s, "end": e} with integer values.
    Return merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            # Check if intervals overlap or touch (end == start)
            if interval["start"] <= last["end"]:
                # Merge by updating the end of the last interval
                last["end"] = max(last["end"], interval["end"])
            else:
                merged.append(interval.copy())
    
    return merged
