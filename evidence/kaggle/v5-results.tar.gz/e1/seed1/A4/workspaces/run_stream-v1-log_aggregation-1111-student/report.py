def count_entries(lines):
    """Count entries by level in log lines.
    
    Each line looks like: "<timestamp> <LEVEL> <service>: <message>"
    Returns a dict mapping each level (upper-case) to its count.
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip malformed lines
        
        # Check format: timestamp, level, service: message
        # We need at least 3 parts: timestamp, level, and the rest
        # The level is the second part (index 1)
        level = parts[1].upper()
        
        # Validate that level is not empty
        if not level:
            continue
        
        counts[level] = counts.get(level, 0) + 1
    
    # Omit keys with zero count (already handled by not adding them)
    return counts
