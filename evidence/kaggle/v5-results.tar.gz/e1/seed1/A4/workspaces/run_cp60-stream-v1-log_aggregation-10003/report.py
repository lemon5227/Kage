def aggregate_log(lines):
    """Aggregate log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns {name: count} per service for levels ERROR, WARN only,
    treating level names case-insensitively (upper-case keys),
    dropping malformed input lines.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) < 3:
            # Malformed: need at least timestamp, level, and service
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Check if it's ERROR or WARN
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Extract service (third part, before the colon)
        service_part = parts[2]
        if ':' not in service_part:
            # Malformed: service should be followed by colon
            continue
        
        service = service_part.split(':')[0]
        
        # Count this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
