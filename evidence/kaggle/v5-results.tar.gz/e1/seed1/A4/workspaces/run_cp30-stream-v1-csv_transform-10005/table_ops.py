import csv
import io

def normalize_table(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with header row (columns: id, email, city, name)
    Output: Cleaned CSV text with the same header
    
    Rules:
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "id" cell is empty
    - Lower-case the "email" column
    - Remove duplicate rows by "email", keeping the first occurrence
    - Sort rows by "email" ascending as strings (stable)
    """
    # Parse CSV text into a list of rows
    lines = text.strip().split('\n')
    
    if len(lines) == 0:
        return ''
    
    # Parse header
    header = lines[0].split(',')
    if 'id' not in header or 'email' not in header:
        return text
    
    # Process data rows
    data_rows = []
    seen_emails = set()
    
    for line in lines[1:]:
        if not line.strip():
            continue
        
        cells = line.split(',')
        if len(cells) < len(header):
            continue
        
        # Strip whitespace from each cell
        cells = [cell.strip() for cell in cells]
        
        # Find column indices
        try:
            id_idx = header.index('id')
            email_idx = header.index('email')
        except ValueError:
            continue
        
        # Drop rows whose "id" cell is empty
        if not cells[id_idx]:
            continue
        
        # Lower-case the "email" column
        email = cells[email_idx].lower()
        
        # Remove duplicate rows by "email", keeping first occurrence
        if email in seen_emails:
            continue
        seen_emails.add(email)
        
        data_rows.append(cells)
    
    # Sort rows by "email" ascending as strings (stable)
    # We need to sort by the email column while maintaining stability
    # Python's sort is stable, so we can just sort by the email value
    data_rows.sort(key=lambda row: row[email_idx])
    
    # Build output CSV text
    output_lines = [','.join(header)]
    for row in data_rows:
        output_lines.append(','.join(row))
    
    return '\n'.join(output_lines)
