import csv
import io

def normalize_table(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with header row (columns: email, id, city, name)
    Output: Cleaned CSV text with the same header
    
    Cleaning steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "id", keeping the first occurrence
    5. Sort rows by "id" ascending as strings (stable)
    
    Returns: Cleaned CSV text with '\n' line endings
    """
    # Parse the CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Check if header has expected columns
    expected_cols = ['email', 'id', 'city', 'name']
    if len(header) != len(expected_cols):
        # If header doesn't match, use the actual headers
        pass
    
    # Process data rows
    data_rows = []
    seen_ids = set()
    
    for row in rows[1:]:
        # Strip whitespace from all cells
        cleaned_row = [cell.strip() for cell in row]
        
        if len(cleaned_row) < 4:
            continue
            
        email, id_val, city, name = cleaned_row[:4]
        
        # Drop rows whose "name" cell is empty
        if not name:
            continue
        
        # Lower-case the "email" column
        email = email.lower()
        
        # Remove duplicate rows by "id", keeping the first occurrence
        if id_val in seen_ids:
            continue
        seen_ids.add(id_val)
        
        data_rows.append((id_val, email, city, name))
    
    # Sort rows by "id" ascending as strings (stable)
    data_rows.sort(key=lambda x: x[0])
    
    # Build output CSV text
    output = []
    output.append(','.join(header))
    
    for id_val, email, city, name in data_rows:
        output.append(f"{email},{id_val},{city},{name}")
    
    return '\n'.join(output)
