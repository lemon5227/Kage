import csv
import io

def clean_rows(text):
    """
    Clean CSV text with a header row (columns: team, name, city, id, score).
    Returns cleaned CSV text with the same header.
    
    Operations in order:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "name" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Check if there's a header row
    if not rows:
        return ''
    
    header = rows[0]
    # Validate header columns
    expected_columns = ['team', 'name', 'city', 'id', 'score']
    if len(header) != len(expected_columns):
        # If header doesn't match, still process but use first column as score
        # For safety, we'll assume the last column is score
        pass
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    if not data_rows:
        # Only header, return just the header line
        return header[0] + '\n'
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)
    
    # Step 2: Drop rows whose "score" cell is empty
    # The score column is the last column (index -1)
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) < 5:
            continue  # Skip rows with insufficient columns
        score = row[-1]
        if not score:
            continue
        filtered_rows.append(row)
    
    if not filtered_rows:
        return header[0] + '\n'
    
    # Step 3: Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in filtered_rows:
        score = row[-1]
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    if not unique_rows:
        return header[0] + '\n'
    
    # Step 4: Sort rows by "name" ascending as strings (stable)
    # The name column is at index 1
    sorted_rows = sorted(unique_rows, key=lambda row: row[1])
    
    # Build output CSV text
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in sorted_rows:
        writer.writerow(row)
    
    return output.getvalue()
