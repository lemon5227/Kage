def coalesce(intervals):
    """Merge overlapping intervals. Each interval is a dict {"from": s, "to": e} with integer values.
    
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Raises ValueError if any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        from_val = interval["from"]
        to_val = interval["to"]
        if from_val > to_val:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last = merged[-1]
            # Check if intervals overlap (not just touching)
            # Overlap occurs if current start < last end
            if interval["from"] < last["to"]:
                # Merge by updating the end to the maximum of both ends
                merged[-1]["to"] = max(last["to"], interval["to"])
            else:
                # No overlap, add new interval
                merged.append(interval)
    
    return merged
