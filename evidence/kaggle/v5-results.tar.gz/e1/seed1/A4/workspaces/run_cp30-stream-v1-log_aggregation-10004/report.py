def digest_lines(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    - Level case may vary and must be upper-cased
    - Ignore lines that do not match the format
    
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # Split by spaces to get parts
        parts = line.split()
        if len(parts) < 3:
            continue
        
        # Check format: timestamp, level, service: message
        # First part is timestamp (any string)
        # Second part is level (must be a string, will be upper-cased)
        # Third part must start with "service:"
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        
        # Check if third part starts with "service:"
        if not parts[2].startswith("service:"):
            continue
        
        # Valid line, count the level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
