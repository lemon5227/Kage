def aggregate_log(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match.
    
    Returns a plain dict of counts.
    """
    level_counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip lines that don't have at least timestamp, level, service
        
        # Check if the third part matches the pattern "<service>: <message>"
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # So parts[0] = timestamp, parts[1] = LEVEL, parts[2] should start with service name followed by colon
        if not parts[2].startswith(':'):
            continue  # Skip lines that don't match the pattern
        
        level = parts[1].upper()
        level_counts[level] = level_counts.get(level, 0) + 1
    
    return level_counts
