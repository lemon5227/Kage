def digest_lines(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    - Level case may vary and must be upper-cased
    - Ignore lines that do not match the format
    - Returns a plain dict of counts: {level: count}
    """
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, and service: message
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1]
        
        # Validate that the level is a valid log level (common ones: DEBUG, INFO, WARN, ERROR, FATAL)
        # We'll accept any non-empty string as a level, but we'll upper-case it
        if not level:
            continue
        
        # Upper-case the level
        level = level.upper()
        
        # Increment count for this level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    return level_counts
