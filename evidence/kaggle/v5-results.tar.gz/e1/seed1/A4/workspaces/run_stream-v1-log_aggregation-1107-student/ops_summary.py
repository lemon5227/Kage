def count_entries(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip lines that don't match the format
        
        # Extract level from second token and convert to uppercase
        level = parts[1].upper()
        
        # Only count if level is not empty (non-zero length)
        if level:
            counts[level] = counts.get(level, 0) + 1
    
    return counts
