import sys
sys.path.insert(0, '.')
from crm_clean import normalize_table

# Test 1: Basic functionality with duplicates
test1 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,test@example.com,Jane"
print("Test 1 (duplicates):")
result = normalize_table(test1)
print(result)
print()

# Test 2: Single row
test2 = "score,id,email,name\n1,abc,test@example.com,John"
print("Test 2 (single row):")
result = normalize_table(test2)
print(result)
print()

# Test 3: Header only
test3 = "score,id,email,name"
print("Test 3 (header only):")
result = normalize_table(test3)
print(result)
print()

# Test 4: Empty input
test4 = ""
print("Test 4 (empty):")
result = normalize_table(test4)
print(repr(result))
print()

# Test 5: Row with empty name
test5 = "score,id,email,name\n1,abc,test@example.com,\n2,def,test@example.com,John"
print("Test 5 (empty name):")
result = normalize_table(test5)
print(result)
print()

# Test 6: Whitespace handling
test6 = " score , id , email , name \n 1 , abc , TEST@EXAMPLE.COM , JOHN "
print("Test 6 (whitespace):")
result = normalize_table(test6)
print(result)
print()
