from crm_clean import normalize_table

# Test 1: Basic functionality with duplicates
test1 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,test@example.com,Jane"
print("Test 1 (duplicates):")
print(normalize_table(test1))

# Test 2: Single row
test2 = "score,id,email,name\n1,abc,test@example.com,John"
print("\nTest 2 (single row):")
print(normalize_table(test2))

# Test 3: Header only
test3 = "score,id,email,name"
print("\nTest 3 (header only):")
print(normalize_table(test3))

# Test 4: Empty input
test4 = ""
print("\nTest 4 (empty):")
print(repr(normalize_table(test4)))

# Test 5: Row with empty name
test5 = "score,id,email,name\n1,abc,test@example.com,\n2,def,test@example.com,John"
print("\nTest 5 (empty name):")
print(normalize_table(test5))

# Test 6: Whitespace handling
test6 = " score , id , email , name \n 1 , abc , TEST@EXAMPLE.COM , JOHN "
print("\nTest 6 (whitespace):")
print(normalize_table(test6))
