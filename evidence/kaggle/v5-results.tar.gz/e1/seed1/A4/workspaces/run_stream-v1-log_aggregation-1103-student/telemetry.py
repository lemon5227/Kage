def summarize(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split by whitespace
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Validate that level is not empty
        if not level:
            continue
        
        # Count the level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
