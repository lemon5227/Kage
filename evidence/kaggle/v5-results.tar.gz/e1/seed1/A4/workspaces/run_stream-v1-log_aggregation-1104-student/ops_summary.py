def tally_events(lines):
    """Tally events by level from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns a dictionary mapping level names (uppercase) to counts.
    Malformed lines are dropped.
    """
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Check format: first part is timestamp, second is LEVEL, third should contain ':'
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, use uppercase
        
        # Validate that the third part contains a colon (service: message)
        if len(parts) < 3 or ':' not in parts[2]:
            continue
        
        # Valid line - increment count for this level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    return level_counts
