def combine_ranges(intervals):
    """
    Merge overlapping intervals. Each interval is a dict {"begin": s, "finish": e}
    with integer values. Return merged intervals as dicts with the same "begin"/"finish" keys,
    sorted by start ascending. Touching intervals like [1,3] and [3,5] should be merged.
    Raise ValueError if any interval has start > end. Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        begin = interval["begin"]
        finish = interval["finish"]
        if begin > finish:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by begin value
    sorted_intervals = sorted(intervals, key=lambda x: x["begin"])
    
    if not sorted_intervals:
        return []
    
    merged = [sorted_intervals[0].copy()]
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # Check if intervals overlap or touch (current begin <= last finish)
        if current["begin"] <= last["finish"]:
            # Merge them
            last["finish"] = max(last["finish"], current["finish"])
        else:
            merged.append(current.copy())
    
    return merged
