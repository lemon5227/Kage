def merge_slots(intervals):
    # Validate intervals and sort by start
    if not intervals:
        return []
    
    # Check for invalid intervals (start > end)
    for interval in intervals:
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start value
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last = merged[-1]
            # Check if intervals overlap or touch (last['to'] >= current['from'])
            if last["to"] >= interval["from"]:
                # Merge them
                merged[-1]["to"] = max(last["to"], interval["to"])
            else:
                merged.append(interval)
    
    return merged
