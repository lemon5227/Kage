def tally_events(lines):
    counts = {}
    for line in lines:
        parts = line.strip().split()
        if len(parts) < 3:
            continue  # malformed line
        # Format: <timestamp> <LEVEL> <service>: <message>
        # parts[0] = timestamp, parts[1] = LEVEL, parts[2] = service
        level = parts[1].upper()  # case-insensitive, use upper-case key
        counts[level] = counts.get(level, 0) + 1
    return counts
