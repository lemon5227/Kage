def merge_bookings(intervals):
    return None
