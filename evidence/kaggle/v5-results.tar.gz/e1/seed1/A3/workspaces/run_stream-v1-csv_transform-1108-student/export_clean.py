import csv
import io


def normalize_table(text):
    """
    Process CSV text with header row (columns: team, name, score).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "team" cell is empty
    3. Remove duplicate rows by "team", keeping the first occurrence
    4. Sort rows by "name" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Parse the CSV text
    lines = text.strip().split('\n')
    
    if not lines:
        return ''
    
    # Check if it's header-only
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    if len(header) != 3 or header[0] != 'team' or header[1] != 'name' or header[2] != 'score':
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) != 3:
            continue
        
        team, name, score = cells
        
        # Strip leading/trailing whitespace from every cell
        team = team.strip()
        name = name.strip()
        score = score.strip()
        
        # Drop rows whose "team" cell is empty
        if not team:
            continue
        
        rows.append((team, name, score))
    
    # Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    unique_rows = []
    for row in rows:
        if row[0] not in seen_teams:
            seen_teams.add(row[0])
            unique_rows.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x[1])
    
    # Build output CSV text
    output_lines = [','.join(header)]
    for row in unique_rows:
        output_lines.append(','.join(row))
    
    return '\n'.join(output_lines)


if __name__ == '__main__':
    # Test examples
    test1 = "team,name,score\nA,Team A,10\nB,Team B,20\nA,Team A,15"
    print(normalize_table(test1))
    
    test2 = "team,name,score\nA,Team A,10"
    print(normalize_table(test2))
    
    test3 = "team,name,score"
    print(normalize_table(test3))
    
    test4 = ""
    print(normalize_table(test4))
