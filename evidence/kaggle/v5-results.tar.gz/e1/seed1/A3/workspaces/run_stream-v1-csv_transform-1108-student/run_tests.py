#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')
from export_clean import normalize_table

# Test 1: Basic functionality with duplicates
test1 = "team,name,score\nA,Team A,10\nB,Team B,20\nA,Team A,15"
result1 = normalize_table(test1)
print("Test 1:")
print(result1)
print()

# Test 2: Header-only input
test2 = "team,name,score"
result2 = normalize_table(test2)
print("Test 2:")
print(result2)
print()

# Test 3: Empty string
test3 = ""
result3 = normalize_table(test3)
print("Test 3:")
print(repr(result3))
print()

# Test 4: Whitespace handling
test4 = " team , name , score \n A , Team A , 10 \n B , Team B , 20 "
result4 = normalize_table(test4)
print("Test 4:")
print(result4)
print()

# Test 5: Sorting by name
test5 = "team,name,score\nB,Team B,20\nA,Team A,10\nC,Team C,30"
result5 = normalize_table(test5)
print("Test 5:")
print(result5)
