import csv
import io

def tidy_csv(text):
    # Handle empty string
    if not text or not text.strip():
        return ''
    
    # Split into lines
    lines = text.strip().split('\n')
    
    # Check if header-only input
    if len(lines) == 1:
        return lines[0]
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # First row is header
    header = rows[0]
    
    # Process data rows
    data_rows = []
    for row in rows[1:]:
        # Strip whitespace from each cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip if name is empty
        if not cleaned_row[3]:  # name is at index 3
            continue
        
        data_rows.append(cleaned_row)
    
    # Remove duplicates by name, keeping first occurrence
    seen_names = set()
    unique_rows = []
    for row in data_rows:
        name = row[3]
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Sort by name ascending (stable sort)
    unique_rows.sort(key=lambda row: row[3])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
