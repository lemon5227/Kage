def allocate(items, capacity):
    """
    Select projects to maximize total value while total weight stays <= capacity.
    Returns sorted list of ids. If tie on total value, return lexicographically smallest sorted id list.
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "weight" not in item or "value" not in item or "id" not in item:
            raise ValueError("Each item must have 'id', 'weight', and 'value' keys")
        if not isinstance(item["id"], str):
            raise ValueError("Item id must be a string")
        if not isinstance(item["weight"], int) or item["weight"] <= 0:
            raise ValueError("Weight must be a positive integer")
        if not isinstance(item["value"], int) or item["value"] < 0:
            raise ValueError("Value must be a non-negative integer")
    
    if not items:
        return []
    
    n = len(items)
    # dp[w] = (max_value, set of ids achieving that value) for weight w
    # We'll track all possible id sets for each weight to handle tie-breaking
    
    # Initialize: dp[0] = ([], [])  # empty set, value 0
    # Actually we need to track which items were selected for each weight
    
    # Use a different approach: dp[w] = (max_value, list of ids)
    # But we need to handle tie-breaking: if multiple selections give same max value,
    # choose the lexicographically smallest sorted id list
    
    # Let's use dp[w] = (max_value, best_ids) where best_ids is the lexicographically smallest
    # among all selections with that weight and max_value
    
    # Initialize dp[0] = (0, [])
    dp = [(0, []) for _ in range(capacity + 1)]
    
    # Process each item
    for item in items:
        item_id = item["id"]
        weight = item["weight"]
        value = item["value"]
        
        # Traverse backwards to avoid using the same item multiple times
        for w in range(capacity, weight - 1, -1):
            # Option 1: don't include this item
            # Option 2: include this item (if w >= weight)
            current_max = dp[w][0]
            
            if w >= weight:
                # Check if including this item gives better value
                new_value = dp[w - weight][0] + value
                if new_value > current_max:
                    # Better value, update
                    dp[w] = (new_value, dp[w - weight][1] + [item_id])
                elif new_value == current_max:
                    # Same value, choose lexicographically smaller id list
                    new_ids = sorted(dp[w - weight][1] + [item_id])
                    if new_ids < dp[w][1]:
                        dp[w] = (new_value, new_ids)
            # else: cannot include this item at weight w
    
    # Find the maximum value among all weights <= capacity
    max_value = 0
    best_ids = []
    
    for w in range(capacity + 1):
        if dp[w][0] > max_value:
            max_value = dp[w][0]
            best_ids = dp[w][1]
        elif dp[w][0] == max_value:
            # Same value, choose lexicographically smaller
            if dp[w][1] < best_ids:
                best_ids = dp[w][1]
    
    return best_ids
