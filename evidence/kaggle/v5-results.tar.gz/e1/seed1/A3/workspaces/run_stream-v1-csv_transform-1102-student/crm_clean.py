import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # Drop rows whose "name" cell is empty
    cleaned = [row for row in cleaned if len(row) > 0 and row[2] != ""]

    # Remove duplicate rows by "id", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        id_val = row[1]
        if id_val in seen:
            continue
        seen.add(id_val)
        deduped.append(row)

    # Sort by "id" ascending as strings (stable)
    def id_key(row):
        return row[1] if len(row) > 1 else ""

    deduped.sort(key=id_key)

    # Lower-case the "email" column
    for row in deduped:
        if len(row) > 0:
            row[0] = row[0].lower()

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()
