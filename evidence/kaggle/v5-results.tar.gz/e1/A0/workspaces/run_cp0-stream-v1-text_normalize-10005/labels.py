def to_key(text):
    return None
