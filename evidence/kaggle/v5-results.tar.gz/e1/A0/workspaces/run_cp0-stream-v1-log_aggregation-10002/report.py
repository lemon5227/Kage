def digest_lines(lines):
    """Process log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per level, treating level names case-insensitively (upper-case keys),
    dropping malformed input lines."""
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Malformed: need at least timestamp, level, and service
            continue
        # Extract level from parts[1]
        level = parts[1].upper()
        # Check if there's a service part (parts[2] should be the service name)
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # So we need at least 3 parts, and parts[2] should contain the service name
        # We'll just count by level regardless of service validity
        counts[level] = counts.get(level, 0) + 1
    return counts
