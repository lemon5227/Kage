def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per service for levels ERROR, WARN only, case-insensitive (upper-case keys).
    Drops malformed input lines."""
    result = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split by spaces to get parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part) and service (third part)
        level = parts[1].upper()
        service = parts[2]
        
        # Only count ERROR and WARN levels
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Increment count for this service
        result[service] = result.get(service, 0) + 1
    
    return result
