def merge_slots(intervals):
    # Validate all intervals first
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        if interval["from"] > interval["to"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start value
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last = merged[-1]
            # Check if intervals overlap or touch (last['to'] >= current['from'])
            if last["to"] >= interval["from"]:
                # Merge them
                merged[-1] = {"from": last["from"], "to": max(last["to"], interval["to"])}
            else:
                merged.append(interval)
    
    return merged
