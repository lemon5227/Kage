import re

def digest_lines(lines):
    counts = {}
    # Pattern: <timestamp> <LEVEL> <service>: <message>
    pattern = r'^\s*.*?\s*(\S+)\s+\S+:\s*.*$'
    for line in lines:
        if not line.strip():
            continue
        match = re.match(pattern, line)
        if match:
            level = match.group(1).upper()
            counts[level] = counts.get(level, 0) + 1
    return counts
