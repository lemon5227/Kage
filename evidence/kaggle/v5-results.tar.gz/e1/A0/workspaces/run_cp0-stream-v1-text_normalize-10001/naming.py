def slugify(text):
    return None
