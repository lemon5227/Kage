def upgrade_config(cfg):
    return None
