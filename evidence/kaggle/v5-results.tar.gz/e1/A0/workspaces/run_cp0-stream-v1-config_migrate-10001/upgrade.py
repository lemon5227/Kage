def convert_settings(cfg):
    return None
