import csv, io

def run(arguments, context):
    target = arguments['target_file']
    fn = arguments['function_name']
    key_col = arguments['key_column']
    sort_col = arguments['sort_column']
    lower_col = arguments.get('lower_column') or ''
    term = arguments.get('line_terminator', '\n')
    src = (
        'import csv\nimport io\n\n\n'
        'def ' + fn + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    data = [[c.strip() for c in r] for r in rows[1:]]\n'
        '    ki = header.index(' + repr(key_col) + ')\n'
        '    data = [r for r in data if r[ki] != ""]\n'
        '    lc = ' + repr(lower_col) + '\n'
        '    if lc:\n'
        '        li = header.index(lc)\n'
        '        for r in data:\n'
        '            r[li] = r[li].lower()\n'
        '    seen = set()\n'
        '    ded = []\n'
        '    for r in data:\n'
        '        k = r[ki]\n'
        '        if k in seen:\n'
        '            continue\n'
        '        seen.add(k)\n'
        '        ded.append(r)\n'
        '    si = header.index(' + repr(sort_col) + ')\n'
        '    ded.sort(key=lambda r: r[si])\n'
        '    out = io.StringIO()\n'
        '    w = csv.writer(out, lineterminator=' + repr(term) + ')\n'
        '    w.writerow(header)\n'
        '    w.writerows(ded)\n'
        '    return out.getvalue()\n'
    )
    path = context['workspace_dir'].rstrip('/') + '/' + target
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
