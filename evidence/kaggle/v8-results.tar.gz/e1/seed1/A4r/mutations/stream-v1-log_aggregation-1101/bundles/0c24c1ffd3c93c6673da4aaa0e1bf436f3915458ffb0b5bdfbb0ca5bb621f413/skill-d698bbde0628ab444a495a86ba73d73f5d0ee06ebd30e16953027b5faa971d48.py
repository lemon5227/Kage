def run(arguments, context):
    import os
    target = arguments['target_file']
    fname = arguments['function_name']
    group_field = arguments.get('group_field', 'service')
    allowed = arguments.get('allowed_levels')
    norm = arguments.get('normalize_upper', True)
    allowed_repr = repr([str(x).upper() for x in allowed]) if allowed else 'None'
    src = (
        'def ' + fname + '(lines):\n'
        '    allowed = ' + allowed_repr + '\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < 3:\n'
        '            continue\n'
        '        ts, level, rest = parts[0], parts[1], parts[2]\n'
        '        if not rest.endswith(":"):\n'
        '            continue\n'
        '        service = rest[:-1]\n'
        '        if not service:\n'
        '            continue\n'
        '        lvl = level.upper()\n'
        '        if allowed is not None and lvl not in allowed:\n'
        '            continue\n'
        '        field = ' + repr(group_field) + '\n'
        '        if field == "level":\n'
        '            key = lvl\n'
        '        elif field == "timestamp":\n'
        '            key = ts\n'
        '        else:\n'
        '            key = service\n'
        '        if ' + repr(norm) + ' and field != "timestamp":\n'
        '            key = key.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
