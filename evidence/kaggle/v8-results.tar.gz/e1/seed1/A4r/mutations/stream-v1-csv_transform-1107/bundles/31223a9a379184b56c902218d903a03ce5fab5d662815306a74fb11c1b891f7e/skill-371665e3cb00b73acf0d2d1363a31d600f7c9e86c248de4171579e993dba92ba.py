import os


def run(arguments, context):
    target = arguments['target_file']
    fn = arguments['function_name']
    key_col = arguments['key_column']
    sort_col = arguments['sort_column']
    term = arguments.get('line_terminator', '\n')
    src = (
        'import csv\n'
        'import io\n'
        '\n'
        '\n'
        'def {fn}(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    data = [[c.strip() for c in r] for r in rows[1:]]\n'
        '    ki = header.index({key!r}) if {key!r} in header else None\n'
        '    si = header.index({sort!r}) if {sort!r} in header else None\n'
        '    if ki is not None:\n'
        '        data = [r for r in data if ki < len(r) and r[ki] != ""]\n'
        '        seen = set()\n'
        '        ded = []\n'
        '        for r in data:\n'
        '            k = r[ki] if ki < len(r) else ""\n'
        '            if k in seen:\n'
        '                continue\n'
        '            seen.add(k)\n'
        '            ded.append(r)\n'
        '        data = ded\n'
        '    if si is not None:\n'
        '        data.sort(key=lambda r: r[si] if si < len(r) else "")\n'
        '    out = io.StringIO()\n'
        '    w = csv.writer(out, lineterminator={term!r})\n'
        '    w.writerow(header)\n'
        '    w.writerows(data)\n'
        '    return out.getvalue()\n'
    ).format(fn=fn, key=key_col, sort=sort_col, term=term)
    path = os.path.join(context['workspace_dir'], target)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
