import csv, io

def run(arguments, context):
    tf = arguments['target_file']
    fn = arguments['function_name']
    key = arguments['key_column']
    sort = arguments['sort_column']
    lower = arguments.get('lower_column', '')
    lt = arguments.get('line_terminator', '\n')
    src = (
        'import csv\nimport io\n\n'
        'def ' + fn + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    data = rows[1:]\n'
        '    cleaned = []\n'
        '    for row in data:\n'
        '        cells = [c.strip() for c in row]\n'
        '        if len(cells) < len(header):\n'
        '            cells += [""] * (len(header) - len(cells))\n'
        '        elif len(cells) > len(header):\n'
        '            cells = cells[:len(header)]\n'
        '        cleaned.append(cells)\n'
        '    ki = header.index(' + repr(key) + ')\n'
        '    si = header.index(' + repr(sort) + ')\n'
        '    cleaned = [r for r in cleaned if r[ki] != ""]\n'
        + (('    li = header.index(' + repr(lower) + ')\n'
            '    for r in cleaned:\n'
            '        r[li] = r[li].lower()\n') if lower else '')
        + '    seen = set()\n'
        '    deduped = []\n'
        '    for r in cleaned:\n'
        '        if r[ki] in seen:\n'
        '            continue\n'
        '        seen.add(r[ki])\n'
        '        deduped.append(r)\n'
        '    deduped.sort(key=lambda r: r[si])\n'
        '    out = io.StringIO()\n'
        '    w = csv.writer(out, lineterminator=' + repr(lt) + ')\n'
        '    w.writerow(header)\n'
        '    w.writerows(deduped)\n'
        '    return out.getvalue()\n'
    )
    path = context['workspace_dir'] + '/' + tf
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': tf, 'bytes_written': len(src)}
