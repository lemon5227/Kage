def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    field = arguments.get('group_field', 'level')
    upper = arguments.get('normalize_upper', True)
    idx = {'timestamp': 0, 'level': 1, 'service': 2}.get(field, 1)
    norm = '.upper()' if upper else ''
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split(None, 2)\n'
        '        if len(parts) < 3 or ":" not in parts[2]:\n'
        '            continue\n'
        '        service, _, message = parts[2].partition(":")\n'
        '        fields = [parts[0], parts[1], service]\n'
        '        key = fields[' + str(idx) + ']' + norm + '\n'
        '        if not key:\n'
        '            continue\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
