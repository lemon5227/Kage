import csv, io

def run(arguments, context):
    target = arguments['target_file']
    fn = arguments['function_name']
    key_col = arguments['key_column']
    sort_col = arguments['sort_column']
    term = arguments.get('line_terminator', '\n')
    src = (
        'import csv\nimport io\n\n\n'
        'def ' + fn + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    ki = header.index(' + repr(key_col) + ')\n'
        '    si = header.index(' + repr(sort_col) + ')\n'
        '    data = [[c.strip() for c in r] for r in rows[1:]]\n'
        '    data = [r for r in data if len(r) > ki and r[ki] != ""]\n'
        '    seen = set()\n'
        '    deduped = []\n'
        '    for r in data:\n'
        '        if r[ki] in seen:\n'
        '            continue\n'
        '        seen.add(r[ki])\n'
        '        deduped.append(r)\n'
        '    deduped.sort(key=lambda r: r[si] if len(r) > si else "")\n'
        '    out = io.StringIO()\n'
        '    w = csv.writer(out, lineterminator=' + repr(term) + ')\n'
        '    w.writerow(header)\n'
        '    for r in deduped:\n'
        '        w.writerow(r)\n'
        '    return out.getvalue()\n'
    )
    path = context['workspace_dir'].rstrip('/') + '/' + target
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
