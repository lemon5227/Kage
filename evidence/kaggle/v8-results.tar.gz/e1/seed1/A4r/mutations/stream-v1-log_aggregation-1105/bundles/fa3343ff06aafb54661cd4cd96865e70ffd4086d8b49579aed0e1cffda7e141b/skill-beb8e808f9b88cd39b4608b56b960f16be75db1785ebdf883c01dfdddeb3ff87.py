import json

def run(arguments, context):
    ws = context['workspace_dir']
    tf = arguments['target_file']
    fn = arguments['function_name']
    gf = arguments.get('group_field', 'service')
    allowed = arguments.get('allowed_levels', [])
    norm = arguments.get('normalize_upper', True)
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split(" ", 2)\n'
        '        if len(parts) != 3:\n'
        '            continue\n'
        '        timestamp, level, rest = parts\n'
        '        if not timestamp or not level:\n'
        '            continue\n'
        '        if ":" not in rest:\n'
        '            continue\n'
        '        service, message = rest.split(":", 1)\n'
        '        service = service.strip()\n'
        '        if not service:\n'
        '            continue\n'
        '        level = level.upper()\n'
        '        if ' + repr(allowed) + ' and level not in ' + repr(allowed) + ':\n'
        '            continue\n'
        '        fields = {"timestamp": timestamp, "level": level, "service": service}\n'
        '        key = fields[' + repr(gf) + ']\n'
        '        if ' + repr(norm) + ':\n'
        '            key = key.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = ws.rstrip('/') + '/' + tf
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': tf, 'bytes_written': len(src)}
