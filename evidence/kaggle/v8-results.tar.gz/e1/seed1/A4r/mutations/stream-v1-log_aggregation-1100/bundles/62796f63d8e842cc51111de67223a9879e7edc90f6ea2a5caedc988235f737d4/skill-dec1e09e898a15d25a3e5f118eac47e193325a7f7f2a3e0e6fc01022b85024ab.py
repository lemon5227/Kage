def run(arguments, context):
    import os
    target = arguments['target_file']
    fname = arguments['function_name']
    group_field = arguments.get('group_field', 'level')
    level_filter = arguments.get('level_filter', '')
    normalize_upper = arguments.get('normalize_upper', True)
    src = '''def {fname}(lines):
    counts = {{}}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        timestamp, level, rest = parts
        if ":" not in rest:
            continue
        service, _sep, _message = rest.partition(":")
        service = service.strip()
        if not service:
            continue
        if {level_filter!r} and level.upper() != {level_filter!r}.upper():
            continue
        field_map = {{"level": level, "service": service, "timestamp": timestamp}}
        key = field_map.get({group_field!r}, level)
        if {normalize_upper!r}:
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
'''.format(fname=fname, level_filter=level_filter, group_field=group_field, normalize_upper=normalize_upper)
    path = os.path.join(context['workspace_dir'], target)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
