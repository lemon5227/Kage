import csv
import io


def dedupe_export(text):
    """
    Process CSV text according to the following rules:
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "name" cell is empty
    - Lower-case the "email" column
    - Remove duplicate rows by "team", keeping the first occurrence
    - Sort rows by "id" ascending as strings (stable)
    
    Args:
        text: CSV text with a header row (columns: city, email, name, id, team)
    
    Returns:
        Cleaned CSV text with the same header
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Check if there's only a header row
    if len(rows) == 1:
        # Return just the header line
        return rows[0][0] + ',' + rows[0][1] + ',' + rows[0][2] + ',' + rows[0][3] + ',' + rows[0][4]
    
    # Extract header
    header = rows[0]
    
    # Process data rows (starting from index 1)
    data_rows = []
    
    for row in rows[1:]:
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Check if "name" cell is empty
        if cleaned_row[2] == '':
            continue
        
        # Lower-case the "email" column (index 1)
        cleaned_row[1] = cleaned_row[1].lower()
        
        data_rows.append(cleaned_row)
    
    # Deduplicate by "team" (index 4), keeping first occurrence
    seen_teams = set()
    deduped_rows = []
    for row in data_rows:
        team = row[4]
        if team not in seen_teams:
            seen_teams.add(team)
            deduped_rows.append(row)
    
    # Sort by "id" (index 3) ascending as strings (stable)
    deduped_rows.sort(key=lambda row: row[3])
    
    # Write output CSV with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()
