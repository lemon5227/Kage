def coalesce(intervals):
    # Validate intervals
    for interval in intervals:
        if interval["start"] > interval["end"]:
            raise ValueError("Interval start > end")
    
    # Sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            if interval["start"] <= last["end"]:  # Overlapping or touching
                # Merge by updating the end to the max of both ends
                last["end"] = max(last["end"], interval["end"])
            else:
                merged.append(interval.copy())
    
    return merged
