def coalesce(intervals):
    """Merge overlapping intervals in a list of dicts with 'from' and 'to' keys.
    
    Args:
        intervals: List of dicts {"from": s, "to": e} with integer values
        
    Returns:
        List of merged dicts sorted by start ascending
        
    Raises:
        ValueError: If any interval has start > end
    """
    # Validate all intervals first
    for interval in intervals:
        if not isinstance(interval, dict) or 'from' not in interval or 'to' not in interval:
            raise ValueError("Each interval must be a dict with 'from' and 'to' keys")
        s = interval['from']
        e = interval['to']
        if not isinstance(s, int) or not isinstance(e, int):
            raise ValueError("Interval values must be integers")
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
    
    if not intervals:
        return []
    
    # Sort by 'from' (start) ascending
    sorted_intervals = sorted(intervals, key=lambda x: x['from'])
    
    merged = [sorted_intervals[0]]
    
    for current in sorted_intervals[1:]:
        prev = merged[-1]
        # Check if intervals overlap: current['from'] < prev['to'] (strictly less than)
        # Touching intervals like [1,3] and [3,5] are NOT merged because 3 < 3 is False
        if current['from'] < prev['to']:
            # Merge them
            prev['to'] = max(prev['to'], current['to'])
        else:
            # No overlap, add current interval
            merged.append(current)
    
    return merged
