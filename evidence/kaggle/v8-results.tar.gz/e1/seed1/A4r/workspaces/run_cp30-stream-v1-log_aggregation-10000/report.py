def count_entries(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3 or ":" not in parts[2]:
            continue
        service, _, message = parts[2].partition(":")
        fields = [parts[0], parts[1], service]
        key = fields[1].upper()
        if not key:
            continue
        counts[key] = counts.get(key, 0) + 1
    return counts
