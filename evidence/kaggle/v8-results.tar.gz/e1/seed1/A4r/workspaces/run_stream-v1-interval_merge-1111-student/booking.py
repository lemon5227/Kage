def coalesce(intervals):
    """Combine overlapping time ranges in intervals."""
    # Validate intervals
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Interval {start}, {end} has start > end")
    
    # Sort by start (and end for stability)
    sorted_intervals = sorted(intervals, key=lambda x: (x[0], x[1]))
    
    # Merge overlapping intervals
    merged = []
    if not sorted_intervals:
        return merged
    
    current_start, current_end = sorted_intervals[0]
    
    for next_start, next_end in sorted_intervals[1:]:
        # Overlap occurs if next_start < current_end (strictly less than)
        if next_start < current_end:
            # Merge by extending the end
            current_end = max(current_end, next_end)
        else:
            # No overlap, add current interval and start new one
            merged.append([current_start, current_end])
            current_start, current_end = next_start, next_end
    
    # Add the last interval
    merged.append([current_start, current_end])
    
    return merged
