def dedupe_export(text):
    """
    Clean CSV text with header row (columns: id, email, score, team, city).
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "email", keeping the first occurrence
    5. Sort rows by "score" ascending as strings (stable)
    
    Returns cleaned CSV text with the same header.
    """
    import csv
    from io import StringIO
    
    # Parse the CSV text
    reader = csv.reader(StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ""
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = []
    for row in rows[1:]:
        # Strip whitespace from all cells
        cleaned_row = [cell.strip() for cell in row]
        
        # Check if score is empty (drop such rows)
        if not cleaned_row[2]:  # score is at index 2
            continue
        
        # Lower-case the email column (index 1)
        cleaned_row[1] = cleaned_row[1].lower()
        
        data_rows.append(cleaned_row)
    
    # Remove duplicates by email (index 1), keeping first occurrence
    seen_emails = set()
    unique_rows = []
    for row in data_rows:
        email = row[1]
        if email not in seen_emails:
            seen_emails.add(email)
            unique_rows.append(row)
    
    # Sort by score (index 2) ascending as strings (stable sort)
    # Using Python's stable sort with key=str
    sorted_rows = sorted(unique_rows, key=lambda row: str(row[2]))
    
    # Write output CSV with \n line endings
    output = StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in sorted_rows:
        writer.writerow(row)
    
    return output.getvalue()
