import csv
import io

def tidy_csv(text):
    # Handle empty string
    if not text or not text.strip():
        return ''
    
    # Split into lines
    lines = text.strip().split('\n')
    
    # If only header, return it
    if len(lines) == 1:
        return lines[0]
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Check if first row is header
    if not rows:
        return ''
    
    header = rows[0]
    # Verify columns: score, id, team, name
    expected_cols = ['score', 'id', 'team', 'name']
    if len(header) != 4 or header != expected_cols:
        # If not matching, still process but use index 3 for name
        pass
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        # Check if name (index 3) is empty
        if not stripped_row[3]:
            continue
        cleaned_rows.append(stripped_row)
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in cleaned_rows:
        name = row[3]
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row[3])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
