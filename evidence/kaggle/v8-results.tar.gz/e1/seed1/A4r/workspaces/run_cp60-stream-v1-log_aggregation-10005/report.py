def summarize(lines):
    return {}
