import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = rows[1:]
    
    # Ensure all rows have the same number of columns as header
    cleaned = []
    for row in data:
        cells = [c.strip() for c in row]
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[:len(header)]
        cleaned.append(cells)
    
    # Find indices
    team_idx = header.index('team')
    city_idx = header.index('city')
    id_idx = header.index('id')
    
    # Drop rows whose "team" cell is empty
    cleaned = [r for r in cleaned if r[team_idx] != ""]
    
    # Remove duplicate rows by "city", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        if r[city_idx] in seen:
            continue
        seen.add(r[city_idx])
        deduped.append(r)
    
    # Sort rows by "id" ascending as strings (stable)
    deduped.sort(key=lambda r: r[id_idx])
    
    # Write output with '\n' line endings
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    w.writerows(deduped)
    return out.getvalue()
