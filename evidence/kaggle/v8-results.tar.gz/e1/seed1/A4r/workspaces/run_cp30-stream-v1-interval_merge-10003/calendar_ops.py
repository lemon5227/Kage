def merge_slots(intervals):
    """
    Merge overlapping time ranges. Each interval is a dict {"start": s, "end": e} with integer values.
    Return merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        if interval["start"] > interval["end"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping or touching intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            # Check if current interval overlaps or touches the last interval
            if interval["start"] <= last["end"]:
                # Merge by updating the end to the maximum of both ends
                last["end"] = max(last["end"], interval["end"])
            else:
                merged.append(interval.copy())
    
    return merged
