def coalesce(intervals):
    # Validate intervals and sort by 'from'
    if not intervals:
        return []
    
    # Check for invalid intervals (start > end)
    for interval in intervals:
        if interval["from"] > interval["to"]:
            raise ValueError("Interval start > end")
    
    # Sort by 'from'
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last = merged[-1]
            # Check for real overlap (not just touching)
            if interval["from"] < last["to"]:
                # Overlap, merge by taking the max of 'to'
                merged[-1] = {"from": last["from"], "to": max(last["to"], interval["to"])}
            else:
                # No overlap, add new interval
                merged.append(interval)
    
    return merged
