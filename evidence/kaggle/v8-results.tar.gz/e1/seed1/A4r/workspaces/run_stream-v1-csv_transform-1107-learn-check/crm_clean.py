import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = [[c.strip() for c in r] for r in rows[1:]]
    ki = header.index('team') if 'team' in header else None
    si = header.index('name') if 'name' in header else None
    if ki is not None:
        data = [r for r in data if ki < len(r) and r[ki] != ""]
        seen = set()
        ded = []
        for r in data:
            k = r[ki] if ki < len(r) else ""
            if k in seen:
                continue
            seen.add(k)
            ded.append(r)
        data = ded
    if si is not None:
        data.sort(key=lambda r: r[si] if si < len(r) else "")
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    w.writerows(data)
    return out.getvalue()
