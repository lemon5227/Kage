def aggregate_log(lines):
    """Aggregate log lines into counts per service for ERROR and WARN levels."""
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3 or ":" not in parts[2]:
            continue
        timestamp, level, rest = parts
        service, _, message = rest.partition(":")
        if not service:
            continue
        # Check if level is ERROR or WARN (case-insensitive)
        level_upper = level.upper()
        if level_upper not in ("ERROR", "WARN"):
            continue
        # Use service as key, upper-case for consistency
        key = service.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
