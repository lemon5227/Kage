def coalesce(intervals):
    """Merge overlapping intervals, including touching ones."""
    # Validate all intervals first
    for interval in intervals:
        if not isinstance(interval, dict) or "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must be a dict with 'from' and 'to' keys")
        s = interval["from"]
        e = interval["to"]
        if not isinstance(s, int) or not isinstance(e, int):
            raise ValueError("Interval values must be integers")
        if s > e:
            raise ValueError(f"Interval start ({s}) cannot be greater than end ({e})")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            if interval["from"] <= last["to"]:  # Overlapping or touching
                # Merge by extending the end
                last["to"] = max(last["to"], interval["to"])
            else:
                merged.append(interval.copy())
    
    return merged
