import csv
import io


def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    ki = header.index('team')
    si = header.index('email')
    data = [[c.strip() for c in r] for r in rows[1:]]
    # Lower-case the email column
    data = [[r[ki], r[si].lower() if len(r) > si else "", *r[si+1:]] for r in data]
    data = [r for r in data if len(r) > ki and r[ki] != ""]
    seen = set()
    deduped = []
    for r in data:
        if r[ki] in seen:
            continue
        seen.add(r[ki])
        deduped.append(r)
    deduped.sort(key=lambda r: r[si] if len(r) > si else "")
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in deduped:
        w.writerow(r)
    return out.getvalue()
