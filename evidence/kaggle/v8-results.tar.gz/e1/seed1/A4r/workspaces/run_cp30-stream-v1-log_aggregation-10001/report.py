def tally_events(lines):
    """Tally events per service for ERROR and WARN levels only."""
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed line
        timestamp = parts[0]
        level = parts[1].upper()
        # Service is the third part, up to the colon
        service_part = parts[2]
        if ':' in service_part:
            service = service_part.split(':')[0]
        else:
            service = service_part
        
        if level not in ('ERROR', 'WARN'):
            continue
        
        counts[service] = counts.get(service, 0) + 1
    
    return counts
