import unicodedata

def make_handle(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace any sequence of non-alphanumeric characters with a single dash
    result = []
    prev_char = None
    for char in lower:
        if char.isalnum():  # alphanumeric means a-z0-9 (since we're already ASCII)
            result.append(char)
            prev_char = char
        else:
            # If we encounter a non-alphanumeric, check if we need to add a dash
            # We only add a dash if the previous character was not a dash or non-alphanumeric
            if prev_char is None or prev_char == '-':
                result.append('-')
                prev_char = '-'
    
    # Strip leading and trailing "-"
    handle = ''.join(result).strip('-')
    
    # If the result is longer than 23 characters, cut to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.rstrip('-')
    
    return handle
