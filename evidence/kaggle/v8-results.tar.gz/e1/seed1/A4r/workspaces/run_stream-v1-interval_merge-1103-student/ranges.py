def combine_ranges(intervals):
    """Merge overlapping intervals. Each interval is a dict {"start": s, "end": e} with integer values.
    
    Returns merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        if "start" not in interval or "end" not in interval:
            raise ValueError("Each interval must have 'start' and 'end' keys")
        if interval["start"] > interval["end"]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            # Check for real overlap (not just touching)
            if interval["start"] < last["end"]:
                # Overlapping, merge by taking the max end
                merged[-1]["end"] = max(last["end"], interval["end"])
            else:
                # Not overlapping, add new interval
                merged.append(interval.copy())
    
    return merged
