def allocate(items, capacity):
    return None
