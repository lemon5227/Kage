def tally_events(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3 or ":" not in parts[2]:
            continue
        timestamp, level, service_message = parts
        service, _, message = service_message.partition(":")
        # Check if level is ERROR or WARN (case-insensitive)
        if level.upper() not in ("ERROR", "WARN"):
            continue
        key = service.upper()
        if not key:
            continue
        counts[key] = counts.get(key, 0) + 1
    return counts
