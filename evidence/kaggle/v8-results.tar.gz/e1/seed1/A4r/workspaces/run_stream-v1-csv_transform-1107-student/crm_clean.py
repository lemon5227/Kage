def clean_rows(text):
    return None
