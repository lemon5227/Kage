def merge_bookings(intervals):
    """
    Merge overlapping time ranges in intervals.
    
    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals sorted by start ascending.
    Touching intervals like [1,3] and [3,5] are merged.
    Raises ValueError if any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start <= last_end:  # Overlapping or touching
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])
    
    return merged
