import csv
import io

def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = rows[1:]
    cleaned = []
    for row in data:
        cells = [c.strip() for c in row]
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[:len(header)]
        cleaned.append(cells)
    ki = header.index('id')
    si = header.index('email')
    cleaned = [r for r in cleaned if r[ki] != ""]
    li = header.index('email')
    for r in cleaned:
        r[li] = r[li].lower()
    seen = set()
    deduped = []
    for r in cleaned:
        if r[ki] in seen:
            continue
        seen.add(r[ki])
        deduped.append(r)
    deduped.sort(key=lambda r: r[si])
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    w.writerows(deduped)
    return out.getvalue()
