def merge_slots(intervals):
    # Check for invalid intervals where start > end
    for interval in intervals:
        if interval[0] > interval[1]:
            raise ValueError("Interval start > end")
    
    # If no intervals, return empty list
    if not intervals:
        return []
    
    # Sort by start time first
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = [sorted_intervals[0][:]]  # Start with the first interval
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # Check if intervals overlap (current start < last end)
        if current[0] < last[1]:
            # Overlap, merge by taking the max of ends
            last[1] = max(last[1], current[1])
        else:
            # No overlap, add current interval
            merged.append(current[:])
    
    return merged
