def count_entries(lines):
    """Count entries by level in lines."""
    counts = {}
    for line in lines:
        # Strip whitespace from line
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        if len(parts) < 2:
            # Malformed line (needs at least timestamp and level)
            continue
        
        # First part is timestamp, second part is LEVEL
        level = parts[1].upper()  # Case-insensitive, report upper-case
        
        # Increment count for this level
        counts[level] = counts.get(level, 0) + 1
    
    # Omit keys with zero count (already handled by not adding zeros)
    return counts
