import unicodedata


def to_key(text):
    """Normalize labels into identifiers."""
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single '_'
    result = []
    last_char_was_alnum = False
    for char in lowercased:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            result.append(char)
            last_char_was_alnum = True
        else:
            # Non-alphanumeric character - add separator only if not already at start/end
            if result and not result[-1].isalnum():
                result.append('_')
            elif not last_char_was_alnum:
                result.append('_')
            last_char_was_alnum = False
    
    # Join and strip leading/trailing underscores
    key = ''.join(result).strip('_')
    
    return key
