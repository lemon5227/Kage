def combine_ranges(intervals):
    """Merge overlapping intervals. Each interval is a dict {"begin": s, "finish": e} with integer values.
    
    Returns merged intervals as dicts with the same "begin"/"finish" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raises ValueError if any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        begin = interval["begin"]
        finish = interval["finish"]
        if begin > finish:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by begin
    sorted_intervals = sorted(intervals, key=lambda x: x["begin"])
    
    # Merge overlapping/touching intervals
    merged = []
    if not sorted_intervals:
        return merged
    
    current_begin = sorted_intervals[0]["begin"]
    current_finish = sorted_intervals[0]["finish"]
    
    for interval in sorted_intervals[1:]:
        begin = interval["begin"]
        finish = interval["finish"]
        
        # If intervals overlap or touch (current_finish >= begin - 1? Actually touching means current_finish == begin)
        # The problem says "touching intervals like [1,3] and [3,5] should be merged"
        # So if current_finish >= begin, they merge
        if current_finish >= begin:
            current_finish = max(current_finish, finish)
        else:
            # No overlap, add current interval and start new one
            merged.append({"begin": current_begin, "finish": current_finish})
            current_begin = begin
            current_finish = finish
    
    # Add the last interval
    merged.append({"begin": current_begin, "finish": current_finish})
    
    return merged
