def merge_slots(intervals):
    # Validate intervals and sort by start
    if not intervals:
        return []
    
    # Check for invalid intervals (start > end)
    for interval in intervals:
        if interval["from"] > interval["to"]:
            raise ValueError("Interval start > end")
    
    # Sort by start (from)
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            # Check if overlapping or touching
            if interval["from"] <= last["to"]:
                # Merge by updating the end to the max of both ends
                last["to"] = max(last["to"], interval["to"])
            else:
                merged.append(interval.copy())
    
    return merged
