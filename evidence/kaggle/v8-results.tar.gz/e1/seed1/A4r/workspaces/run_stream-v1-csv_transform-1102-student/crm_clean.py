import csv
import io


def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    id_idx = header.index('id')
    name_idx = header.index('name')
    email_idx = header.index('email')
    data = [[c.strip() for c in r] for r in rows[1:]]
    
    # Drop rows whose "name" cell is empty
    data = [r for r in data if len(r) > name_idx and r[name_idx] != ""]
    
    # Lower-case the "email" column
    for r in data:
        if len(r) > email_idx:
            r[email_idx] = r[email_idx].lower()
    
    # Remove duplicate rows by "id", keeping the first occurrence
    seen = set()
    deduped = []
    for r in data:
        if r[id_idx] in seen:
            continue
        seen.add(r[id_idx])
        deduped.append(r)
    
    # Sort rows by "id" ascending as strings (stable)
    deduped.sort(key=lambda r: r[id_idx] if len(r) > id_idx else "")
    
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in deduped:
        w.writerow(r)
    return out.getvalue()
