def migrate(cfg):
    # Check version - raise ValueError if not v1
    if cfg.get("version") != 1:
        raise ValueError("Only v1 config is supported for migration")
    
    # Create a new dict for the migrated config
    migrated = {"version": 2}
    
    # Process keys
    keys_to_remove = []
    
    # Rename pwd_file -> password_file
    if "pwd_file" in cfg:
        migrated["password_file"] = cfg["pwd_file"]
    
    # Rename user -> username
    if "user" in cfg:
        migrated["username"] = cfg["user"]
    
    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    migrated["network"] = network
    
    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        migrated["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but not version, pwd_file, user, cache_size, workers, timeout_ms)
    for key in cfg:
        if key not in ["version", "pwd_file", "user", "cache_size", "workers", "timeout_ms"]:
            # Only keep if value is not None
            if cfg[key] is not None:
                migrated[key] = cfg[key]
    
    return migrated
