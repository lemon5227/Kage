import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    ki = header.index('id')
    si = header.index('score')
    ei = header.index('email')
    data = [[c.strip() for c in r] for r in rows[1:]]
    # Drop rows whose "id" cell is empty
    data = [r for r in data if len(r) > ki and r[ki] != ""]
    # Lower-case the "email" column
    data = [[r[0], r[1], r[2], r[3].lower() if len(r) > 3 else "", r[4]] for r in data]
    seen = set()
    deduped = []
    for r in data:
        if r[ki] in seen:
            continue
        seen.add(r[ki])
        deduped.append(r)
    deduped.sort(key=lambda r: r[si] if len(r) > si else "")
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in deduped:
        w.writerow(r)
    return out.getvalue()
