import unicodedata
import re


def make_handle(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    text = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    text = text.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    text = text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    text = re.sub(r'[^a-z0-9]+', '-', text)
    
    # Strip leading and trailing "-"
    text = text.strip('-')
    
    return text
