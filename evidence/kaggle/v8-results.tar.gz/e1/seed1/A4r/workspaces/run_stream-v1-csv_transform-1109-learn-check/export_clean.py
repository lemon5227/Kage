import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = [[c.strip() for c in r] for r in rows[1:]]
    ki = header.index('id')
    data = [r for r in data if r[ki] != ""]
    lc = 'email'
    if lc:
        li = header.index(lc)
        for r in data:
            r[li] = r[li].lower()
    seen = set()
    ded = []
    for r in data:
        k = r[ki]
        if k in seen:
            continue
        seen.add(k)
        ded.append(r)
    si = header.index('score')
    ded.sort(key=lambda r: r[si])
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    w.writerows(ded)
    return out.getvalue()
