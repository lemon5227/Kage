def slugify(text):
    """Build a URL slug from text.
    
    Applies unicodedata NFKD normalization, drops non-ASCII characters,
    lower-cases, replaces every run of characters outside [a-z0-9] with a single "-",
    and strips leading and trailing "-".
    
    Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    text = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    text = ''.join(char for char in text if ord(char) < 128)
    
    # Lower-case
    text = text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for char in text:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                result.append('-')
            prev_char = char
        else:
            prev_char = None
    
    text = ''.join(result)
    
    # Strip leading and trailing "-"
    text = text.strip('-')
    
    return text
