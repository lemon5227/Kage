def merge_slots(intervals):
    # Validate intervals and sort by 'from'
    if not intervals:
        return []
    
    # Check for invalid intervals (start > end)
    for interval in intervals:
        if interval['from'] > interval['to']:
            raise ValueError("Interval start > end")
    
    # Sort by 'from' value
    sorted_intervals = sorted(intervals, key=lambda x: x['from'])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last = merged[-1]
            # Check if intervals overlap or touch (last['to'] >= current['from'])
            if last['to'] >= interval['from']:
                # Merge them
                merged[-1] = {'from': last['from'], 'to': max(last['to'], interval['to'])}
            else:
                merged.append(interval)
    
    return merged
