def summarize(lines):
    allowed = ['ERROR', 'WARN']
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        ts, level, rest = parts[0], parts[1], parts[2]
        if not rest.endswith(":"):
            continue
        service = rest[:-1]
        if not service:
            continue
        lvl = level.upper()
        if allowed is not None and lvl not in allowed:
            continue
        field = 'service'
        if field == "level":
            key = lvl
        elif field == "timestamp":
            key = ts
        else:
            key = service
        if True and field != "timestamp":
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
