def summarize(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(" ", 2)
        if len(parts) != 3:
            continue
        timestamp, level, rest = parts
        if not timestamp or not level:
            continue
        if ":" not in rest:
            continue
        service, message = rest.split(":", 1)
        service = service.strip()
        if not service:
            continue
        level = level.upper()
        if ['ERROR', 'WARN'] and level not in ['ERROR', 'WARN']:
            continue
        fields = {"timestamp": timestamp, "level": level, "service": service}
        key = fields['service']
        if True:
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
