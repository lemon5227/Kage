import unicodedata

def to_key(text):
    """Normalize text into a key identifier."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we replace any sequence of non-alphanumeric characters with a single underscore
    result = []
    last_was_alnum = False
    for char in lower:
        if char.isalnum():
            result.append(char)
            last_was_alnum = True
        else:
            if last_was_alnum:
                result.append('_')
                last_was_alnum = False
            else:
                result.append('_')
    
    key = ''.join(result)
    
    # Strip leading and trailing "_"
    return key.strip('_')
