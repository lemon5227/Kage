import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    
    # Parse CSV
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    
    header = [c.strip() for c in rows[0]]
    data = rows[1:]
    
    # Find column indices
    team_idx = header.index('team')
    score_idx = header.index('score')
    
    # Strip whitespace from all cells and ensure correct number of columns
    cleaned = []
    for row in data:
        cells = [c.strip() for c in row]
        # Pad or truncate to match header length
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[:len(header)]
        cleaned.append(cells)
    
    # Drop rows where score is empty
    cleaned = [r for r in cleaned if r[score_idx] != ""]
    
    # Deduplicate by team, keeping first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        if r[team_idx] in seen:
            continue
        seen.add(r[team_idx])
        deduped.append(r)
    
    # Sort by score ascending as strings (stable sort)
    deduped.sort(key=lambda r: r[score_idx])
    
    # Write output with csv module using '\n' line endings
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    w.writerows(deduped)
    return out.getvalue()
