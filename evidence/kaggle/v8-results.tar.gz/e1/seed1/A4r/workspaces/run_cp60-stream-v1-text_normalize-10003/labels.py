def make_handle(text):
    return None
