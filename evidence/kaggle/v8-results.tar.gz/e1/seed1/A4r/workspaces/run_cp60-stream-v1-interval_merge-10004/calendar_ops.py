def merge_slots(intervals):
    """Merge overlapping intervals in a list of [start, end] pairs.
    
    Args:
        intervals: List of two-element lists [start, end] of integers.
        
    Returns:
        List of merged intervals in [start, end] form, sorted by start ascending.
        
    Raises:
        ValueError: If any interval has start > end.
    """
    # Check for invalid intervals (start > end)
    for interval in intervals:
        if interval[0] > interval[1]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals (only when start < last_end, not touching)
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start < last_end:  # Overlapping only (not touching)
                # Merge by extending the end
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])
    
    return merged
