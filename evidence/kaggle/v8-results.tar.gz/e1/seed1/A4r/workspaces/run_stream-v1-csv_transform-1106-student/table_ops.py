import csv
import io


def normalize_table(text):
    if text == "":
        return ""
    
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    
    # Strip whitespace from header
    header = [c.strip() for c in rows[0]]
    
    # Find column indices
    id_idx = header.index('id')
    city_idx = header.index('city')
    team_idx = header.index('team')
    
    # Process data rows - strip whitespace from all cells
    data = [[c.strip() for c in r] for r in rows[1:]]
    
    # Drop rows where 'team' cell is empty
    data = [r for r in data if len(r) > team_idx and r[team_idx] != ""]
    
    # Remove duplicates by 'id', keeping first occurrence
    seen = set()
    deduped = []
    for r in data:
        if r[id_idx] in seen:
            continue
        seen.add(r[id_idx])
        deduped.append(r)
    
    # Sort by 'city' ascending (stable sort)
    deduped.sort(key=lambda r: r[city_idx] if len(r) > city_idx else "")
    
    # Write output with csv module using '\n' line endings
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in deduped:
        w.writerow(r)
    
    return out.getvalue()
