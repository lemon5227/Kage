def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Raise ValueError if version is not 1
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")
    
    # Create new dict with version 2
    result = {"version": 2}
    
    # Rename top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    
    # Move "port" and "workers" into a sub-dict "storage"
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    result["storage"] = storage
    
    # Handle "timeout_ms" - convert to "timeout_s" if exists
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged
    for key, value in cfg.items():
        if key not in ["version", "dir", "host", "port", "workers", "timeout_ms"] and value is not None:
            result[key] = value
    
    # Drop keys whose value is None
    # Already handled above by skipping None values
    
    return result
