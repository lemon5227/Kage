def combine_ranges(intervals):
    # Check for invalid intervals (start > end)
    for start, end in intervals:
        if start > end:
            raise ValueError("Interval start must not be greater than end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last_start, last_end = merged[-1]
            if interval[0] <= last_end:  # Overlapping or touching
                merged[-1] = [last_start, max(last_end, interval[1])]
            else:
                merged.append(interval)
    
    return merged
