def tally_events(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        timestamp, level, rest = parts
        if ":" not in rest:
            continue
        service, _sep, _message = rest.partition(":")
        service = service.strip()
        if not service:
            continue
        if 'WARN' and level.upper() != 'WARN'.upper():
            continue
        field_map = {"level": level, "service": service, "timestamp": timestamp}
        key = field_map.get('service', level)
        if True:
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
