def normalize_table(text):
    return None
