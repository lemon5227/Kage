import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    # Strip whitespace from header
    header = [c.strip() for c in rows[0]]
    # Find indices
    score_idx = header.index('score')
    team_idx = header.index('team')
    
    # Strip whitespace from all cells
    data = [[c.strip() for c in r] for r in rows[1:]]
    
    # Drop rows where score is empty
    data = [r for r in data if r[score_idx] != "" and len(r) > score_idx]
    
    # Remove duplicate rows by team, keeping first occurrence
    seen_teams = set()
    deduped = []
    for r in data:
        if r[team_idx] in seen_teams:
            continue
        seen_teams.add(r[team_idx])
        deduped.append(r)
    
    # Sort rows by score ascending as strings (stable)
    deduped.sort(key=lambda r: r[score_idx] if len(r) > score_idx else "", reverse=False)
    
    # Write output with csv module using '\n' line endings
    out = io.StringIO()
    w = csv.writer(out, lineterminator='\n')
    w.writerow(header)
    for r in deduped:
        w.writerow(r)
    return out.getvalue()
