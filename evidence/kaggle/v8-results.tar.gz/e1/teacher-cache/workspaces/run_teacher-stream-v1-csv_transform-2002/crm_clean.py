import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "id" cell is empty
    try:
        id_idx = header.index("id")
    except ValueError:
        id_idx = None

    if id_idx is not None:
        cleaned = [r for r in cleaned if id_idx < len(r) and r[id_idx] != ""]

    # remove duplicate rows by "city", keeping the first occurrence
    try:
        city_idx = header.index("city")
    except ValueError:
        city_idx = None

    if city_idx is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            key = r[city_idx] if city_idx < len(r) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(r)
        cleaned = deduped

    # sort rows by "name" ascending as strings (stable)
    try:
        name_idx = header.index("name")
    except ValueError:
        name_idx = None

    if name_idx is not None:
        cleaned.sort(key=lambda r: r[name_idx] if name_idx < len(r) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
