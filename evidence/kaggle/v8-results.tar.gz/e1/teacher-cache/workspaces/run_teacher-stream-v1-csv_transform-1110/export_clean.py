import csv
import io

HEADER = ["score", "team", "name", "email"]


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        # pad/truncate to header length
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[: len(header)]
        cleaned.append(cells)

    # drop rows whose "team" cell is empty
    try:
        team_idx = header.index("team")
    except ValueError:
        team_idx = 1
    cleaned = [r for r in cleaned if r[team_idx] != ""]

    # lower-case the "email" column
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = 3
    for r in cleaned:
        r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[team_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    # sort rows by "email" ascending as strings (stable)
    deduped.sort(key=lambda r: r[email_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
