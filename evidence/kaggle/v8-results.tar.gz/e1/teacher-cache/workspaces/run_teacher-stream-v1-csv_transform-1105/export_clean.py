import csv
import io


def dedupe_export(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    body = rows[1:]

    cleaned = []
    for row in body:
        cells = [cell.strip() for cell in row]
        # normalize row length to header length
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[: len(header)]
        cleaned.append(cells)

    try:
        name_idx = header.index("name")
    except ValueError:
        name_idx = None
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None
    try:
        team_idx = header.index("team")
    except ValueError:
        team_idx = None
    try:
        id_idx = header.index("id")
    except ValueError:
        id_idx = None

    # drop rows whose "name" cell is empty
    if name_idx is not None:
        cleaned = [r for r in cleaned if r[name_idx] != ""]

    # lower-case the "email" column
    if email_idx is not None:
        for r in cleaned:
            r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "team", keeping the first occurrence
    if team_idx is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            key = r[team_idx]
            if key in seen:
                continue
            seen.add(key)
            deduped.append(r)
        cleaned = deduped

    # sort rows by "id" ascending as strings (stable)
    if id_idx is not None:
        cleaned.sort(key=lambda r: r[id_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
