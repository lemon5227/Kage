import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip whitespace from every cell
    cleaned = [[cell.strip() for cell in row] for row in data]

    # drop rows whose "email" cell is empty
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    if email_idx is not None:
        cleaned = [row for row in cleaned if len(row) > email_idx and row[email_idx] != ""]

    # lower-case the "email" column
    if email_idx is not None:
        for row in cleaned:
            if len(row) > email_idx:
                row[email_idx] = row[email_idx].lower()

    # remove duplicate rows by "email", keeping the first occurrence
    if email_idx is not None:
        seen = set()
        deduped = []
        for row in cleaned:
            key = row[email_idx] if len(row) > email_idx else None
            if key in seen:
                continue
            seen.add(key)
            deduped.append(row)
        cleaned = deduped

    # sort rows by "score" ascending as strings (stable)
    try:
        score_idx = header.index("score")
    except ValueError:
        score_idx = None

    if score_idx is not None:
        cleaned.sort(key=lambda row: row[score_idx] if len(row) > score_idx else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
