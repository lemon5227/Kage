import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    body = rows[1:]

    cleaned = []
    for row in body:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "team" cell is empty
    cleaned = [r for r in cleaned if len(r) > 0 and r[0] != ""]

    # lower-case the "email" column
    for r in cleaned:
        if len(r) > 1:
            r[1] = r[1].lower()

    # remove duplicate rows by "city", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        city = r[3] if len(r) > 3 else ""
        if city in seen:
            continue
        seen.add(city)
        deduped.append(r)

    # sort rows by "email" ascending as strings (stable)
    deduped.sort(key=lambda r: r[1] if len(r) > 1 else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
