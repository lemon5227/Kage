def tidy_csv(text):
    return None
