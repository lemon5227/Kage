import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        # pad short rows so indexing is safe
        while len(row) < len(header):
            row.append("")
        cleaned.append(row)

    # drop rows whose "email" cell is empty
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    if email_idx is not None:
        cleaned = [row for row in cleaned if row[email_idx] != ""]
        # lower-case the email column
        for row in cleaned:
            row[email_idx] = row[email_idx].lower()

    # remove duplicate rows by "name", keeping the first occurrence
    try:
        name_idx = header.index("name")
    except ValueError:
        name_idx = None

    if name_idx is not None:
        seen = set()
        deduped = []
        for row in cleaned:
            key = row[name_idx]
            if key in seen:
                continue
            seen.add(key)
            deduped.append(row)
        cleaned = deduped

    # sort rows by "score" ascending as strings (stable)
    try:
        score_idx = header.index("score")
    except ValueError:
        score_idx = None

    if score_idx is not None:
        cleaned.sort(key=lambda row: row[score_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
