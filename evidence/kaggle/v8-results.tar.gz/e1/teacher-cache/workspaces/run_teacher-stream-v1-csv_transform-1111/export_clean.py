import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # Drop rows whose "city" cell is empty
    cleaned = [row for row in cleaned if len(row) > 0 and row[0] != ""]

    # Remove duplicate rows by "city", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        city = row[0]
        if city in seen:
            continue
        seen.add(city)
        deduped.append(row)

    # Sort by "score" ascending as strings (stable)
    deduped.sort(key=lambda row: row[2] if len(row) > 2 else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
