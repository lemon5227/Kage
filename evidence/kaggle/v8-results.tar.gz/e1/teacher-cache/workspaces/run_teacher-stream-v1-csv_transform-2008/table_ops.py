import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    body = rows[1:]

    cleaned = []
    for row in body:
        row = [cell.strip() for cell in row]
        # pad short rows so indexing by column name is safe
        if len(row) < len(header):
            row = row + [""] * (len(header) - len(row))
        cleaned.append(row)

    name_idx = header.index("name") if "name" in header else None
    id_idx = header.index("id") if "id" in header else None
    team_idx = header.index("team") if "team" in header else None

    # drop rows whose "name" cell is empty
    if name_idx is not None:
        cleaned = [row for row in cleaned if row[name_idx] != ""]

    # remove duplicate rows by "id", keeping the first occurrence
    if id_idx is not None:
        seen = set()
        deduped = []
        for row in cleaned:
            key = row[id_idx]
            if key in seen:
                continue
            seen.add(key)
            deduped.append(row)
        cleaned = deduped

    # sort rows by "team" ascending as strings (stable)
    if team_idx is not None:
        cleaned.sort(key=lambda row: row[team_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
