import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # Drop rows whose "team" cell is empty
    cleaned = [row for row in cleaned if len(row) > 0 and row[0] != ""]

    # Remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        team = row[0]
        if team in seen:
            continue
        seen.add(team)
        deduped.append(row)

    # Sort by "name" ascending as strings (stable)
    def name_key(row):
        return row[1] if len(row) > 1 else ""

    deduped.sort(key=name_key)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()
