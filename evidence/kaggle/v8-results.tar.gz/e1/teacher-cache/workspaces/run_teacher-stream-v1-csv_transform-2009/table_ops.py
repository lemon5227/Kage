import csv
import io


def dedupe_export(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "team" cell is empty
    cleaned = [row for row in cleaned if len(row) > 0 and row[0] != ""]

    # lower-case the "email" column (index 3)
    for row in cleaned:
        if len(row) > 3:
            row[3] = row[3].lower()

    # remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        team = row[0] if len(row) > 0 else ""
        if team in seen:
            continue
        seen.add(team)
        deduped.append(row)

    # sort rows by "email" ascending as strings (stable)
    deduped.sort(key=lambda row: row[3] if len(row) > 3 else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
