import re


def run(arguments, context):
    path = arguments['file_path']
    fn = arguments['function_name']
    pattern = arguments['line_regex']
    upper = arguments['uppercase_field']
    src = (
        'import re\n'
        '\n'
        'def ' + fn + '(lines):\n'
        '    pat = re.compile(' + repr(pattern) + ')\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        m = pat.search(line.strip())\n'
        '        if not m:\n'
        '            continue\n'
        '        key = m.group(1)\n'
        + ('        key = key.upper()\n' if upper else '')
        + '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': path, 'bytes_written': len(src)}
