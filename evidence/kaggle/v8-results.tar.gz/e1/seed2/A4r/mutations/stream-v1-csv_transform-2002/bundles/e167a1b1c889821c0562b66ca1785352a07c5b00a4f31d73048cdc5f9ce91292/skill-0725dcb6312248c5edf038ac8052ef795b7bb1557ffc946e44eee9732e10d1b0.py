import csv, io

def run(arguments, context):
    fp = arguments['file_path']
    fn = arguments['function_name']
    key_col = arguments['key_column']
    sort_col = arguments['sort_column']
    lc = arguments['lowercase_key']
    src = (
        'import csv, io\n'
        'def ' + fn + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    data = [[c.strip() for c in r] for r in rows[1:]]\n'
        '    ki = header.index(' + repr(key_col) + ') if ' + repr(key_col) + ' in header else None\n'
        '    si = header.index(' + repr(sort_col) + ') if ' + repr(sort_col) + ' in header else None\n'
        '    if ki is not None:\n'
        '        data = [r for r in data if len(r) > ki and r[ki] != ""]\n'
        '        if ' + repr(lc) + ':\n'
        '            for r in data:\n'
        '                if len(r) > ki:\n'
        '                    r[ki] = r[ki].lower()\n'
        '        seen = set(); out = []\n'
        '        for r in data:\n'
        '            k = r[ki] if len(r) > ki else None\n'
        '            if k in seen:\n'
        '                continue\n'
        '            seen.add(k); out.append(r)\n'
        '        data = out\n'
        '    if si is not None:\n'
        '        data.sort(key=lambda r: r[si] if len(r) > si else "")\n'
        '    buf = io.StringIO()\n'
        '    w = csv.writer(buf, lineterminator="\\n")\n'
        '    w.writerow(header)\n'
        '    w.writerows(data)\n'
        '    return buf.getvalue()\n'
    )
    import os
    path = os.path.join(context['workspace_dir'], fp)
    with open(path, 'w') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn, 'bytes_written': len(src)}
