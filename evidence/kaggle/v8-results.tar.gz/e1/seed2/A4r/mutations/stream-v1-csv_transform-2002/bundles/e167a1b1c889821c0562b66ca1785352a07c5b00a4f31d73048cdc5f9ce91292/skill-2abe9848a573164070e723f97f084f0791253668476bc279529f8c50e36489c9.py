import os

def run(arguments, context):
    path = os.path.join(context['workspace_dir'], arguments['file_path'])
    fn = arguments['function_name']
    idf = arguments['id_field']
    wf = arguments['weight_field']
    vf = arguments['value_field']
    code = '''def {fn}(items, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    entries = []
    for item in items:
        w = item["{wf}"]
        v = item["{vf}"]
        if w <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["{idf}"], w, v))
    best = [(0, ()) for _ in range(capacity + 1)]
    for iid, w, v in entries:
        for c in range(capacity, w - 1, -1):
            pv, pi = best[c - w]
            cv = pv + v
            ci = tuple(sorted(pi + (iid,)))
            bv, bi = best[c]
            if cv > bv or (cv == bv and ci < bi):
                best[c] = (cv, ci)
    return list(best[capacity][1])
'''.format(fn=fn, idf=idf, wf=wf, vf=vf)
    with open(path, 'w') as f:
        f.write(code)
    return {"success": True, "path": arguments['file_path']}