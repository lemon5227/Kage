import csv, io

def run(arguments, context):
    fp = arguments['file_path']
    fn = arguments['function_name']
    drop_col = arguments['drop_empty_column']
    dedupe_col = arguments['dedupe_column']
    sort_col = arguments['sort_column']
    src = '''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = [[c.strip() for c in r] for r in rows[1:]]

    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None

    di = idx({drop!r})
    if di is not None:
        data = [r for r in data if di < len(r) and r[di] != ""]

    ci = idx({dedupe!r})
    if ci is not None:
        seen = set()
        out = []
        for r in data:
            k = r[ci] if ci < len(r) else ""
            if k in seen:
                continue
            seen.add(k)
            out.append(r)
        data = out

    si = idx({sort!r})
    if si is not None:
        data.sort(key=lambda r: r[si] if si < len(r) else "")

    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\\n")
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
'''.format(fn=fn, drop=drop_col, dedupe=dedupe_col, sort=sort_col)
    path = context['workspace_dir'].rstrip('/') + '/' + fp
    with open(path, 'w') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn, 'bytes_written': len(src)}
