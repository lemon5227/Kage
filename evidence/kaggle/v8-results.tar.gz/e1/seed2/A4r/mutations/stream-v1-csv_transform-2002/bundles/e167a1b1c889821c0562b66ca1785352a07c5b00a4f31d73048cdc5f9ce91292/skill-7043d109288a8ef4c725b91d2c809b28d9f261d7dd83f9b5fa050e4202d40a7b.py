import re


def run(arguments, context):
    path = arguments['file_path']
    fname = arguments['function_name']
    pattern = arguments['line_regex']
    upper = arguments['uppercase_field']
    src = (
        'import re\n\n'
        '_RE = re.compile(' + repr(pattern) + ')\n\n\n'
        'def ' + fname + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        m = _RE.match(line.strip())\n'
        '        if not m:\n'
        '            continue\n'
        '        key = m.group(1)\n'
        + ('        key = key.upper()\n' if upper else '')
        + '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    import os
    full = os.path.join(context['workspace_dir'], path)
    with open(full, 'w') as f:
        f.write(src)
    return {'success': True, 'path': path, 'bytes_written': len(src)}
