import csv, io

def run(arguments, context):
    fp = arguments['file_path']
    fn = arguments['function_name']
    drop_col = arguments['drop_empty_column']
    dedupe_col = arguments['dedupe_column']
    sort_col = arguments['sort_column']
    lower_col = arguments.get('lowercase_column', '')
    src = (
        'import csv\nimport io\n\n'
        'def ' + fn + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]]\n'
        '    idx = {name: i for i, name in enumerate(header)}\n'
        '    def cell(row, name):\n'
        '        i = idx.get(name)\n'
        '        return row[i] if i is not None and i < len(row) else ""\n'
        '    data = [[c.strip() for c in r] for r in rows[1:]]\n'
        '    data = [r for r in data if cell(r, ' + repr(drop_col) + ') != ""]\n'
        '    lc = idx.get(' + repr(lower_col) + ')\n'
        '    if lc is not None:\n'
        '        for r in data:\n'
        '            if lc < len(r):\n'
        '                r[lc] = r[lc].lower()\n'
        '    seen = set()\n'
        '    deduped = []\n'
        '    for r in data:\n'
        '        k = cell(r, ' + repr(dedupe_col) + ')\n'
        '        if k in seen:\n'
        '            continue\n'
        '        seen.add(k)\n'
        '        deduped.append(r)\n'
        '    deduped.sort(key=lambda r: cell(r, ' + repr(sort_col) + '))\n'
        '    out = io.StringIO()\n'
        '    w = csv.writer(out, lineterminator="\\n")\n'
        '    w.writerow(header)\n'
        '    w.writerows(deduped)\n'
        '    return out.getvalue()\n'
    )
    path = context['workspace_dir'].rstrip('/') + '/' + fp
    with open(path, 'w') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn, 'bytes_written': len(src)}
