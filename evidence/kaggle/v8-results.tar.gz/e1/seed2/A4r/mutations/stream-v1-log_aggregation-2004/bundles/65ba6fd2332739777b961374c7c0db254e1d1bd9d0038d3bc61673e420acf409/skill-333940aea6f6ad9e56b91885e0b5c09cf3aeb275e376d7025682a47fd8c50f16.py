def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    gf = arguments['group_field']
    fl = arguments['filter_level']
    ug = arguments['uppercase_group']
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split(None, 3)\n'
        '        if len(parts) < 4:\n'
        '            continue\n'
        '        _ts, level, service, _msg = parts\n'
        '        if not service.endswith(":"):\n'
        '            continue\n'
        '        service = service[:-1]\n'
        '        if not service:\n'
        '            continue\n'
        '        if ' + repr(fl) + ' and level.upper() != ' + repr(fl.upper()) + ':\n'
        '            continue\n'
        '        if ' + repr(gf) + ' == "level":\n'
        '            key = level\n'
        '        else:\n'
        '            key = service\n'
        '        if ' + repr(ug) + ':\n'
        '            key = key.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], fp)
    with open(path, 'w') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn, 'bytes_written': len(src)}
