import os

def run(arguments, context):
    fp = arguments['file_path']
    fn = arguments['function_name']
    gi = arguments['group_field_index']
    li = arguments['level_field_index']
    allowed = [str(x).upper() for x in arguments['allowed_levels']]
    up = arguments['uppercase_group']
    mt = arguments['min_tokens']
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + repr(mt) + ':\n'
        '            continue\n'
        '        if parts[' + repr(li) + '].upper() not in ' + repr(allowed) + ':\n'
        '            continue\n'
        '        key = parts[' + repr(gi) + ']\n'
        '        if key.endswith(":"):\n'
        '            key = key[:-1]\n'
        '        if not key:\n'
        '            continue\n'
        '        if ' + repr(up) + ':\n'
        '            key = key.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], fp)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn, 'bytes_written': len(src)}
