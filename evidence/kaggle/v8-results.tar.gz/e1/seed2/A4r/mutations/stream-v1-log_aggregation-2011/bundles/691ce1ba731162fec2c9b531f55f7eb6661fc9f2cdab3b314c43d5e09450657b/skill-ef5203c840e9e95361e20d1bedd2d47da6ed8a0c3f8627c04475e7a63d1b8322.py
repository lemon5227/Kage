def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    idx = int(arguments['field_index'])
    min_tokens = int(arguments['min_tokens'])
    up = bool(arguments['uppercase_field'])
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + repr(min_tokens) + ':\n'
        '            continue\n'
        '        key = parts[' + repr(idx) + ']\n'
        + ('        key = key.upper()\n' if up else '') +
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], fp)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn, 'bytes_written': len(src)}
