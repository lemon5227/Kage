def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    sk = arguments['start_key']
    ek = arguments['end_key']
    src = (
        'def {fn}(intervals):\n'
        '    norm = []\n'
        '    for iv in intervals:\n'
        '        s = iv["{sk}"]\n'
        '        e = iv["{ek}"]\n'
        '        if s > e:\n'
        '            raise ValueError("start > end")\n'
        '        norm.append((s, e))\n'
        '    norm.sort(key=lambda p: p[0])\n'
        '    merged = []\n'
        '    for s, e in norm:\n'
        '        if merged and s < merged[-1][1]:\n'
        '            if e > merged[-1][1]:\n'
        '                merged[-1][1] = e\n'
        '        else:\n'
        '            merged.append([s, e])\n'
        '    return [{{"{sk}": s, "{ek}": e}} for s, e in merged]\n'
    ).format(fn=fn, sk=sk, ek=ek)
    path = os.path.join(context['workspace_dir'], fp)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn, 'bytes_written': len(src)}
