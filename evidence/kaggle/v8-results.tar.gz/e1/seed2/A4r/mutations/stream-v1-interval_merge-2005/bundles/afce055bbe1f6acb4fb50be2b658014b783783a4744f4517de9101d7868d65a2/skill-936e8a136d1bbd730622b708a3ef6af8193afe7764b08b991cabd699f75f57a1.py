def run(arguments, context):
    import os
    path = os.path.join(context['workspace_dir'], arguments['file_path'])
    fn = arguments['function_name']
    idx = arguments['field_index']
    up = arguments['uppercase_field']
    min_tokens = arguments['min_tokens']
    src = (
        "def " + fn + "(lines):\n"
        "    counts = {}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        parts = line.split()\n"
        "        if len(parts) < " + str(min_tokens) + ":\n"
        "            continue\n"
        "        field = parts[" + str(idx) + "]\n"
        "        if not field:\n"
        "            continue\n"
        + ("        field = field.upper()\n" if up else "")
        + "        counts[field] = counts.get(field, 0) + 1\n"
        "    return counts\n"
    )
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'file_path': arguments['file_path'], 'function_name': fn}
