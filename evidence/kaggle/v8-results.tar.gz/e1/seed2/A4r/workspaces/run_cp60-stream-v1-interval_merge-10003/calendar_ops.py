def merge_slots(intervals):
    """Merge overlapping time ranges in intervals list.
    
    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Touching intervals like [1,3] and [3,5] 
    are merged. Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate and normalize intervals
    norm = []
    for iv in intervals:
        s = iv["start"]
        e = iv["end"]
        if s > e:
            raise ValueError("invalid interval: start > end")
        norm.append((s, e))
    
    # Sort by start
    norm.sort(key=lambda x: x[0])
    
    # Merge overlapping or touching intervals
    merged = []
    for s, e in norm:
        if merged and s <= merged[-1][1]:  # Overlapping or touching
            if e > merged[-1][1]:
                merged[-1] = (merged[-1][0], e)
        else:
            merged.append((s, e))
    
    # Convert back to dicts
    result = []
    for s, e in merged:
        result.append({"start": s, "end": e})
    
    return result
