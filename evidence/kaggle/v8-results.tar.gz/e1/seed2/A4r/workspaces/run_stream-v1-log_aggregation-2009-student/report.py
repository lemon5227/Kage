def count_entries(lines):
    """Count log entries by service for ERROR and WARN levels only.
    
    Log format: <timestamp> <LEVEL> <service>: <message>
    Returns: {service_name: count} with upper-case keys.
    Malformed lines are dropped.
    """
    service_counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        # Expected format: <timestamp> <LEVEL> <service>: <message>
        # We need to extract LEVEL and SERVICE
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service:
        if len(parts) < 3:
            continue
        
        # The third part should be "service:" (with colon)
        # Let's check if the format is correct
        try:
            # parts[0] = timestamp
            # parts[1] = LEVEL
            # parts[2] should start with service name and end with colon
            level = parts[1].upper()  # Case-insensitive, convert to upper
            
            # Check if level is ERROR or WARN
            if level not in ('ERROR', 'WARN'):
                continue
            
            # Extract service name from parts[2]
            # parts[2] should be like "service:"
            service_part = parts[2]
            if not service_part.endswith(':'):
                # Malformed line - skip
                continue
            
            service_name = service_part[:-1]  # Remove the colon
            
            # Count the service
            service_counts[service_name] = service_counts.get(service_name, 0) + 1
            
        except (IndexError, ValueError):
            # Malformed line - skip
            continue
    
    return service_counts
