def coalesce(intervals):
    return None
