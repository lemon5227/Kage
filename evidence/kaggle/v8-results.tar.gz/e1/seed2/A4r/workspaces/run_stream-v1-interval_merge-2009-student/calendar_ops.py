def merge_bookings(intervals):
    """
    Merge overlapping time ranges. Each interval is a dict {"from": s, "to": e} with integer values.
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    """
    # Validate all intervals first
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort intervals by start time
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last = merged[-1]
            # Check for real overlap (not just touching)
            if interval["from"] < last["to"]:
                # Overlap exists, merge them
                new_end = max(last["to"], interval["to"])
                merged[-1] = {"from": last["from"], "to": new_end}
            else:
                # No overlap, add the current interval
                merged.append(interval)
    
    return merged
