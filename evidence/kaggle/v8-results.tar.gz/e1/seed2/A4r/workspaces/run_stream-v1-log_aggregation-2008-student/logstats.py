def digest_lines(lines):
    """
    Process log lines in format: <timestamp> <LEVEL> <service>: <message>
    Returns a dict mapping each level (uppercase) to its count.
    Skips malformed lines and omits keys with zero count.
    """
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report uppercase
        # Check if the line has the expected format with colon after service
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # So we need at least 3 parts, and part[2] should contain a colon
        
        # Validate that level is not empty
        if not level:
            continue
        
        # Count the level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    # Return only non-zero counts (already handled by dict)
    return level_counts
