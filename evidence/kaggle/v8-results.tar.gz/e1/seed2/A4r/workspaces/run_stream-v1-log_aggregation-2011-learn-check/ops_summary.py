def aggregate_log(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        key = parts[1]
        key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
