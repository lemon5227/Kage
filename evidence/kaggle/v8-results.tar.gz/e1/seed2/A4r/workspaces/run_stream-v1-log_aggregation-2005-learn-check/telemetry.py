import re

def digest_lines(lines):
    pat = re.compile('^\\s*\\S+\\s+(\\S+)\\s+.*$')
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        m = pat.search(line.strip())
        if not m:
            continue
        key = m.group(1)
        key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
