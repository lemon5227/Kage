#!/usr/bin/env python3
"""Run tests for crm_clean.py"""

import sys
sys.path.insert(0, '.')
from test_crm_clean import *

# Actually run the tests
print("Running tests...")

# Test 1: Basic functionality
test_input = """city,score,email,name,team
NY,100,test@example.com,Alice,Team1
LA,200,another@example.com,Bob,Team2
NY,150,duplicate@example.com,Charlie,Team3
"""

result = clean_rows(test_input)
print("Test 1 - Basic functionality:")
print(result)
print()

# Test 2: Empty string
result2 = clean_rows('')
print("Test 2 - Empty string:")
print(repr(result2))
print()

# Test 3: Header-only input
test3 = "city,score,email,name,team"
result3 = clean_rows(test3)
print("Test 3 - Header-only input:")
print(result3)
print()

# Test 4: Whitespace stripping
test4 = """ city , 100 , test@example.com , Alice , Team1 
"""
result4 = clean_rows(test4)
print("Test 4 - Whitespace stripping:")
print(result4)
