#!/usr/bin/env python3
"""Clean exported CSV table data."""

import csv
import io


def clean_rows(text):
    """Clean an exported CSV text with header row (city, score, email, name, team).
    
    Returns cleaned CSV text with the same header.
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "score" cell is empty
    - Lower-case the "email" column
    - Remove duplicate rows by "city", keeping the first occurrence
    - Sort rows by "name" ascending as strings (stable)
    """
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ''
    
    # Validate header
    expected_header = ['city', 'score', 'email', 'name', 'team']
    if header != expected_header:
        # If header doesn't match, still process but use given columns
        pass
    
    rows = list(reader)
    
    # Process rows
    cleaned_rows = []
    seen_cities = set()
    
    for row in rows:
        # Strip whitespace from every cell
        row = [cell.strip() for cell in row]
        
        # Check if score is empty (drop such rows)
        if not row[1]:  # score is at index 1
            continue
        
        # Lower-case the email column (index 2)
        row[2] = row[2].lower()
        
        # Remove duplicate rows by city, keeping first occurrence
        city = row[0]
        if city in seen_cities:
            continue
        seen_cities.add(city)
        
        cleaned_rows.append(row)
    
    # Sort rows by "name" ascending (stable sort)
    # Use a stable sort - Python's sorted is stable
    cleaned_rows.sort(key=lambda row: row[3])
    
    # Build output CSV text with \n line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(cleaned_rows)
    
    return output.getvalue()


if __name__ == '__main__':
    # Test example
    test_input = """city,score,email,name,team
NY,100,test@example.com,Alice,Team1
LA,200,another@example.com,Bob,Team2
NY,150,duplicate@example.com,Charlie,Team3
"""
    result = clean_rows(test_input)
    print(result)
