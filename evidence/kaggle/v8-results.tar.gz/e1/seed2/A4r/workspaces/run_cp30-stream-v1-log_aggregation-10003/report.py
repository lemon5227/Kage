def aggregate_log(lines):
    return {}
