def tally_events(lines):
    return {}
