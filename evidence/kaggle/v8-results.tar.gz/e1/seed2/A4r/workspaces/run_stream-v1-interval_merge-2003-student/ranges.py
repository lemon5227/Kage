def coalesce(intervals):
    """Merge overlapping intervals in a list of [start, end] pairs."""
    # Check for invalid intervals where start > end
    for interval in intervals:
        if interval[0] > interval[1]:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort intervals by start
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start <= last_end:  # Overlapping (not just touching)
                # Merge by extending the end
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])
    
    return merged
