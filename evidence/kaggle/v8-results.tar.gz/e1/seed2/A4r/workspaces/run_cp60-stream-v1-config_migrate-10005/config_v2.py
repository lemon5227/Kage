def convert_settings(cfg):
    # Check version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")
    
    # Create new dict with version 2
    result = {"version": 2}
    
    # Process keys
    for key, value in cfg.items():
        if key == "user":
            result["username"] = value
        elif key == "dir":
            result["directory"] = value
        elif key == "cache_size":
            result.setdefault("limits", {})["cache_size"] = value
        elif key == "retries":
            result.setdefault("limits", {})["retries"] = value
        elif key == "timeout_ms":
            if value is not None:
                result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged, but drop if value is None
            if value is not None:
                result[key] = value
    
    return result
