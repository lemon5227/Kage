def merge_bookings(intervals):
    # Check for invalid intervals (start > end)
    for start, end in intervals:
        if start > end:
            raise ValueError("Interval start must not be greater than end")
    
    # If no intervals, return empty list
    if not intervals:
        return []
    
    # Sort intervals by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = [sorted_intervals[0][:]]  # Start with the first interval
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # If current interval overlaps or touches the last merged interval
        if current[0] <= last[1]:
            # Merge them by taking the minimum start and maximum end
            merged[-1][0] = min(last[0], current[0])
            merged[-1][1] = max(last[1], current[1])
        else:
            # No overlap, add the current interval as a new one
            merged.append(current[:])
    
    return merged
