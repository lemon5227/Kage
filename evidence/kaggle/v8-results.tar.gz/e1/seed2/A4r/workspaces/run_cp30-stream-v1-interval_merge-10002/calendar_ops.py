def coalesce(intervals):
    """Merge overlapping intervals. Each interval is a dict {"start": s, "end": e}.
    
    Returns merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] are merged.
    Raises ValueError if any interval has start > end.
    """
    # Validate and normalize intervals
    norm = []
    for iv in intervals:
        s = iv["start"]
        e = iv["end"]
        if s > e:
            raise ValueError(f"invalid interval: start > end")
        norm.append([s, e])
    
    # Sort by start
    norm.sort(key=lambda x: x[0])
    
    # Merge overlapping/touching intervals
    out = []
    for s, e in norm:
        if out and s <= out[-1][1]:
            if e > out[-1][1]:
                out[-1][1] = e
        else:
            out.append([s, e])
    
    # Convert back to dicts
    result = []
    for s, e in out:
        result.append({"start": s, "end": e})
    
    return result
