def merge_bookings(intervals):
    """Merge overlapping intervals, each represented as a dict with 'begin' and 'finish' keys."""
    # Validate and normalize intervals
    norm = []
    for iv in intervals:
        s = iv["begin"]
        e = iv["finish"]
        if s > e:
            raise ValueError("invalid interval: start > end")
        norm.append([s, e])
    
    # Sort by start
    norm.sort(key=lambda x: x[0])
    
    # Merge overlapping/touching intervals
    out = []
    for s, e in norm:
        if out and s <= out[-1][1]:
            if e > out[-1][1]:
                out[-1][1] = e
        else:
            out.append([s, e])
    
    # Convert back to dicts with 'begin' and 'finish' keys
    return [{"begin": s, "finish": e} for s, e in out]
