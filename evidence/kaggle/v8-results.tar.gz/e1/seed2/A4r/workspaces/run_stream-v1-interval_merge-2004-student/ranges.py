def coalesce(intervals):
    """Merge overlapping time ranges. Each interval is a dict {"from": s, "to": e}.
    
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals (end == next start) are NOT merged; only real overlaps merge.
    Raises ValueError if any interval has start > end.
    """
    # Validate and normalize intervals
    norm = []
    for iv in intervals:
        s = iv["from"]
        e = iv["to"]
        if s > e:
            raise ValueError(f"invalid interval: start > end")
        norm.append((s, e))
    
    # Sort by start
    norm.sort(key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for s, e in norm:
        if merged and s < merged[-1][1]:  # strict overlap (s < last_end)
            # Overlap: merge by extending the end
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))
    
    # Convert back to dicts
    result = []
    for s, e in merged:
        result.append({"from": s, "to": e})
    
    return result
