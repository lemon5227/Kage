import re

_RE = re.compile('^\\S+\\s+(\\w+)\\s+.*')


def tally_events(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        m = _RE.match(line.strip())
        if not m:
            continue
        key = m.group(1)
        key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
