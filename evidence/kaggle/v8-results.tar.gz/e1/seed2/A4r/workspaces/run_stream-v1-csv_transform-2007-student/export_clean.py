import csv
import io

def normalize_table(text):
    """Clean an exported table from CSV text."""
    # Parse the CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = rows[1:]
    
    # Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        cleaned_row = [cell.strip() for cell in row]
        cleaned_rows.append(cleaned_row)
    
    # Drop rows whose "team" cell is empty
    # The columns are: score, team, id, name, city
    # So team is at index 1
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) > 1 and row[1] != '':
            filtered_rows.append(row)
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in filtered_rows:
        score = row[0]
        if score not in seen_scores:
            seen_scores.add(score)
            deduped_rows.append(row)
    
    # Sort rows by "id" ascending as strings (stable)
    # The id is at index 2
    deduped_rows.sort(key=lambda row: row[2])
    
    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()
