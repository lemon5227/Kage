def merge_slots(intervals):
    return None
