import unicodedata

def make_handle(text):
    """Turn a title into a handle."""
    # Check if input is a string
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace any sequence of non-alphanumeric characters with a single dash
    result = []
    prev_char = None
    for char in lowercased:
        if char.isalnum():  # alphanumeric means a-z0-9 (since we're already ASCII)
            result.append(char)
        else:
            # If we encounter a non-alphanumeric, add a dash only if the previous character was not a dash
            if prev_char != '-':
                result.append('-')
            prev_char = '-'
    
    handle = ''.join(result)
    
    # Strip leading and trailing "-"
    handle = handle.strip('-')
    
    # If result is longer than 23 characters, cut to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.strip('-')
    
    return handle
