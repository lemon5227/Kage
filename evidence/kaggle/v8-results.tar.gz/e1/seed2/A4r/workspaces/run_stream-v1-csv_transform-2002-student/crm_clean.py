import csv
import io


def tidy_csv(text):
    """Tidy a CSV export with columns: team, city, name, score, id.
    
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "id" cell is empty
    - Remove duplicate rows by "city", keeping the first occurrence
    - Sort rows by "name" ascending as strings (stable)
    """
    if text == "":
        return ""
    
    # Parse CSV
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    
    header = [c.strip() for c in rows[0]]
    data = [[c.strip() for c in r] for r in rows[1:]]
    
    # Find column indices
    id_idx = header.index('id') if 'id' in header else None
    city_idx = header.index('city') if 'city' in header else None
    name_idx = header.index('name') if 'name' in header else None
    
    # Drop rows whose "id" cell is empty
    if id_idx is not None:
        data = [r for r in data if len(r) > id_idx and r[id_idx] != ""]
    
    # Remove duplicate rows by "city", keeping the first occurrence
    if city_idx is not None:
        seen = set()
        out = []
        for r in data:
            if len(r) > city_idx:
                city = r[city_idx]
                if city not in seen:
                    seen.add(city)
                    out.append(r)
        data = out
    
    # Sort rows by "name" ascending as strings (stable sort)
    if name_idx is not None:
        data.sort(key=lambda r: r[name_idx] if len(r) > name_idx else "", stable=True)
    
    # Write output with csv module using '\n' line endings
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
