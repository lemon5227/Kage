def tally_events(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        field = parts[1]
        if not field:
            continue
        field = field.upper()
        counts[field] = counts.get(field, 0) + 1
    return counts
