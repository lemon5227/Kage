import csv
import io

def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    idx = {name: i for i, name in enumerate(header)}
    def cell(row, name):
        i = idx.get(name)
        return row[i] if i is not None and i < len(row) else ""
    data = [[c.strip() for c in r] for r in rows[1:]]
    data = [r for r in data if cell(r, 'name') != ""]
    lc = idx.get('email')
    if lc is not None:
        for r in data:
            if lc < len(r):
                r[lc] = r[lc].lower()
    seen = set()
    deduped = []
    for r in data:
        k = cell(r, 'name')
        if k in seen:
            continue
        seen.add(k)
        deduped.append(r)
    deduped.sort(key=lambda r: cell(r, 'email'))
    out = io.StringIO()
    w = csv.writer(out, lineterminator="\n")
    w.writerow(header)
    w.writerows(deduped)
    return out.getvalue()
