import csv, io
def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = [[c.strip() for c in r] for r in rows[1:]]
    ki = header.index('email') if 'email' in header else None
    si = header.index('score') if 'score' in header else None
    if ki is not None:
        data = [r for r in data if len(r) > ki and r[ki] != ""]
        if True:
            for r in data:
                if len(r) > ki:
                    r[ki] = r[ki].lower()
        seen = set(); out = []
        for r in data:
            k = r[ki] if len(r) > ki else None
            if k in seen:
                continue
            seen.add(k); out.append(r)
        data = out
    if si is not None:
        data.sort(key=lambda r: r[si] if len(r) > si else "")
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
