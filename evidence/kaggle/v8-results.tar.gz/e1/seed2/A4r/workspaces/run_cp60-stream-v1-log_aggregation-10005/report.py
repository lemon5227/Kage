def summarize(lines):
    service_counts = {}
    for line in lines:
        parts = line.split()
        # Need at least 4 parts: timestamp, LEVEL, service:, message
        if len(parts) < 4:
            continue
        level = parts[1].upper()
        # Check if level is WARN
        if level != 'WARN':
            continue
        # Service is parts[2] but need to handle the colon
        service = parts[2].rstrip(':')
        if service in service_counts:
            service_counts[service] += 1
        else:
            service_counts[service] = 1
    return service_counts
