def digest_lines(lines):
    key, only = 'level', []
    out = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(' ', 3)
        if len(parts) < 4 or not parts[2].endswith(':') or len(parts[2]) < 2:
            continue
        level, service = parts[1].upper(), parts[2][:-1]
        if only and level not in only:
            continue
        name = level if key == 'level' else service
        out[name] = out.get(name, 0) + 1
    return out
