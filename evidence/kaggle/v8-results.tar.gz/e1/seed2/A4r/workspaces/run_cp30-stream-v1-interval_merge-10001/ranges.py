def merge_slots(intervals):
    norm = []
    for iv in intervals:
        s, e = iv['from'], iv['to']
        if s > e:
            raise ValueError("invalid interval: start > end")
        norm.append([s, e])
    norm.sort(key=lambda x: x[0])
    out = []
    for s, e in norm:
        if out and s <= out[-1][1]:
            if e > out[-1][1]:
                out[-1][1] = e
        else:
            out.append([s, e])
    return [{'from': s, 'to': e} for s, e in out]
