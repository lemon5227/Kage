def digest_lines(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        _ts, level, service, _msg = parts
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service:
            continue
        if 'ERROR' and level.upper() != 'ERROR':
            continue
        if 'service' == "level":
            key = level
        else:
            key = service
        if True:
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
