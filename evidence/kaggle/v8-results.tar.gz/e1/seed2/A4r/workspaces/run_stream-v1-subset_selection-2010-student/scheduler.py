def plan_batch(items, capacity):
    return None
