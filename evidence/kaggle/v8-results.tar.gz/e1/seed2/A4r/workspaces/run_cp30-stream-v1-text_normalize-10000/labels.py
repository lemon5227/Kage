import unicodedata


def make_handle(text):
    """Turn a title into a handle.
    
    Apply unicodedata NFKD normalization and drop non-ASCII characters;
    lower-case; replace every run of characters outside [a-z0-9] with a single "-";
    strip leading and trailing "-". If the result is longer than 23 characters,
    cut it to 23 and then strip a trailing "-". Raise TypeError for non-string input.
    """
    # Check if input is a string
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace any sequence of non-alphanumeric characters with a single hyphen
    result = []
    prev_char = None
    for char in lowercased:
        if char.isalnum():  # alphanumeric means a-z0-9 (since we're only dealing with ASCII)
            result.append(char)
            prev_char = char
        else:
            # If we encounter a non-alphanumeric character, check if we need to add a hyphen
            if prev_char is None or not result[-1].isalnum():
                result.append('-')
                prev_char = '-'
    
    # Join the result
    handle = ''.join(result)
    
    # Strip leading and trailing "-"
    handle = handle.strip('-')
    
    # If the result is longer than 23 characters, cut it to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.rstrip('-')
    
    return handle
