def merge_slots(intervals):
    """Merge overlapping time ranges into non-overlapping intervals sorted by start."""
    norm = []
    for iv in intervals:
        s, e = iv['start'], iv['end']
        if s > e:
            raise ValueError("invalid interval: start > end")
        norm.append([s, e])
    norm.sort(key=lambda x: x[0])
    out = []
    for s, e in norm:
        if out and s <= out[-1][1]:
            if e > out[-1][1]:
                out[-1][1] = e
        else:
            out.append([s, e])
    # Convert lists to dicts with 'start' and 'end' keys
    return [{'start': s, 'end': e} for s, e in out]
