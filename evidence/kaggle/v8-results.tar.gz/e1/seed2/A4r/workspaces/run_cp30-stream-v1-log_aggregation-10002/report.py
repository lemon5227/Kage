def digest_lines(lines):
    """Process log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per level, treating level names case-insensitively (upper-case keys),
    dropping malformed input lines.
    """
    counts = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split by spaces to get parts
        parts = line.split()
        if len(parts) < 3:
            # Malformed: need at least timestamp, level, and service
            continue
        
        # Check format: <timestamp> <LEVEL> <service>: <message>
        # The third part should end with ':'
        if parts[2].endswith(':'):
            timestamp = parts[0]
            level = parts[1]
            service = parts[2]
            message = ' '.join(parts[3:]) if len(parts) > 3 else ''
            
            # Validate that we have a valid level (non-empty)
            if not level:
                continue
            
            # Store level in uppercase
            level_upper = level.upper()
            counts[level_upper] = counts.get(level_upper, 0) + 1
    
    return counts
