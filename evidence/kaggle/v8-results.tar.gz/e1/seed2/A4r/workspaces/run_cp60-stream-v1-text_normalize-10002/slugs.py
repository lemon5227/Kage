import unicodedata


def slugify(text):
    """Build a URL slug from text.
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with a single "-", and
    strips leading and trailing "-".
    
    Raises TypeError if text is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we replace any sequence of non-alphanumeric characters with "-"
    slug = ''
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            # If this is a non-alphanumeric character and the previous was also non-alphanumeric,
            # skip it (we only want one "-" per run)
            if prev_char is None or prev_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                slug += '-'
        else:
            # Keep alphanumeric characters
            slug += char
        prev_char = char
    
    # Strip leading and trailing "-"
    slug = slug.strip('-')
    
    return slug
