def digest_lines(lines):
    return {}
