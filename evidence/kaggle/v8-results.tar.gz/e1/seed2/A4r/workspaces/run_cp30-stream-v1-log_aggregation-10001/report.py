def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'
    
    Returns {name: count} per service for levels ERROR, WARN only, treating level names case-insensitively.
    Drops malformed input lines.
    """
    counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split by spaces to get parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, convert to uppercase
        service = parts[2]
        
        # Check if level is ERROR or WARN
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Count this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
