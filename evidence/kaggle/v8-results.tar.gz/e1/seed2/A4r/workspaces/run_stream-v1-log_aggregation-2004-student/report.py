def digest_lines(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        service = parts[2]
        if level != "ERROR":
            continue
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
