def select_tasks(items, capacity):
    return None
