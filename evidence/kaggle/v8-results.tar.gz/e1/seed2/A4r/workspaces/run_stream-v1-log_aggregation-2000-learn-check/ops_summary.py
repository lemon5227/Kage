def aggregate_log(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        if parts[1].upper() not in ['ERROR', 'WARN']:
            continue
        key = parts[2]
        if key.endswith(":"):
            key = key[:-1]
        if not key:
            continue
        if True:
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
