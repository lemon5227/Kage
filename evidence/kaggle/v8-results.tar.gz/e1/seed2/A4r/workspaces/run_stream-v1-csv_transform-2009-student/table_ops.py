def dedupe_export(text):
    return None
