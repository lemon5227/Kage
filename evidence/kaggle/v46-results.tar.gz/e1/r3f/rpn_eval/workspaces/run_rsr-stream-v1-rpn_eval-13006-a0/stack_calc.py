def calc_rpn(expr):
    """
    Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: string of space-separated tokens (integers and operators + - *)
    
    Returns:
        int: the result of evaluating the expression
    
    Raises:
        ValueError: if an unknown token, operator without two operands, 
                   or anything other than exactly one value left
    """
    # Split into tokens
    tokens = expr.split()
    
    # Stack to hold operands
    stack = []
    
    for token in tokens:
        # Check if token is a valid integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Not an integer, must be an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError(f"Operator '+' requires two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError(f"Operator '-' requires two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError(f"Operator '*' requires two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains on the stack
    if len(stack) != 1:
        raise ValueError("Expression must evaluate to exactly one value")
    
    return stack[0]
