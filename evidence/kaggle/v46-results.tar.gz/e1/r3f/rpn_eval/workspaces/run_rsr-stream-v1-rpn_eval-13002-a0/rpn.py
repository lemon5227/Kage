def run_postfix(expr):
    """Evaluate a postfix expression (reverse Polish notation).
    
    The expression is a string of space-separated tokens containing integers
    (possibly negative) and operators + - * /. 
    Division is integer division truncated toward zero.
    
    Raises:
        ZeroDivisionError: if dividing by zero
        ValueError: for unknown token, operator without two operands,
                    or anything other than exactly one value left
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
            continue
        except ValueError:
            pass
        
        # Check operators
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        elif token == '/':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            if b == 0:
                raise ZeroDivisionError("Division by zero")
            # Integer division truncated toward zero
            stack.append(int(a / b))
        else:
            raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
