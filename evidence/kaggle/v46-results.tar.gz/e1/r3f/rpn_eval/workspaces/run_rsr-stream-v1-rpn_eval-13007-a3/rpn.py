def eval_stack(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: A string of space-separated tokens in RPN format.
              Tokens can be integers (possibly negative) or operators + - * /.
              '/' is integer floor division (like Python //).
    
    Returns:
        The integer result of the evaluation.
    
    Raises:
        ValueError: If an unknown token, operator without two operands, 
                   or more than one value left at the end.
        ZeroDivisionError: If division by zero occurs.
    """
    stack = []
    tokens = expr.split()
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
            continue
        except ValueError:
            pass
        
        # Check if it's an operator
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        elif token == '/':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            if b == 0:
                raise ZeroDivisionError("Division by zero")
            # Integer floor division (like Python //)
            stack.append(a // b)
        else:
            raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("More than one value left")
    
    return stack[0]
