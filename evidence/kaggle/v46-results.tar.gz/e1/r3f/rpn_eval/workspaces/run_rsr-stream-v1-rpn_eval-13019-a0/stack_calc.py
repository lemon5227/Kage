def evaluate(expr):
    """
    Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: string of space-separated tokens in reverse Polish notation.
              Integers (possibly negative, like -4) and operators + - * /.
              "/" is integer floor division (like Python //).
    
    Returns:
        int: the integer result.
    
    Raises:
        ValueError: for unknown token, operator without two operands, or anything other than exactly one value left.
        ZeroDivisionError: when dividing by zero.
    """
    stack = []
    tokens = expr.split()
    
    for token in tokens:
        # Check if token is a number (including negative numbers)
        try:
            num = int(token)
            stack.append(num)
            continue
        except ValueError:
            pass
        
        # Check if it's an operator
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        elif token == '/':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            if b == 0:
                raise ZeroDivisionError("division by zero")
            # Integer floor division (like Python //)
            stack.append(a // b)
        else:
            raise ValueError(f"Unknown token: {token}")
    
    # After processing all tokens, there should be exactly one value left
    if len(stack) != 1:
        raise ValueError("Expected exactly one value left")
    
    return stack[0]
