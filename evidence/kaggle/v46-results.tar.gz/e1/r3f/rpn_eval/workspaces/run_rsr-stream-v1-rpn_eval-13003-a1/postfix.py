def evaluate(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    The expression is a string of space-separated tokens in reverse Polish notation:
    integers (possibly negative, like -4) and the operators + - *.
    Returns the integer result. Raises ValueError for:
    - unknown token
    - operator without two operands
    - anything other than exactly one value left
    """
    tokens = expr.split()
    
    if not tokens:
        raise ValueError("Empty expression")
    
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative numbers)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Token is not a valid integer, check if it's an operator
            if token in ('+', '-', '*'):
                # Operator - need to pop two operands
                if len(stack) < 2:
                    raise ValueError(f"Operator '{token}' without two operands")
                b = stack.pop()
                a = stack.pop()
                if token == '+':
                    result = a + b
                elif token == '-':
                    result = a - b
                elif token == '*':
                    result = a * b
                else:
                    raise ValueError(f"Unknown operator '{token}'")
                stack.append(result)
            else:
                raise ValueError(f"Unknown token '{token}'")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError(f"Expected exactly one value, got {len(stack)} values")
    
    return stack[0]
