def run_postfix(expr):
    """
    Evaluate a postfix expression.
    
    The expression is a string of space-separated tokens in reverse Polish notation.
    Tokens can be integers (possibly negative, like -4) and operators + - * /.
    "/" is integer division truncated toward zero (so -7 / 2 is -3).
    Dividing by zero raises ZeroDivisionError.
    Returns the integer result.
    Raises ValueError for:
    - an unknown token
    - an operator without two operands
    - anything other than exactly one value left
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            elif token == '/':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                if b == 0:
                    raise ZeroDivisionError
                # Integer division truncated toward zero
                result = a // b if (a * b) >= 0 else -(abs(a) // abs(b))
                stack.append(result)
            else:
                raise ValueError("Unknown token")
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
