def run_postfix(expr):
    """Evaluate a postfix expression (reverse Polish notation).
    
    Args:
        expr: A string of space-separated tokens containing integers and operators (+, -, *)
    
    Returns:
        The integer result
    
    Raises:
        ValueError: For unknown tokens, operators without two operands, or not exactly one value left
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a valid integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token not in ('+', '-', '*'):
                raise ValueError(f"Unknown token: {token}")
            
            # Check if there are at least two operands
            if len(stack) < 2:
                raise ValueError(f"Operator '{token}' without two operands")
            
            # Pop the two top operands
            b = stack.pop()
            a = stack.pop()
            
            # Apply the operator
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Not exactly one value left")
    
    return stack[0]
