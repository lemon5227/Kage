def evaluate(expr):
    """Evaluate a postfix expression.
    
    Args:
        expr: A string of space-separated tokens in reverse Polish notation.
        
    Returns:
        The integer result.
        
    Raises:
        ValueError: For unknown token, operator without two operands, or more than one value left.
        ZeroDivisionError: When dividing by zero.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a negative number (starts with -)
        # We need to handle negative numbers like -4
        if token.startswith('-'):
            try:
                value = int(token)
                stack.append(value)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
        else:
            try:
                value = int(token)
                stack.append(value)
            except ValueError:
                # Check if it's an operator
                if token in ('+', '-', '*', '/'):
                    # Operators need two operands
                    if len(stack) < 2:
                        raise ValueError(f"Operator {token} without two operands")
                    # Pop two operands and apply operator
                    b = stack.pop()
                    a = stack.pop()
                    if token == '+':
                        result = a + b
                    elif token == '-':
                        result = a - b
                    elif token == '*':
                        result = a * b
                    elif token == '/':
                        if b == 0:
                            raise ZeroDivisionError
                        # Integer division truncated toward zero
                        result = int(a / b)
                    else:
                        raise ValueError(f"Unknown operator: {token}")
                    stack.append(result)
                else:
                    raise ValueError(f"Unknown token: {token}")
    
    # Must have exactly one value left
    if len(stack) != 1:
        raise ValueError("More than one value left")
    
    return stack[0]
