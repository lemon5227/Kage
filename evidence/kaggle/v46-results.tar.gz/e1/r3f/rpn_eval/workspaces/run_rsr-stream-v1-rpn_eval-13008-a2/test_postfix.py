from postfix import evaluate

# Test cases
test_cases = [
    ("5 3 +", 8),
    ("10 2 *", 20),
    ("-4 2 +", -2),  # -4 + 2 = -2
    ("10 2 /", 5),
    ("-7 2 /", -3),  # -7 / 2 = -3 (truncated toward zero)
    ("3 4 * 2 +", 14),  # 3*4=12, 12+2=14
    ("1 2 3 + -", -0),  # 1+2=3, 3+3=6, 6-3=3? Wait: 1 2 3 + - means 1 2 3 + = 6, then 6 - 3 = 3
    # Let me recalculate: 1 2 3 + - -> 1 2 3 + = 6, then 6 - 3 = 3
    ("1 2 3 + -", 3),
    ("5 3 + 2 *", 16),  # 5+3=8, 8*2=16
    ("-4 2 + 3 *", -3),  # -4+2=-2, -2*3=-6? Wait: -4 2 + = -2, -2 3 * = -6
    ("-4 2 + 3 *", -6),
]

print("Running tests...")
for expr, expected in test_cases:
    try:
        result = evaluate(expr)
        status = "PASS" if result == expected else f"FAIL (got {result}, expected {expected})"
        print(f"{expr}: {status}")
    except Exception as e:
        print(f"{expr}: ERROR - {e}")

# Test error cases
error_cases = [
    ("1 2 + 3", "More than one value left"),  # 1+2=3, then 3+3=6? Wait: 1 2 + = 3, 3 3 + = 6. So this should be 6, not error.
    # Let me reconsider: 1 2 + 3 -> 1 2 + = 3, then 3 3 + = 6. So this is valid and returns 6.
    # I need to test actual errors:
    ("1 +", "Operator without two operands"),
    ("1 2 + 3 *", "More than one value left"),  # 1+2=3, 3*3=9, wait that's correct. Let me think again.
    # Actually: 1 2 + 3 * -> 1 2 + = 3, then 3 3 * = 9. So it's valid.
    # I need to find a case with more than one value left.
    ("1 2", "More than one value left"),  # Two values on stack, no operator
]

print("\nTesting error cases...")
for expr, expected_error in error_cases:
    try:
        result = evaluate(expr)
        print(f"{expr}: FAIL (got {result}, expected error)")
    except Exception as e:
        if "ValueError" in str(type(e)) or "ZeroDivisionError" in str(type(e)):
            print(f"{expr}: PASS (raised {type(e).__name__})")
        else:
            print(f"{expr}: ERROR - {e}")
