def eval_stack(expr):
    """Evaluate a postfix expression (reverse Polish notation).
    
    Args:
        expr: String of space-separated tokens. Tokens can be integers (including negative) 
              or operators (+, -, *, /).
    
    Returns:
        Integer result of the evaluation.
    
    Raises:
        ZeroDivisionError: If division by zero occurs.
        ValueError: If there's an unknown token, an operator without two operands, 
                    or more than one value left at the end.
    """
    tokens = expr.split()
    stack = []
    
    # Process tokens from right to left (postfix evaluation)
    for i in range(len(tokens) - 1, -1, -1):
        token = tokens[i]
        
        # Check if token is an integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Token is an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            elif token == '/':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                if b == 0:
                    raise ZeroDivisionError("Division by zero")
                # Integer division truncated toward zero
                result = int(a / b)
                stack.append(result)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains
    if len(stack) != 1:
        raise ValueError("More than one value left")
    
    return stack[0]
