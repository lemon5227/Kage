def evaluate(expr):
    """Evaluate a postfix expression (reverse Polish notation).
    
    Args:
        expr: string of space-separated tokens
        
    Returns:
        int: the result of the evaluation
        
    Raises:
        ValueError: for unknown token, operator without two operands, or not exactly one value left
        ZeroDivisionError: when dividing by zero
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token.startswith('-'):
            # Negative number - parse as integer
            try:
                num = int(token)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
        else:
            try:
                num = int(token)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
        
        if token in ('+', '-', '*', '/'):
            if len(stack) < 2:
                raise ValueError(f"Operator {token} without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            elif token == '/':
                if b == 0:
                    raise ZeroDivisionError("Division by zero")
                # Integer floor division (like Python //)
                result = a // b
            else:
                raise ValueError(f"Unknown operator: {token}")
            stack.append(result)
        else:
            raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("Expected exactly one value left")
    
    return stack[0]
