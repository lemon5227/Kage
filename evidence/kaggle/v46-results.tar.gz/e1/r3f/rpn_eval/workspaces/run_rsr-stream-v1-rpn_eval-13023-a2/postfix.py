def calc_rpn(expr):
    """Evaluate a postfix expression in reverse Polish notation.
    
    Args:
        expr: String of space-separated tokens (integers, +, -, *)
    
    Returns:
        Integer result
    
    Raises:
        ValueError: For unknown tokens, operator without two operands, or incorrect final state
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
            continue
        except ValueError:
            pass
        
        # Check if it's an operator
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        else:
            raise ValueError(f"Unknown token: {token}")
    
    # Must have exactly one value left
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
