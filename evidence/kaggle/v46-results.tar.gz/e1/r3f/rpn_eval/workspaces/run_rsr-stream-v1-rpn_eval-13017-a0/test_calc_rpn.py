#!/usr/bin/env python3
from stack_calc import calc_rpn

def test_calc_rpn():
    # Test basic operations
    assert calc_rpn("3 4 +") == 7
    assert calc_rpn("3 4 -") == -1
    assert calc_rpn("3 4 *") == 12
    assert calc_rpn("3 4 /") == 0
    
    # Test negative numbers
    assert calc_rpn("-4 5 -") == -1
    assert calc_rpn("5 -4 +") == 1
    assert calc_rpn("-7 2 /") == -3
    
    # Test multiple operations
    assert calc_rpn("3 4 * 2 +") == 14
    assert calc_rpn("10 2 / 3 *") == 6
    
    # Test nested operations
    assert calc_rpn("3 4 + 2 *") == 14
    assert calc_rpn("3 4 + 2 -") == 5
    
    # Test error cases
    try:
        calc_rpn("3 +")
        assert False, "Should raise ValueError"
    except ValueError as e:
        pass  # Expected
    
    try:
        calc_rpn("3 4 + 5")
        assert False, "Should raise ValueError"
    except ValueError as e:
        pass  # Expected
    
    try:
        calc_rpn("")
        assert False, "Should raise ValueError"
    except ValueError as e:
        pass  # Expected
    
    try:
        calc_rpn("3 / 0")
        assert False, "Should raise ZeroDivisionError"
    except ZeroDivisionError:
        pass  # Expected
    
    # Test unknown token
    try:
        calc_rpn("3 ?")
        assert False, "Should raise ValueError"
    except ValueError as e:
        pass  # Expected
    
    print("All tests passed!")

if __name__ == "__main__":
    test_calc_rpn()
