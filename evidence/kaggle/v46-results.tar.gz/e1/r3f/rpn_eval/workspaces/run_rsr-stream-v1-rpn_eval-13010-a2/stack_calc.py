def evaluate(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: A string of space-separated tokens in reverse Polish notation.
              Integers (possibly negative, like -4) and operators + - *.
    
    Returns:
        The integer result.
    
    Raises:
        ValueError: For unknown token, operator without two operands,
                    or anything other than exactly one value left.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Not a valid number, check if it's an operator
            if token in '+- *':
                # Operator: need two operands
                if len(stack) < 2:
                    raise ValueError(f"Operator '{token}' requires two operands")
                b = stack.pop()
                a = stack.pop()
                if token == '+':
                    result = a + b
                elif token == '-':
                    result = a - b
                elif token == '*':
                    result = a * b
                else:
                    raise ValueError(f"Unknown operator '{token}'")
                stack.append(result)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains on the stack
    if len(stack) != 1:
        raise ValueError("Expected exactly one value left on stack")
    
    return stack[0]
