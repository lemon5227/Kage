def calc_rpn(expr):
    """Evaluate a postfix expression."""
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
            continue
        except ValueError:
            pass
        
        # Check if it's an operator
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        else:
            raise ValueError(f"Unknown token: {token}")
    
    # Should have exactly one value left
    if len(stack) != 1:
        raise ValueError("Not exactly one value left")
    
    return stack[0]
