def calc_rpn(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: String of space-separated tokens in reverse Polish notation.
              Tokens can be integers (possibly negative) or operators: + - *
    
    Returns:
        int: The integer result of the evaluation.
    
    Raises:
        ValueError: If an unknown token is found, an operator has fewer than 
                   two operands, or the final stack does not contain exactly one value.
    """
    # Split expression into tokens
    tokens = expr.split()
    
    # Stack to hold operands
    stack = []
    
    # Process each token
    for token in tokens:
        # Check if token is a number (integer, possibly negative)
        try:
            value = int(token)
            stack.append(value)
        except ValueError:
            # Token is not a valid integer, must be an operator
            if token == '+':
                # Pop two operands and add them
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Exactly one value left on stack")
    
    return stack[0]
