def calc_rpn(expr):
    """Evaluate a postfix expression (reverse Polish notation).
    
    Args:
        expr: string of space-separated tokens
        
    Returns:
        int: result of evaluation
        
    Raises:
        ValueError: for unknown token, operator without two operands, or not exactly one value left
        ZeroDivisionError: when dividing by zero
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token.isdigit() or (token.startswith('-') and token[1:].isdigit()):
            # Integer token
            stack.append(int(token))
        elif token in ('+', '-', '*', '/'):
            # Binary operator
            if len(stack) < 2:
                raise ValueError(f"Operator {token} without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            elif token == '/':
                if b == 0:
                    raise ZeroDivisionError("division by zero")
                # Integer division truncated toward zero
                result = int(a / b)
            else:
                raise ValueError(f"Unknown operator {token}")
            stack.append(result)
        else:
            raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("Expected exactly one value left")
    
    return stack[0]
