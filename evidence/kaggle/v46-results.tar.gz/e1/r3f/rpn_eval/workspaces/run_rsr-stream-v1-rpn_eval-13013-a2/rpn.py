def evaluate(expr):
    """Evaluate a postfix expression (RPN).
    
    Args:
        expr: A string of space-separated tokens in reverse Polish notation.
               Tokens can be integers (possibly negative) or operators (+, -, *).
    
    Returns:
        The integer result.
    
    Raises:
        ValueError: For unknown token, operator without two operands,
                    or anything other than exactly one value left.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token.isdigit() or (token.startswith('-') and token[1:].isdigit()):
            # It's an integer
            stack.append(int(token))
        elif token in '+-*':
            # It's an operator - need two operands
            if len(stack) < 2:
                raise ValueError(f"Operator '{token}' without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
        else:
            raise ValueError(f"Unknown token: '{token}'")
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
