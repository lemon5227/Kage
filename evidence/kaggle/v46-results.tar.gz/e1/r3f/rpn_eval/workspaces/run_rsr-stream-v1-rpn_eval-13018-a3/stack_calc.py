def evaluate(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: string of space-separated tokens. Integers (possibly negative) 
              and operators + - * are supported.
    
    Returns:
        int: The result of the evaluation.
    
    Raises:
        ValueError: If an unknown token is found, an operator without two 
                   operands, or not exactly one value remains.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is an integer (including negative)
        try:
            num = int(token)
            stack.append(num)
            continue
        except ValueError:
            pass
        
        # Check if it's an operator
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        else:
            raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Not exactly one value left")
    
    return stack[0]
