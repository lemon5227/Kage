def evaluate(expr):
    """Evaluate a postfix expression (reverse Polish notation).
    
    Args:
        expr: A string of space-separated tokens (integers and operators + - *)
    
    Returns:
        The integer result
    
    Raises:
        ValueError: For unknown token, operator without two operands, or wrong number of values left
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is an integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token not in '+-*':
                raise ValueError(f"Unknown token: {token}")
            
            # Need two operands
            if len(stack) < 2:
                raise ValueError(f"Operator '{token}' without two operands")
            
            # Pop two operands
            b = stack.pop()
            a = stack.pop()
            
            # Apply operator
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            else:
                raise ValueError(f"Unknown operator: {token}")
            
            stack.append(result)
    
    # Check exactly one value left
    if len(stack) != 1:
        raise ValueError("Exactly one value must remain on the stack")
    
    return stack[0]
