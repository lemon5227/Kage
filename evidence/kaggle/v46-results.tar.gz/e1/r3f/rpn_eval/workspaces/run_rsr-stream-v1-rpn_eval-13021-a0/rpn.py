def eval_stack(expr):
    """Evaluate a postfix expression in reverse Polish notation.
    
    Args:
        expr: string of space-separated tokens (integers and operators + - *)
        
    Returns:
        int: the result of evaluating the expression
        
    Raises:
        ValueError: if unknown token, operator without two operands, or not exactly one value left
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a valid integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Not exactly one value left")
    
    return stack[0]
