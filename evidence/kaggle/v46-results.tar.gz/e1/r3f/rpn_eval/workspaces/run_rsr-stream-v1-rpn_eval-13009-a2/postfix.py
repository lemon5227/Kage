def calc_rpn(expr):
    """Evaluate a postfix expression."""
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if it's an operator
        if token in '+- *':
            # Operators need two operands
            if len(stack) < 2:
                raise ValueError(f"Operator {token} without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            else:
                raise ValueError(f"Unknown operator {token}")
            stack.append(result)
        else:
            # Check if it's a valid integer (including negative)
            try:
                num = int(token)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
            stack.append(num)
    
    # Must have exactly one value left
    if len(stack) != 1:
        raise ValueError("More than one value left in stack")
    
    return stack[0]
