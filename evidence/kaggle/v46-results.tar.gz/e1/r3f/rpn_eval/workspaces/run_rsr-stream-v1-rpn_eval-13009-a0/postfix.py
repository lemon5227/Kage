def calc_rpn(expr):
    """
    Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: A string of space-separated tokens in RPN format.
              Tokens are integers (possibly negative) and operators (+, -, *).
    
    Returns:
        The integer result of the evaluation.
    
    Raises:
        ValueError: If an unknown token is found, an operator has fewer than two operands,
                   or the expression doesn't evaluate to exactly one value.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a valid integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Not an integer, must be an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError(f"Operator '+' requires two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError(f"Operator '-' requires two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError(f"Operator '*' requires two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Expression does not evaluate to exactly one value")
    
    return stack[0]
