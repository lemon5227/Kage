from rpn import eval_stack

# Test cases
test_cases = [
    ("5 3 +", 8),
    ("10 2 *", 20),
    ("-4 2 +", -2),
    ("10 2 /", 5),
    ("-7 2 /", -3),  # Truncation toward zero: -7/2 = -3.5 -> -3
    ("10 2 -", 8),
    ("1 2 3 * +", 7),  # 1 2 3 * + => (1 2 *) 3 + => 2*3=6, 6+1=7
    ("5 3 -", 2),  # 5-3 = 2
    ("10 2 3 * +", 16),  # 10 2 3 * + => 10 (2*3) + => 10+6=16
    ("-5 2 /", -2),  # -5/2 = -2.5 -> -2
]

print("Testing eval_stack:")
for expr, expected in test_cases:
    try:
        result = eval_stack(expr)
        status = "PASS" if result == expected else f"FAIL (got {result}, expected {expected})"
        print(f"{expr} -> {result} [{status}]")
    except Exception as e:
        print(f"{expr} -> ERROR: {e}")

# Test error cases
error_cases = [
    ("", "Empty expression"),
    ("5 +", "Operator without two operands"),
    ("+ 5 3", "Operator without two operands"),
    ("5 0 /", "Division by zero"),
    ("1 2 3 * + 4", "More than one value left"),
]

print("\nTesting error cases:")
for expr, expected_error in error_cases:
    try:
        result = eval_stack(expr)
        print(f"{expr} -> UNEXPECTED SUCCESS: {result}")
    except Exception as e:
        print(f"{expr} -> {type(e).__name__}: {e}")
