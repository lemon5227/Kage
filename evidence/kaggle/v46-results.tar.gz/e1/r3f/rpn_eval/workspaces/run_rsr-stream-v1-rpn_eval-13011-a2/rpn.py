def eval_stack(expr):
    """Evaluate a postfix expression.
    
    Args:
        expr: string of space-separated tokens in reverse Polish notation
        
    Returns:
        int: the result of the evaluation
        
    Raises:
        ValueError: for unknown token, operator without two operands, or more than one value left
        ZeroDivisionError: when dividing by zero
    """
    tokens = expr.split()
    
    if not tokens:
        raise ValueError("Empty expression")
    
    stack = []
    
    for token in tokens:
        # Check if token is an integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            elif token == '/':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                if b == 0:
                    raise ZeroDivisionError("Division by zero")
                # Integer division truncated toward zero
                result = a // b
                # But need to handle negative numbers correctly for truncation toward zero
                # Python's // is floor division, which can be different from truncation toward zero
                # For example: -7 // 2 = -4, but we want -3
                # We need to implement truncation toward zero manually
                if (a < 0) != (b < 0):
                    # Result should be negative
                    result = -(abs(a) // abs(b))
                else:
                    result = a // b
                stack.append(result)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("More than one value left")
    
    return stack[0]
