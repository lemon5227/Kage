def calc_rpn(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: string of space-separated tokens (integers and operators)
    
    Returns:
        int: the result of evaluation
    
    Raises:
        ValueError: for unknown token, operator without two operands, or more than one value left
        ZeroDivisionError: when division by zero occurs
    """
    stack = []
    tokens = expr.split()
    
    for token in tokens:
        # Check if token is an integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            elif token == '/':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                # Integer division truncated toward zero
                stack.append(int(a / b))
            else:
                raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("More than one value left")
    
    return stack[0]
