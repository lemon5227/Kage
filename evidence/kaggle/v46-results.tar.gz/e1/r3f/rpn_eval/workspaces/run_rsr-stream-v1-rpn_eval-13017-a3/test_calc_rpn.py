from stack_calc import calc_rpn

# Test cases
print("Test 1:", calc_rpn("3 4 +"))  # 7
print("Test 2:", calc_rpn("10 5 -"))  # 5
print("Test 3:", calc_rpn("10 2 *"))  # 20
print("Test 4:", calc_rpn("7 2 /"))  # 3
print("Test 5:", calc_rpn("-7 2 /"))  # -3 (truncated toward zero)
print("Test 6:", calc_rpn("-10 2 /"))  # -5
print("Test 7:", calc_rpn("3 4 5 * +"))  # 23
print("Test 8:", calc_rpn("-4 2 +"))  # -2

# Test error cases
try:
    calc_rpn("3")  # Only one operand, should raise ValueError
except ValueError as e:
    print("Error test 1:", e)

try:
    calc_rpn("3 4 + 5")  # More than one value left
except ValueError as e:
    print("Error test 2:", e)

try:
    calc_rpn("3 abc")  # Unknown token
except ValueError as e:
    print("Error test 3:", e)

try:
    calc_rpn("10 0 /")  # Division by zero
except ZeroDivisionError:
    print("Error test 4: ZeroDivisionError raised correctly")
