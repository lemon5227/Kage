def evaluate(expr):
    """Evaluate a postfix expression string.
    
    Args:
        expr: Space-separated tokens in reverse Polish notation (integers, +, -, *)
    
    Returns:
        Integer result
    
    Raises:
        ValueError: For unknown token, operator without two operands, or incorrect final state
    """
    stack = []
    tokens = expr.split()
    
    for token in tokens:
        # Check if token is a valid integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Token is not an integer, must be an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # After processing all tokens, there should be exactly one value left
    if len(stack) != 1:
        raise ValueError("Expected exactly one value left")
    
    return stack[0]
