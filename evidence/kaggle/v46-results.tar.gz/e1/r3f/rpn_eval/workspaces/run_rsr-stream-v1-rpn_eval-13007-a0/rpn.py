def eval_stack(expr):
    """Evaluate a postfix expression (RPN).
    
    Args:
        expr: A string of space-separated tokens in reverse Polish notation.
               Integers (possibly negative, like -4) and operators + - * /.
               "/" is integer floor division (like Python //).
    
    Returns:
        int: The integer result.
    
    Raises:
        ValueError: For an unknown token, an operator without two operands,
                    or anything other than exactly one value left.
        ZeroDivisionError: When dividing by zero.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative numbers)
        try:
            num = int(token)
            stack.append(num)
            continue
        except ValueError:
            pass
        
        # Handle operators
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        elif token == '/':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            if b == 0:
                raise ZeroDivisionError("Division by zero")
            stack.append(a // b)  # Integer floor division
        else:
            raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
