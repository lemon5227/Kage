def evaluate(expr):
    """Evaluate a postfix expression (Reverse Polish notation)."""
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token in ['+', '-', '*', '/']:
            if len(stack) < 2:
                raise ValueError(f"Operator {token} without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            elif token == '/':
                if b == 0:
                    raise ZeroDivisionError("Division by zero")
                # Integer floor division (like Python //)
                result = a // b
            else:
                raise ValueError(f"Unknown operator {token}")
            stack.append(result)
        else:
            try:
                # Parse integer, including negative numbers
                value = int(token)
                stack.append(value)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("Only one value left in stack")
    
    return stack[0]
