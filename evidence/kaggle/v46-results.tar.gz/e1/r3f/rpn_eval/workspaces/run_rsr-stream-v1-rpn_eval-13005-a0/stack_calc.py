def run_postfix(expr):
    """
    Evaluate a postfix expression (Reverse Polish Notation).
    Tokens are space-separated; integers (possibly negative) and operators + - *.
    Returns the integer result. Raises ValueError for unknown tokens, 
    operator without two operands, or anything other than exactly one value left.
    """
    tokens = expr.split()
    
    # Stack to hold operands
    stack = []
    
    for token in tokens:
        # Check if token is a number (possibly negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
