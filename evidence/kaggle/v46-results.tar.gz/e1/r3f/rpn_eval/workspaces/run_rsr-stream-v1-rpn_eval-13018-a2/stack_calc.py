def evaluate(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: string of space-separated tokens (integers and operators + - *)
    
    Returns:
        int: result of evaluation
    
    Raises:
        ValueError: if an unknown token, operator without two operands,
                   or more than one value left at the end
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token not in ['+', '-', '*']:
                raise ValueError(f"Unknown token: {token}")
            
            # Need two operands for binary operators
            if len(stack) < 2:
                raise ValueError(f"Operator {token} without two operands")
            
            # Pop two operands
            b = stack.pop()
            a = stack.pop()
            
            # Apply operator
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
    
    # Must have exactly one value left
    if len(stack) != 1:
        raise ValueError("More than one value left at the end")
    
    return stack[0]
