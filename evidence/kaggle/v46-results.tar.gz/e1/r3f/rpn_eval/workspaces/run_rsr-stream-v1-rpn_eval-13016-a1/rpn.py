def eval_stack(expr):
    """Evaluate a postfix (Reverse Polish Notation) expression."""
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token.isdigit() or (token.startswith('-') and token[1:].isdigit()):
            # It's an integer
            stack.append(int(token))
        elif token in '+-*/':
            if len(stack) < 2:
                raise ValueError(f"Operator '{token}' without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            elif token == '/':
                if b == 0:
                    raise ZeroDivisionError("Division by zero")
                result = int(a // b)  # floor division
            else:
                raise ValueError(f"Unknown operator '{token}'")
            stack.append(result)
        else:
            raise ValueError(f"Unknown token '{token}'")
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    return stack[0]
