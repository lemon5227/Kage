def calc_rpn(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: A string of space-separated tokens in RPN format.
              Integers (possibly negative) and operators + - * are allowed.
    
    Returns:
        int: The integer result of the evaluation.
    
    Raises:
        ValueError: If an unknown token is found, an operator without two operands,
                    or if exactly one value is left after evaluation.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check for integers (including negative numbers)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # After processing all tokens, there should be exactly one value left
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
