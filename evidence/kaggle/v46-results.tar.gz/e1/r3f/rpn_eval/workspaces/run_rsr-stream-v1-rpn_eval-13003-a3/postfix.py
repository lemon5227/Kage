def evaluate(expr):
    """Evaluate a postfix (reverse Polish) expression.
    
    Args:
        expr: String of space-separated tokens in reverse Polish notation.
               Tokens are integers (possibly negative) and operators + - *
    
    Returns:
        Integer result of the evaluation.
    
    Raises:
        ValueError: For unknown token, operator without two operands,
                    or anything other than exactly one value left.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token in ('+', '-', '*'):
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
            else:
                raise ValueError("Unknown operator")
        else:
            try:
                value = int(token)
                stack.append(value)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
