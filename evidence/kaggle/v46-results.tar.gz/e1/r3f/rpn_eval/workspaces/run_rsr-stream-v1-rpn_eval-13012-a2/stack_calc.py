def eval_stack(expr):
    """Evaluate a postfix expression (Reverse Polish Notation)."""
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative numbers)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Token is not a valid integer
            if token in ('+', '-', '*'):
                # It's an operator, check if there are two operands
                if len(stack) < 2:
                    raise ValueError(f"Operator '{token}' without two operands")
                # Pop two operands
                b = stack.pop()
                a = stack.pop()
                if token == '+':
                    stack.append(a + b)
                elif token == '-':
                    stack.append(a - b)
                elif token == '*':
                    stack.append(a * b)
                else:
                    raise ValueError(f"Unknown operator '{token}'")
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Exactly one value left in stack")
    
    return stack[0]
