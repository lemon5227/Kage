def evaluate(expr):
    """Evaluate a postfix expression."""
    stack = []
    tokens = expr.split()
    
    for token in tokens:
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        elif token == '/':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a // b)  # floor division
        else:
            try:
                value = int(token)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
            stack.append(value)
    
    if len(stack) != 1:
        raise ValueError("Expected exactly one value left")
    
    return stack[0]
