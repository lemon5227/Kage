def run_postfix(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    The expression is a string of space-separated tokens containing integers
    (possibly negative, like -4) and operators + - *.
    Returns the integer result.
    Raises ValueError for:
    - Unknown token
    - An operator without two operands
    - Anything other than exactly one value left
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is an integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token not in ['+', '-', '*']:
                raise ValueError(f"Unknown token: {token}")
            
            # Need exactly two operands
            if len(stack) < 2:
                raise ValueError(f"Operator {token} without two operands")
            
            # Pop two operands and apply operator
            b = stack.pop()
            a = stack.pop()
            
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
    
    # Check that exactly one value remains
    if len(stack) != 1:
        raise ValueError("Expected exactly one value left")
    
    return stack[0]
