def eval_stack(expr):
    """Evaluate a postfix expression (reverse Polish notation).
    
    Args:
        expr: String of space-separated tokens (integers and operators + - *)
    
    Returns:
        Integer result
    
    Raises:
        ValueError: For unknown token, operator without two operands, or not exactly one value left
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token in ('+', '-', '*'):
            if len(stack) < 2:
                raise ValueError(f"Operator '{token}' without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            else:
                raise ValueError(f"Unknown operator '{token}'")
            stack.append(result)
        else:
            # Try to parse as integer (handles negative numbers like -4)
            try:
                num = int(token)
            except ValueError:
                raise ValueError(f"Unknown token '{token}'")
            stack.append(num)
    
    if len(stack) != 1:
        raise ValueError("Not exactly one value left on stack")
    
    return stack[0]
