from postfix import calc_rpn

# Test cases
print("Test 1:", calc_rpn("3 4 +"))  # Should be 7
print("Test 2:", calc_rpn("10 5 -"))  # Should be 5
print("Test 3:", calc_rpn("2 3 *"))  # Should be 6
print("Test 4:", calc_rpn("3 4 + 2 *"))  # Should be 14
print("Test 5:", calc_rpn("-4 2 +"))  # Should be -2
print("Test 6:", calc_rpn("1 2 3 * +"))  # Should be 7
