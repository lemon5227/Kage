def calc_rpn(expr):
    """Evaluate a postfix expression (RPN).
    
    Args:
        expr: A string of space-separated tokens in reverse Polish notation.
              Integers (possibly negative, like -4) and operators + - * /.
    
    Returns:
        The integer result.
    
    Raises:
        ValueError: For an unknown token, an operator without two operands,
                   or anything other than exactly one value left.
        ZeroDivisionError: When dividing by zero.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Token is an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            elif token == '/':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                # Integer division truncated toward zero
                result = a // b
                # Handle negative numbers correctly for truncation toward zero
                # Python's // uses floor division, which is different from truncation toward zero
                # For example: -7 // 2 = -4 (floor), but we want -3 (truncated toward zero)
                if (a > 0 and b < 0) or (a < 0 and b > 0):
                    # One positive, one negative: adjust result by +1 if result is negative
                    # Actually, we need to compute truncation toward zero manually
                    result = abs(a) // abs(b)
                    if (a < 0) != (b < 0):
                        result = -result
                stack.append(result)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
