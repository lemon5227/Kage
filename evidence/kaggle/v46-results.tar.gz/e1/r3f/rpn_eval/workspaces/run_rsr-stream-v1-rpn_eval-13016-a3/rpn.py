def eval_stack(expr):
    return None
