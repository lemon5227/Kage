def run_postfix(expr):
    """
    Evaluate a postfix expression.
    
    The expression is a string of space-separated tokens in reverse Polish notation:
    integers (possibly negative, like -4) and the operators + - * /.
    "/" is integer division truncated toward zero (so -7 / 2 is -3).
    Dividing by zero raises ZeroDivisionError.
    Return the integer result.
    Raise ValueError for an unknown token, an operator without two operands,
    or anything other than exactly one value left.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a valid integer (including negative)
        try:
            num = int(token)
        except ValueError:
            # Not an integer, must be an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            elif token == '/':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                # Integer division truncated toward zero
                result = int(a / b)
                stack.append(result)
            else:
                raise ValueError(f"Unknown token: {token}")
        else:
            stack.append(num)
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
