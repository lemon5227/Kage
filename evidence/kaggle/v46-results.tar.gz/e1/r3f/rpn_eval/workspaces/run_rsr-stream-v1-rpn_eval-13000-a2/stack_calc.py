def evaluate(expr):
    """Evaluate a postfix expression (Reverse Polish Notation)."""
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token not in '+-*':
                raise ValueError(f"Unknown token: {token}")
            
            # Need two operands
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            
            # Pop operands
            b = stack.pop()
            a = stack.pop()
            
            # Apply operation
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            else:
                raise ValueError(f"Unknown operator: {token}")
            
            stack.append(result)
    
    # Should have exactly one value left
    if len(stack) != 1:
        raise ValueError("Anything other than exactly one value left")
    
    return stack[0]
