def eval_stack(expr):
    """Evaluate a postfix expression (reverse Polish notation)."""
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token == '+':
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        elif token == '/':
            b = stack.pop()
            a = stack.pop()
            if b == 0:
                raise ZeroDivisionError("Division by zero")
            stack.append(int(a // b))  # floor division
        else:
            # Try to parse as integer (positive or negative)
            try:
                stack.append(int(token))
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("Expected exactly one value left")
    
    return stack[0]
