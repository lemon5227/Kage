def evaluate(expr):
    """
    Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: A string of space-separated tokens in reverse Polish notation.
              Tokens are integers (possibly negative) and operators (+, -, *).
    
    Returns:
        The integer result.
    
    Raises:
        ValueError: For an unknown token, an operator without two operands,
                   or anything other than exactly one value left.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a valid integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token not in ('+', '-', '*'):
                raise ValueError(f"Unknown token: {token}")
            
            # Check if there are at least two operands
            if len(stack) < 2:
                raise ValueError(f"Operator '{token}' without two operands")
            
            # Pop two operands
            b = stack.pop()
            a = stack.pop()
            
            # Apply operator
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
    
    # Check if exactly one value remains
    if len(stack) != 1:
        raise ValueError("Exactly one value must remain after evaluation")
    
    return stack[0]
