def eval_stack(expr):
    """
    Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: A string of space-separated tokens in reverse Polish notation.
              Tokens are integers (possibly negative, like -4) and operators + - *.
    
    Returns:
        The integer result of the evaluation.
    
    Raises:
        ValueError: If an unknown token is found, an operator has fewer than 
                   two operands, or the final stack does not contain exactly one value.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a negative number (starts with -)
        # Note: We need to handle -4 as a single token, not '-' and '4'
        # So we check if the token starts with '-'
        try:
            # Try parsing as integer
            num = int(token)
            stack.append(num)
        except ValueError:
            # Not an integer, must be an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Expected exactly one value left")
    
    return stack[0]
