def eval_stack(expr):
    """Evaluate a postfix expression (RPN).
    
    Args:
        expr: string of space-separated tokens in reverse Polish notation.
               Integers (possibly negative, like -4) and operators + - *.
    
    Returns:
        The integer result.
    
    Raises:
        ValueError: For unknown token, operator without two operands,
                   or anything other than exactly one value left.
    """
    stack = []
    tokens = expr.split()
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Check if it's an operator
            if token in '+- *':
                # Operator needs two operands
                if len(stack) < 2:
                    raise ValueError(f"Operator '{token}' without two operands")
                b = stack.pop()
                a = stack.pop()
                if token == '+':
                    stack.append(a + b)
                elif token == '-':
                    stack.append(a - b)
                elif token == '*':
                    stack.append(a * b)
                else:
                    raise ValueError(f"Unknown operator '{token}'")
            else:
                raise ValueError(f"Unknown token '{token}'")
    
    # After processing all tokens, there should be exactly one value left
    if len(stack) != 1:
        raise ValueError(f"Expected exactly one value left, but got {len(stack)} values")
    
    return stack[0]
