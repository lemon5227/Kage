def evaluate(expr):
    """Evaluate a postfix expression (reverse Polish notation).
    
    Args:
        expr: String of space-separated tokens. Tokens are integers (possibly negative)
              and operators +, -, *.
    
    Returns:
        Integer result of the evaluation.
    
    Raises:
        ValueError: If there is an unknown token, an operator without two operands,
                   or more than one value left at the end.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token not in ('+', '-', '*'):
                raise ValueError(f"Unknown token: {token}")
            
            # Check if there are at least two operands
            if len(stack) < 2:
                raise ValueError(f"Operator {token} without two operands")
            
            # Pop two operands and apply operator
            b = stack.pop()
            a = stack.pop()
            
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
    
    # Check that exactly one value remains
    if len(stack) != 1:
        raise ValueError("More than one value left")
    
    return stack[0]
