def evaluate(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: String of space-separated tokens in reverse Polish notation.
              Integers (possibly negative, like -4) and operators + - * /.
              "/" is integer floor division (like Python //).
    
    Returns:
        Integer result.
    
    Raises:
        ValueError: For unknown token, operator without two operands, or anything other than exactly one value left.
        ZeroDivisionError: When dividing by zero.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a negative number (starts with -)
        if token.startswith('-'):
            # Parse as integer, handling the negative sign
            try:
                value = int(token)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
        else:
            # Try parsing as integer first
            try:
                value = int(token)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
        
        # Check if it's an operator
        if token in '+-*/':
            if len(stack) < 2:
                raise ValueError(f"Operator {token} without two operands")
            b = stack.pop()
            a = stack.pop()
            
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            elif token == '/':
                if b == 0:
                    raise ZeroDivisionError("Division by zero")
                # Floor division (like Python //)
                result = a // b
            else:
                raise ValueError(f"Unknown operator: {token}")
            
            stack.append(result)
        else:
            # Should be an integer
            if len(stack) < 1:
                raise ValueError(f"Unknown token: {token}")
            stack.append(value)
    
    if len(stack) != 1:
        raise ValueError("More than one value left")
    
    return stack[0]
