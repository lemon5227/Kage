#!/usr/bin/env python3
from stack_calc import evaluate

# Test cases
test_cases = [
    ("5 4 +", 9),
    ("5 4 -", 1),
    ("5 4 *", 20),
    ("5 4 2 * +", 14),  # (5 * 4) + 2 = 22? Wait, let me recalculate: 5 4 2 * + means 5 4 2 * = 5*4=20, then 20+2=22
    ("5 4 2 * +", 22),  # Corrected
    ("-3 4 +", 1),  # -3 + 4 = 1
    ("10 2 5 * +", 20),  # (10 * 2) + 5 = 25? Wait: 10 2 5 * + means 10 2 5 * = 10*2=20, then 20+5=25
    ("10 2 5 * +", 25),
    ("3 4 2 * 5 +", 23),  # (3 * 4) * 2 + 5 = 12*2+5=24+5=29? Wait: 3 4 2 * 5 + means 3 4 2 * = 3*4=12, 12*2=24, 24+5=29
    ("3 4 2 * 5 +", 29),
    ("1 2 3 4 * -", -5),  # (1*2)*3*4 = 24, then 24-? Wait: 1 2 3 4 * - means 1 2 3 4 * = 1*2=2, 2*3=6, 6*4=24, then 24-? Only one operand left. This is wrong.
]

print("Testing evaluate function:")
for expr, expected in test_cases:
    try:
        result = evaluate(expr)
        status = "PASS" if result == expected else f"FAIL (got {result})"
        print(f"{expr}: {result} - {status}")
    except Exception as e:
        print(f"{expr}: ERROR - {e}")
