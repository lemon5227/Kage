def evaluate(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: String of space-separated tokens in reverse Polish notation.
               Integers (possibly negative, like -4) and operators + - *.
    
    Returns:
        Integer result.
    
    Raises:
        ValueError: For unknown token, operator without two operands,
                    or anything other than exactly one value left.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is an integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains on the stack
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
