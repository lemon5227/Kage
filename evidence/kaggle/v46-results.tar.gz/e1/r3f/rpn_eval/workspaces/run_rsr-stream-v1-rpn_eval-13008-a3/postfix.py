def evaluate(expr):
    """Evaluate a postfix expression."""
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token == '+' or token == '-' or token == '*' or token == '/':
            if len(stack) < 2:
                raise ValueError(f"Operator {token} without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            elif token == '/':
                if b == 0:
                    raise ZeroDivisionError("Division by zero")
                # Integer division truncated toward zero
                result = int(a / b)
            else:
                raise ValueError(f"Unknown token: {token}")
            stack.append(result)
        else:
            # Try to parse as integer (including negative)
            try:
                num = int(token)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
            stack.append(num)
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
