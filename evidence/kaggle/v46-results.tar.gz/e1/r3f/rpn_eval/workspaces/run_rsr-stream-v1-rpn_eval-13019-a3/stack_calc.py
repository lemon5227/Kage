def evaluate(expr):
    """Evaluate a postfix (reverse Polish) expression.
    
    Args:
        expr: A string of space-separated tokens in reverse Polish notation.
               Tokens can be integers (possibly negative) or operators + - * /.
    
    Returns:
        The integer result of the expression.
    
    Raises:
        ValueError: If an unknown token is encountered, an operator has fewer than two operands,
                    or the expression doesn't evaluate to exactly one value.
        ZeroDivisionError: If division by zero occurs.
    """
    # Parse tokens from the expression
    tokens = expr.split()
    
    # Stack to hold operands
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
            continue
        except ValueError:
            pass
        
        # Check if token is an operator
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        
        elif token == '/':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            if b == 0:
                raise ZeroDivisionError("Division by zero")
            # Integer floor division (like Python //)
            stack.append(a // b)
        
        else:
            raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains on the stack
    if len(stack) != 1:
        raise ValueError("Expression doesn't evaluate to exactly one value")
    
    return stack[0]
