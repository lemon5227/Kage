#!/usr/bin/env python3
from stack_calc import evaluate

# Test cases
test_cases = [
    ("1 2 +", 3),
    ("1 2 3 * +", 7),  # (1*2)+3 = 5? Wait: 1 2 3 * + means 1 2 3 * = 6, then 6+3=9? Let me recalculate.
                       # Actually: 1 2 3 * + means: push 1, push 2, push 3, multiply 2*3=6, then 1+6=7. Correct.
    ("1 2 3 * +", 7),
    ("-4 5 -", -9),  # -4 - 5 = -9
    ("10 2 /", 5),   # 10 // 2 = 5
    ("10 0 /", None),  # Should raise ZeroDivisionError
]

print("Testing evaluate function:")
for expr, expected in test_cases:
    try:
        result = evaluate(expr)
        if expected is None:
            print(f"FAIL: {expr} should raise ZeroDivisionError but got {result}")
        else:
            if result == expected:
                print(f"PASS: {expr} = {result}")
            else:
                print(f"FAIL: {expr} = {result}, expected {expected}")
    except ZeroDivisionError as e:
        if expected is None:
            print(f"PASS: {expr} raised ZeroDivisionError")
        else:
            print(f"FAIL: {expr} raised ZeroDivisionError but expected {expected}")
    except ValueError as e:
        print(f"ERROR: {expr} raised ValueError: {e}")

# Test error cases
error_cases = [
    ("1 2 +", "Should not raise"),  # Actually this is valid, let me use a different one
    ("1 2", "Missing operator"),
    ("1 2 + 3", "Multiple results"),
    ("a 1 +", "Unknown token"),
    ("1 + 2", "Operator without operands"),
]

print("\nTesting error cases:")
for expr, desc in error_cases:
    try:
        result = evaluate(expr)
        print(f"FAIL: {expr} should raise error but got {result}")
    except ValueError as e:
        print(f"PASS: {expr} raised ValueError: {e}")
    except ZeroDivisionError as e:
        print(f"PASS: {expr} raised ZeroDivisionError: {e}")
