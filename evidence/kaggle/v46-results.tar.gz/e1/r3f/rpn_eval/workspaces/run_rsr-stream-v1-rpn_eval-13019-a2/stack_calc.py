def evaluate(expr):
    """Evaluate a postfix expression (Reverse Polish Notation)."""
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Handle negative numbers like -4
        if token.startswith('-') and not token.lstrip('-').isdigit():
            try:
                num = int(token)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
        elif token.lstrip('-').isdigit() or token.isdigit():
            # Integer (possibly negative)
            num = int(token)
        else:
            raise ValueError(f"Unknown token: {token}")
        
        if token in ['+', '-', '*', '/']:
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            elif token == '/':
                if b == 0:
                    raise ZeroDivisionError("Division by zero")
                result = int(a // b)  # Floor division
            else:
                raise ValueError(f"Unknown operator: {token}")
            stack.append(result)
        else:
            raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
