def evaluate(expr):
    """Evaluate a postfix expression.
    
    Args:
        expr: string of space-separated tokens in reverse Polish notation
        
    Returns:
        int: result of the evaluation
        
    Raises:
        ValueError: for unknown token, operator without two operands, or not exactly one value left
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token in ('+', '-', '*'):
            if len(stack) < 2:
                raise ValueError(f"Operator '{token}' without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
        else:
            try:
                value = int(token)
                stack.append(value)
            except ValueError:
                raise ValueError(f"Unknown token: '{token}'")
    
    if len(stack) != 1:
        raise ValueError("Not exactly one value left")
    
    return stack[0]
