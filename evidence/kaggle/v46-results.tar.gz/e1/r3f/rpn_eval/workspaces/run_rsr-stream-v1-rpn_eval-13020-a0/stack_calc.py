def calc_rpn(expr):
    """Evaluate a postfix expression (reverse Polish notation).
    
    Args:
        expr: string of space-separated tokens
        
    Returns:
        int: the result of the evaluation
        
    Raises:
        ValueError: for unknown token, operator without two operands, or not exactly one value left
        ZeroDivisionError: when dividing by zero
    """
    # Split the expression into tokens
    tokens = expr.split()
    
    # Stack to hold operands
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Token is not a number, must be an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            elif token == '/':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                # Integer division truncated toward zero
                result = int(a / b)
                stack.append(result)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Not exactly one value left")
    
    return stack[0]
