def eval_stack(expr):
    """Evaluate a postfix expression (reverse Polish notation).
    
    Args:
        expr: A string of space-separated tokens. Tokens can be integers (possibly negative) 
              or operators +, -, *.
    
    Returns:
        The integer result of the evaluation.
    
    Raises:
        ValueError: For unknown tokens, operators without two operands, or not exactly one value left.
    """
    # Split expression into tokens
    tokens = expr.split()
    
    if not tokens:
        raise ValueError("Empty expression")
    
    # Stack to hold operands
    stack = []
    
    for token in tokens:
        # Check if token is a number (integer, possibly negative)
        try:
            num = int(token)
            stack.append(num)
            continue
        except ValueError:
            pass
        
        # Check for operators
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        else:
            raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains
    if len(stack) != 1:
        raise ValueError("Not exactly one value left")
    
    return stack[0]
