def calc_rpn(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: A string of space-separated tokens in RPN format.
              Tokens can be integers (possibly negative, like -4) or operators (+, -, *).
    
    Returns:
        int: The integer result.
    
    Raises:
        ValueError: If an unknown token is encountered, an operator is used without two operands,
                   or the stack does not contain exactly one value at the end.
    """
    import re
    
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check for operators
        if token in ['+', '-', '*']:
            # Need two operands
            if len(stack) < 2:
                raise ValueError(f"Operator '{token}' without two operands")
            
            # Pop the two operands
            b = stack.pop()
            a = stack.pop()
            
            # Apply operator
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            else:
                raise ValueError(f"Unknown operator '{token}'")
            
            # Push result back
            stack.append(result)
        else:
            # Check if it's a valid integer (including negative)
            try:
                # Handle negative numbers like -4
                # The token might start with '-' but we need to parse it correctly
                num = int(token)
                stack.append(num)
            except ValueError as e:
                raise ValueError(f"Unknown token '{token}'") from e
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Stack does not contain exactly one value at the end")
    
    return stack[0]
