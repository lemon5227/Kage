from stack_calc import calc_rpn

# Test cases
print("Test 1:", calc_rpn("3 4 +"))  # Should be 7
print("Test 2:", calc_rpn("5 2 *"))  # Should be 10
print("Test 3:", calc_rpn("-4 2 +"))  # Should be -2
print("Test 4:", calc_rpn("1 2 3 + *"))  # Should be (1+2)*3 = 9
print("Test 5:", calc_rpn("3 4 5 - *"))  # Should be (3-4)*5 = -5
