def run_postfix(expr):
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        else:
            # Try to parse as integer
            try:
                num = int(token)
                stack.append(num)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
