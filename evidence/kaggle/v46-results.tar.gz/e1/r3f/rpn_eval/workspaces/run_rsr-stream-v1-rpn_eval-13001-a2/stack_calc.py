def evaluate(expr):
    """
    Evaluate a postfix expression (reverse Polish notation).
    
    Args:
        expr: A string of space-separated tokens. Tokens can be integers (possibly negative) 
              or operators (+, -, *).
    
    Returns:
        The integer result of the evaluation.
    
    Raises:
        ValueError: If there is an unknown token, an operator without two operands, 
                   or if the final result is not exactly one value.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative numbers)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Not a valid integer, check if it's an operator
            if token in ['+', '-', '*']:
                # Operator - need two operands
                if len(stack) < 2:
                    raise ValueError(f"Operator '{token}' without two operands")
                b = stack.pop()
                a = stack.pop()
                if token == '+':
                    stack.append(a + b)
                elif token == '-':
                    stack.append(a - b)
                elif token == '*':
                    stack.append(a * b)
                else:
                    raise ValueError(f"Unknown operator '{token}'")
            else:
                raise ValueError(f"Unknown token '{token}'")
    
    # After processing all tokens, there should be exactly one value left
    if len(stack) != 1:
        raise ValueError("Expected exactly one value in the stack")
    
    return stack[0]
