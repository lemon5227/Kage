def eval_stack(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: string of space-separated tokens in reverse Polish notation.
              Tokens are integers (possibly negative, like -4) and operators + - *
    
    Returns:
        int: The integer result
    
    Raises:
        ValueError: For unknown token, operator without two operands,
                   or anything other than exactly one value left.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Not a valid integer, check if it's an operator
            if token in ('+', '-', '*'):
                # Operator - need two operands
                if len(stack) < 2:
                    raise ValueError(f"Operator '{token}' without two operands")
                b = stack.pop()
                a = stack.pop()
                if token == '+':
                    stack.append(a + b)
                elif token == '-':
                    stack.append(a - b)
                elif token == '*':
                    stack.append(a * b)
            else:
                raise ValueError(f"Unknown token: '{token}'")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Result is not a single value")
    
    return stack[0]
