def calc_rpn(expr):
    """
    Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: A string of space-separated tokens in RPN format.
              Tokens can be integers (possibly negative) or operators (+, -, *).
    
    Returns:
        The integer result.
    
    Raises:
        ValueError: For unknown token, operator without two operands, 
                   or anything other than exactly one value left.
    """
    stack = []
    tokens = expr.split()
    
    for token in tokens:
        if token in ['+', '-', '*']:
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
            else:
                raise ValueError(f"Unknown operator: {token}")
        else:
            try:
                value = int(token)
                stack.append(value)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
