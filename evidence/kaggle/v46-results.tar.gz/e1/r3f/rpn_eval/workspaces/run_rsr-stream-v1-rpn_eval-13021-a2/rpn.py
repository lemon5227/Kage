def eval_stack(expr):
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token in ('+', '-', '*'):
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
            else:
                raise ValueError("Unknown token")
        else:
            try:
                num = int(token)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
            stack.append(num)
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
