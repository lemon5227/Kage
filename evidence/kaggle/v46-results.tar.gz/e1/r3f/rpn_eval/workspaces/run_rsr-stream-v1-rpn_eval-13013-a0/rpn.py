def evaluate(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: string of space-separated tokens (integers and operators +, -, *)
    
    Returns:
        int: result of evaluation
    
    Raises:
        ValueError: for unknown token, operator without two operands, or more than one value left
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a valid integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Not a valid integer
            if token in ('+', '-', '*'):
                # It's an operator, need two operands
                if len(stack) < 2:
                    raise ValueError(f"Operator '{token}' without two operands")
                # Pop two operands and apply operator
                b = stack.pop()
                a = stack.pop()
                if token == '+':
                    stack.append(a + b)
                elif token == '-':
                    stack.append(a - b)
                elif token == '*':
                    stack.append(a * b)
                else:
                    raise ValueError(f"Unknown operator '{token}'")
            else:
                raise ValueError(f"Unknown token '{token}'")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("More than one value left")
    
    return stack[0]
