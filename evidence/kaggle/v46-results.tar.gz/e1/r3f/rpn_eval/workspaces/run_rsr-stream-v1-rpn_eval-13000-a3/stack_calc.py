def evaluate(expr):
    """Evaluate a postfix expression (reverse Polish notation).
    
    Args:
        expr: string of space-separated tokens (integers and operators + - *)
    
    Returns:
        int: the result of the evaluation
    
    Raises:
        ValueError: for unknown token, operator without two operands, or not exactly one value left
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is an integer (including negative)
        try:
            num = int(token)
            stack.append(num)
            continue
        except ValueError:
            pass
        
        # Check if it's an operator
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        else:
            raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains on the stack
    if len(stack) != 1:
        raise ValueError("Exactly one value left on stack")
    
    return stack[0]
