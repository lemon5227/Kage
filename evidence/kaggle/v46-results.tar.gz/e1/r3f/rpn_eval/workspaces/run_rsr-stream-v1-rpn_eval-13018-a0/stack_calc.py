def evaluate(expr):
    """
    Evaluate a postfix expression (Reverse Polish Notation).
    The expression is a string of space-separated tokens.
    Supports integers (possibly negative) and operators + - *.
    Returns the integer result.
    Raises ValueError for unknown tokens, operators without two operands,
    or anything other than exactly one value left.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a negative number (starts with -)
        if token.startswith('-'):
            try:
                num = int(token)
                stack.append(num)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
        elif token.startswith('+'):
            # Positive numbers can start with +, but in typical RPN they don't usually appear
            # We'll handle it as a positive integer
            try:
                num = int(token)
                stack.append(num)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
        elif token in ['+', '-', '*']:
            # Operators need two operands
            if len(stack) < 2:
                raise ValueError(f"Operator {token} without two operands")
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            else:
                raise ValueError(f"Unknown operator: {token}")
            stack.append(result)
        else:
            # Unknown token
            raise ValueError(f"Unknown token: {token}")
    
    # After processing all tokens, there should be exactly one value left
    if len(stack) != 1:
        raise ValueError("Not exactly one value left")
    
    return stack[0]
