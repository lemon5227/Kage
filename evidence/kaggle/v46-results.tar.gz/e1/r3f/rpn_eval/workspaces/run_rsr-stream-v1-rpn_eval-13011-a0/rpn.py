def eval_stack(expr):
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        elif token == '/':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            # Integer division truncated toward zero
            stack.append(int(a / b))
        else:
            # Try to parse as integer (including negative numbers)
            try:
                num = int(token)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
            stack.append(num)
    
    if len(stack) != 1:
        raise ValueError("Exactly one value left")
    
    return stack[0]
