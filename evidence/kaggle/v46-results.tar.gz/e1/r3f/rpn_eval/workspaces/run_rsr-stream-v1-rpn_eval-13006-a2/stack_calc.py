def calc_rpn(expr):
    """Evaluate a postfix expression (RPN).
    
    Args:
        expr: A string of space-separated tokens in reverse Polish notation.
               Integers (possibly negative, like -4) and operators + - *.
    
    Returns:
        The integer result.
    
    Raises:
        ValueError: For unknown token, operator without two operands, 
                   or anything other than exactly one value left.
    """
    # Split the expression into tokens
    tokens = expr.split()
    
    if not tokens:
        raise ValueError("Empty expression")
    
    # Stack to hold operands
    stack = []
    
    for token in tokens:
        # Check if token is a number (integer, possibly negative)
        try:
            num = int(token)
            stack.append(num)
            continue
        except ValueError:
            pass
        
        # Check if it's an operator
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        else:
            raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains on the stack
    if len(stack) != 1:
        raise ValueError("Not exactly one value left")
    
    return stack[0]
