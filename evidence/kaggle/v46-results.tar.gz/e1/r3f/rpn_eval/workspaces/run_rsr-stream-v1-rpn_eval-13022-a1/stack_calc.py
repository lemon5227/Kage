def calc_rpn(expr):
    """Evaluate a postfix expression.
    
    Args:
        expr: A string of space-separated tokens in reverse Polish notation.
              Tokens can be integers (including negative) or operators (+, -, *).
    
    Returns:
        The integer result.
    
    Raises:
        ValueError: For unknown token, operator without two operands, 
                   or more than one value left on stack.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is an integer (including negative)
        try:
            num = int(token)
            stack.append(num)
            continue
        except ValueError:
            pass
        
        # Check for operators
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        else:
            raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("More than one value left on stack")
    
    return stack[0]
