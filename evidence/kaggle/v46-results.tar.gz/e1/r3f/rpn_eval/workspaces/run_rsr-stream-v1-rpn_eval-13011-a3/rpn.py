def eval_stack(expr):
    """Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: String of space-separated tokens in reverse Polish notation.
               Integers (possibly negative, like -4) and operators + - * /.
    
    Returns:
        Integer result.
    
    Raises:
        ValueError: For unknown token, operator without two operands, or not exactly one value left.
        ZeroDivisionError: When dividing by zero.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        if token == '+':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a + b)
        elif token == '-':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a - b)
        elif token == '*':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            stack.append(a * b)
        elif token == '/':
            if len(stack) < 2:
                raise ValueError("Operator without two operands")
            b = stack.pop()
            a = stack.pop()
            # Integer division truncated toward zero
            if (a >= 0 and b < 0) or (a < 0 and b > 0):
                # Signs differ, result is negative
                result = -(abs(a) // abs(b))
            else:
                # Same sign, result is positive
                result = abs(a) // abs(b)
            stack.append(result)
        else:
            # Try to parse as integer (including negative)
            try:
                num = int(token)
                stack.append(num)
            except ValueError:
                raise ValueError(f"Unknown token: {token}")
    
    if len(stack) != 1:
        raise ValueError("Not exactly one value left")
    
    return stack[0]
