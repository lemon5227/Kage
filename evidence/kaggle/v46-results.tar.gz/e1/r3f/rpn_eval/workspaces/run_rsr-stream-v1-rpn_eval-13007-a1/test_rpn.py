#!/usr/bin/env python3
from rpn import eval_stack

# Test cases
test_cases = [
    ("3 4 +", 7),
    ("10 2 *", 20),
    ("5 -3 +", 2),
    ("10 2 /", 5),
    ("10 2 5 * +", 25),
    ("-4 2 +", -2),
    ("10 0 /", "ZeroDivisionError"),
    ("3 4 5 + *", 27),
    ("1 2 3 4 + +", 9),
]

print("Testing eval_stack:")
for expr, expected in test_cases:
    try:
        result = eval_stack(expr)
        if isinstance(expected, str):
            print(f"FAIL: {expr} -> {result} (expected ZeroDivisionError)")
        else:
            if result == expected:
                print(f"PASS: {expr} -> {result}")
            else:
                print(f"FAIL: {expr} -> {result} (expected {expected})")
    except ValueError as e:
        if "ZeroDivisionError" in expected or "ValueError" in expected:
            print(f"PASS: {expr} -> ValueError: {e}")
        else:
            print(f"FAIL: {expr} -> ValueError: {e}")
    except ZeroDivisionError as e:
        if "ZeroDivisionError" in expected:
            print(f"PASS: {expr} -> ZeroDivisionError: {e}")
        else:
            print(f"FAIL: {expr} -> ZeroDivisionError: {e}")

# Test error cases
error_cases = [
    ("3 +", "ValueError - operator without two operands"),
    ("+ 3 4", "ValueError - unknown token or operator without two operands"),
    ("1 2 3", "ValueError - more than one value left"),
]

print("\nTesting error cases:")
for expr, expected_msg in error_cases:
    try:
        result = eval_stack(expr)
        print(f"FAIL: {expr} -> {result} (expected {expected_msg})")
    except ValueError as e:
        print(f"PASS: {expr} -> ValueError: {e}")
    except ZeroDivisionError as e:
        print(f"FAIL: {expr} -> ZeroDivisionError: {e}")
