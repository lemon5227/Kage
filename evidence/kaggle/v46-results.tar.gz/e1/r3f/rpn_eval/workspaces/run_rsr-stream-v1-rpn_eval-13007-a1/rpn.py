def eval_stack(expr):
    """Evaluate a postfix expression (RPN).
    
    Args:
        expr: A string of space-separated tokens in reverse Polish notation.
               Tokens can be integers (possibly negative) or operators (+, -, *, /).
               '/' is integer floor division (like Python //).
    
    Returns:
        The integer result.
    
    Raises:
        ValueError: For unknown token, operator without two operands, or more than one value left.
        ZeroDivisionError: When dividing by zero.
    """
    # Split the expression into tokens
    tokens = expr.split()
    
    # Stack to hold operands
    stack = []
    
    for token in tokens:
        # Check if token is an integer (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Not an integer, must be an operator
            if token not in ['+', '-', '*', '/']:
                raise ValueError(f"Unknown token: {token}")
            
            # Operator - need two operands
            if len(stack) < 2:
                raise ValueError(f"Operator '{token}' without two operands")
            
            # Pop two operands (second operand is on top of stack)
            b = stack.pop()
            a = stack.pop()
            
            # Apply operator
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            elif token == '/':
                if b == 0:
                    raise ZeroDivisionError("Division by zero")
                result = a // b  # Integer floor division
            
            stack.append(result)
    
    # After processing all tokens, there should be exactly one value left
    if len(stack) != 1:
        raise ValueError("More than one value left on stack")
    
    return stack[0]
