def calc_rpn(expr):
    """Evaluate a postfix expression (reverse Polish notation).
    
    The expression is a string of space-separated tokens in reverse Polish notation:
    integers (possibly negative, like -4) and the operators + - *.
    Returns the integer result. Raises ValueError for:
    - an unknown token
    - an operator without two operands
    - anything other than exactly one value left
    
    Args:
        expr: string of space-separated tokens
        
    Returns:
        int: result of evaluation
        
    Raises:
        ValueError: if expression is invalid
    """
    # Split the expression into tokens
    tokens = expr.split()
    
    # Stack to hold operands
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative numbers)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # Not a number, must be an operator
            if token == '+':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif token == '-':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a - b)
            elif token == '*':
                if len(stack) < 2:
                    raise ValueError("Operator without two operands")
                b = stack.pop()
                a = stack.pop()
                stack.append(a * b)
            else:
                raise ValueError(f"Unknown token: {token}")
    
    # Check that exactly one value remains in the stack
    if len(stack) != 1:
        raise ValueError("Not exactly one value left in stack")
    
    return stack[0]
