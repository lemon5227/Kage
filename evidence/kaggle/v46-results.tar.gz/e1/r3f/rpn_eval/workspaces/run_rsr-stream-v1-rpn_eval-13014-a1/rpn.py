def eval_stack(expr):
    """
    Evaluate a postfix expression (Reverse Polish Notation).
    
    Args:
        expr: A string of space-separated tokens. Tokens can be integers 
              (possibly negative like -4) or operators +, -, *.
    
    Returns:
        The integer result of the evaluation.
    
    Raises:
        ValueError: If an unknown token is encountered, an operator has 
                   fewer than two operands, or there is not exactly one value left.
    """
    tokens = expr.split()
    stack = []
    
    for token in tokens:
        # Check if token is a number (including negative)
        try:
            num = int(token)
            stack.append(num)
        except ValueError:
            # It's an operator
            if token not in ['+', '-', '*']:
                raise ValueError(f"Unknown token: {token}")
            
            # Need exactly two operands
            if len(stack) < 2:
                raise ValueError(f"Operator {token} without two operands")
            
            # Pop the two top operands
            b = stack.pop()
            a = stack.pop()
            
            # Apply operator
            if token == '+':
                result = a + b
            elif token == '-':
                result = a - b
            elif token == '*':
                result = a * b
            else:
                raise ValueError(f"Unknown operator: {token}")
            
            stack.append(result)
    
    # Check there is exactly one value left
    if len(stack) != 1:
        raise ValueError("Not exactly one value left")
    
    return stack[0]
