def rle_encode(text):
    if text == "":
        return ""
    
    # Check for digits
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 0:
        return ""
    
    result = []
    i = 0
    while i < len(text):
        char = text[i]
        count = 1
        # Count consecutive occurrences of the same character
        while i + count < len(text) and text[i + count] == char:
            count += 1
        
        # Write the group
        if count == 1:
            result.append(char)
        else:
            result.append(str(count) + char)
        
        i += count
    
    return "".join(result)
