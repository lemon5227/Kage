def encode_runs(text):
    """Run-length encode a string."""
    if not text:
        return ""
    
    # Check for digits
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    if not text:
        return ""
    
    current_char = text[0]
    count = 1
    
    for i in range(1, len(text)):
        char = text[i]
        if char == current_char:
            count += 1
        else:
            if count == 1:
                result.append(current_char)
            else:
                result.append(f"{current_char}{count}")
            current_char = char
            count = 1
    
    # Append the last run
    if count == 1:
        result.append(current_char)
    else:
        result.append(f"{current_char}{count}")
    
    return "".join(result)
