def rle_encode(text):
    if not text:
        return ""
    
    # Check for digits in the text
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        current_char = text[i]
        count = 1
        
        # Count consecutive runs of the same character
        while i + count < n and text[i + count] == current_char:
            count += 1
        
        # Append the encoded group
        if count == 1:
            result.append(current_char)
        else:
            result.append(f"{count}{current_char}")
        
        i += count
    
    return "".join(result)
