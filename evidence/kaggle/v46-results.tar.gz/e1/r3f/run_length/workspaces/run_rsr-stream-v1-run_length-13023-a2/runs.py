def compress_runs(text):
    """Run-length encode a string, replacing every run of the same character 
    with one group written as 'a3' (character before the count)."""
    
    # Check for digits in the text
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if not text:
        return ""
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Append character and count
        result.append(char)
        result.append(str(count))
        
        i += count
    
    return ''.join(result)
