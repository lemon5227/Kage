def encode_runs(text):
    """Run-length encode a string, replacing runs with character+count."""
    # Check for digits in the input
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if not text:
        return ""
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive occurrences of the same character
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Append character followed by count
        result.append(char)
        result.append(str(count))
        
        i += count
    
    return "".join(result)
