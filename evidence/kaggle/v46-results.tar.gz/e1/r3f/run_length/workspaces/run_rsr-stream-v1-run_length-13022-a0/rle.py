def encode_runs(text):
    """Run-length encode a string according to the specified rules."""
    if not text:
        return ""
    
    # Check for digits in the input
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Apply encoding rules
        if count == 1:
            result.append(char)
        else:
            result.append(f"{char}{count}")
        
        i += count
    
    return "".join(result)
