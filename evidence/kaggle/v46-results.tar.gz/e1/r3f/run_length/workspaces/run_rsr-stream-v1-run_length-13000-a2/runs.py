def compress_runs(text):
    """Run-length encode a string."""
    if not text:
        return ""
    
    # Check for digits in the input
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    if not text:
        return ""
    
    prev_char = text[0]
    count = 1
    
    for i in range(1, len(text)):
        char = text[i]
        if char == prev_char:
            count += 1
        else:
            if count == 1:
                result.append(prev_char)
            else:
                result.append(f"{count}{prev_char}")
            prev_char = char
            count = 1
    
    # Append the last run
    if count == 1:
        result.append(prev_char)
    else:
        result.append(f"{count}{prev_char}")
    
    return "".join(result)
