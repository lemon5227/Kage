def pack_text(text):
    if text == "":
        return ""
    
    # Check for digits
    for char in text:
        if char.isdigit():
            raise ValueError("Text contains digits")
    
    result = []
    i = 0
    while i < len(text):
        char = text[i]
        count = 1
        while i + count < len(text) and text[i + count] == char:
            count += 1
        
        if count == 1:
            result.append(char)
        else:
            result.append(str(count) + char)
        
        i += count
    
    return "".join(result)
