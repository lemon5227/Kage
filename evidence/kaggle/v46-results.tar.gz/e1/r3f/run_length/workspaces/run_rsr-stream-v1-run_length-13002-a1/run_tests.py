from packing import rle_encode

# Test cases
print("Test 1:", rle_encode("aaabb"))  # Expected: "3a2b"
print("Test 2:", rle_encode("a"))     # Expected: "a"
print("Test 3:", rle_encode(""))      # Expected: ""
print("Test 4:", rle_encode("a b c")) # Expected: "a b c" (each run is length 1)
print("Test 5:", rle_encode("AaaBbb")) # Expected: "Aa3b2b" - case matters
try:
    print("Test 6:", rle_encode("123"))   # Should raise ValueError
except ValueError as e:
    print("Test 6: ValueError raised:", e)
