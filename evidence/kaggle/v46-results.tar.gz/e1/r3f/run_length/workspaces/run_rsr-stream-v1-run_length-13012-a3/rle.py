def pack_text(text):
    if not text:
        return ""
    
    # Check for digits
    for char in text:
        if char.isdigit():
            raise ValueError("Text contains digits")
    
    result = []
    i = 0
    while i < len(text):
        char = text[i]
        count = 1
        while i + count < len(text) and text[i + count] == char:
            count += 1
        result.append(char + str(count))
        i += count
    
    return "".join(result)
