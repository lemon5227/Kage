def encode_runs(text):
    if not text:
        return ""
    
    # Check for digits
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 1:
        return text
    
    result = []
    i = 0
    while i < len(text):
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < len(text) and text[i + count] == char:
            count += 1
        
        # Append the encoded run
        if count == 1:
            result.append(char)
        else:
            result.append(f"{char}{count}")
        
        i += count
    
    return "".join(result)
