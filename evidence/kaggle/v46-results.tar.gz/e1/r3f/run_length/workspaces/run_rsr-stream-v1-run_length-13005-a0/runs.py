def rle_encode(text):
    """Run-length encode a string.
    
    Replaces every run of the same character with one group written as "charcount"
    (character before the count). A run of length 1 is written as the bare character,
    without a count. Spaces and punctuation are characters like any other; case matters.
    The empty string encodes to "". Raise ValueError if the text contains any digit.
    """
    if not text:
        return ""
    
    # Check for digits
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    i = 0
    while i < len(text):
        char = text[i]
        count = 1
        
        # Count consecutive occurrences of the same character
        while i + count < len(text) and text[i + count] == char:
            count += 1
        
        # Append the encoded group
        if count == 1:
            result.append(char)
        else:
            result.append(f"{char}{count}")
        
        i += count
    
    return ''.join(result)
