def compress_runs(text):
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if not text:
        return ""
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Append either the bare character (if count is 1) or "count" + char
        if count == 1:
            result.append(char)
        else:
            result.append(f"{count}{char}")
        
        i += count
    
    return "".join(result)
