def compress_runs(text):
    if not text:
        return ""
    
    # Check for digits in the text
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 1:
        return f"1{text[0]}"
    
    result = []
    count = 1
    
    for i in range(1, len(text)):
        if text[i] == text[i-1]:
            count += 1
        else:
            result.append(f"{count}{text[i-1]}")
            count = 1
    
    # Append the last run
    result.append(f"{count}{text[-1]}")
    
    return "".join(result)
