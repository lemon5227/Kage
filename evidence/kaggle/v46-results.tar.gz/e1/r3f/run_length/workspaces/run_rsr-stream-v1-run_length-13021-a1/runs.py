def encode_runs(text):
    """Run-length encode a string.
    
    Replace every run of the same character with one group written as "a3" (character before the count).
    A run of length 1 is written as the bare character, without a count.
    Spaces and punctuation are characters like any other; case matters.
    The empty string encodes to "".
    Raise ValueError if the text contains any digit.
    """
    if not text:
        return ""
    
    # Check for digits first
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 1:
        return text
    
    prev_char = text[0]
    count = 1
    
    result = []
    
    for i in range(1, len(text)):
        char = text[i]
        
        if char == prev_char:
            count += 1
        else:
            if count == 1:
                result.append(prev_char)
            else:
                result.append(f"{prev_char}{count}")
            prev_char = char
            count = 1
    
    # Handle the last run
    if count == 1:
        result.append(prev_char)
    else:
        result.append(f"{prev_char}{count}")
    
    return "".join(result)
