def rle_encode(text):
    if not text:
        return ""
    
    # Check for digits in text
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 1:
        return f"{text}1"
    
    result = []
    current_char = text[0]
    count = 1
    
    for i in range(1, len(text)):
        if text[i] == current_char:
            count += 1
        else:
            result.append(f"{current_char}{count}")
            current_char = text[i]
            count = 1
    
    # Append the last run
    result.append(f"{current_char}{count}")
    
    return "".join(result)
