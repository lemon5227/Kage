from rle import rle_encode

# Test cases
print("Empty:", repr(rle_encode("")))
print("a:", repr(rle_encode("a")))
print("aa:", repr(rle_encode("aa")))
print("aabb:", repr(rle_encode("aabb")))
print("abc:", repr(rle_encode("abc")))
print("Aa:", repr(rle_encode("Aa")))
print("123:", end=" ")
try:
    rle_encode("123")
except ValueError as e:
    print("ValueError:", e)
