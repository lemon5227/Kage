def rle_encode(text):
    if not text:
        return ""
    
    # Check for digits
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Add to result: if count is 1, just the character; otherwise "count+char"
        if count == 1:
            result.append(char)
        else:
            result.append(f"{count}{char}")
        
        i += count
    
    return "".join(result)
