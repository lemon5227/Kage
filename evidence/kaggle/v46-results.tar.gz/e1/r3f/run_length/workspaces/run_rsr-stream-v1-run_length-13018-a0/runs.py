def rle_encode(text):
    """Run-length encode a string."""
    # Check for digits
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if not text:
        return ""
    
    result = []
    prev_char = None
    count = 0
    
    for char in text:
        if char == prev_char:
            count += 1
        else:
            if prev_char is not None:
                result.append(f"{prev_char}{count}")
            prev_char = char
            count = 1
    
    # Append the last run
    if prev_char is not None:
        result.append(f"{prev_char}{count}")
    
    return "".join(result)
