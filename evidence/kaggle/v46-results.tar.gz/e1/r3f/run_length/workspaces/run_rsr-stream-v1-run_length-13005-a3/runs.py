def rle_encode(text):
    """Run-length encode a string."""
    # Check for digits in text
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if not text:
        return ""
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Append the encoded run
        if count > 1:
            result.append(f"{char}{count}")
        else:
            result.append(char)
        
        i += count
    
    return "".join(result)
