def pack_text(text):
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if not text:
        return ""
    
    result = []
    i = 0
    while i < len(text):
        char = text[i]
        count = 1
        while i + count < len(text) and text[i + count] == char:
            count += 1
        if count == 1:
            result.append(char)
        else:
            result.append(str(count) + char)
        i += count
    
    return ''.join(result)
