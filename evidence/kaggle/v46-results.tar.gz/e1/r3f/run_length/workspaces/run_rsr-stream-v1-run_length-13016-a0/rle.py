def encode_runs(text):
    if not text:
        return ""
    
    # Check for digits
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    i = 0
    while i < len(text):
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < len(text) and text[i + count] == char:
            count += 1
        
        # Write the encoded group
        if count == 1:
            result.append(char)
        else:
            result.append(char + str(count))
        
        i += count
    
    return ''.join(result)
