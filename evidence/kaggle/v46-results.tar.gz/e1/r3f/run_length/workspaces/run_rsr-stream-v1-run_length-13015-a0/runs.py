def pack_text(text):
    """Run-length encode a string."""
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if not text:
        return ""
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Append the encoded group
        if count == 1:
            result.append(char)
        else:
            result.append(f"{count}{char}")
        
        i += count
    
    return ''.join(result)
