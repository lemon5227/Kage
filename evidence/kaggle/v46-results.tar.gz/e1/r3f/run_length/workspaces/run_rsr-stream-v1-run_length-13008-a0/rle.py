def rle_encode(text):
    """Run-length encode a string."""
    if not text:
        return ""
    
    # Check for digits in the input
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 1:
        return text
    
    prev_char = text[0]
    count = 1
    
    result = []
    
    for i in range(1, len(text)):
        current_char = text[i]
        
        if current_char == prev_char:
            count += 1
        else:
            if count == 1:
                result.append(prev_char)
            else:
                result.append(f"{count}{prev_char}")
            prev_char = current_char
            count = 1
    
    # Handle the last run
    if count == 1:
        result.append(prev_char)
    else:
        result.append(f"{count}{prev_char}")
    
    return "".join(result)
