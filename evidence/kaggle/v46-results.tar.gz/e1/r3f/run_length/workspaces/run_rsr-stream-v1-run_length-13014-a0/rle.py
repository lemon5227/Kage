def pack_text(text):
    if not text:
        return ""
    
    # Check for digits in the input
    for char in text:
        if char.isdigit():
            raise ValueError("Text contains digits")
    
    result = []
    i = 0
    while i < len(text):
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < len(text) and text[i + count] == char:
            count += 1
        
        # Append the encoded run
        if count == 1:
            result.append(char)
        else:
            result.append(str(count) + char)
        
        i += count
    
    return ''.join(result)
