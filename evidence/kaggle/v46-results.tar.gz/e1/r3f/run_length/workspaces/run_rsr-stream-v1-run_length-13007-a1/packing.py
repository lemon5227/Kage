def rle_encode(text):
    """Run-length encode a string."""
    if not text:
        return ""
    
    # Check for digits in the text
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 1:
        return text
    
    result = []
    i = 0
    while i < len(text):
        char = text[i]
        count = 1
        while i + count < len(text) and text[i + count] == char:
            count += 1
        result.append(char + str(count))
        i += count
    
    return "".join(result)
