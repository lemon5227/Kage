def compress_runs(text):
    """
    Run-length encode a string.
    
    Replace every run of the same character with one group written as "a3" (character before the count).
    A run of length 1 is written with its count 1 too.
    Spaces and punctuation are characters like any other; case matters.
    The empty string encodes to "".
    Raise ValueError if the text contains any digit.
    """
    if not text:
        return ""
    
    # Check for digits in the input
    for char in text:
        if char.isdigit():
            raise ValueError("Text contains digits")
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Append the encoded group: character followed by count
        result.append(char)
        result.append(str(count))
        
        i += count
    
    return "".join(result)
