def encode_runs(text):
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if not text:
        return ""
    
    result = []
    current_char = text[0]
    count = 1
    
    for i in range(1, len(text)):
        if text[i] == current_char:
            count += 1
        else:
            if count == 1:
                result.append(current_char)
            else:
                result.append(f"{count}{current_char}")
            current_char = text[i]
            count = 1
    
    # Handle the last run
    if count == 1:
        result.append(current_char)
    else:
        result.append(f"{count}{current_char}")
    
    return "".join(result)
