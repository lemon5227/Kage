def encode_runs(text):
    """Run-length encode a string."""
    if not text:
        return ""
    
    # Check for digits
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 1:
        return text
    
    result = []
    i = 0
    while i < len(text):
        current_char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < len(text) and text[i + count] == current_char:
            count += 1
        
        # Append character followed by count
        result.append(current_char)
        result.append(str(count))
        
        i += count
    
    return "".join(result)
