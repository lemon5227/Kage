def pack_text(text):
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if not text:
        return ""
    
    result = []
    current_char = text[0]
    count = 1
    
    for i in range(1, len(text)):
        if text[i] == current_char:
            count += 1
        else:
            result.append(f"a{count}{current_char}")
            current_char = text[i]
            count = 1
    
    # Append the last run
    result.append(f"a{count}{current_char}")
    
    return "".join(result)
