def pack_text(text):
    if text == "":
        return ""
    
    # Check for digits in the text
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Append the character followed by its count
        result.append(char)
        result.append(str(count))
        
        i += count
    
    return "".join(result)
