def pack_text(text):
    """Run-length encode a string."""
    if not text:
        return ""
    
    # Check for digits
    for char in text:
        if char.isdigit():
            raise ValueError("Text contains digits")
    
    if len(text) == 1:
        return f"a{text[0]}"
    
    result = []
    current_char = text[0]
    count = 1
    
    for i in range(1, len(text)):
        if text[i] == current_char:
            count += 1
        else:
            result.append(f"a{count}{current_char}")
            current_char = text[i]
            count = 1
    
    # Append the last run
    result.append(f"a{count}{current_char}")
    
    return "".join(result)
