def rle_encode(text):
    """Run-length encode a string."""
    if not text:
        return ""
    
    # Check for digits in the input
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Append count and character
        result.append(f"{count}{char}")
        
        # Move to next run
        i += count
    
    return "".join(result)
