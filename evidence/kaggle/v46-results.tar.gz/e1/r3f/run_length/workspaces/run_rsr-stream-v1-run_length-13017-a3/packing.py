def rle_encode(text):
    """Run-length encode a string."""
    if not text:
        return ""
    
    # Check for digits
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 1:
        return text
    
    result = []
    current_char = text[0]
    count = 1
    
    for i in range(1, len(text)):
        if text[i] == current_char:
            count += 1
        else:
            if count == 1:
                result.append(current_char)
            else:
                result.append(f"{count}{current_char}")
            current_char = text[i]
            count = 1
    
    # Append the last run
    if count == 1:
        result.append(current_char)
    else:
        result.append(f"{count}{current_char}")
    
    return "".join(result)
