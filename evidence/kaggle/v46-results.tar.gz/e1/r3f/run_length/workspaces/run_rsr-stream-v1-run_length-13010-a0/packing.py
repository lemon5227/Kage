def compress_runs(text):
    """Run-length encode a string.
    
    Replace every run of the same character with one group written as "count+char".
    A run of length 1 is written as the bare character, without a count.
    Spaces and punctuation are characters like any other; case matters.
    The empty string encodes to "".
    Raise ValueError if the text contains any digit.
    """
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Check for digits in the input
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 0:
        return ""
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Append the encoded run
        if count == 1:
            result.append(char)
        else:
            result.append(f"{count}{char}")
        
        i += count
    
    return "".join(result)
