def rle_encode(text):
    """Run-length encode a string."""
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if not text:
        return ""
    
    result = []
    i = 0
    while i < len(text):
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < len(text) and text[i + count] == char:
            count += 1
        
        # If count is 1, write just the character; otherwise write count + character
        if count == 1:
            result.append(char)
        else:
            result.append(str(count) + char)
        
        i += count
    
    return ''.join(result)
