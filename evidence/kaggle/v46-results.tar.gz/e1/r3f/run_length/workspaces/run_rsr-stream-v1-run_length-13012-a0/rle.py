def pack_text(text):
    if not text:
        return ""
    
    # Check for digits
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive occurrences of the same character
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Append character followed by count
        result.append(char)
        result.append(str(count))
        
        i += count
    
    return "".join(result)
