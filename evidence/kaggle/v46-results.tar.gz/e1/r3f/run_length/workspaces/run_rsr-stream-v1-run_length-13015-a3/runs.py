def pack_text(text):
    """Run-length encode a string."""
    if not text:
        return ""
    
    # Check for digits
    if any(char.isdigit() for char in text):
        raise ValueError("Text contains digits")
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == char:
            count += 1
        
        # Append the encoded segment
        if count == 1:
            result.append(char)
        else:
            result.append(f"{count}{char}")
        
        i += count
    
    return "".join(result)
