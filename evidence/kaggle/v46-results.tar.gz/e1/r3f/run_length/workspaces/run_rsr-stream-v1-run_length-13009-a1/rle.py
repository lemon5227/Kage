def compress_runs(text):
    if not text:
        return ""
    
    # Check for digits in the input
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    i = 0
    while i < len(text):
        char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < len(text) and text[i + count] == char:
            count += 1
        
        # Append the encoded run
        result.append(f"{count}{char}")
        
        # Move to the next character
        i += count
    
    return "".join(result)
