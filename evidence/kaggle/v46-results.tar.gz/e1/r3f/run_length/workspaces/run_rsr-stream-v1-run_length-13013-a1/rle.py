def encode_runs(text):
    if text == "":
        return ""
    
    # Check for digits in the text
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        current_char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == current_char:
            count += 1
        
        # For runs of length 1, write just the character; otherwise write count+char
        if count == 1:
            result.append(current_char)
        else:
            result.append(f"{count}{current_char}")
        
        i += count
    
    return "".join(result)
