def compress_runs(text):
    """Run-length encode a string, replacing every run of the same character 
    with one group written as "a3" (character before the count). 
    A run of length 1 is written with its count 1 too. 
    Spaces and punctuation are characters like any other; case matters.
    The empty string encodes to "". Raise ValueError if the text contains any digit."""
    
    if not text:
        return ""
    
    # Check for digits in the input
    for char in text:
        if char.isdigit():
            raise ValueError("Text contains digits")
    
    result = []
    if not text:
        return ""
    
    current_char = text[0]
    count = 1
    
    for i in range(1, len(text)):
        if text[i] == current_char:
            count += 1
        else:
            result.append(current_char)
            result.append(str(count))
            current_char = text[i]
            count = 1
    
    # Append the last run
    result.append(current_char)
    result.append(str(count))
    
    return "".join(result)
