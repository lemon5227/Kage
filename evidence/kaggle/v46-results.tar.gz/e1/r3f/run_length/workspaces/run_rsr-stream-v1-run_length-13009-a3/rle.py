def compress_runs(text):
    if not text:
        return ""
    
    # Check for digits in the text
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    result = []
    if not text:
        return ""
    
    prev_char = None
    count = 0
    
    for char in text:
        if char == prev_char:
            count += 1
        else:
            if prev_char is not None:
                result.append(f"{count}{prev_char}")
            prev_char = char
            count = 1
    
    # Append the last run
    result.append(f"{count}{prev_char}")
    
    return "".join(result)
