def rle_encode(text):
    """Run-length encode a string."""
    if not text:
        return ""
    
    # Check for digits
    if any(char.isdigit() for char in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 1:
        return text
    
    result = []
    i = 0
    while i < len(text):
        current_char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < len(text) and text[i + count] == current_char:
            count += 1
        
        # Append the encoded group
        if count == 1:
            result.append(current_char)
        else:
            result.append(f"{count}{current_char}")
        
        i += count
    
    return "".join(result)
