def encode_runs(text):
    """Run-length encode a string."""
    if not text:
        return ""
    
    # Check for digits
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 1:
        return text
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        current_char = text[i]
        count = 1
        
        # Count consecutive occurrences of the same character
        while i + count < n and text[i + count] == current_char:
            count += 1
        
        # Append to result
        if count == 1:
            result.append(current_char)
        else:
            result.append(f"{current_char}{count}")
        
        i += count
    
    return "".join(result)
