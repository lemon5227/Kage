def encode_runs(text):
    if not isinstance(text, str):
        raise TypeError("text must be a string")
    
    # Check for digits in the input
    if any(c.isdigit() for c in text):
        raise ValueError("Text contains digits")
    
    if len(text) == 0:
        return ""
    
    result = []
    i = 0
    n = len(text)
    
    while i < n:
        current_char = text[i]
        count = 1
        
        # Count consecutive identical characters
        while i + count < n and text[i + count] == current_char:
            count += 1
        
        # Append the encoded group
        if count == 1:
            result.append(current_char)
        else:
            result.append(f"{current_char}{count}")
        
        i += count
    
    return "".join(result)
