def rotate(grid, turns):
    """
    Rotate a grid counter-clockwise by 90 degrees, turns times.
    The grid is a list of rows (lists) of equal length.
    Turns is any integer; negative turns rotate the other way and only turns modulo 4 matters.
    Returns a new list of lists without modifying the input.
    Raises ValueError if the rows have different lengths.
    """
    # Handle empty grid or grid with empty rows
    if not grid or (len(grid) == 0 or all(len(row) == 0 for row in grid)):
        return []
    
    # Check if all rows have the same length
    first_len = len(grid[0])
    for row in grid:
        if len(row) != first_len:
            raise ValueError("Rows have different lengths")
    
    rows = len(grid)
    cols = first_len
    
    # Normalize turns to 0-3 range
    turns = turns % 4
    
    # For a single 90 degree counter-clockwise rotation:
    # new_grid[i][j] = old_grid[rows - 1 - j][i]
    if turns == 0:
        return grid
    
    # 90° CCW rotation
    if turns == 1:
        new_grid = []
        for i in range(cols):
            new_row = [grid[rows - 1 - j][i] for j in range(rows)]
            new_grid.append(new_row)
        return new_grid
    
    # 180° CCW rotation (2 turns)
    if turns == 2:
        new_grid = []
        for i in range(cols):
            new_row = [grid[rows - 1 - j][i] for j in range(rows)]
            new_grid.append(new_row)
        return rotate(new_grid, 1)
    
    # 270° CCW rotation (3 turns), which is equivalent to 90° clockwise
    # 270° CCW = 90° CW = 3×90° CCW
    if turns == 3:
        new_grid = []
        for i in range(cols):
            new_row = [grid[j][cols - 1 - i] for j in range(rows)]
            new_grid.append(new_row)
        return new_grid
    
    return grid
