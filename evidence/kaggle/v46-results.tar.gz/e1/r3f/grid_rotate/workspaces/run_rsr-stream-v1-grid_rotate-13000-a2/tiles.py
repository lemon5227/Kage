def rotate(grid, turns):
    return None
