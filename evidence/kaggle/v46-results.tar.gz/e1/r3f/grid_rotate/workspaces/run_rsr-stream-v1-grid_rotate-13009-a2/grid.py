def rotate_tiles(grid, turns):
    """
    Rotate a grid counter-clockwise by 90 degrees, turns times.
    The grid is a list of rows (lists) of equal length.
    Turns is any integer; negative turns rotate the other way and only turns modulo 4 matters.
    Return a new list of lists and do not modify the input.
    An empty grid ([]) or a grid of empty rows is returned unchanged as a new list.
    Raise ValueError if the rows have different lengths.
    """
    # Handle empty grid or grid with empty rows
    if not grid or all(len(row) == 0 for row in grid):
        return []

    # Check if all rows have the same length
    first_len = len(grid[0])
    for row in grid:
        if len(row) != first_len:
            raise ValueError("Rows have different lengths")

    # Calculate effective turns (modulo 4)
    # Counter-clockwise rotation: 1 turn = 90° CCW, 2 turns = 180°, 3 turns = 270° CCW (or 90° CW), 4 turns = 360° (no change)
    # We'll normalize turns to [0, 1, 2, 3]
    effective_turns = turns % 4

    # Handle negative turns: in Python, -1 % 4 = 3, which is correct for 3 CCW rotations (or 1 CW rotation)
    # So we can directly use effective_turns

    rows = len(grid)
    cols = first_len

    # Perform rotation
    # Counter-clockwise rotation: new grid[i][j] = old grid[j][rows - 1 - i]
    # Let's verify: for 1 CCW turn, new[0][0] = old[0][rows-1], new[0][1] = old[1][rows-1], etc.
    # Actually, let's think carefully:
    # Original grid:
    #   [a, b, c]
    #   [d, e, f]
    # After 1 CCW rotation (90°):
    #   [c, f]
    #   [b, e]
    #   [a, d]
    # So new[i][j] = old[j][rows - 1 - i]
    new_grid = []
    for i in range(effective_turns):
        # Perform one CCW rotation
        temp = []
        for j in range(cols):
            row = [grid[j][rows - 1 - i] for j in range(rows)]
            temp.append(row)
        new_grid = temp

    return new_grid
