def turn_grid(grid, turns):
    """Rotate a grid counter-clockwise by 90 degrees 'turns' times.
    
    Args:
        grid: A list of rows (lists) of equal length.
        turns: An integer representing the number of rotations.
        
    Returns:
        A new list of lists representing the rotated grid.
        
    Raises:
        ValueError: If rows have different lengths.
    """
    # Handle empty grid or grid with empty rows
    if not grid or (all(len(row) == 0 for row in grid)):
        return []
    
    # Check that all rows have the same length
    row_length = len(grid[0])
    for row in grid:
        if len(row) != row_length:
            raise ValueError("Rows have different lengths")
    
    # Normalize turns to be positive modulo 4
    turns = turns % 4
    
    # Rotate counter-clockwise by 90 degrees 'turns' times
    # One counter-clockwise rotation: transpose and reverse each row
    # Actually, counter-clockwise 90° = transpose then reverse each column?
    # Let's think: clockwise 90° = transpose then reverse each row
    # Counter-clockwise 90° = reverse each row then transpose
    # Or: counter-clockwise 90° = transpose then reverse each column
    
    # Let's verify with an example:
    # [[1, 2], [3, 4]]
    # Clockwise 90°: [[3, 1], [4, 2]]
    # Counter-clockwise 90°: [[2, 4], [1, 3]]
    
    # For counter-clockwise:
    # Reverse each row: [[2, 1], [4, 3]]
    # Then transpose: [[2, 4], [1, 3]] ✓
    
    # So one CCW rotation = reverse each row, then transpose
    
    if turns == 0:
        return grid[:]  # Return a copy
    
    if turns == 1:
        # One counter-clockwise rotation
        new_grid = []
        for i in range(len(grid[0])):
            new_row = [grid[j][i] for j in range(len(grid))]
            new_grid.append(new_row)
        return new_grid
    
    if turns == 2:
        # Two counter-clockwise rotations = 180° rotation
        # Reverse each row and then reverse the order of rows
        new_grid = []
        for i in range(len(grid) - 1, -1, -1):
            new_grid.append(list(reversed(grid[i])))
        return new_grid
    
    if turns == 3:
        # Three counter-clockwise rotations = 270° CCW = 90° clockwise
        # One clockwise rotation: transpose then reverse each row
        # Or: reverse each column then transpose? 
        # Let's use: clockwise 90° = transpose then reverse each row
        # Actually, simpler: 3 CCW = 1 CW
        # Clockwise: [[3, 1], [4, 2]] from [[1, 2], [3, 4]]
        # So: new_grid[i][j] = grid[j][len(grid) - 1 - i]
        new_grid = []
        for i in range(len(grid)):
            new_row = []
            for j in range(len(grid[0])):
                new_row.append(grid[j][len(grid) - 1 - i])
            new_grid.append(new_row)
        return new_grid
    
    # For negative turns, the modulo operation handles it
    # But let's make sure we handle any integer correctly
    # Actually, the problem says "turns modulo 4 matters"
    # So we should just use the normalized turns value
    
    # Let's recalculate using a general approach
    # After normalization, turns is 0, 1, 2, or 3
    # We've handled all cases above
    
    return grid[:]
