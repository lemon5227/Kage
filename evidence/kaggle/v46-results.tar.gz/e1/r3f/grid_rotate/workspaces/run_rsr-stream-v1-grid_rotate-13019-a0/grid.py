def turn_grid(grid, turns):
    # Handle empty grid or grid with empty rows
    if not grid or (len(grid) == 0 or all(len(row) == 0 for row in grid)):
        return []
    
    # Check that all rows have equal length
    row_lengths = [len(row) for row in grid]
    if len(set(row_lengths)) != 1:
        raise ValueError("Rows have different lengths")
    
    m = len(grid)  # number of rows
    n = len(grid[0])  # number of columns
    
    # Calculate effective turns (only modulo 4 matters)
    effective_turns = turns % 4
    
    # Rotate counter-clockwise by 90 degrees for each turn
    # Counter-clockwise rotation: new_grid[i][j] = old_grid[j][m-1-i]
    for _ in range(effective_turns):
        # Create new grid
        new_grid = []
        for i in range(n):
            row = []
            for j in range(m - 1 - i):
                row.append(grid[j][i])
            new_grid.append(row)
        grid = new_grid
    
    return grid
