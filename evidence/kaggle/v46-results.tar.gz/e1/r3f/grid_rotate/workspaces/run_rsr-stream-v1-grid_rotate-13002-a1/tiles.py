def spin_board(grid, turns):
    # Handle empty grid or grid of empty rows
    if not grid:
        return []
    
    # Check if all rows are empty
    if all(not row for row in grid):
        return []
    
    # Check if all rows have same length
    first_len = len(grid[0])
    for row in grid:
        if len(row) != first_len:
            raise ValueError("Rows have different lengths")
    
    # Normalize turns to [0, 1, 2, 3]
    turns = turns % 4
    
    # Rotate counter-clockwise by 90 degrees once
    def rotate_ccw(grid):
        rows = grid
        cols = len(rows[0])
        new_grid = []
        for col in range(cols):
            new_row = [row[col] for row in reversed(rows)]
            new_grid.append(new_row)
        return new_grid
    
    # Apply rotation `turns` times
    for _ in range(turns):
        grid = rotate_ccw(grid)
    
    return grid
