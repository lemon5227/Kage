def rotate(grid, turns):
    """
    Rotate a grid counter-clockwise by `turns` times (90 degrees per turn).
    
    Args:
        grid: List of rows (lists) of equal length
        turns: Integer number of rotations
    
    Returns:
        New list of lists rotated counter-clockwise
    
    Raises:
        ValueError: If rows have different lengths
    """
    # Handle empty grid or grid with empty rows
    if not grid or (len(grid) == 1 and len(grid[0]) == 0):
        return []
    
    # Check that all rows have the same length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Rows have different lengths")
    
    rows = len(grid)
    cols = len(grid[0])
    
    # Normalize turns to 0-3 range
    normalized_turns = turns % 4
    
    # If normalized_turns is negative, convert to positive equivalent
    if normalized_turns < 0:
        normalized_turns += 4
    
    # If turns is 0, return original as new list
    if normalized_turns == 0:
        return [row[:] for row in grid]
    
    # Perform rotation based on normalized_turns
    if normalized_turns == 1:  # 90° CCW
        # new_grid[i][j] = old_grid[j][cols-1-i]
        new_grid = []
        for i in range(cols):
            new_row = []
            for j in range(rows):
                new_row.append(grid[j][cols-1-i])
            new_grid.append(new_row)
        return new_grid
    
    elif normalized_turns == 2:  # 180° CCW
        # new_grid[i][j] = old_grid[rows-1-j][cols-1-i]
        new_grid = []
        for i in range(cols):
            new_row = []
            for j in range(rows):
                new_row.append(grid[rows-1-j][cols-1-i])
            new_grid.append(new_row)
        return new_grid
    
    elif normalized_turns == 3:  # 270° CCW (or 90° CW)
        # new_grid[i][j] = old_grid[cols-1-j][rows-1-i]
        new_grid = []
        for i in range(cols):
            new_row = []
            for j in range(rows):
                new_row.append(grid[cols-1-j][rows-1-i])
            new_grid.append(new_row)
        return new_grid
    
    else:
        # Should not happen due to normalization, but just in case
        return [row[:] for row in grid]
