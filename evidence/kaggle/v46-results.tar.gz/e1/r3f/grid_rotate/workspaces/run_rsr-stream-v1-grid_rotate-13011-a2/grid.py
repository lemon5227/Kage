def rotate(grid, turns):
    """
    Rotate a grid counter-clockwise by turns times (each turn is 90 degrees).
    
    Args:
        grid: A list of rows (lists) of equal length
        turns: Integer number of rotations
        
    Returns:
        A new list of lists rotated counter-clockwise
        
    Raises:
        ValueError: If rows have different lengths
    """
    # Handle empty grid or grid with empty rows
    if not grid or not grid[0]:
        return []
    
    # Check that all rows have the same length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Rows have different lengths")
    
    # Normalize turns to 0-3 range (counter-clockwise rotations)
    # Each turn is 90 degrees counter-clockwise
    # turns modulo 4 gives the effective rotation
    turns = turns % 4
    
    rows = len(grid)
    cols = len(grid[0])
    
    # Rotate counter-clockwise by 90 degrees
    # This means: new_grid[j][rows - 1 - i] = grid[i][j]
    # Or equivalently: new_grid[i][j] = grid[j][rows - 1 - i]
    # Let's derive: after 1 counter-clockwise rotation:
    #   Original: row i, col j -> New: row j, col (rows - 1 - i)
    #   So new_grid[j][rows - 1 - i] = grid[i][j]
    #   Let's swap indices: new_grid[i][j] = grid[j][rows - 1 - i]
    
    if turns == 0:
        return [list(row) for row in grid]
    elif turns == 1:
        # One counter-clockwise rotation
        new_grid = []
        for j in range(cols):
            row = []
            for i in range(rows):
                row.append(grid[i][j])
            new_grid.append(row)
        return new_grid
    elif turns == 2:
        # Two counter-clockwise rotations = 180 degrees
        new_grid = []
        for i in range(rows):
            row = list(reversed(grid[i]))
            new_grid.append(row)
        return new_grid
    elif turns == 3:
        # Three counter-clockwise rotations = 270 degrees = 1 counter-clockwise + 180
        # Or equivalently, 1 clockwise rotation
        new_grid = []
        for j in range(cols):
            row = []
            for i in range(rows):
                row.append(grid[i][j])
            new_grid.append(row)
        return new_grid
    
    # This should never happen due to modulo
    raise ValueError("Invalid number of turns")
