def rotate(grid, turns):
    # Handle empty grid or grid of empty rows
    if not grid or (not grid[0] and len(grid) > 0):
        return []
    
    # Check if all rows have equal length
    row_length = len(grid[0])
    for row in grid:
        if len(row) != row_length:
            raise ValueError("Rows have different lengths")
    
    # Normalize turns to 0-3 range (modulo 4)
    turns = turns % 4
    
    rows = len(grid)
    cols = row_length
    
    if turns == 1:
        # Rotate clockwise 90 degrees
        new_grid = []
        for j in range(cols):
            new_row = []
            for i in range(rows):
                new_row.append(grid[i][j])
            new_grid.append(new_row)
        return new_grid
    elif turns == 2:
        # Rotate 180 degrees (twice clockwise)
        new_grid = []
        for i in range(rows - 1, -1, -1):
            new_row = list(reversed(grid[i]))
            new_grid.append(new_row)
        return new_grid
    elif turns == 3:
        # Rotate 270 degrees clockwise (90 degrees counterclockwise)
        new_grid = []
        for j in range(cols - 1, -1, -1):
            new_row = []
            for i in range(rows):
                new_row.append(grid[i][j])
            new_grid.append(new_row)
        return new_grid
    else:
        # turns == 0, return original grid as new list
        return [list(row) for row in grid]
