def rotate(grid, turns):
    # Handle empty grid or grid of empty rows
    if not grid or (all(row == [] for row in grid)):
        return []
    
    # Check if all rows have equal length
    row_length = len(grid[0])
    for row in grid:
        if len(row) != row_length:
            raise ValueError("Rows have different lengths")
    
    # Calculate effective turns (counter-clockwise rotations)
    effective_turns = turns % 4
    
    rows = len(grid)
    cols = row_length
    
    # Perform counter-clockwise rotation for effective_turns times
    for _ in range(effective_turns):
        # Counter-clockwise 90° rotation: new_grid[i][j] = old_grid[cols-1-j][i]
        new_grid = []
        for i in range(cols):
            new_row = []
            for j in range(rows):
                new_row.append(grid[j][i])
            new_grid.append(new_row)
        grid = new_grid
    
    return grid
