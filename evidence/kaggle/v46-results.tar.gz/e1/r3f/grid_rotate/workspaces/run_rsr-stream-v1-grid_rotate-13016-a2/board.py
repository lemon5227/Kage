def turn_grid(grid, turns):
    # Handle empty grid or grid of empty rows
    if not grid or (len(grid) == 0 and all(len(row) == 0 for row in grid)):
        return []
    
    # Check if all rows have the same length
    first_len = len(grid[0])
    for row in grid:
        if len(row) != first_len:
            raise ValueError("Rows have different lengths")
    
    # Normalize turns to 0-3 range (clockwise rotations)
    # Positive turns: clockwise, negative turns: counterclockwise
    # Only turns % 4 matters
    normalized_turns = turns % 4
    
    # Rotate clockwise by 90 degrees for each rotation
    result = grid
    for _ in range(normalized_turns):
        new_grid = []
        # Rotate clockwise: first column becomes first row
        for col in range(len(grid[0])):
            new_row = [row[col] for row in grid]
            new_grid.append(new_row)
        result = new_grid
    
    return result
