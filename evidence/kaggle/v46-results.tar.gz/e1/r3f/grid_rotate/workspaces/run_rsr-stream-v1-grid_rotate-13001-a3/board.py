def rotate(grid, turns):
    """
    Rotate a grid clockwise by 90 degrees `turns` times.
    
    Args:
        grid: List of rows (lists) of equal length
        turns: Integer number of rotations (positive or negative)
    
    Returns:
        New list of lists representing the rotated grid
    
    Raises:
        ValueError: If rows have different lengths
    """
    # Handle empty grid
    if not grid:
        return []
    
    # Handle grid with empty rows - return unchanged new list
    if all(row == [] for row in grid):
        return []
    
    # Check that all rows have equal length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Rows have different lengths")
    
    # Normalize turns to 0-3 range (clockwise rotations)
    # Positive turns: clockwise, negative turns: counterclockwise
    # Since we rotate clockwise, negative turns should be converted to positive
    # by adding 4 until positive, then taking modulo 4
    normalized_turns = (turns % 4 + 4) % 4
    
    # Get dimensions
    rows = len(grid)
    cols = len(grid[0])
    
    # Rotate clockwise by 90 degrees
    # For a grid of size rows x cols, rotated becomes cols x rows
    rotated = []
    for col in range(cols):
        new_row = []
        for row in range(rows):
            new_row.append(grid[row][col])
        rotated.append(new_row)
    
    # Apply rotation multiple times if needed
    for _ in range(normalized_turns):
        # Rotate clockwise once
        rows = len(rotated)
        cols = len(rotated[0])
        new_rotated = []
        for col in range(cols):
            new_row = []
            for row in range(rows):
                new_row.append(rotated[row][col])
            new_rotated.append(new_row)
        rotated = new_rotated
    
    return rotated
