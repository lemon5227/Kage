def rotate_tiles(grid, turns):
    """
    Rotate a grid counter-clockwise by 90 degrees, turns times.
    The grid is a list of rows (lists) of equal length.
    Returns a new list of lists without modifying the input.
    An empty grid or a grid of empty rows is returned unchanged as a new list.
    Raises ValueError if the rows have different lengths.
    """
    # Handle empty grid cases
    if not grid:
        return []
    
    # Check if all rows are empty
    if all(not row for row in grid):
        return []
    
    # Check if rows have equal length
    first_len = len(grid[0])
    for row in grid:
        if len(row) != first_len:
            raise ValueError("Rows have different lengths")
    
    # Calculate effective turns (modulo 4)
    effective_turns = turns % 4
    
    # Rotate counter-clockwise by 90 degrees, effective_turns times
    # One counter-clockwise rotation: new_grid[i][j] = grid[n-1-j][i]
    # where n is the number of rows
    
    n = len(grid)  # number of rows
    m = first_len  # number of columns
    
    if effective_turns == 0:
        return [list(row) for row in grid]
    
    # Perform counter-clockwise rotations
    result = []
    for _ in range(effective_turns):
        # Rotate one time counter-clockwise
        new_grid = []
        for j in range(m - 1, -1, -1):
            new_row = []
            for i in range(n):
                new_row.append(grid[i][j])
            new_grid.append(new_row)
        result = new_grid
    
    return result
