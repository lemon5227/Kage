def rotate_tiles(grid, turns):
    """
    Rotate a grid counter-clockwise by 90 degrees, turns times.
    
    Args:
        grid: A list of rows (lists) of equal length
        turns: Integer number of rotations
    
    Returns:
        A new list of lists rotated counter-clockwise
    
    Raises:
        ValueError: If rows have different lengths
    """
    # Handle empty grid or grid of empty rows
    if not grid or all(len(row) == 0 for row in grid):
        return []
    
    # Check that all rows have the same length
    row_length = len(grid[0])
    for row in grid:
        if len(row) != row_length:
            raise ValueError("Rows have different lengths")
    
    # Normalize turns to [0, 1, 2, 3] range
    # Counter-clockwise rotation: 90 degrees per turn
    # If turns is negative, it rotates clockwise (which is counter-clockwise by -turns)
    # Since -turns % 4 gives the correct rotation in [0, 3], we can use turns % 4 directly
    # But note: in Python, negative numbers mod 4 give positive results
    # e.g., -1 % 4 = 3 (which is 270 degrees counter-clockwise or 90 degrees clockwise)
    # So we can simply use: effective_turns = turns % 4
    
    effective_turns = turns % 4
    
    # For 0 rotations, return original
    if effective_turns == 0:
        return [row[:] for row in grid]  # Return a copy
    
    # For 1 rotation (90 degrees counter-clockwise)
    if effective_turns == 1:
        n = len(grid)
        result = []
        for col in range(n):
            row = []
            for row_idx in range(n - 1, -1, -1):
                row.append(grid[row_idx][col])
            result.append(row)
        return result
    
    # For 2 rotations (180 degrees counter-clockwise)
    if effective_turns == 2:
        n = len(grid)
        result = []
        for i in range(n):
            row = [grid[n - 1 - i][j] for j in range(n)]
            result.append(row)
        return result
    
    # For 3 rotations (270 degrees counter-clockwise, or 90 degrees clockwise)
    if effective_turns == 3:
        n = len(grid)
        result = []
        for col in range(n):
            row = []
            for row_idx in range(n):
                row.append(grid[row_idx][col])
            result.append(row)
        return result
    
    # Fallback (should not reach here)
    return [row[:] for row in grid]
