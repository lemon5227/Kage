def spin_board(grid, turns):
    # Handle empty grid or grid of empty rows
    if not grid or (len(grid) == 0 or all(len(row) == 0 for row in grid)):
        return []
    
    # Check that all rows have equal length
    row_lengths = [len(row) for row in grid]
    if len(set(row_lengths)) != 1:
        raise ValueError("Rows have different lengths")
    
    n_rows = len(grid)
    n_cols = len(grid[0])
    
    # Normalize turns (modulo 4) - negative values handled by Python's modulo
    turns = turns % 4
    
    # Rotate counter-clockwise by turns * 90 degrees
    # Counter-clockwise rotation: new[i][j] = old[n_rows-1-j][i]
    # After k rotations: new[i][j] = old[n_rows-1-(j*turns)%(n_rows)][(i*turns)%n_rows]
    # Simpler approach: apply rotation k times
    
    current_grid = grid
    for _ in range(turns):
        # Rotate counter-clockwise by 90 degrees
        new_grid = []
        for j in range(n_cols):
            new_row = []
            for i in range(n_rows):
                new_row.append(current_grid[i][n_cols - 1 - j])
            new_grid.append(new_row)
        current_grid = new_grid
    
    return current_grid
