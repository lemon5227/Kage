def turn_grid(grid, turns):
    # Handle empty grid or grid of empty rows
    if not grid or (len(grid) == 0 or all(len(row) == 0 for row in grid)):
        return []
    
    # Check that all rows have equal length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Rows have different lengths")
    
    rows_len = len(grid)
    cols_len = len(grid[0])
    
    # Normalize turns to 0-3 range
    # Positive: clockwise, Negative: counterclockwise
    # Only turns % 4 matters
    # In Python, negative modulo gives positive result in range [0, 3]
    # But we need to handle it correctly: -1 % 4 = 3 (270° clockwise = 90° counterclockwise)
    # So we can use turns % 4 directly
    effective_turns = turns % 4
    
    if effective_turns == 0:
        return [row[:] for row in grid]  # Return a copy
    
    if effective_turns == 1:
        # Clockwise 90°: new_grid[i][j] = old_grid[rows_len - 1 - j][i]
        new_grid = []
        for i in range(cols_len):
            row = []
            for j in range(rows_len):
                row.append(grid[j][i])
            new_grid.append(row)
        return new_grid
    
    if effective_turns == 2:
        # 180°: reverse each row
        return [row[:] for row in reversed(grid)]
    
    if effective_turns == 3:
        # 270° clockwise = 90° counterclockwise
        # new_grid[i][j] = old_grid[j][cols_len - 1 - i]
        new_grid = []
        for i in range(cols_len):
            row = []
            for j in range(rows_len):
                row.append(grid[j][cols_len - 1 - i])
            new_grid.append(row)
        return new_grid
    
    # Should not reach here due to modulo, but just in case
    return [row[:] for row in grid]
