def rotate(grid, turns):
    """Rotate a grid clockwise by 90 degrees, turns times.
    
    Args:
        grid: A list of rows (lists) of equal length.
        turns: An integer representing the number of 90-degree rotations.
               Negative turns rotate counter-clockwise; only turns % 4 matters.
    
    Returns:
        A new list of lists representing the rotated grid.
        Returns unchanged if grid is empty or all rows are empty.
    
    Raises:
        ValueError: If the rows have different lengths.
    """
    # Handle empty grid or grid with empty rows
    if not grid:
        return []
    
    # Check if all rows are empty
    if all(len(row) == 0 for row in grid):
        return []
    
    # Check that all rows have the same length
    first_len = len(grid[0])
    for row in grid:
        if len(row) != first_len:
            raise ValueError("Rows have different lengths")
    
    # Calculate effective rotations
    turns = turns % 4
    
    # If no rotation needed, return a copy of the original grid
    if turns == 0:
        return [row[:] for row in grid]
    
    # Perform the rotation
    # Rotate clockwise by 90 degrees: transpose and reverse each row
    rows = len(grid)
    cols = first_len
    
    # After n rotations, dimensions become (cols, rows)
    # For each rotation, we need to compute the new grid
    
    # Start with original dimensions
    curr_rows = rows
    curr_cols = cols
    
    # Perform rotations
    for _ in range(turns):
        # New grid after one clockwise rotation:
        # new_grid[j][i] = old_grid[i][curr_rows - 1 - j]
        new_grid = []
        for j in range(curr_cols):
            row = []
            for i in range(curr_rows):
                row.append(grid[i][curr_rows - 1 - j])
            new_grid.append(row)
        grid = new_grid
        curr_rows = curr_cols
        curr_cols = len(new_grid)
    
    return grid
