#!/usr/bin/env python3
from grid import turn_grid

# Test 1: Basic 90 degree clockwise rotation
grid1 = [[1, 2], [3, 4]]
result1 = turn_grid(grid1, 1)
print("Test 1 - 90° clockwise:")
print(f"Input: {grid1}")
print(f"Output: {result1}")
print(f"Expected: [[3, 1], [4, 2]]")
print()

# Test 2: 180 degree rotation (2 turns)
grid2 = [[1, 2], [3, 4]]
result2 = turn_grid(grid2, 2)
print("Test 2 - 180° rotation:")
print(f"Input: {grid2}")
print(f"Output: {result2}")
print(f"Expected: [[4, 3], [2, 1]]")
print()

# Test 3: 270 degree clockwise rotation (3 turns)
grid3 = [[1, 2], [3, 4]]
result3 = turn_grid(grid3, 3)
print("Test 3 - 270° clockwise:")
print(f"Input: {grid3}")
print(f"Output: {result3}")
print(f"Expected: [[2, 4], [1, 3]]")
print()

# Test 4: Negative turns (clockwise rotation by -90° = 270°)
grid4 = [[1, 2], [3, 4]]
result4 = turn_grid(grid4, -1)
print("Test 4 - -90° (equivalent to 270°):")
print(f"Input: {grid4}")
print(f"Output: {result4}")
print(f"Expected: [[2, 4], [1, 3]]")
print()

# Test 5: Empty grid
grid5 = []
result5 = turn_grid(grid5, 1)
print("Test 5 - Empty grid:")
print(f"Input: {grid5}")
print(f"Output: {result5}")
print(f"Expected: []")
print()

# Test 6: Grid with empty rows
grid6 = [[], []]
result6 = turn_grid(grid6, 1)
print("Test 6 - Grid with empty rows:")
print(f"Input: {grid6}")
print(f"Output: {result6}")
print(f"Expected: []")
print()

# Test 7: ValueError for different lengths
grid7 = [[1, 2], [3, 4]]
try:
    result7 = turn_grid(grid7, 1)
    print("Test 7 - Should have raised ValueError")
except ValueError as e:
    print(f"Test 7 - ValueError raised correctly: {e}")
print()

# Test 8: Identity rotation (4 turns = 0)
grid8 = [[1, 2], [3, 4]]
result8 = turn_grid(grid8, 4)
print("Test 8 - 4 turns (identity):")
print(f"Input: {grid8}")
print(f"Output: {result8}")
print(f"Expected: [[1, 2], [3, 4]]")
print()

# Test 9: Single element grid
grid9 = [[1]]
result9 = turn_grid(grid9, 1)
print("Test 9 - Single element:")
print(f"Input: {grid9}")
print(f"Output: {result9}")
print(f"Expected: [[1]]")
print()

# Test 10: Larger grid
grid10 = [[1, 2, 3], [4, 5, 6]]
result10 = turn_grid(grid10, 1)
print("Test 10 - 2x3 grid:")
print(f"Input: {grid10}")
print(f"Output: {result10}")
print(f"Expected: [[4, 1], [5, 2], [6, 3]]")
