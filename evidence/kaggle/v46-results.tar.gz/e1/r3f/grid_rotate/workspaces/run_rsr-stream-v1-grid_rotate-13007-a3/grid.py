def turn_grid(grid, turns):
    """
    Rotate a grid clockwise by 90 degrees, turns times.
    The grid is a list of rows (lists) of equal length.
    Returns a new list of lists without modifying the input.
    Raises ValueError if rows have different lengths.
    """
    # Handle empty grid or grid with empty rows
    if not grid or (len(grid) == 0 and all(len(row) == 0 for row in grid)):
        return []
    
    # Check if all rows have the same length
    if not grid:
        return []
    
    row_length = len(grid[0])
    for row in grid:
        if len(row) != row_length:
            raise ValueError("Rows have different lengths")
    
    # Calculate effective turns (modulo 4)
    effective_turns = turns % 4
    
    # Handle negative turns - they rotate the other way
    # A clockwise rotation by 90 degrees is equivalent to a counter-clockwise rotation by 270 degrees
    # We'll handle this by rotating in the correct direction
    
    if effective_turns == 0:
        return grid.copy()  # No rotation needed
    
    # For positive turns (clockwise)
    # 1 turn clockwise: transpose and reverse each row
    # 2 turns clockwise: rotate 180 degrees - reverse each row then reverse order of rows
    # 3 turns clockwise: rotate 270 degrees - equivalent to 1 turn counter-clockwise
    
    if effective_turns == 1:
        # Rotate 90 degrees clockwise
        new_grid = []
        for col in range(row_length):
            new_row = [grid[row][col] for row in range(len(grid))]
            new_grid.append(new_row)
        return new_grid
    
    elif effective_turns == 2:
        # Rotate 180 degrees - reverse each row and reverse the order of rows
        new_grid = []
        for row in reversed(grid):
            new_grid.append(list(reversed(row)))
        return new_grid
    
    elif effective_turns == 3:
        # Rotate 270 degrees clockwise (or 90 degrees counter-clockwise)
        new_grid = []
        for col in range(row_length):
            new_row = [grid[row][col] for row in reversed(range(len(grid)))]
            new_grid.append(new_row)
        return new_grid
    
    # Default: no rotation
    return grid.copy()
