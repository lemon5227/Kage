#!/usr/bin/env python3
import subprocess
import sys

# Run the test file with Python
result = subprocess.run([sys.executable, "test_grid.py"], capture_output=True, text=True)
print(result.stdout)
if result.stderr:
    print("STDERR:", result.stderr)
print(f"Return code: {result.returncode}")
