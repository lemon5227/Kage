def rotate(grid, turns):
    """
    Rotate a grid clockwise by 90 degrees, turns times.
    
    Args:
        grid: A list of rows (lists) of equal length
        turns: Integer number of rotations (positive = clockwise, negative = counter-clockwise)
    
    Returns:
        A new list of lists representing the rotated grid
    
    Raises:
        ValueError: If the rows have different lengths
    """
    # Handle empty grid or grid with empty rows
    if not grid or len(grid[0]) == 0:
        return []
    
    # Check if all rows have the same length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Rows have different lengths")
    
    # Calculate effective rotations (modulo 4)
    # Positive turns: clockwise, negative turns: counter-clockwise
    # Each full rotation is 360 degrees = 4 * 90 degrees
    mod = 4
    effective_turns = turns % mod
    
    # If effective_turns is negative, convert to positive equivalent
    if effective_turns < 0:
        effective_turns += mod
    
    # Perform the rotation
    rows = grid
    for _ in range(effective_turns):
        # Rotate clockwise by 90 degrees
        new_grid = []
        num_cols = len(rows[0])
        num_rows = len(rows)
        
        for col in range(num_cols):
            new_row = [rows[row][col] for row in range(num_rows)]
            new_grid.append(new_row)
        
        rows = new_grid
    
    return rows
