def rotate(grid, turns):
    """Rotate a grid counter-clockwise by `turns` times (90° each).
    
    Args:
        grid: A list of rows (lists) of equal length.
        turns: Any integer; only turns % 4 matters.
    
    Returns:
        A new list of lists representing the rotated grid.
    
    Raises:
        ValueError: If rows have different lengths.
    """
    # Handle empty grid or grid with empty rows
    if not grid or (len(grid) == 1 and len(grid[0]) == 0):
        return []
    
    # Check all rows have equal length
    row_len = len(grid[0])
    for row in grid:
        if len(row) != row_len:
            raise ValueError("Rows have different lengths")
    
    # Normalize turns to 0-3 range
    turns = turns % 4
    
    # Counter-clockwise rotation: 
    # 1 turn (90° CCW): transpose then reverse each row
    # Actually: 90° CCW = transpose then reverse columns, or: [col[::-1] for col in zip(*grid)]
    # Let's implement 90° CCW rotation:
    # For grid [[1,2],[3,4]], 90° CCW should be [[3,1],[4,2]]
    # This is equivalent to: transpose then reverse each row
    # Or: [row[::-1] for row in zip(*grid)] doesn't work directly.
    # Correct: new_grid = [[grid[j][i] for j in range(len(grid))] for i in range(row_len)]
    # But simpler: 90° CCW = transpose then reverse each row? Let's think:
    # Original: (0,0)=1, (0,1)=2, (1,0)=3, (1,1)=4
    # After 90° CCW: (0,0)=3, (0,1)=1, (1,0)=4, (1,1)=2
    # So new[i][j] = old[j][row_len-1-i]
    
    if turns == 0:
        return [row[:] for row in grid]
    
    n = len(grid)
    m = row_len
    
    # 90° CCW rotation: new[i][j] = old[j][m-1-i]
    # This is equivalent to: transpose then reverse each row
    # Actually: first transpose, then reverse each row of the transposed result?
    # Let's test: grid = [[1,2],[3,4]]
    # Transpose: [[1,3],[2,4]]
    # Reverse each row: [[3,1],[4,2]] - correct!
    
    if turns == 1:
        # 90° CCW: transpose then reverse each row
        transposed = list(zip(*grid))
        return [list(row[::-1]) for row in transposed]
    
    elif turns == 2:
        # 180° CCW: reverse each row then reverse order of rows
        return [row[::-1] for row in reversed(grid)]
    
    elif turns == 3:
        # 270° CCW = 90° CW: reverse order of rows then transpose
        transposed = list(zip(*grid))
        return [list(row) for row in reversed(transposed)]
