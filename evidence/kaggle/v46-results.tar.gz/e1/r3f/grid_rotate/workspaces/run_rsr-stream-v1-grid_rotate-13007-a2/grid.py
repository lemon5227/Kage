def turn_grid(grid, turns):
    """
    Rotate a grid clockwise by 90 degrees, turns times.
    
    Args:
        grid: List of rows (lists) of equal length
        turns: Integer number of rotations (positive or negative)
    
    Returns:
        New list of lists representing the rotated grid
    
    Raises:
        ValueError: If rows have different lengths
    """
    # Handle empty grid or grid of empty rows
    if not grid:
        return []
    
    # Check if all rows are empty
    first_row = grid[0]
    if not first_row:
        # All rows are empty (or at least the first is, and we'll validate lengths)
        # Return a copy of the grid as is
        return [row[:] for row in grid]
    
    # Check that all rows have equal length
    row_length = len(first_row)
    for row in grid:
        if len(row) != row_length:
            raise ValueError("Rows have different lengths")
    
    # Calculate effective rotations (turns modulo 4)
    # Positive: clockwise, Negative: counter-clockwise
    # Only the remainder matters
    effective_turns = turns % 4
    
    # If effective_turns is 0, no rotation needed
    if effective_turns == 0:
        return [row[:] for row in grid]  # Return a copy
    
    # Rotate clockwise by 90 degrees, effective_turns times
    # One 90-degree clockwise rotation: 
    # new_grid[i][j] = old_grid[rows-1-j][i]
    rows = len(grid)
    
    # Perform the rotation
    def rotate_once(grid):
        new_grid = []
        for j in range(rows):
            new_row = []
            for i in range(len(grid[0])):
                new_row.append(grid[rows - 1 - i][j])
            new_grid.append(new_row)
        return new_grid
    
    # Apply rotation effective_turns times
    current_grid = grid
    for _ in range(effective_turns):
        current_grid = rotate_once(current_grid)
    
    return current_grid
