def turn_grid(grid, turns):
    """Rotate a grid counter-clockwise by 90 degrees, turns times.
    
    Args:
        grid: A list of rows (lists) of equal length
        turns: Integer number of rotations (negative rotates the other way)
    
    Returns:
        A new list of lists representing the rotated grid
    
    Raises:
        ValueError: If rows have different lengths
    """
    # Handle empty grid or grid of empty rows
    if not grid or all(len(row) == 0 for row in grid):
        return []
    
    # Check that all rows have equal length
    if not grid:
        return []
    first_len = len(grid[0])
    for row in grid:
        if len(row) != first_len:
            raise ValueError("Rows have different lengths")
    
    # Normalize turns to 0-3 range
    # Counter-clockwise rotation is equivalent to 3 clockwise rotations
    # But we'll implement counter-clockwise directly
    # For n rotations, we can compute effective rotation
    num_rows = len(grid)
    effective_turns = turns % 4
    
    # If effective_turns is negative (from modulo of negative), Python handles it correctly
    # But let's ensure it's in [0, 3]
    while effective_turns < 0:
        effective_turns += 4
    
    # Perform the rotation
    # Counter-clockwise rotation by 90 degrees:
    # new_grid[i][j] = old_grid[num_rows-1-j][i]
    # This is equivalent to transposing and then reversing each row
    
    # First, transpose the grid (swap rows and columns)
    transposed = [[grid[j][i] for j in range(num_rows)] for i in range(first_len)]
    
    # Then reverse each row (this gives counter-clockwise rotation)
    # Actually, for counter-clockwise: [1,2], [3,4] -> [3,1], [4,2]
    # Let's verify: original: rows 0:[1,2], 1:[3,4]
    # After transpose: [[1,3], [2,4]]
    # Reverse each row: [[3,1], [4,2]] - this is correct counter-clockwise
    
    rotated = [row[::-1] for row in transposed]
    
    # Apply rotation multiple times if needed
    for _ in range(effective_turns):
        # Counter-clockwise rotation
        num_rows = len(rotated)
        first_len = len(rotated[0])
        new_rotated = [[rotated[j][i] for j in range(num_rows)] for i in range(first_len)]
        rotated = [row[::-1] for row in new_rotated]
    
    return rotated
