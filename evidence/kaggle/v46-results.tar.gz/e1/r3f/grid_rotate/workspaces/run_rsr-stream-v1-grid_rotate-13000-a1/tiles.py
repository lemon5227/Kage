def rotate(grid, turns):
    # Handle empty grid or grid with empty rows
    if not grid or (not grid[0] and len(grid) > 0):
        return []
    
    # Check if all rows have the same length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Rows have different lengths")
    
    # Normalize turns to 0-3 range
    turns = turns % 4
    
    # If no rotation needed (0 or 4), return a copy of the grid
    if turns == 0:
        return [row[:] for row in grid]
    
    # Rotate clockwise by turns * 90 degrees
    # For 1 rotation (90° clockwise): transpose and reverse each row
    # For 2 rotations (180°): reverse each row
    # For 3 rotations (270° clockwise = 90° counter-clockwise): transpose then reverse each column
    
    if turns == 1:
        # 90° clockwise: new_grid[i][j] = grid[-1-j][i]
        new_grid = []
        for j in range(len(grid[0])):
            new_row = []
            for i in range(len(grid)):
                new_row.append(grid[i][j])
            new_grid.append(new_row)
        return new_grid
    
    elif turns == 2:
        # 180°: reverse each row
        return [row[:] for row in reversed(grid)]
    
    elif turns == 3:
        # 270° clockwise = 90° counter-clockwise: new_grid[i][j] = grid[j][-1-i]
        new_grid = []
        for j in range(len(grid[0])):
            new_row = []
            for i in range(len(grid)):
                new_row.append(grid[j][len(grid) - 1 - i])
            new_grid.append(new_row)
        return new_grid
    
    return grid
