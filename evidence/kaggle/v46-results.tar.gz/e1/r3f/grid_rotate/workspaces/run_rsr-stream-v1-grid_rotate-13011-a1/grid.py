def rotate(grid, turns):
    """Rotate a grid counter-clockwise by 90 degrees * turns times.
    
    Args:
        grid: A list of rows (lists) of equal length
        turns: Any integer; negative turns rotate the other way and only 
               turns modulo 4 matters
    
    Returns:
        A new list of lists rotated counter-clockwise
    
    Raises:
        ValueError: If the rows have different lengths
    """
    # Handle empty grid or grid with empty rows
    if not grid or (not grid[0] and len(grid) == 1):
        return []
    
    # Check that all rows have the same length
    row_lengths = [len(row) for row in grid]
    if len(set(row_lengths)) != 1:
        raise ValueError("Rows have different lengths")
    
    # Normalize turns to 0-3 range (counter-clockwise rotation)
    # Counter-clockwise rotation by 90 degrees is the same as 
    # clockwise rotation by 270 degrees, or 3 times clockwise 90-degree rotation
    # But we're rotating counter-clockwise, so:
    # - 1 turn = 90° CCW = 3 × 90° CW
    # - 2 turns = 180° CCW = 2 × 90° CW
    # - 3 turns = 270° CCW = 1 × 90° CW
    # - 4 turns = 360° CCW = 0 rotation
    # So we can use: turns % 4, where positive means CCW
    turns = turns % 4
    
    rows = len(grid)
    cols = len(grid[0])
    
    # Create the rotated grid
    # Counter-clockwise rotation: column i becomes row (rows - 1 - i)
    # New grid[j][i] = old grid[i][rows - 1 - j]
    new_grid = []
    for j in range(cols):
        new_row = []
        for i in range(rows):
            new_row.append(grid[i][rows - 1 - j])
        new_grid.append(new_row)
    
    return new_grid
