def turn_grid(grid, turns):
    """Rotate a grid clockwise by 90 degrees `turns` times.
    
    Args:
        grid: List of lists (rows) of equal length
        turns: Integer number of rotations (positive = clockwise, negative = counter-clockwise)
    
    Returns:
        New list of lists representing the rotated grid
    
    Raises:
        ValueError: If rows have different lengths
    """
    # Handle empty grid or grid of empty rows
    if not grid or all(not row for row in grid):
        return []
    
    # Check that all rows have equal length
    if not grid:
        return []
    first_len = len(grid[0])
    for row in grid:
        if len(row) != first_len:
            raise ValueError("Rows have different lengths")
    
    # Calculate effective rotations (modulo 4)
    # Positive turns = clockwise, negative = counter-clockwise
    mod = 4
    effective_turns = abs(turns) % mod
    if turns < 0:
        effective_turns = mod - (effective_turns % mod) if effective_turns != 0 else 0
    
    # Perform rotation
    rows = grid
    for _ in range(effective_turns):
        # Rotate clockwise: new_grid[j][i] = grid[i][len(grid)-1-j]
        new_grid = []
        for j in range(len(grid)):
            new_row = []
            for i in range(len(grid[0])):
                new_row.append(grid[i][len(grid) - 1 - j])
            new_grid.append(new_row)
        rows = new_grid
    
    return rows
