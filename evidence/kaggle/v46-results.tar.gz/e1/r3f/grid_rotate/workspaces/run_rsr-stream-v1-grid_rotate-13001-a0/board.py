def rotate(grid, turns):
    # Handle empty grid or grid of empty rows
    if not grid:
        return []
    
    # Check if all rows have the same length
    row_lengths = [len(row) for row in grid]
    if not all(length == row_lengths[0] for length in row_lengths):
        raise ValueError("Rows have different lengths")
    
    # Determine effective turns (modulo 4)
    effective_turns = turns % 4
    
    # If no rotation needed
    if effective_turns == 0:
        return grid[:]  # Return a copy
    
    # Rotate clockwise by 90 * effective_turns degrees
    # Each 90 degree clockwise rotation: transpose and reverse each row
    result = []
    rows = grid
    
    for _ in range(effective_turns):
        # Transpose the grid
        new_grid = [[grid[j][i] for j in range(len(grid))] for i in range(len(grid[0]))]
        # Reverse each row to get clockwise rotation
        result = [[row[::-1] for row in new_grid]]
    
    return result
