def turn_grid(grid, turns):
    return None
