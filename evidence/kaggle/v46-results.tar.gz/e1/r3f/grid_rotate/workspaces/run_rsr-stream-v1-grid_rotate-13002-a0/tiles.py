def spin_board(grid, turns):
    return None
