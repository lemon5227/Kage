def sort_versions(versions):
    """Sort version strings in descending order (newest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    Missing trailing parts count as 0, so "1.2" and "1.2.0" are equal versions.
    Equal versions are ordered by their string, in the same direction (descending).
    
    Raises ValueError for an empty string or any non-numeric part.
    """
    def validate_and_parse(version):
        """Parse a version string into a tuple of integers."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part:
                raise ValueError(f"Empty part in version {version}")
            try:
                num = int(part)
                if num < 0:
                    raise ValueError(f"Non-negative integer required in version {version}")
                result.append(num)
            except ValueError as e:
                raise ValueError(f"Non-numeric part '{part}' in version {version}") from e
        return result
    
    # Parse all versions
    parsed_versions = []
    for version in versions:
        parsed_versions.append(validate_and_parse(version))
    
    # Find the maximum number of parts
    max_len = max(len(v) for v in parsed_versions)
    
    # Create padded versions for comparison
    padded_versions = []
    for v in parsed_versions:
        padded_versions.append(list(v + [0] * (max_len - len(v))))
    
    # Sort using a key that handles the requirements
    def version_key(version_str):
        """Create a tuple for sorting."""
        parsed = validate_and_parse(version_str)
        padded = list(parsed + [0] * (max_len - len(parsed)))
        return tuple(padded), version_str
    
    # Sort descending by the key
    sorted_versions = sorted(versions, key=version_key, reverse=True)
    
    return sorted_versions
