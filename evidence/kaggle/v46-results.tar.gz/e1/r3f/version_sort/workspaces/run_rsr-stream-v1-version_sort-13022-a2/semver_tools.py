def sort_versions(versions):
    """Sort version strings according to semantic versioning rules."""
    # Validate and parse each version, track max length
    parsed_versions = []
    max_len = 0
    
    for version in versions:
        if not version:
            raise ValueError("Empty string version")
        
        parts = version.split('.')
        numeric_parts = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            numeric_parts.append(int(part))
        max_len = max(max_len, len(numeric_parts))
        
        # Pad with zeros to match max_len
        padded = list(numeric_parts)
        while len(padded) < max_len:
            padded.append(0)
        
        parsed_versions.append((tuple(padded), version))
    
    # Sort by numeric parts first, then by original string for equal versions
    parsed_versions.sort(key=lambda x: (x[0], x[1]))
    
    # Extract the original version strings in sorted order
    return [v[1] for v in parsed_versions]
