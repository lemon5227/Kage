def sort_versions(versions):
    """Sort version strings in ascending order (oldest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers. Missing trailing parts count as 0.
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    def validate_and_parse(version_str):
        """Validate and parse a version string into a list of integers."""
        if not version_str:
            raise ValueError("Empty version string")
        
        parts = version_str.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version_str}")
            result.append(int(part))
        return result
    
    # Validate and parse all versions
    parsed_versions = []
    for version in versions:
        parsed_versions.append(validate_and_parse(version))
    
    # Sort: primary by parsed integer parts, secondary by original string for equal versions
    def sort_key(version_parts):
        # Pad with zeros to ensure equal length for comparison
        max_len = max(len(v) for v in parsed_versions)
        padded = list(v + [0] * (max_len - len(v)) for v in parsed_versions)
        return (padded, version)
    
    sorted_versions = sorted(versions, key=sort_key)
    return sorted_versions
