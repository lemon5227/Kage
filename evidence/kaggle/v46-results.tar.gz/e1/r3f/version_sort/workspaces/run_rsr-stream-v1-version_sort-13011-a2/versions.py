def sorted_tags(versions):
    """
    Sort version strings like "1.10.2" in ascending order (oldest first).
    Each version is a string of dot-separated non-negative integers.
    
    - Compare part by part as integers (so "1.10" is newer than "1.9")
    - A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0"
    - Equal versions are ordered by their string, in the same direction
    - Raise ValueError for an empty string or any non-numeric part
    """
    def validate_and_parse(version):
        """Validate and parse a version string into a list of integers."""
        if not version:
            raise ValueError("Empty string")
        
        parts = version.split('.')
        for i, part in enumerate(parts):
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version {version}")
            parts[i] = int(part)
        return parts
    
    def compare_versions(v1, v2):
        """Compare two version lists. Returns -1, 0, or 1."""
        max_len = max(len(v1), len(v2))
        
        for i in range(max_len):
            p1 = v1[i] if i < len(v1) else 0
            p2 = v2[i] if i < len(v2) else 0
            
            if p1 != p2:
                return -1 if p1 < p2 else 1
        
        # If all numeric parts are equal, the shorter version is older
        # This handles cases like "1.2" vs "1.2.0"
        return -1 if len(v1) < len(v2) else 1
    
    # Parse all versions
    parsed_versions = []
    for version in versions:
        parsed_versions.append(validate_and_parse(version))
    
    # Sort using the comparison function
    sorted_versions = sorted(parsed_versions, key=lambda v: v)
    
    # Convert back to strings
    return [f"{parts[0]}" + "." + f"{parts[1]}" + "." + f"{parts[2]}" if len(parts) == 3 else 
            f"{parts[0]}" + "." + f"{parts[1]}" if len(parts) == 2 else 
            f"{parts[0]}" for parts in sorted_versions]
