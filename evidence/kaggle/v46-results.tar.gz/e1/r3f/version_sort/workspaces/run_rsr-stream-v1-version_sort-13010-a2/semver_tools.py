def sort_versions(versions):
    """Sort version strings according to semantic versioning rules."""
    
    # Validate and parse each version
    parsed_versions = []
    for version in versions:
        if not version:
            raise ValueError("Empty string is not a valid version")
        
        parts = version.split('.')
        parsed_parts = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part '{part}' in version '{version}'")
            parsed_parts.append(int(part))
        parsed_versions.append(parsed_parts)
    
    # Sort using a custom comparator that handles the rules
    def compare_versions(v1, v2):
        # Compare part by part
        max_len = max(len(v1), len(v2))
        
        for i in range(max_len):
            p1 = v1[i] if i < len(v1) else 0
            p2 = v2[i] if i < len(v2) else 0
            
            if p1 != p2:
                # Return -1 if v1 < v2, 1 if v1 > v2
                return -1 if p1 < p2 else 1
        
        # If all parts are equal, shorter version is older (comes first)
        # But we need to handle the case where they are exactly equal
        # The requirement says: "Equal versions are ordered by their string, in the same direction"
        # So if versions are identical, we should use the original string comparison
        if len(v1) == len(v2):
            return 0
        
        # One version is a prefix of the other - shorter is older
        # But we need to compare by string as well for equal parts
        # Actually, let's re-read: "A shorter version that is a prefix of a longer one is older"
        # So "1.2" comes before "1.2.0"
        # And "Equal versions are ordered by their string" - this means if they are exactly equal (same parts),
        # we should use the original string order
        
        # For "1.2" and "1.2.0", they are not equal, but the first is a prefix of the second
        # So shorter comes first
        return -1 if len(v1) < len(v2) else 1
    
    # Sort the versions
    sorted_versions = sorted(parsed_versions, key=lambda v: (v, tuple(v)))
    
    # Convert back to strings
    result = []
    for parsed in sorted_versions:
        result.append('.'.join(str(p) for p in parsed))
    
    return result
