def order_releases(versions):
    """Sort version strings as integers part by part, returning oldest first."""
    # Validate and parse each version string
    parsed_versions = []
    for v in versions:
        if not v:  # Empty string
            raise ValueError("Empty version string")
        
        parts = v.split('.')
        for part in parts:
            if not part.isdigit():  # Check if non-numeric
                raise ValueError(f"Non-numeric part in version: {v}")
        
        parsed_versions.append((v, [int(p) for p in parts]))
    
    # Custom comparison key function
    def compare_versions(v1, v2):
        parts1 = v1[1]  # integer parts of version 1
        parts2 = v2[1]  # integer parts of version 2
        
        # Compare part by part
        min_len = min(len(parts1), len(parts2))
        for i in range(min_len):
            if parts1[i] != parts2[i]:
                return parts1[i] - parts2[i]
        
        # If all common parts are equal, shorter version is older
        if len(parts1) < len(parts2):
            return -1
        elif len(parts1) > len(parts2):
            return 1
        
        # Equal versions: order by string representation
        return v1[0] - v2[0]
    
    # Sort using the custom comparison
    sorted_versions = sorted(parsed_versions, key=lambda x: (x[1], x[0]))
    
    # Extract just the version strings in sorted order
    return [v[0] for v in sorted_versions]
