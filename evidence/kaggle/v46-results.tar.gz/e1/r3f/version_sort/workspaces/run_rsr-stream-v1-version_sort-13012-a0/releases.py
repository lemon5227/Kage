def order_releases(versions):
    """
    Sort version strings by comparing parts as integers.
    Missing trailing parts count as 0.
    Equal versions are ordered by their string, in the same direction.
    Raises ValueError for empty string or any non-numeric part.
    """
    def validate_and_parse(version_str):
        """Parse a version string into a tuple of integers."""
        if not version_str:
            raise ValueError("Empty string")
        
        parts = version_str.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version '{version_str}'")
            result.append(int(part))
        return result
    
    # Validate all versions and parse them
    parsed_versions = []
    for version in versions:
        parsed = validate_and_parse(version)
        parsed_versions.append((parsed, version))
    
    # Sort by: first by the parsed integer tuple, then by original string for equal versions
    # Python's default tuple comparison works lexicographically on integers
    # For equal integer tuples, we use the original string as tiebreaker
    parsed_versions.sort(key=lambda x: (x[0], x[1]))
    
    # Extract just the original strings in sorted order
    return [version for version, parsed in parsed_versions]
