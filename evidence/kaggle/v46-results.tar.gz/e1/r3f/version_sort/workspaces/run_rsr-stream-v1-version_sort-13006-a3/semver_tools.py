def rank_versions(versions):
    """
    Sort version strings according to semantic versioning rules.
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9") and return a new list ordered oldest first (ascending).
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    def validate_and_parse(version):
        """Validate version string and return list of integers."""
        if not version:
            raise ValueError("Empty string is not a valid version")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part '{part}' in version '{version}'")
            result.append(int(part))
        return result
    
    def compare_versions(v1, v2):
        """Compare two version tuples. Returns -1, 0, or 1."""
        # Pad shorter version with zeros to match longer length
        max_len = max(len(v1), len(v2))
        v1_padded = v1 + [0] * (max_len - len(v1))
        v2_padded = v2 + [0] * (max_len - len(v2))
        
        # Compare part by part
        for i in range(max_len):
            if v1_padded[i] < v2_padded[i]:
                return -1
            elif v1_padded[i] > v2_padded[i]:
                return 1
        
        # If all parts are equal, use the original string comparison
        # This ensures stable sort for equal versions
        if v1 == v2:
            return 0
        else:
            # Return comparison based on string representation
            # Since they represent the same numeric version but different string format,
            # we need to maintain the order from the input. Using string comparison
            # preserves the original relative order for equal numeric versions.
            return -1 if v1 < v2 else 1
    
    # Validate and parse all versions
    parsed_versions = []
    for version in versions:
        parsed_versions.append((validate_and_parse(version), version))
    
    # Sort using the comparison function
    sorted_versions = sorted(parsed_versions, key=lambda x: x[0])
    
    # Return only the version strings in sorted order
    return [v[1] for v in sorted_versions]
