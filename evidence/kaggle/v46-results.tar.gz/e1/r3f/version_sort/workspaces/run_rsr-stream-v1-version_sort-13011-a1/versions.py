def sorted_tags(versions):
    """
    Sort version strings in ascending order (oldest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers. A shorter version that is a prefix of a longer 
    one is older. Equal versions are ordered by their string.
    
    Raises:
        ValueError: If an empty string or any non-numeric part is found.
    """
    def validate_and_parse(version):
        """Validate version string and return tuple of integers."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            result.append(int(part))
        return result
    
    # Validate all versions and parse them
    parsed_versions = []
    original_versions = []
    for version in versions:
        parsed = validate_and_parse(version)
        parsed_versions.append(parsed)
        original_versions.append(version)
    
    # Define comparison function
    def compare_versions(v1, v2):
        """Compare two version tuples. Returns negative if v1 < v2, positive if v1 > v2, 0 if equal."""
        # Compare part by part
        min_len = min(len(v1), len(v2))
        
        for i in range(min_len):
            part1 = v1[i]
            part2 = v2[i]
            
            if part1 < part2:
                return -1
            elif part1 > part2:
                return 1
            else:
                # Parts are equal, continue to next part
                continue
        
        # One version is a prefix of the other
        if len(v1) < len(v2):
            return -1  # v1 is shorter, so it's older
        elif len(v1) > len(v2):
            return 1  # v2 is shorter, so it's older
        
        # Both versions have same length and all parts are equal
        # Equal versions are ordered by their string, in the same direction
        if original_versions[v1.__index__] < original_versions[v2.__index__]:
            return -1
        elif original_versions[v1.__index__] > original_versions[v2.__index__]:
            return 1
        return 0
    
    # Sort using the comparison function
    from functools import cmp_to_key
    
    sorted_parsed = sorted(parsed_versions, key=cmp_to_key(compare_versions))
    
    # Convert back to strings
    result = []
    for i, v in enumerate(sorted_parsed):
        version_str = ".".join(map(str, v))
        result.append(version_str)
    
    return result
