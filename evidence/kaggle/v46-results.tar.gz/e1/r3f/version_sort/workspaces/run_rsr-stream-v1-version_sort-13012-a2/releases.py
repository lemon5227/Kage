def order_releases(versions):
    """
    Sort version strings like "1.10.2" by comparing parts as integers.
    Missing trailing parts count as 0.
    Equal versions are ordered by their string (ascending).
    Raises ValueError for empty string or non-numeric parts.
    Returns new list ordered oldest first (ascending).
    """
    def validate_and_parse(version):
        """Validate version string and return list of integers."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            result.append(int(part))
        return result
    
    # Parse all versions
    parsed_versions = []
    for v in versions:
        parsed = validate_and_parse(v)
        # Store (parsed, original_string) for tie-breaking
        parsed_versions.append((parsed, v))
    
    # Sort by: 1) parsed parts (as tuples of integers), 2) original string
    # Since we want equal versions ordered by their string in the same direction,
    # and ascending means alphabetical order, we sort by (parsed, original_string)
    sorted_versions = sorted(parsed_versions, key=lambda x: (x[0], x[1]))
    
    # Extract just the original strings
    return [v[1] for v in sorted_versions]
