def sort_versions(versions):
    """Sort version strings in ascending order (oldest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    # Validate and parse versions
    parsed_versions = []
    for version in versions:
        if not version:
            raise ValueError(f"Empty version string: '{version}'")
        
        parts = version.split('.')
        for i, part in enumerate(parts):
            try:
                num = int(part)
                if num < 0:
                    raise ValueError(f"Negative number in version part {i}: '{part}'")
            except ValueError as e:
                raise ValueError(f"Non-numeric part in version '{version}': '{part}'") from e
        
        parsed_versions.append(parts)
    
    # Sort versions
    def version_key(v):
        parts = v
        # Create a key for sorting
        # For equal versions, use the original string for stable ordering
        # For prefix cases, shorter versions come first
        # We'll create a tuple that handles this:
        # (length, parts as integers, original string)
        return (len(parts), tuple(parts), v)
    
    sorted_versions = sorted(parsed_versions, key=version_key)
    
    # Convert back to strings
    result = []
    for parts in sorted_versions:
        result.append('.' .join(map(str, parts)))
    
    return result
