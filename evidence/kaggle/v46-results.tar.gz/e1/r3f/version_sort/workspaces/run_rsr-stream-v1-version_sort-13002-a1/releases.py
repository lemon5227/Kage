def order_releases(versions):
    """
    Sort version strings by dot-separated non-negative integers.
    Returns a new list ordered newest first (descending).
    Missing trailing parts count as 0.
    Equal versions are ordered by their string, in the same direction.
    Raises ValueError for an empty string or any non-numeric part.
    """
    if not versions:
        return []
    
    def validate_and_parse(version):
        """Validate and parse a version string into a list of integers."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part:
                raise ValueError(f"Empty part in version '{version}'")
            try:
                num = int(part)
                if num < 0:
                    raise ValueError(f"Non-negative integer required, got {num} in version '{version}'")
                result.append(num)
            except ValueError as e:
                raise ValueError(f"Non-numeric part '{part}' in version '{version}'") from e
        return result
    
    # Parse all versions and keep track of original strings
    parsed_versions = []
    for version in versions:
        parsed_versions.append(validate_and_parse(version))
    
    # Sort: newest first (descending), equal versions ordered by their string
    def comparison_key(version_parts):
        """
        Create a comparison key for sorting.
        For descending order, we negate the numeric values.
        For equal versions, we use the original string.
        """
        # Pad with zeros to handle variable length properly when comparing
        # But we can't easily pad all tuples to same length in key.
        # Instead, we'll compare part by part using a custom sort.
        # We'll use: (-part1, -part2, ...) for descending numeric order,
        # and the original string for tie-breaking.
        return tuple(-part for part in version_parts) + (version,)
    
    # Sort using the key
    sorted_indices = sorted(range(len(parsed_versions)), key=lambda i: comparison_key(parsed_versions[i]))
    
    # Build result list with original strings
    result = []
    for idx in sorted_indices:
        result.append(versions[idx])
    
    return result
