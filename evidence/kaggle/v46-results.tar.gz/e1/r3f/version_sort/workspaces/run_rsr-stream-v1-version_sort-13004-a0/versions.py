def rank_versions(versions):
    return None
