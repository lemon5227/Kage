def sort_versions(versions):
    """Sort version strings in descending order (newest first).
    
    Args:
        versions: List of version strings like "1.10.2"
        
    Returns:
        New list ordered newest first
        
    Raises:
        ValueError: If any version is empty or contains non-numeric parts
    """
    # Validate and parse each version
    parsed_versions = []
    for v in versions:
        if not v:
            raise ValueError(f"Empty version string: '{v}'")
        
        parts = v.split('.')
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: '{v}'")
            parsed_versions.append((v, [int(p) for p in parts]))
    
    # Custom comparison function for sorting
    def compare_versions(v1_parts, v2_parts):
        """Compare two version parts lists. Returns -1, 0, or 1."""
        # Pad to same length
        max_len = max(len(v1_parts), len(v2_parts))
        
        # Compare part by part
        for i in range(max_len):
            p1 = v1_parts[i] if i < len(v1_parts) else 0
            p2 = v2_parts[i] if i < len(v2_parts) else 0
            
            if p1 != p2:
                # Return -1 if v1 < v2, 1 if v1 > v2
                return -1 if p1 < p2 else 1
        
        # If all parts are equal, compare by original string (descending)
        # The requirement says "Equal versions are ordered by their string, in the same direction"
        # Since we want descending order, we compare strings lexicographically
        return -1 if v1_parts < v2_parts else 1
    
    # Sort in descending order using the comparison function
    # We'll use a key-based approach with a custom comparator
    # Python's sort with key is tricky for custom comparators, so we'll use functools.cmp_to_key
    
    from functools import cmp_to_key
    
    def version_compare(v1, v2):
        """Compare two versions. Returns negative if v1 < v2, positive if v1 > v2."""
        p1 = parsed_versions[v1][1]
        p2 = parsed_versions[v2][1]
        return compare_versions(p1, p2)
    
    # Sort in descending order: we want highest first
    # So we reverse the result of sorting with cmp_to_key
    sorted_indices = sorted(range(len(parsed_versions)), key=cmp_to_key(version_compare))
    
    # Extract the version strings in sorted order (descending)
    return [parsed_versions[i][0] for i in sorted_indices]
