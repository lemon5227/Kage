def sort_versions(versions):
    """
    Sort version strings according to semantic versioning rules.
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    Return a new list ordered newest first (descending).
    Missing trailing parts count as 0, so "1.2" and "1.2.0" are equal versions.
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    def validate_and_parse(version):
        """Validate version string and parse into list of integers."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            result.append(int(part))
        return result
    
    # Parse and validate all versions
    parsed_versions = []
    for v in versions:
        parsed_versions.append(validate_and_parse(v))
    
    # Sort by: first by version parts (descending), then by original string (ascending for ties)
    # Since we want newest first, we sort descending on the tuple of integers
    # For equal versions, we need to break ties by original string representation
    # The requirement says "Equal versions are ordered by their string, in the same direction"
    # This likely means if two versions are numerically equal, sort them alphabetically/lexicographically
    # But since they're numeric, we can just compare the string representation
    
    # We'll use a custom key: (-version_tuple, original_string)
    # The negative version_tuple makes it descending on numeric parts
    # The original_string breaks ties in ascending order (alphabetical)
    
    sorted_versions = []
    for v in versions:
        parsed = validate_and_parse(v)
        # We need the original string for tie-breaking
        sorted_versions.append((parsed, v))
    
    # Sort: primary by version parts descending, secondary by original string ascending
    sorted_versions.sort(key=lambda x: (-x[0], x[1]))
    
    # Extract just the original strings
    return [v for v, _ in sorted_versions]
