def rank_versions(versions):
    """
    Sort version strings in descending order (newest first).
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    
    Comparison rules:
    - Compare part by part as integers (so "1.10" is newer than "1.9")
    - A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0"
    - Equal versions are ordered by their string, in the same direction (descending)
    
    Raises:
        ValueError: if an empty string or any non-numeric part is found
    """
    # Validate and parse all versions
    parsed_versions = []
    for version in versions:
        if not version:
            raise ValueError("Empty string")
        
        parts = version.split('.')
        numeric_parts = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version '{version}'")
            numeric_parts.append(int(part))
        parsed_versions.append(numeric_parts)
    
    # Sort in descending order using custom comparison
    def compare_versions(v1, v2):
        """Compare two version lists. Returns -1 if v1 < v2, 0 if equal, 1 if v1 > v2."""
        max_len = max(len(v1), len(v2))
        
        for i in range(max_len):
            p1 = v1[i] if i < len(v1) else 0
            p2 = v2[i] if i < len(v2) else 0
            
            if p1 != p2:
                # For descending order, we want larger numbers first
                return 1 if p1 > p2 else -1
        
        # If all parts are equal, use string comparison for tie-breaking
        # Equal versions ordered by their string in the same direction (descending)
        str1 = '.'.join(map(str, v1))
        str2 = '.'.join(map(str, v2))
        return 1 if str1 > str2 else -1
    
    # Sort descending
    sorted_versions = sorted(parsed_versions, key=lambda v: (-tuple(v), tuple(v)), reverse=True)
    
    # Convert back to strings
    return [','.join(map(str, v)) for v in sorted_versions]
