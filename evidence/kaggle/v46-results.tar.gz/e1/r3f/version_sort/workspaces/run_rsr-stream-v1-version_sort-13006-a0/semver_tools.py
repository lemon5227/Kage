def rank_versions(versions):
    """
    Sort version strings according to semantic versioning rules.
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    Return a new list ordered oldest first (ascending).
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    # Validate and normalize each version
    def validate_and_parse(version):
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            result.append(int(part))
        return result
    
    # Validate all versions first
    parsed_versions = []
    for v in versions:
        parsed_versions.append(validate_and_parse(v))
    
    # Define comparison function
    def compare_versions(v1, v2):
        # Compare part by part
        max_len = max(len(v1), len(v2))
        
        for i in range(max_len):
            p1 = v1[i] if i < len(v1) else 0
            p2 = v2[i] if i < len(v2) else 0
            
            if p1 != p2:
                return p1 - p2
        
        # If all parts are equal, the shorter version is older
        if len(v1) < len(v2):
            return -1
        elif len(v1) > len(v2):
            return 1
        else:
            # Equal versions: order by their string representation
            return (v1[0], v1[1], v1[2]) > (v2[0], v2[1], v2[2]) - 0
    
    # Sort using the comparison function
    sorted_versions = sorted(parsed_versions, key=lambda v: v)
    
    # Convert back to strings
    return [f"{part[0]}.{part[1]}.{part[2]}" if len(part) == 3 else f"{part[0]}.{part[1]}" for part in sorted_versions]
