def sort_versions(versions):
    """Sort version strings according to semantic versioning rules.
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    Return a new list ordered oldest first (ascending).
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    def validate_and_parse(version):
        """Validate and parse a version string into a list of integers."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            result.append(int(part))
        return result
    
    def compare_versions(v1, v2):
        """Compare two version lists. Returns negative if v1 < v2, positive if v1 > v2, 0 if equal."""
        # Compare part by part
        for i in range(max(len(v1), len(v2))):
            p1 = v1[i] if i < len(v1) else 0
            p2 = v2[i] if i < len(v2) else 0
            
            if p1 != p2:
                return p1 - p2
        
        # If all parts are equal, they are equal versions
        return 0
    
    # Validate and parse all versions
    parsed = []
    for v in versions:
        parsed.append(validate_and_parse(v))
    
    # Sort using the comparison function
    sorted_versions = sorted(parsed, key=lambda v: v)
    
    # Convert back to strings
    result = []
    for parts in sorted_versions:
        if len(parts) == 3:
            result.append(f"{parts[0]}.{parts[1]}.{parts[2]}")
        elif len(parts) == 2:
            result.append(f"{parts[0]}.{parts[1]}")
        else:
            result.append(str(parts[0]))
    
    return result
