def sort_versions(versions):
    """Sort version strings in ascending order (oldest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    def validate_and_parse(version):
        parts = version.split('.')
        for i, part in enumerate(parts):
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version '{version}'")
            # Convert to int for comparison
            parts[i] = int(part)
        return parts
    
    def compare_versions(v1_parts, v2_parts):
        # Pad shorter version with zeros? No: "1.2" is older than "1.2.0"
        # So we need to handle prefix rule: if v1 is prefix of v2, v1 < v2
        max_len = max(len(v1_parts), len(v2_parts))
        
        # Compare part by part
        for i in range(min(len(v1_parts), len(v2_parts))):
            if v1_parts[i] != v2_parts[i]:
                return -1 if v1_parts[i] < v2_parts[i] else 1
        
        # If all compared parts are equal, the shorter one is older
        if len(v1_parts) < len(v2_parts):
            return -1
        elif len(v1_parts) > len(v2_parts):
            return 1
        else:
            # Equal versions: order by their string (same direction)
            return -1 if v1_parts < v2_parts else 1
    
    # Validate and parse all versions
    parsed_versions = []
    for version in versions:
        if not version:
            raise ValueError("Empty string in versions list")
        parsed_versions.append(validate_and_parse(version))
    
    # Sort using the comparison function
    return sorted(parsed_versions, key=lambda parts: (parts,))
