def sorted_tags(versions):
    """Sort version strings in descending order (newest first)."""
    for version in versions:
        if not version:
            raise ValueError("Empty string provided")
        parts = version.split('.')
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
    
    def parse_version(v):
        """Parse version string into a list of integers."""
        return [int(p) for p in v.split('.')]
    
    def compare_versions(v1, v2):
        """Compare two version strings. Returns -1 if v1 > v2, 1 if v1 < v2, 0 if equal."""
        parts1 = parse_version(v1)
        parts2 = parse_version(v2)
        
        # Compare part by part as integers
        for i in range(max(len(parts1), len(parts2))):
            p1 = parts1[i] if i < len(parts1) else 0
            p2 = parts2[i] if i < len(parts2) else 0
            
            if p1 != p2:
                # Return negative if v1 > v2 (descending order)
                return -(p1 - p2)
        
        # If all compared parts are equal, shorter version is older
        # So longer version should come first in descending order
        if len(parts1) != len(parts2):
            return -(len(parts1) - len(parts2))
        
        # Equal versions: order by their string in the same direction (descending)
        if v1 > v2:
            return -1
        elif v1 < v2:
            return 1
        else:
            return 0
    
    # Use sorted with a key that handles the comparison logic
    # We can't directly use a comparison function with sorted, so we'll use a custom sort
    # or implement it manually
    
    result = []
    for _ in range(len(versions)):
        remaining = list(versions)
        if not remaining:
            break
        
        # Find the maximum version among remaining
        max_v = None
        for v in remaining:
            if max_v is None:
                max_v = v
            else:
                if compare_versions(v, max_v) >= 0:
                    max_v = v
        
        result.append(max_v)
        remaining.remove(max_v)
    
    return result
