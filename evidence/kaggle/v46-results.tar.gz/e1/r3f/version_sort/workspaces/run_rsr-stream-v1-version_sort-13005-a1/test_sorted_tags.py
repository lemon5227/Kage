from releases import sorted_tags

# Test cases
test_cases = [
    (["1.10.2", "1.9", "1.10"], ["1.10.2", "1.10", "1.9"]),
    (["1.2", "1.2.0"], ["1.2.0", "1.2"]),
    (["1.0", "1.0.0"], ["1.0.0", "1.0"]),
    (["2.0", "1.0", "1.10"], ["2.0", "1.10", "1.0"]),
    (["1.0", "1.0"], ["1.0", "1.0"]),  # Equal versions, string order
    (["1.10.2", "1.10.2"], ["1.10.2", "1.10.2"]),
    (["1.11", "1.10", "1.9"], ["1.11", "1.10", "1.9"]),
]

print("Running tests...")
for versions, expected in test_cases:
    result = sorted_tags(versions)
    print(f"Input: {versions}")
    print(f"Expected: {expected}")
    print(f"Got: {result}")
    assert result == expected, f"Failed for {versions}"
    print("PASS")
    print()

print("All tests passed!")
