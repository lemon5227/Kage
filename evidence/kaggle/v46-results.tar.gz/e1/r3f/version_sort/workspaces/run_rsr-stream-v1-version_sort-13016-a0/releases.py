def sort_versions(versions):
    """
    Sort version strings in descending order (newest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    
    Raises:
        ValueError: If an empty string or any non-numeric part is found.
    """
    def validate_version(version):
        """Validate that a version string contains only non-negative integers separated by dots."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
        
        return parts
    
    def compare_versions(version1, version2):
        """Compare two version strings. Returns -1 if v1 < v2, 1 if v1 > v2, 0 if equal."""
        parts1 = validate_version(version1)
        parts2 = validate_version(version2)
        
        # Compare part by part as integers
        max_len = max(len(parts1), len(parts2))
        
        for i in range(max_len):
            p1 = int(parts1[i]) if i < len(parts1) else 0
            p2 = int(parts2[i]) if i < len(parts2) else 0
            
            if p1 != p2:
                if p1 < p2:
                    return -1
                else:
                    return 1
        
        # If all compared parts are equal, shorter version is older
        if len(parts1) < len(parts2):
            return -1  # v1 is older, so v1 < v2
        else:
            return 1  # v1 is newer or equal length, so v1 > v2
        
        # If lengths are equal and all parts equal, they are equal versions
        return 0
    
    # Validate all versions first
    for version in versions:
        validate_version(version)
    
    # Sort using a key function that returns a tuple for comparison
    # We need to create a key that represents the version in a way that sorts correctly
    def version_key(version):
        parts = validate_version(version)
        # Convert to tuple of integers
        int_parts = tuple(int(p) for p in parts)
        # For descending order, we want to sort by the key in reverse
        # But we also need to handle the case where shorter versions are older
        # The key should be such that when reversed, it gives correct order
        # Let's think: "1.2" vs "1.2.0" - "1.2" is older
        # In ascending order, "1.2" < "1.2.0" because we compare part by part
        # So we want to sort in descending order (newest first)
        # We can use reverse=True with a key that represents the version
        return int_parts
    
    sorted_versions = sorted(versions, key=version_key, reverse=True)
    
    return sorted_versions
