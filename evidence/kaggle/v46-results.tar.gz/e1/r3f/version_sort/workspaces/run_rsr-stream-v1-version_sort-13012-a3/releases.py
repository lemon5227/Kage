def order_releases(versions):
    """Sort version strings in ascending order."""
    # Validate and parse each version
    parsed_versions = []
    for v in versions:
        if not v:
            raise ValueError(f"Empty version string: '{v}'")
        
        parts = v.split('.')
        int_parts = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: '{v}'")
            int_parts.append(int(part))
        
        parsed_versions.append((int_parts, v))
    
    # Find the maximum number of parts
    max_parts = max(len(parts) for parts, _ in parsed_versions)
    
    # Pad each version with zeros to match max_parts
    padded_versions = []
    for int_parts, original in parsed_versions:
        padded = list(int_parts) + [0] * (max_parts - len(int_parts))
        padded_versions.append((padded, original))
    
    # Sort by integer parts first, then by original string for equal versions
    sorted_versions = sorted(padded_versions, key=lambda x: (x[0], x[1]))
    
    # Extract just the original version strings
    return [v[1] for v in sorted_versions]
