def sort_versions(versions):
    """
    Sort version strings in descending order (newest first).
    
    Each version is a string of dot-separated non-negative integers.
    Compare part by part as integers.
    
    - "1.10" is newer than "1.9"
    - "1.2" comes before "1.2.0" (shorter prefix is older)
    - Equal versions are ordered by their string, in the same direction
    
    Raises ValueError for an empty string or any non-numeric part.
    """
    if not versions:
        return []
    
    def validate_and_parse(version):
        """Validate version string and return list of integers."""
        parts = version.split('.')
        for i, part in enumerate(parts):
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version {version}")
            # Convert to integer (handles leading zeros)
            parts[i] = int(part)
        return parts
    
    def compare_versions(v1_parts, v2_parts):
        """
        Compare two version parts.
        Returns:
        - Negative if v1 < v2
        - Positive if v1 > v2
        - 0 if equal
        
        A shorter version that is a prefix of a longer one is older.
        """
        # If all parts are equal, compare as strings (same direction)
        if len(v1_parts) == len(v2_parts):
            if v1_parts == v2_parts:
                return 0
            else:
                # Equal up to this point, but different lengths - longer is newer
                # For descending order, we want longer to come first
                if v1_parts > v2_parts:
                    return 1
                else:
                    return -1
        else:
            # Compare lengths first
            max_len = max(len(v1_parts), len(v2_parts))
            
            # Pad with zeros to make lengths equal for comparison
            v1_extended = v1_parts + [0] * (max_len - len(v1_parts))
            v2_extended = v2_parts + [0] * (max_len - len(v2_parts))
            
            # Compare part by part
            for i in range(max_len):
                p1 = v1_extended[i]
                p2 = v2_extended[i]
                
                if p1 != p2:
                    if p1 > p2:
                        return 1
                    else:
                        return -1
            
            # If all parts are equal (except for length), the longer one is newer
            if len(v1_parts) > len(v2_parts):
                return 1
            else:
                return -1
    
    # Validate and parse all versions
    parsed_versions = []
    for version in versions:
        if not version:
            raise ValueError("Empty version string")
        parsed_versions.append(validate_and_parse(version))
    
    # Sort in descending order (newest first)
    # We'll use a custom sort key to achieve the desired ordering
    def sort_key(version_parts):
        """
        Create a sort key for descending order.
        For descending, we want higher values first.
        """
        # Reverse the parts to make longer versions appear "larger" in sorting
        return tuple(-p for p in reversed(version_parts))
    
    sorted_versions = sorted(parsed_versions, key=sort_key, reverse=True)
    
    # Convert back to original string format
    result = []
    for parts in sorted_versions:
        result.append('.'.join(str(p) for p in parts))
    
    return result
