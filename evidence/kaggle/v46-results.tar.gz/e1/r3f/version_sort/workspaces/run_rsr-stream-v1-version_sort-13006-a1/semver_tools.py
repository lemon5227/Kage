def rank_versions(versions):
    """
    Sort version strings according to semantic versioning rules.
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    
    Raises ValueError for an empty string or any non-numeric part.
    
    Returns a new list ordered oldest first (ascending).
    """
    def validate_and_parse(version):
        """Validate and parse a version string into a list of integers."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            result.append(int(part))
        return result
    
    def compare_versions(v1, v2):
        """
        Compare two version lists.
        Returns negative if v1 < v2, positive if v1 > v2, 0 if equal.
        """
        # Compare part by part
        for i in range(min(len(v1), len(v2))):
            if v1[i] != v2[i]:
                if v1[i] < v2[i]:
                    return -1
                else:
                    return 1
        
        # If all compared parts are equal, shorter version is older
        if len(v1) < len(v2):
            return -1
        elif len(v1) > len(v2):
            return 1
        else:
            # Equal versions - order by their string representation
            str_v1 = '.'.join(map(str, v1))
            str_v2 = '.'.join(map(str, v2))
            if str_v1 < str_v2:
                return -1
            else:
                return 1
    
    # Validate and parse all versions
    parsed_versions = []
    for version in versions:
        parsed_versions.append(validate_and_parse(version))
    
    # Sort using the comparison function
    sorted_versions = sorted(parsed_versions, key=lambda v: (v, tuple(v)))
    
    # Convert back to strings
    result = ['.'.join(map(str, v)) for v in sorted_versions]
    
    return result
