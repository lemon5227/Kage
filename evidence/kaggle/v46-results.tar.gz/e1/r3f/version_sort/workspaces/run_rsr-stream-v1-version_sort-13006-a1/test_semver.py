from semver_tools import rank_versions

# Test basic sorting
print("Test 1: Basic versions")
print(rank_versions(["1.9", "1.10", "1.2"]))
# Expected: ["1.2", "1.9", "1.10"]

# Test prefix rule
print("\nTest 2: Prefix rule")
print(rank_versions(["1.2", "1.2.0", "1.2.1"]))
# Expected: ["1.2", "1.2.0", "1.2.1"]

# Test equal versions
print("\nTest 3: Equal versions")
print(rank_versions(["1.0.0", "1.0.0", "1.0.1"]))
# Expected: ["1.0.0", "1.0.0", "1.0.1"]

# Test error handling
print("\nTest 4: Error handling")
try:
    rank_versions([""])
except ValueError as e:
    print(f"Caught expected error: {e}")

try:
    rank_versions(["1.2.3a"])
except ValueError as e:
    print(f"Caught expected error: {e}")

print("\nAll tests completed!")
