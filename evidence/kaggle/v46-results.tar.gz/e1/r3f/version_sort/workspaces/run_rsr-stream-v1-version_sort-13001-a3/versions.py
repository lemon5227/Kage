def sort_versions(versions):
    """Sort version strings in ascending order (oldest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Missing trailing parts count as 0, so "1.2" and "1.2.0" are equal versions.
    Equal versions are ordered by their string, in the same direction.
    
    Raises:
        ValueError: If an empty string or any non-numeric part is found.
    """
    def validate_and_parse(version):
        """Validate and parse a version string into a list of integers."""
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            result.append(int(part))
        return result
    
    def compare_versions(v1, v2):
        """Compare two version lists.
        
        Returns:
            -1 if v1 < v2
            1 if v1 > v2
            0 if v1 == v2 (considering missing parts as 0)
        """
        # Pad shorter list with zeros to match longer list
        max_len = max(len(v1), len(v2))
        v1_padded = v1 + [0] * (max_len - len(v1))
        v2_padded = v2 + [0] * (max_len - len(v2))
        
        for i in range(max_len):
            if v1_padded[i] < v2_padded[i]:
                return -1
            elif v1_padded[i] > v2_padded[i]:
                return 1
        
        # Equal up to the max length
        return 0
    
    # Validate and parse all versions
    parsed_versions = []
    original_strings = []
    for version in versions:
        if not version:
            raise ValueError("Empty string in version list")
        parsed_versions.append(validate_and_parse(version))
        original_strings.append(version)
    
    # Sort using a key that handles the requirements
    def sort_key(version_list):
        """Create a sort key for version lists."""
        # First, get the padded version for numeric comparison
        max_len = max(len(v) for v in parsed_versions)
        padded = [v + [0] * (max_len - len(v)) for v in parsed_versions]
        
        # For each version, create a key: (padded_tuple, original_string)
        # This ensures numeric comparison first, then string order for equal versions
        return (tuple(padded), original_strings)
    
    # Sort by the key
    sorted_indices = sorted(range(len(parsed_versions)), key=lambda i: sort_key(parsed_versions[i]))
    
    # Build the result list
    result = []
    for idx in sorted_indices:
        parts = parsed_versions[idx]
        # Reconstruct the version string, but we need to handle the case where
        # equal versions should be ordered by their original string.
        # The sort key ensures this.
        result.append(original_strings[idx])
    
    return result
