from versions import sort_versions

# Test cases
test_cases = [
    ["1.10.2", "1.9", "1.10"],  # Should be: 1.9, 1.10, 1.10.2
    ["1.2", "1.2.0"],  # Equal versions, should order by string: "1.2" comes before "1.2.0" alphabetically?
    ["1.0.0", "1.0.1", "1.0.2"],  # Simple ascending
    ["2.0", "1.9", "1.10"],  # 1.10 > 1.9, so 1.9, 1.10, 2.0
    ["1.0", "1.0.0", "1.0.0.0"],  # All equal, order by string
]

for versions in test_cases:
    print(f"Input: {versions}")
    try:
        result = sort_versions(versions)
        print(f"Output: {result}")
    except Exception as e:
        print(f"Error: {e}")
    print()

# Test error cases
error_cases = [
    ["", "1.0"],  # Empty string
    ["1.a.0", "1.0"],  # Non-numeric part
]

for versions in error_cases:
    print(f"Input: {versions}")
    try:
        result = sort_versions(versions)
        print(f"Output: {result}")
    except Exception as e:
        print(f"Error: {e}")
    print()
