def rank_versions(versions):
    """Sort version strings in ascending order (oldest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    def validate_and_parse(version_str):
        """Validate and parse a version string into a list of integers."""
        if not version_str:
            raise ValueError("Empty string")
        
        parts = version_str.split('.')
        for i, part in enumerate(parts):
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version_str}")
            parts[i] = int(part)
        return parts
    
    def compare_versions(v1, v2):
        """Compare two version lists. Returns negative if v1 < v2, positive if v1 > v2, 0 if equal."""
        # Compare part by part
        min_len = min(len(v1), len(v2))
        
        for i in range(min_len):
            if v1[i] != v2[i]:
                return -1 if v1[i] < v2[i] else 1
        
        # If all compared parts are equal, shorter version is older (smaller)
        if len(v1) < len(v2):
            return -1
        elif len(v1) > len(v2):
            return 1
        
        # Equal versions: order by their string representation
        v1_str = '.'.join(map(str, v1))
        v2_str = '.'.join(map(str, v2))
        return -1 if v1_str < v2_str else 1
    
    # Validate and parse all versions
    parsed_versions = []
    for version in versions:
        parsed_versions.append(validate_and_parse(version))
    
    # Sort using a tuple key that captures the comparison logic
    # We need to handle the special case where equal versions are ordered by string
    # Create a key that includes the parsed parts and the original string for tie-breaking
    def version_key(v):
        # v is the index in versions list, we need to get the parsed version
        # Actually, let's create a tuple: (parsed_version, original_string)
        # But we need to handle the comparison properly
        pass
    
    # Use a custom sorting algorithm since Python 3 doesn't support cmp parameter
    def sort_versions(parsed):
        """Sort versions using a custom comparison."""
        result = []
        while len(result) < len(parsed):
            # Find the smallest version not yet in result
            min_idx = None
            for i in range(len(parsed)):
                if i in [j for j in range(len(result))]:
                    continue
                if min_idx is None:
                    min_idx = i
                else:
                    if compare_versions(parsed[i], parsed[min_idx]) < 0:
                        min_idx = i
            result.append(parsed[min_idx])
            # Remove the used index from consideration
            del parsed[min_idx]
        return result
    
    sorted_parsed = sort_versions(parsed_versions)
    
    # Return the sorted list of original strings in the same order
    return [versions[i] for i in range(len(versions)) if parsed_versions[i] in sorted_parsed]
