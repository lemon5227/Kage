def rank_versions(versions):
    """Sort version strings in ascending order (oldest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    Missing trailing parts count as 0, so "1.2" and "1.2.0" are equal versions.
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    def validate_and_parse(version_str):
        """Validate version string and return list of integers."""
        if not version_str:
            raise ValueError("Empty version string")
        
        parts = version_str.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {part}")
            result.append(int(part))
        return result
    
    def compare_versions(v1, v2):
        """Compare two version lists. Returns negative if v1 < v2, positive if v1 > v2, 0 if equal."""
        # Pad shorter list with zeros to match length of longer list
        max_len = max(len(v1), len(v2))
        v1_padded = v1 + [0] * (max_len - len(v1))
        v2_padded = v2 + [0] * (max_len - len(v2))
        
        # Compare part by part
        for i in range(max_len):
            if v1_padded[i] != v2_padded[i]:
                if v1_padded[i] < v2_padded[i]:
                    return -1
                else:
                    return 1
        
        # If all parts are equal, compare as strings (same direction - ascending)
        if str(v1) < str(v2):
            return -1
        elif str(v1) > str(v2):
            return 1
        return 0
    
    # Validate and parse all versions
    parsed_versions = []
    for version in versions:
        parsed_versions.append(validate_and_parse(version))
    
    # Sort using the comparison function
    sorted_versions = sorted(parsed_versions, key=lambda v: (v, str(v)))
    
    return [str(v) for v in sorted_versions]
