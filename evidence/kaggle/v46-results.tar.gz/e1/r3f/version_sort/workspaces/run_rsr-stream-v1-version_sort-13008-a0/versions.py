def rank_versions(versions):
    """
    Sort version strings by comparing parts as integers.
    
    Args:
        versions: List of version strings like "1.10.2"
    
    Returns:
        New list ordered oldest first (ascending)
    
    Raises:
        ValueError: If an empty string or any non-numeric part is found
    """
    def validate_and_parse(version):
        """Validate and parse a version string into a list of integers."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            result.append(int(part))
        return result
    
    # Validate and parse all versions
    parsed_versions = []
    for version in versions:
        parsed_versions.append(validate_and_parse(version))
    
    # Sort versions: compare part by part as integers
    # Missing trailing parts count as 0, so "1.2" and "1.2.0" are equal
    # Equal versions are ordered by their string (in the same direction)
    def compare_versions(v1, v2):
        """Compare two version lists."""
        # Pad shorter list with zeros to match length
        max_len = max(len(v1), len(v2))
        v1_padded = v1 + [0] * (max_len - len(v1))
        v2_padded = v2 + [0] * (max_len - len(v2))
        
        # Compare part by part
        for i in range(max_len):
            if v1_padded[i] != v2_padded[i]:
                return v1_padded[i] - v2_padded[i]
        
        # If all parts are equal, order by original string
        return 0
    
    # Sort using the comparison function
    sorted_versions = sorted(parsed_versions, key=lambda v: (v, tuple(v)))
    
    # Return the sorted versions as strings
    return [f"{','.join(map(str, v))}" for v in sorted_versions]
