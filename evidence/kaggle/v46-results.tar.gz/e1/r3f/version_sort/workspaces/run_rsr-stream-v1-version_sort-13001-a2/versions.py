def sort_versions(versions):
    """Sort version strings according to semantic versioning rules."""
    # Validate and parse each version
    parsed_versions = []
    for version in versions:
        if not version:
            raise ValueError("Empty string is not a valid version")
        
        parts = version.split('.')
        numeric_parts = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part '{part}' in version '{version}'")
            numeric_parts.append(int(part))
        # Pad with zeros to match the longest version length
        max_len = len(numeric_parts)
        for i in range(len(numeric_parts), max_len):
            numeric_parts.append(0)
        parsed_versions.append((numeric_parts, version))
    
    # Sort by numeric parts first, then by string for equal versions
    parsed_versions.sort(key=lambda x: (x[0], x[1]))
    
    # Return only the version strings
    return [v[1] for v in parsed_versions]
