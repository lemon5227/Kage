def sorted_tags(versions):
    """Sort version strings in ascending order (oldest first).
    
    Version strings are dot-separated non-negative integers like "1.10.2".
    - Compare parts as integers (so "1.10" is newer than "1.9")
    - Missing trailing parts count as 0 (so "1.2" and "1.2.0" are equal)
    - Equal versions are ordered by their string, in the same direction
    - Raise ValueError for empty string or any non-numeric part
    """
    def parse_version(version_str):
        """Parse a version string into a tuple of integers."""
        if not version_str:
            raise ValueError("Empty string is not a valid version")
        
        parts = version_str.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part '{part}' in version '{version_str}'")
            result.append(int(part))
        return result
    
    # Validate all versions
    parsed_versions = []
    for v in versions:
        parsed_versions.append(parse_version(v))
    
    # Sort: first by numeric tuple (padded with zeros to handle missing trailing parts)
    # Then by original string for equal versions
    def sort_key(version_tuple):
        # Pad with zeros to handle missing trailing parts
        # Example: "1.2" -> (1, 2, 0), "1.2.0" -> (1, 2, 0)
        # We need to compare as if they have equal length by padding with zeros
        # But we don't know the max length. So we can compare tuples directly - 
        # Python compares tuples element by element, and missing parts are treated as 0.
        return version_tuple
    
    # Actually, we need to handle equal versions by their string order.
    # So we need a key that returns (numeric_tuple, original_string)
    
    sorted_versions = sorted(versions, key=lambda v: (parse_version(v), v))
    
    return sorted_versions
