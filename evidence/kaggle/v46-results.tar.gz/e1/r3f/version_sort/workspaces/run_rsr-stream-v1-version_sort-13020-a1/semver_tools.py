def sort_versions(versions):
    """
    Sort version strings in descending order (newest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    Missing trailing parts count as 0, so "1.2" and "1.2.0" are equal versions.
    Equal versions are ordered by their string, in the same direction (descending).
    Raise ValueError for an empty string or any non-numeric part.
    """
    from functools import cmp_to_key
    
    def parse_version(version_str):
        """Parse a version string into a tuple of integers."""
        if not version_str:
            raise ValueError("Empty version string")
        
        parts = version_str.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version_str}")
            result.append(int(part))
        return result
    
    def compare_version(a, b):
        """Compare two version strings. Returns -1 if a > b, 1 if a < b, 0 if equal."""
        parsed_a = parse_version(a)
        parsed_b = parse_version(b)
        
        # Pad to same length
        max_len = max(len(parsed_a), len(parsed_b))
        parsed_a = parsed_a + [0] * (max_len - len(parsed_a))
        parsed_b = parsed_b + [0] * (max_len - len(parsed_b))
        
        # Compare numerically first
        for i in range(max_len):
            if parsed_a[i] != parsed_b[i]:
                return parsed_a[i] - parsed_b[i]
        
        # If numerically equal, compare by string value (descending)
        return -1 if a > b else 1
    
    # Sort using cmp_to_key for descending order
    sorted_versions = sorted(versions, key=cmp_to_key(compare_version))
    
    # Reverse to get newest first (descending)
    return list(reversed(sorted_versions))
