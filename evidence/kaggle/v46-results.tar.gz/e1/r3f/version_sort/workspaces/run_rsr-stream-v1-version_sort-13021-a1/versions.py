def rank_versions(versions):
    """Sort version strings in ascending order (oldest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    def validate_and_parse(version):
        """Validate and parse a version string into a list of integers."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
            result.append(int(part))
        return result
    
    # Validate all versions first
    parsed_versions = []
    original_versions = []
    for v in versions:
        parsed_versions.append(validate_and_parse(v))
        original_versions.append(v)
    
    # Custom comparison function for sorting
    def compare_versions(v1, v2):
        """Compare two version lists. Returns negative if v1 < v2, positive if v1 > v2, 0 if equal."""
        max_len = max(len(v1), len(v2))
        
        for i in range(max_len):
            # If one version is shorter, it's older (smaller)
            if i >= len(v1):
                return -1  # v1 is older
            if i >= len(v2):
                return 1   # v2 is older
            
            part1 = v1[i]
            part2 = v2[i]
            
            if part1 < part2:
                return -1
            elif part1 > part2:
                return 1
        
        # If we reach here, versions are numerically equal
        # Use original string as tiebreaker
        return 0 if original_versions[0] == original_versions[1] else -1 if original_versions[0] < original_versions[1] else 1
    
    # Sort using the custom comparator
    return sorted(versions, key=lambda v: (v, original_versions.index(v)))
