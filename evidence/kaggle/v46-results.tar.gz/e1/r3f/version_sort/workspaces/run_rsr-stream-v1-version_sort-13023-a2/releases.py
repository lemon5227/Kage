def sort_versions(versions):
    """Sort version strings in ascending order (oldest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers. A shorter version that is a prefix of a longer one is older.
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    if not versions:
        return []
    
    def validate_and_parse(version):
        """Validate version string and parse into list of integers."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        for i, part in enumerate(parts):
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version '{version}'")
            # Convert to integer (non-negative)
            parts[i] = int(part)
        return parts
    
    def compare_versions(v1, v2):
        """Compare two version lists. Returns negative if v1 < v2, positive if v1 > v2, 0 if equal."""
        # Pad the shorter list with zeros to match length of longer list
        max_len = max(len(v1), len(v2))
        v1_padded = v1 + [0] * (max_len - len(v1))
        v2_padded = v2 + [0] * (max_len - len(v2))
        
        for i in range(max_len):
            if v1_padded[i] < v2_padded[i]:
                return -1
            elif v1_padded[i] > v2_padded[i]:
                return 1
        
        # If all parts are equal, use string comparison as tiebreaker
        # Convert back to strings for comparison
        v1_str = '.'.join(str(p) for p in v1)
        v2_str = '.'.join(str(p) for p in v2)
        
        if v1_str < v2_str:
            return -1
        elif v1_str > v2_str:
            return 1
        return 0
    
    # Validate and parse all versions
    parsed_versions = []
    for version in versions:
        parsed_versions.append(validate_and_parse(version))
    
    # Sort using the comparison function
    sorted_versions = sorted(parsed_versions, key=lambda v: v)
    
    # Convert back to strings
    return ['.'.join(str(p) for p in v) for v in sorted_versions]
