def sort_versions(versions):
    """Sort version strings in descending order (newest first).
    
    Args:
        versions: List of version strings like "1.10.2"
        
    Returns:
        New list of versions sorted newest first
        
    Raises:
        ValueError: If any version string is empty or contains non-numeric parts
    """
    def validate_version(version):
        """Validate that a version string contains only non-negative integers separated by dots."""
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version: {version}")
        
    def parse_version(version):
        """Parse a version string into a tuple of integers."""
        return tuple(int(part) for part in version.split('.'))
    
    # Validate all versions first
    for version in versions:
        validate_version(version)
    
    # Sort in descending order based on version tuples
    # For equal versions, maintain original order by string comparison (descending)
    sorted_versions = sorted(versions, key=lambda v: parse_version(v), reverse=True)
    
    return sorted_versions
