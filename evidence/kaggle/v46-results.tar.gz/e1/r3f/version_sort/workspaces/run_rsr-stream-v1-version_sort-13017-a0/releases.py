def order_releases(versions):
    """Sort version strings (dot-separated non-negative integers) ascending."""
    # Validate and parse each version
    parsed_versions = []
    for v in versions:
        if not v:
            raise ValueError("Empty string")
        parts = v.split('.')
        for i, part in enumerate(parts):
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in {v}")
            parsed_versions.append((i, int(part), v))
    
    # Sort: first by version number (tuple of ints), then by string for equal versions
    # For prefix comparison: shorter version that is a prefix of longer one is older
    # We can achieve this by comparing the integer parts and handling length
    def compare_versions(a, b):
        # a = (index, int_parts_a, original_str_a)
        # b = (index, int_parts_b, original_str_b)
        # Compare part by part as integers
        max_len = max(len(a[1]), len(b[1]))
        for i in range(max_len):
            part_a = a[1][i] if i < len(a[1]) else 0
            part_b = b[1][i] if i < len(b[1]) else 0
            if part_a != part_b:
                return part_a - part_b
        # If all parts are equal, shorter version is older
        if len(a[1]) != len(b[1]):
            return len(a[1]) - len(b[1])
        # Equal versions: order by string (same direction as specified)
        return 0
    
    # Sort using the custom comparison
    sorted_versions = sorted(parsed_versions, key=lambda x: x)
    
    # Extract original strings in sorted order
    return [v[2] for v in sorted_versions]
