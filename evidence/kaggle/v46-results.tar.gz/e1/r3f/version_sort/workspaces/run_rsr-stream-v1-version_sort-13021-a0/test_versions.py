from versions import rank_versions

# Test cases
test_cases = [
    ["1.10", "1.9", "1.10.2"],
    ["1.2", "1.2.0", "1.2.1"],
    ["1.0", "1.0.0", "1.0.0.0"],
    ["2.0", "1.9", "1.10", "1.9.1"],
    ["1.10.2", "1.10.2", "1.10.2"],  # Equal versions should be ordered by string
]

print("Testing rank_versions function:")
for test in test_cases:
    try:
        result = rank_versions(test)
        print(f"Input: {test}")
        print(f"Output: {result}")
        print()
    except Exception as e:
        print(f"Error with {test}: {e}")
        print()

# Test error cases
error_cases = [
    ["", "1.0"],  # Empty string
    ["1.0", "a.0"],  # Non-numeric part
]

print("Testing error cases:")
for test in error_cases:
    try:
        result = rank_versions(test)
        print(f"Input: {test}")
        print(f"Output: {result}")
        print()
    except Exception as e:
        print(f"Expected error with {test}: {e}")
        print()
