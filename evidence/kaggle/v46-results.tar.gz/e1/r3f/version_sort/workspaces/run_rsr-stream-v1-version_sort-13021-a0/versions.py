def rank_versions(versions):
    """Sort version strings in ascending order (oldest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    def validate_and_parse(version):
        """Validate a version string and return a list of integers."""
        parts = version.split('.')
        result = []
        for part in parts:
            if not part.isdigit():
                raise ValueError(f"Non-numeric part in version '{version}'")
            result.append(int(part))
        return result
    
    # Validate all versions first
    parsed_versions = []
    for version in versions:
        if not version:
            raise ValueError("Empty string in version list")
        parsed_versions.append(validate_and_parse(version))
    
    # Custom comparison function for sorting
    def compare_versions(v1, v2):
        """Compare two version tuples. Returns negative if v1 < v2, positive if v1 > v2, 0 if equal."""
        # Compare part by part
        max_len = max(len(v1), len(v2))
        
        for i in range(max_len):
            # If one version is shorter and it's a prefix, the shorter is older
            if i >= len(v1):
                return -1  # v1 is a prefix of v2, so v1 is older
            if i >= len(v2):
                return 1  # v2 is a prefix of v1, so v2 is older
            
            # Compare the parts as integers
            if v1[i] < v2[i]:
                return -1
            elif v1[i] > v2[i]:
                return 1
        
        # If all parts are equal, order by string representation
        return -1 if v1 < v2 else 1
    
    # Sort the versions using the custom comparator
    sorted_indices = sorted(range(len(versions)), key=lambda i: parsed_versions[i])
    
    # Return the original version strings in sorted order
    return [versions[i] for i in sorted_indices]
