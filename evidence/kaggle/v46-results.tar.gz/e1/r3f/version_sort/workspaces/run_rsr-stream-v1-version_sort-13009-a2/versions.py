def sort_versions(versions):
    """Sort version strings in descending order (newest first).
    
    Each version is a string of dot-separated non-negative integers like "1.10.2".
    Compare part by part as integers (so "1.10" is newer than "1.9").
    A shorter version that is a prefix of a longer one is older, so "1.2" comes before "1.2.0".
    Equal versions are ordered by their string, in the same direction.
    Raise ValueError for an empty string or any non-numeric part.
    """
    # Validate and parse each version
    parsed_versions = []
    for version in versions:
        if not version:
            raise ValueError("Empty version string")
        
        parts = version.split('.')
        for part in parts:
            try:
                num = int(part)
            except ValueError:
                raise ValueError(f"Non-numeric part in version '{version}': '{part}'")
            parsed_versions.append((version, num))
    
    # Sort: newest first (descending)
    # For equal versions, order by their string in the same direction (descending)
    def compare_versions(v1, v2):
        # Compare part by part
        max_len = max(len(v1[1]), len(v2[1]))
        
        for i in range(max_len):
            p1 = v1[1][i] if i < len(v1[1]) else 0
            p2 = v2[1][i] if i < len(v2[1]) else 0
            
            if p1 != p2:
                # Descending order (newest first)
                return p2 - p1
        
        # If all parts are equal, compare the original string in descending order
        return v2[0] - v1[0]
    
    # Sort using the comparison function
    parsed_versions.sort(key=lambda v: v[1], reverse=True)
    
    # Extract just the version strings
    return [v[0] for v in parsed_versions]
