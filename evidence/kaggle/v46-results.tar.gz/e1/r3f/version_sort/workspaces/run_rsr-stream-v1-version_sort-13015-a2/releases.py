def sorted_tags(versions):
    """Sort version strings in descending order (newest first)."""
    # Validate and parse each version
    parsed_versions = []
    for version in versions:
        if not version:
            raise ValueError("Empty string is not a valid version")
        
        parts = version.split('.')
        integer_parts = []
        for part in parts:
            try:
                integer_parts.append(int(part))
            except ValueError:
                raise ValueError(f"Non-numeric part in version: {version}")
        
        # Pad with zeros to match the longest version length
        max_len = len(integer_parts)
        while len(integer_parts) < max_len:
            integer_parts.append(0)
        
        parsed_versions.append(tuple(integer_parts))
    
    # Sort by version numbers in descending order, then by string representation for equal versions
    # For equal versions (same tuple), we need to sort by the original string representation
    # We'll keep track of original strings for tie-breaking
    
    # Create a list of (version_tuple, original_string)
    version_with_string = []
    for i, version in enumerate(versions):
        parsed = parsed_versions[i]
        version_with_string.append((parsed, version))
    
    # Sort: primary by version tuple descending, secondary by original string ascending (or descending?)
    # The requirement says "Equal versions are ordered by their string, in the same direction"
    # Since we're sorting newest first (descending), for equal versions we should also sort in the same direction (descending)
    # So we want: highest version first, and for equal versions, highest string first
    version_with_string.sort(key=lambda x: x[0], reverse=True)
    
    # But we need to handle the tie-breaking: equal versions ordered by their string in the same direction
    # The requirement is ambiguous - "in the same direction" likely means descending order as well
    # Let's re-read: "Equal versions are ordered by their string, in the same direction."
    # Since the overall sorting is descending (newest first), equal versions should also be sorted descending.
    
    # However, we need to be careful: if two versions are numerically equal but have different strings,
    # we should sort them by their string representation. The question is whether this is ascending or descending.
    # "in the same direction" suggests the same direction as the overall sorting (descending).
    
    # Let's implement: first sort by version tuple descending, then by original string descending for ties
    version_with_string.sort(key=lambda x: (x[0], x[1]), reverse=True)
    
    # Extract just the strings in the sorted order
    return [v[1] for v in version_with_string]
