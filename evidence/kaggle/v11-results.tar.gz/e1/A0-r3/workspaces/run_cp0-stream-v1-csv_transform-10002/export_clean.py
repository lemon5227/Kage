import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with header row (columns: name, team, city, id, score)
    Output: Cleaned CSV text with the same header.
    """
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines and handle line endings
    lines = text.split('\n')
    
    # If only header, return it
    if len(lines) == 1:
        return lines[0]
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = []
    for row in rows[1:]:
        # Strip whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip if name is empty
        if not cleaned_row[0]:
            continue
        
        data_rows.append(cleaned_row)
    
    # Remove duplicate rows by "score", keeping first occurrence
    seen_scores = set()
    unique_rows = []
    for row in data_rows:
        score = row[-1]  # last column is score
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort rows by "id" ascending as strings (stable)
    # The id is at index 3 (0=name, 1=team, 2=city, 3=id, 4=score)
    unique_rows.sort(key=lambda row: row[3], reverse=False)
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
