import csv
import io


def normalize_table(text):
    """
    Process CSV text with header row (columns: score, id, email, name).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "name", keeping the first occurrence
    5. Sort rows by "email" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Parse the CSV text
    if not text.strip():
        return ''
    
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Check if first line is a header
    header_line = lines[0].strip()
    if not header_line:
        return ''
    
    # Parse header
    header_cells = header_line.split(',')
    if len(header_cells) != 4 or header_cells[0] != 'score' or header_cells[1] != 'id' or header_cells[2] != 'email' or header_cells[3] != 'name':
        return ''
    
    # Parse data rows
    data_rows = []
    for i, line in enumerate(lines[1:], 1):
        if not line.strip():
            continue
        
        cells = line.split(',')
        if len(cells) != 4:
            continue
        
        score, id_val, email, name = cells
        
        # Step 1: Strip leading/trailing whitespace from every cell
        score = score.strip()
        id_val = id_val.strip()
        email = email.strip()
        name = name.strip()
        
        # Step 2: Drop rows whose "name" cell is empty
        if not name:
            continue
        
        # Step 3: Lower-case the "email" column
        email = email.lower()
        
        data_rows.append({
            'score': score,
            'id': id_val,
            'email': email,
            'name': name,
            'original_index': i  # for stable sort
        })
    
    # Step 4: Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in data_rows:
        if row['name'] not in seen_names:
            seen_names.add(row['name'])
            unique_rows.append(row)
    
    # Step 5: Sort rows by "email" ascending as strings (stable)
    # We need to maintain stability, so we sort by email first, then by original_index
    unique_rows.sort(key=lambda row: (row['email'], row['original_index']))
    
    # Build output CSV
    output = io.StringIO()
    output.write(header_line + '\n')
    
    for row in unique_rows:
        output.write(f"{row['score']},{row['id']},{row['email']},{row['name']}")
        if not row['original_index'] % 1000:  # Add newline after each row
            output.write('\n')
    
    return output.getvalue()


if __name__ == '__main__':
    # Test cases
    test1 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,test@example.com,Jane"
    print("Test 1:", normalize_table(test1))
    
    test2 = "score,id,email,name\n1,abc,test@example.com,John"
    print("Test 2:", normalize_table(test2))
    
    test3 = ""
    print("Test 3:", normalize_table(test3))
    
    test4 = "score,id,email,name"
    print("Test 4:", normalize_table(test4))
