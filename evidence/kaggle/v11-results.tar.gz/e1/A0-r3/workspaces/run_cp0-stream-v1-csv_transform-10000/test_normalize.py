#!/usr/bin/env python3
from crm_clean import normalize_table

# Test 1: Basic functionality with duplicates
test1 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,test@example.com,Jane"
result1 = normalize_table(test1)
print("Test 1 (duplicates):")
print(result1)
print()

# Test 2: Single row
test2 = "score,id,email,name\n1,abc,test@example.com,John"
result2 = normalize_table(test2)
print("Test 2 (single row):")
print(result2)
print()

# Test 3: Empty string
test3 = ""
result3 = normalize_table(test3)
print("Test 3 (empty):")
print(repr(result3))
print()

# Test 4: Header only
test4 = "score,id,email,name"
result4 = normalize_table(test4)
print("Test 4 (header only):")
print(result4)
print()

# Test 5: Whitespace handling
test5 = " score , id , email , name \n 1 , abc , TEST@EXAMPLE.COM , JOHN "
result5 = normalize_table(test5)
print("Test 5 (whitespace):")
print(result5)
print()

# Test 6: Multiple duplicates and sorting
test6 = "score,id,email,name\n1,abc,test@example.com,John\n2,def,TEST@EXAMPLE.COM,Jane\n3,ghi,JOHN@EXAMPLE.COM,Bob"
result6 = normalize_table(test6)
print("Test 6 (sorting):")
print(result6)
