def merge_slots(intervals):
    # Check for invalid intervals where start > end
    for start, end in intervals:
        if start > end:
            raise ValueError("Interval start > end")
    
    # Sort intervals by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start < last_end:  # Overlapping (touching intervals are NOT merged)
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])
    
    return merged
