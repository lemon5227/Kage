def count_entries(lines):
    level_counts = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service: message
        if len(parts) < 3:
            continue
        
        # Extract the level (second part)
        level = parts[1]
        
        # Convert to uppercase for case-insensitive comparison
        level_upper = level.upper()
        
        # Increment count for this level
        level_counts[level_upper] = level_counts.get(level_upper, 0) + 1
    
    # Return only levels with non-zero counts (already handled by dict)
    return level_counts
