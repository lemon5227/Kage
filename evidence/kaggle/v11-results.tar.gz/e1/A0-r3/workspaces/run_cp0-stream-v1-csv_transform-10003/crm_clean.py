import csv
import io


def tidy_csv(text):
    """Clean an exported CSV table.
    
    Input: CSV text with header row (columns: name, city, score, team)
    Output: Cleaned CSV text with the same header
    
    Steps:
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "name" cell is empty
    - Remove duplicate rows by "name", keeping the first occurrence
    - Sort rows by "city" ascending as strings (stable)
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV text into a list of lists
    lines = text.strip().split('\n')
    
    # Check if header-only input
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    # Expected columns: name, city, score, team
    if len(header) != 4:
        raise ValueError("Expected 4 columns: name, city, score, team")
    
    # Parse data rows
    data_rows = []
    for line in lines[1:]:
        cells = line.split(',')
        if len(cells) != 4:
            continue  # Skip malformed rows
        
        name = cells[0].strip()
        city = cells[1].strip()
        score = cells[2].strip()
        team = cells[3].strip()
        
        # Drop rows where "name" is empty
        if not name:
            continue
        
        data_rows.append({
            'name': name,
            'city': city,
            'score': score,
            'team': team
        })
    
    # Remove duplicate rows by "name", keeping first occurrence
    seen_names = set()
    unique_rows = []
    for row in data_rows:
        if row['name'] not in seen_names:
            seen_names.add(row['name'])
            unique_rows.append(row)
    
    # Sort rows by "city" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x['city'])
    
    # Write output using csv module with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for row in unique_rows:
        writer.writerow([row['name'], row['city'], row['score'], row['team']])
    
    return output.getvalue()
