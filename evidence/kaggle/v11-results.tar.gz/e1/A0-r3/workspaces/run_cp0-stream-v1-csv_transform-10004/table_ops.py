import csv
import io


def clean_rows(text):
    """Clean an exported table CSV text.
    
    Input: CSV text with header row (columns: id, team, score)
    Output: Cleaned CSV text with the same header
    
    Processing steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Remove duplicate rows by "team", keeping the first occurrence
    4. Sort rows by "score" ascending as strings (stable)
    
    Returns empty string for empty input, header-only input returns just the header line.
    """
    # Parse CSV text
    lines = text.strip().split('\n')
    
    if not lines:
        return ''
    
    # Check if header-only input
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    if len(header) != 3 or header[0] != 'id' or header[1] != 'team' or header[2] != 'score':
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) != 3:
            continue
        
        id_val, team_val, score_val = cells
        
        # Strip whitespace from every cell
        id_val = id_val.strip()
        team_val = team_val.strip()
        score_val = score_val.strip()
        
        # Drop rows whose "score" cell is empty
        if not score_val:
            continue
        
        rows.append((id_val, team_val, score_val))
    
    # Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    unique_rows = []
    for row in rows:
        team = row[1]
        if team not in seen_teams:
            seen_teams.add(team)
            unique_rows.append(row)
    
    # Sort rows by "score" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x[2])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
