def tally_events(lines):
    """Tally events for ERROR and WARN levels only, case-insensitively."""
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) < 3:
            # Malformed line (need at least timestamp, level, service)
            continue
        
        # Extract level and service
        level = parts[1].upper()
        service = parts[2]
        
        # Check if it's ERROR or WARN
        if level in ('ERROR', 'WARN'):
            counts[service] = counts.get(service, 0) + 1
    
    return counts
