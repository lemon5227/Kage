def select(instruction, skills):
    """Show skills whose verified instructions are close to this task.

    Lowered threshold from 0.3 to 0.1: the failing log_aggregation task had a
    top similarity of ~0.15 and received no skill, so the student fell back to
    a wrong ad-hoc implementation. A 0.1 cutoff surfaces such borderline-but-
    relevant procedural skills while still excluding clearly unrelated ones
    (read_preserve=0.01, inspect_question=0.04).
    """
    ranked = sorted(skills, key=lambda s: (-s["similarity"], s["skill_id"]))
    return [s["skill_id"] for s in ranked if s["similarity"] >= 0.1][:3]
