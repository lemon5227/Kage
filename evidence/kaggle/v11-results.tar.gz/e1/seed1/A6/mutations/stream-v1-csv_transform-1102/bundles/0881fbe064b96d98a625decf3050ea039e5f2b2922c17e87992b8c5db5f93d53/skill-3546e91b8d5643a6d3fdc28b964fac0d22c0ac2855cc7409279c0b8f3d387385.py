def run(arguments, context):
    import os
    target = arguments['target_file']
    fname = arguments['function_name']
    err = arguments.get('error_type', 'ValueError')
    touching = bool(arguments.get('merge_touching', False))
    order = arguments.get('sort_key', 'start')
    reverse = order == 'start_desc'
    lines = []
    lines.append('def %s(intervals):' % fname)
    lines.append('    normalized = []')
    lines.append('    for interval in intervals:')
    lines.append('        start, end = interval[0], interval[1]')
    lines.append('        if start > end:')
    lines.append('            raise %s("invalid interval: start %%r > end %%r" %% (start, end))' % err)
    lines.append('        normalized.append([start, end])')
    lines.append('    normalized.sort(key=lambda pair: (pair[0], pair[1]), reverse=%r)' % reverse)
    lines.append('    merged = []')
    lines.append('    for start, end in normalized:')
    if touching:
        lines.append('        if merged and start <= merged[-1][1]:')
    else:
        lines.append('        if merged and start < merged[-1][1]:')
    lines.append('            if end > merged[-1][1]:')
    lines.append('                merged[-1][1] = end')
    lines.append('        else:')
    lines.append('            merged.append([start, end])')
    lines.append('    return merged')
    content = '\n'.join(lines) + '\n'
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w') as f:
        f.write(content)
    return {'success': True, 'path': target, 'bytes_written': len(content)}
