import csv, io

def run(arguments, context):
    tf = arguments['target_file']
    fn = arguments['function_name']
    fc = arguments.get('filter_column')
    dc = arguments.get('dedup_column')
    sc = arguments.get('sort_column')
    strip = arguments.get('strip_cells', True)
    drop = arguments.get('drop_empty_filter', True)
    dedup = arguments.get('dedup', True)
    asc = arguments.get('sort_ascending', True)
    le = arguments.get('line_ending', '\n')
    src = (
        'import csv\nimport io\n\n'
        'def ' + fn + '(text):\n'
        '    if text == "":\n        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n        return ""\n'
        '    header = [c.strip() for c in rows[0]] if ' + repr(strip) + ' else list(rows[0])\n'
        '    idx = {name: i for i, name in enumerate(header)}\n'
        '    data = []\n'
        '    for row in rows[1:]:\n'
        '        cells = [c.strip() for c in row] if ' + repr(strip) + ' else list(row)\n'
        '        data.append(cells)\n'
        '    fc = ' + repr(fc) + '\n'
        '    dc = ' + repr(dc) + '\n'
        '    sc = ' + repr(sc) + '\n'
        '    if ' + repr(drop) + ' and fc in idx:\n'
        '        i = idx[fc]\n'
        '        data = [r for r in data if i < len(r) and r[i] != ""]\n'
        '    if ' + repr(dedup) + ' and dc in idx:\n'
        '        i = idx[dc]\n'
        '        seen = set()\n        out = []\n'
        '        for r in data:\n'
        '            k = r[i] if i < len(r) else ""\n'
        '            if k in seen:\n                continue\n'
        '            seen.add(k)\n            out.append(r)\n'
        '        data = out\n'
        '    if ' + repr(asc) + ' and sc in idx:\n'
        '        i = idx[sc]\n'
        '        data.sort(key=lambda r: r[i] if i < len(r) else "")\n'
        '    buf = io.StringIO()\n'
        '    w = csv.writer(buf, lineterminator=' + repr(le) + ')\n'
        '    w.writerow(header)\n'
        '    for r in data:\n        w.writerow(r)\n'
        '    return buf.getvalue()\n'
    )
    path = context['workspace_dir'].rstrip('/') + '/' + tf
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': tf, 'bytes_written': len(src)}
