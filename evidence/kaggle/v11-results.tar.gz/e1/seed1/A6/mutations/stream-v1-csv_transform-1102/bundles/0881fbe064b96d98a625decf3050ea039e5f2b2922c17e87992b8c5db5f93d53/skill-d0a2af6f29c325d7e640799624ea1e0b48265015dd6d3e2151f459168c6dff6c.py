import csv, io

def run(arguments, context):
    tf = arguments['target_file']
    fn = arguments['function_name']
    fc = arguments.get('filter_column', '')
    de = arguments.get('drop_empty_filter', False)
    lc = arguments.get('lower_column', '')
    lo = arguments.get('lower_cells', False)
    dc = arguments.get('dedup_column', '')
    dd = arguments.get('dedup', False)
    sc = arguments.get('sort_column', '')
    sa = arguments.get('sort_ascending', False)
    st = arguments.get('strip_cells', True)
    le = arguments.get('line_ending', '\n')
    src = '''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]] if {st} else list(rows[0])
    data = rows[1:]
    cleaned = []
    for row in data:
        cleaned.append([c.strip() for c in row] if {st} else list(row))
    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None
    if {de}:
        i = idx({fc!r})
        if i is not None:
            cleaned = [r for r in cleaned if i < len(r) and r[i] != ""]
    if {lo}:
        i = idx({lc!r})
        if i is not None:
            for r in cleaned:
                if i < len(r):
                    r[i] = r[i].lower()
    if {dd}:
        i = idx({dc!r})
        if i is not None:
            seen = set()
            out = []
            for r in cleaned:
                k = r[i] if i < len(r) else ""
                if k in seen:
                    continue
                seen.add(k)
                out.append(r)
            cleaned = out
    if {sa}:
        i = idx({sc!r})
        if i is not None:
            cleaned.sort(key=lambda r: r[i] if i < len(r) else "")
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator={le!r})
    w.writerow(header)
    w.writerows(cleaned)
    return buf.getvalue()
'''.format(fn=fn, st=st, de=de, fc=fc, lo=lo, lc=lc, dd=dd, dc=dc, sa=sa, sc=sc, le=le)
    path = context['workspace_dir'].rstrip('/') + '/' + tf
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': tf, 'bytes_written': len(src)}