def run(arguments, context):
    import os
    tf = arguments['target_file']
    fn = arguments['function_name']
    idf = arguments.get('id_field', 'id')
    wf = arguments.get('weight_field', 'weight')
    vf = arguments.get('value_field', 'value')
    cp = arguments.get('capacity_param', 'capacity')
    ip = arguments.get('items_param', 'items')
    src = (
        'def ' + fn + '(' + ip + ', ' + cp + '):\n'
        '    if ' + cp + ' < 0:\n'
        '        raise ValueError("' + cp + ' must be non-negative")\n'
        '    entries = []\n'
        '    for item in ' + ip + ':\n'
        '        w = item["' + wf + '"]\n'
        '        v = item["' + vf + '"]\n'
        '        if w <= 0:\n'
        '            raise ValueError("' + wf + ' must be positive")\n'
        '        entries.append((item["' + idf + '"], w, v))\n'
        '    best = [(0, []) for _ in range(' + cp + ' + 1)]\n'
        '    for iid, w, v in entries:\n'
        '        for c in range(' + cp + ', w - 1, -1):\n'
        '            pv, pi = best[c - w]\n'
        '            cv = pv + v\n'
        '            ci = sorted(pi + [iid])\n'
        '            ov, oi = best[c]\n'
        '            if cv > ov or (cv == ov and ci < oi):\n'
        '                best[c] = (cv, ci)\n'
        '    return best[' + cp + '][1]\n'
    )
    path = os.path.join(context['workspace_dir'], tf)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': tf, 'bytes_written': len(src)}
