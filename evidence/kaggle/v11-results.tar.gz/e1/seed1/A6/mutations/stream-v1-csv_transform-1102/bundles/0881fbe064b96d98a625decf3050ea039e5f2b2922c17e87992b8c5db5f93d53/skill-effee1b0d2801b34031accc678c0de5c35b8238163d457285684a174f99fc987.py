import json

def run(arguments, context):
    target_file = arguments['target_file']
    function_name = arguments['function_name']
    key_column = arguments['key_column']
    drop_empty_key = arguments.get('drop_empty_key', True)
    dedup_by_key = arguments.get('dedup_by_key', True)
    sort_by_key = arguments.get('sort_by_key', True)
    strip_cells = arguments.get('strip_cells', True)
    line_ending = arguments.get('line_ending', '\n')

    code = f'''import csv
import io


def {function_name}(text):
    if text == "":
        return ""
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]] if {strip_cells!r} else list(rows[0])
    data = rows[1:]
    cleaned = []
    for row in data:
        cells = [c.strip() for c in row] if {strip_cells!r} else list(row)
        cleaned.append(cells)
    try:
        key_idx = header.index({key_column!r})
    except ValueError:
        key_idx = None
    def key_of(cells):
        if key_idx is None or key_idx >= len(cells):
            return ""
        return cells[key_idx]
    if {drop_empty_key!r}:
        cleaned = [c for c in cleaned if key_of(c) != ""]
    if {dedup_by_key!r}:
        seen = set()
        deduped = []
        for c in cleaned:
            k = key_of(c)
            if k in seen:
                continue
            seen.add(k)
            deduped.append(c)
        cleaned = deduped
    if {sort_by_key!r}:
        cleaned.sort(key=key_of)
    out = io.StringIO()
    writer = csv.writer(out, lineterminator={line_ending!r})
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
'''

    import os
    path = os.path.join(context['workspace_dir'], target_file)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(code)
    return {'success': True, 'path': target_file, 'bytes_written': len(code.encode('utf-8'))}
