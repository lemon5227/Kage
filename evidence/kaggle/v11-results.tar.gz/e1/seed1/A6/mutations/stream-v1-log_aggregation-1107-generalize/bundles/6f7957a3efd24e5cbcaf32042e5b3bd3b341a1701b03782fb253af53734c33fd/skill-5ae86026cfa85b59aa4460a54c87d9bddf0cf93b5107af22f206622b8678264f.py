import re

LINE_RE = re.compile(r"^\S+\s+(\S+)\s+(\S+):\s+.*$")


def run(arguments, context):
    target_file = arguments["target_file"]
    function_name = arguments["function_name"]
    group_field = arguments["group_field"]
    level_filter = arguments.get("level_filter", "")
    lines_param = arguments.get("lines_param", "lines")
    idx = 1 if group_field == "level" else 2
    src = (
        "import re\n\n"
        "LINE_RE = re.compile(r\"^\\\\S+\\\\s+(\\\\S+)\\\\s+(\\\\S+):\\\\s+.*$\")\n\n\n"
        "def {fn}({lp}):\n"
        "    counts = {{}}\n"
        "    for line in {lp}:\n"
        "        m = LINE_RE.match(line.strip())\n"
        "        if not m:\n"
        "            continue\n"
        "        level = m.group(1).upper()\n"
        "        service = m.group(2)\n"
        "        if {lf!r} and level != {lf!r}:\n"
        "            continue\n"
        "        key = level if {idx} == 1 else service\n"
        "        counts[key] = counts.get(key, 0) + 1\n"
        "    return counts\n"
    ).format(fn=function_name, lp=lines_param, lf=level_filter, idx=idx)
    path = context["workspace_dir"] + "/" + target_file
    with open(path, "w") as f:
        f.write(src)
    return {"success": True, "path": target_file, "bytes_written": len(src)}
