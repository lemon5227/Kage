import json, os

def run(arguments, context):
    ws = context.get('workspace_dir', '.')
    target = arguments['target_file']
    fn = arguments['function_name']
    strip = arguments.get('strip_cells', True)
    drop = arguments.get('drop_empty_filter', False)
    fcol = arguments.get('filter_column', '')
    lower = arguments.get('lower_cells', False)
    lcol = arguments.get('lower_column', '')
    dedup = arguments.get('dedup', False)
    dcol = arguments.get('dedup_column', '')
    sort = arguments.get('sort_ascending', False)
    scol = arguments.get('sort_column', '')
    le = arguments.get('line_ending', '\n')
    cfg = {'strip': strip, 'drop': drop, 'fcol': fcol, 'lower': lower, 'lcol': lcol,
           'dedup': dedup, 'dcol': dcol, 'sort': sort, 'scol': scol, 'le': le}
    code = (
        'import csv\nimport io\n\n'
        'CFG = ' + json.dumps(cfg) + '\n\n\n'
        'def ' + fn + '(text):\n'
        '    if text == "":\n'
        '        return ""\n'
        '    rows = list(csv.reader(io.StringIO(text)))\n'
        '    if not rows:\n'
        '        return ""\n'
        '    header = [c.strip() for c in rows[0]] if CFG["strip"] else list(rows[0])\n'
        '    n = len(header)\n'
        '    data = []\n'
        '    for row in rows[1:]:\n'
        '        cells = [c.strip() for c in row] if CFG["strip"] else list(row)\n'
        '        if len(cells) < n:\n'
        '            cells += [""] * (n - len(cells))\n'
        '        elif len(cells) > n:\n'
        '            cells = cells[:n]\n'
        '        data.append(cells)\n'
        '    def idx(name):\n'
        '        return header.index(name) if name in header else -1\n'
        '    if CFG["drop"]:\n'
        '        i = idx(CFG["fcol"])\n'
        '        if i >= 0:\n'
        '            data = [r for r in data if r[i] != ""]\n'
        '    if CFG["lower"]:\n'
        '        i = idx(CFG["lcol"])\n'
        '        if i >= 0:\n'
        '            for r in data:\n'
        '                r[i] = r[i].lower()\n'
        '    if CFG["dedup"]:\n'
        '        i = idx(CFG["dcol"])\n'
        '        if i >= 0:\n'
        '            seen = set()\n'
        '            out = []\n'
        '            for r in data:\n'
        '                if r[i] in seen:\n'
        '                    continue\n'
        '                seen.add(r[i])\n'
        '                out.append(r)\n'
        '            data = out\n'
        '    if CFG["sort"]:\n'
        '        i = idx(CFG["scol"])\n'
        '        if i >= 0:\n'
        '            data.sort(key=lambda r: r[i])\n'
        '    buf = io.StringIO()\n'
        '    w = csv.writer(buf, lineterminator=CFG["le"])\n'
        '    w.writerow(header)\n'
        '    w.writerows(data)\n'
        '    return buf.getvalue()\n'
    )
    path = os.path.join(ws, target)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(code)
    return {'success': True, 'path': target, 'bytes_written': len(code)}
