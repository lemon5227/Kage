def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    levels = [str(l).upper() for l in arguments.get('levels', ['ERROR', 'WARN'])]
    group_by = arguments.get('group_by', 'service')
    upper_keys = bool(arguments.get('uppercase_keys', group_by == 'level'))
    require_colon = bool(arguments.get('require_colon', True))
    src = (
        'def ' + fn + '(lines):\n'
        '    levels = ' + repr(levels) + '\n'
        '    group_by = ' + repr(group_by) + '\n'
        '    upper_keys = ' + repr(upper_keys) + '\n'
        '    require_colon = ' + repr(require_colon) + '\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < 3:\n'
        '            continue\n'
        '        level = parts[1].upper()\n'
        '        if level not in levels:\n'
        '            continue\n'
        '        if group_by == "level":\n'
        '            key = level\n'
        '        else:\n'
        '            token = parts[2]\n'
        '            if require_colon:\n'
        '                if not token.endswith(":"):\n'
        '                    continue\n'
        '                token = token[:-1]\n'
        '            if not token:\n'
        '                continue\n'
        '            key = token\n'
        '        if upper_keys:\n'
        '            key = key.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src.encode('utf-8'))}
