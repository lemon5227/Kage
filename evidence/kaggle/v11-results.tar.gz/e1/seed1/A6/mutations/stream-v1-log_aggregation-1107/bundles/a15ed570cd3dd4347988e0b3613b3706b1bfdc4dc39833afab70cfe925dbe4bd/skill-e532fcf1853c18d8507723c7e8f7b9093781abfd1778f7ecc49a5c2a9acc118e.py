import json, os, re


def run(arguments, context):
    target = arguments['target_file']
    fname = arguments['function_name']
    lines_param = arguments.get('lines_param', 'lines')
    pattern = arguments.get('line_pattern', r'^\S+\s+([A-Za-z]+)\s+\S+:\s+.*$')
    group = int(arguments.get('level_group', 1))
    upper = bool(arguments.get('uppercase_level', True))
    src = (
        'import re\n\n'
        'LINE_RE = re.compile(' + repr(pattern) + ')\n\n\n'
        'def ' + fname + '(' + lines_param + '):\n'
        '    counts = {}\n'
        '    for line in ' + lines_param + ':\n'
        '        m = LINE_RE.match(line.strip())\n'
        '        if not m:\n'
        '            continue\n'
        '        level = m.group(' + str(group) + ')\n'
        + ('        level = level.upper()\n' if upper else '')
        + '        counts[level] = counts.get(level, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src.encode('utf-8'))}
