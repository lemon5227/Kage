def run(arguments, context):
    import os
    target = arguments['target_file']
    fn = arguments['function_name']
    lines_param = arguments.get('lines_param', 'lines')
    level_index = arguments.get('level_index', 1)
    min_tokens = arguments.get('min_tokens', 3)
    upper = arguments.get('uppercase_level', True)
    src = (
        'def ' + fn + '(' + lines_param + '):\n'
        '    counts = {}\n'
        '    for line in ' + lines_param + ':\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < ' + str(min_tokens) + ':\n'
        '            continue\n'
        '        level = parts[' + str(level_index) + ']\n'
        + ('        level = level.upper()\n' if upper else '')
        + '        counts[level] = counts.get(level, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], target)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': target, 'bytes_written': len(src)}
