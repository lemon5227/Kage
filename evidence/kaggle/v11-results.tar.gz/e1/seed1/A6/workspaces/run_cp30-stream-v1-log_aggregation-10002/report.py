def digest_lines(lines):
    """Summarize log lines into {level: {name: count}}.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Level names are matched case-insensitively and stored with uppercase keys.
    Malformed lines are dropped.
    """
    result = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service = parts[2]
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service:
            continue
        if level not in result:
            result[level] = {}
        result[level][service] = result[level].get(service, 0) + 1
    return result
