def tally_events(lines):
    counts = {}
    for line in lines:
        # Parse format: <timestamp> <LEVEL> <service>: <message>
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed line
        
        # Check if third part contains colon (service:)
        if parts[2].endswith(':'):
            level = parts[1]
            # Case-insensitive, store as uppercase
            level_upper = level.upper()
            counts[level_upper] = counts.get(level_upper, 0) + 1
        else:
            continue  # malformed line (no service colon)
    
    return counts
