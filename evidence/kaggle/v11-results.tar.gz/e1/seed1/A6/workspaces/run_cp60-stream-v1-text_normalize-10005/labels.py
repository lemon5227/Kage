import unicodedata
import re

def to_key(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = re.sub(r'[^a-z0-9]+', '_', lower)
    
    # Strip leading and trailing "_"
    result = result.strip('_')
    
    return result
