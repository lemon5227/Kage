def digest_lines(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN", "INFO", "DEBUG"):
            continue
        service = parts[2]
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service:
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
