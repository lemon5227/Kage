import unicodedata

def make_handle(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for char in lower:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                # Start of a run of non-alphanumerics, add hyphen
                result.append('-')
            else:
                # Continue the run, skip this character
                continue
        else:
            # Alphanumeric character, add it
            result.append(char)
        prev_char = char
    
    # Join and strip leading/trailing hyphens
    handle = ''.join(result).strip('-')
    
    # If result is longer than 23 characters, cut to 23 and then strip trailing "-"
    if len(handle) > 23:
        handle = handle[:23].strip('-')
    
    return handle
