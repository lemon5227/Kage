def coalesce(intervals):
    """Merge overlapping intervals given as dicts with 'start' and 'end' keys.

    Each interval is a dict {"start": s, "end": e} where s and e are integers.
    Returns merged intervals as dicts with the same keys, sorted by start ascending.
    Touching intervals (e.g. {"start": 1, "end": 3} and {"start": 3, "end": 5})
    are merged into a single interval.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                f"invalid interval: start {start} > end {end}"
            )
        normalized.append({"start": start, "end": end})

    # Sort by start ascending (then by end for stability)
    normalized.sort(key=lambda pair: (pair["start"], pair["end"]))

    # Merge overlapping intervals
    merged = []
    for interval in normalized:
        start = interval["start"]
        end = interval["end"]
        if merged and start <= merged[-1]["end"]:
            # Overlapping or touching: extend the current interval
            if end > merged[-1]["end"]:
                merged[-1]["end"] = end
        else:
            merged.append({"start": start, "end": end})

    return merged
