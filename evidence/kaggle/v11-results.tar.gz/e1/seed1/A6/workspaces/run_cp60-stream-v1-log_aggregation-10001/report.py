def tally_events(lines):
    """
    Tally events from log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    Returns {name: count} per service for levels ERROR, WARN only, treating level names case-insensitively.
    Drops malformed input lines.
    """
    counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split by spaces to get parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Check if service contains a colon (service: message)
        # The format is "<timestamp> <LEVEL> <service>: <message>"
        # So service should be the third token, and we need to check if there's a colon after it
        # Actually, the format suggests service is followed by a colon
        # Let's check if parts[2] ends with ':' or if there's a colon in the line
        
        # More robust: find the first colon to separate service from message
        colon_index = line.find(':')
        if colon_index == -1:
            # No colon found, malformed
            continue
        
        # Extract service (everything before the colon)
        service = line[:colon_index].strip()
        
        # Check if service is empty
        if not service:
            continue
        
        # Check if level is ERROR or WARN (case-insensitive, already upper-cased)
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Increment count for this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
