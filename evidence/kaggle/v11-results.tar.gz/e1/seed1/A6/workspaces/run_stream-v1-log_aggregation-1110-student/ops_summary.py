def tally_events(lines):
    """Count log lines per level from a list of log lines.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    - Level case may vary and must be upper-cased
    - Ignore lines that do not match the format
    
    Returns: plain dict of counts
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service:
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1]
        
        # Check if it's a valid log level
        valid_levels = {'DEBUG', 'INFO', 'WARN', 'WARNING', 'ERROR', 'FATAL', 'TRACE'}
        level_upper = level.upper()
        
        # Only count lines with valid log levels
        if level_upper not in valid_levels:
            continue
        
        # Increment count for this level
        counts[level_upper] = counts.get(level_upper, 0) + 1
    
    return counts
