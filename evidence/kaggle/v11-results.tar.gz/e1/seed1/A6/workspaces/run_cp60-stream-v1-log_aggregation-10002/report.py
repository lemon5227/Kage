def digest_lines(lines):
    """
    Parse log strings formatted as "<timestamp> <LEVEL> <service>: <message>".
    Returns {name: count} per level, treating level names case-insensitively (upper-case keys),
    dropping malformed input lines.
    """
    counts = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split into parts: timestamp, level, service: message
        parts = line.split(' ', 2)
        if len(parts) < 3:
            # Malformed line (not enough parts)
            continue
        
        timestamp, level, rest = parts
        # Check if the third part starts with ':'
        if not rest.startswith(':'):
            # Malformed line (service: message format incorrect)
            continue
        
        # Extract service name from "service: message"
        service_part = rest.split(':', 1)[0]
        if not service_part.strip():
            # Malformed line (empty service name)
            continue
        
        service_name = service_part.strip()
        
        # Get level, convert to uppercase for case-insensitive handling
        level_upper = level.strip().upper()
        
        # Increment count for this level
        counts[level_upper] = counts.get(level_upper, 0) + 1
    
    return counts
