import csv
import io

def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]] if True else list(rows[0])
    idx = {name: i for i, name in enumerate(header)}
    data = []
    for row in rows[1:]:
        cells = [c.strip() for c in row] if True else list(row)
        data.append(cells)
    fc = 'team'
    dc = 'team'
    sc = 'email'
    if True and fc in idx:
        i = idx[fc]
        data = [r for r in data if i < len(r) and r[i] != ""]
    if True and dc in idx:
        i = idx[dc]
        seen = set()
        out = []
        for r in data:
            k = r[i] if i < len(r) else ""
            if k in seen:
                continue
            seen.add(k)
            out.append(r)
        data = out
    if True and sc in idx:
        i = idx[sc]
        data.sort(key=lambda r: r[i] if i < len(r) else "")
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\n')
    w.writerow(header)
    for r in data:
        w.writerow(r)
    return buf.getvalue()
