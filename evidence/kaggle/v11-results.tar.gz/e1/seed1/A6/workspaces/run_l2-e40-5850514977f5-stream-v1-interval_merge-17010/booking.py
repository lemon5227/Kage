def merge_bookings(intervals):
    """Merge overlapping bookings.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        normalized.append(interval)

    # Sort by start, then by end
    normalized.sort(key=lambda pair: (pair["start"], pair["end"]))

    merged = []
    for interval in normalized:
        start = interval["start"]
        end = interval["end"]
        if merged and start < merged[-1]["end"]:
            # Real overlap: extend the current interval if needed.
            if end > merged[-1]["end"]:
                merged[-1]["end"] = end
        else:
            merged.append(interval.copy())

    return merged
