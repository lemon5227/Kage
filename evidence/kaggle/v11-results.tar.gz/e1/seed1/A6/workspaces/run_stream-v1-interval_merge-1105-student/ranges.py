def combine_ranges(intervals):
    """Merge overlapping intervals given as dicts with 'begin' and 'finish' keys.

    Each interval is a dict {"begin": s, "finish": e} where s and e are integers.
    Returns merged intervals as dicts with the same keys, sorted by begin ascending.
    Touching intervals (e.g. [1,3] and [3,5]) are merged.
    Raises ValueError if any interval has begin > finish.
    The input is not modified.
    """
    # Validate and convert to list of tuples
    normalized = []
    for interval in intervals:
        begin = interval["begin"]
        finish = interval["finish"]
        if begin > finish:
            raise ValueError(
                "invalid interval: begin %r > finish %r" % (begin, finish)
            )
        normalized.append((begin, finish))

    # Sort by begin, then by finish
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    # Merge overlapping intervals (including touching)
    merged = []
    for begin, finish in normalized:
        if merged and begin <= merged[-1][1]:
            # Overlap or touching: extend the current interval if needed
            if finish > merged[-1][1]:
                merged[-1] = (merged[-1][0], finish)
        else:
            merged.append((begin, finish))

    # Convert back to dicts with original keys
    result = []
    for begin, finish in merged:
        result.append({"begin": begin, "finish": finish})

    return result
