def coalesce(intervals):
    """Merge overlapping intervals. Each interval is a dict {"from": s, "to": e} with integer values.
    Return merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged. Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start (from)
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping or touching intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            # Check if current interval overlaps or touches the last one
            if interval["from"] <= last["to"]:
                # Merge by updating last interval's 'to' to max of both
                last["to"] = max(last["to"], interval["to"])
            else:
                merged.append(interval.copy())
    
    return merged
