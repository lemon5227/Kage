def allocate(items, capacity):
    """Choose a subset of items maximizing total score with total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of chosen ids.
    Ties on total score are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on a copy so the input is never modified.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("size must be positive")
        entries.append((item["id"], size, score))

    # 0/1 knapsack over capacity, tracking the best (score, id-list) per size.
    # best[w] = (total_score, sorted_id_list) for the best selection with
    # total size exactly <= w. We keep the lexicographically smallest id list
    # among selections with equal score.
    best = [(0, []) for _ in range(capacity + 1)]

    for item_id, size, score in entries:
        # Iterate sizes downward so each item is used at most once.
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = best[w - size]
            cand_score = prev_score + score
            cand_ids = sorted(prev_ids + [item_id])
            cur_score, cur_ids = best[w]
            if cand_score > cur_score or (cand_score == cur_score and cand_ids < cur_ids):
                best[w] = (cand_score, cand_ids)

    # best[capacity] already accounts for "at most capacity" since we never
    # require exact fill; the empty selection is represented by (0, []).
    return best[capacity][1]
