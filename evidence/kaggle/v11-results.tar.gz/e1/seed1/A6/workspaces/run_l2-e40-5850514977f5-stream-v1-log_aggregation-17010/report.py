def count_entries(lines):
    """Count log entries per level and service.
    
    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"
    
    Returns a dict mapping level (uppercase) to {service: count}.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service = parts[2]
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service:
            continue
        key = (level, service)
        counts[key] = counts.get(key, 0) + 1
    return counts
