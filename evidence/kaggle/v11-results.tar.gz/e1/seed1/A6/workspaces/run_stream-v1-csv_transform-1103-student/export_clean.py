import csv
import io

def tidy_csv(text):
    # Handle empty string
    if not text or not text.strip():
        return ''
    
    # Split into lines
    lines = text.strip().split('\n')
    
    # If only header, return it
    if len(lines) == 1:
        return lines[0]
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    header = next(reader)
    
    # Verify columns: score, id, team, name
    expected_cols = ['score', 'id', 'team', 'name']
    if len(header) != 4 or header != expected_cols:
        # If header doesn't match, still process but use index 3 for name
        pass
    
    # Process rows
    rows = []
    seen_names = set()
    
    for row in reader:
        # Strip whitespace from each cell
        row = [cell.strip() for cell in row]
        
        # Skip if name is empty
        if not row[3]:
            continue
        
        # Remove duplicates by name, keep first occurrence
        if row[3] in seen_names:
            continue
        seen_names.add(row[3])
        
        rows.append(row)
    
    # Sort by name ascending (stable sort)
    rows.sort(key=lambda r: r[3])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in rows:
        writer.writerow(row)
    
    return output.getvalue()
