def coalesce(intervals):
    """Combine overlapping time ranges.
    
    Args:
        intervals: List of two-element lists [start, end] of integers
        
    Returns:
        List of merged intervals sorted by start ascending
        
    Raises:
        ValueError: If any interval has start > end
    """
    # Validate all intervals first
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Interval [{start}, {end}] has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if not merged:
            merged.append([start, end])
        else:
            last_start, last_end = merged[-1]
            if start <= last_end:  # Overlapping (not just touching)
                # Merge by extending the end
                merged[-1][1] = max(last_end, end)
            else:
                merged.append([start, end])
    
    return merged
