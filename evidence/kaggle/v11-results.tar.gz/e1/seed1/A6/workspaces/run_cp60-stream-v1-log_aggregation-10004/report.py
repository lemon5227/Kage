import re

LINE_RE = re.compile(r"^\S+\s+([A-Za-z]+)\s+\S+:\s+.*$")


def digest_lines(lines):
    counts = {}
    for line in lines:
        match = LINE_RE.match(line.strip())
        if not match:
            continue
        level = match.group(1).upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
