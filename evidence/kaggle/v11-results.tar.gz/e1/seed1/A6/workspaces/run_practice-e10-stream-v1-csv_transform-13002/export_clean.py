import csv
import io


def clean_rows(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]] if True else list(rows[0])
    data = rows[1:]
    cleaned = []
    for row in data:
        cleaned.append([c.strip() for c in row] if True else list(row))
    def idx(name):
        try:
            return header.index(name)
        except ValueError:
            return None
    if True:
        i = idx('email')
        if i is not None:
            cleaned = [r for r in cleaned if i < len(r) and r[i] != ""]
    if True:
        i = idx('email')
        if i is not None:
            for r in cleaned:
                if i < len(r):
                    r[i] = r[i].lower()
    if True:
        i = idx('score')
        if i is not None:
            seen = set()
            out = []
            for r in cleaned:
                k = r[i] if i < len(r) else ""
                if k in seen:
                    continue
                seen.add(k)
                out.append(r)
            cleaned = out
    if True:
        i = idx('team')
        if i is not None:
            cleaned.sort(key=lambda r: r[i] if i < len(r) else "")
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\n')
    w.writerow(header)
    w.writerows(cleaned)
    return buf.getvalue()
