def allocate(items, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    entries = []
    for item in items:
        w = item["size"]
        v = item["score"]
        if w <= 0:
            raise ValueError("size must be positive")
        entries.append((item["id"], w, v))
    best = [(0, []) for _ in range(capacity + 1)]
    for iid, w, v in entries:
        for c in range(capacity, w - 1, -1):
            pv, pi = best[c - w]
            cv = pv + v
            ci = sorted(pi + [iid])
            ov, oi = best[c]
            if cv > ov or (cv == ov and ci < oi):
                best[c] = (cv, ci)
    return best[capacity][1]
