import re

LINE_RE = re.compile(r"^\\S+\\s+(\\S+)\\s+(\\S+):\\s+.*$")


def summarize(lines):
    counts = {}
    for line in lines:
        m = LINE_RE.match(line.strip())
        if not m:
            continue
        level = m.group(1).upper()
        service = m.group(2)
        if '' and level != '':
            continue
        key = level if 1 == 1 else service
        counts[key] = counts.get(key, 0) + 1
    return counts
