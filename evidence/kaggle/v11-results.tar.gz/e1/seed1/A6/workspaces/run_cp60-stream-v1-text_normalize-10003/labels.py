import unicodedata

def make_handle(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace any sequence of non-alphanumeric characters with a single hyphen
    slug = []
    prev_char = None
    for char in lowercased:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            slug.append(char)
        else:
            if prev_char is not None:  # Only add hyphen if we've already added something
                slug.append('-')
            prev_char = char
    
    # Join and strip leading/trailing hyphens
    result = ''.join(slug).strip('-')
    
    return result
