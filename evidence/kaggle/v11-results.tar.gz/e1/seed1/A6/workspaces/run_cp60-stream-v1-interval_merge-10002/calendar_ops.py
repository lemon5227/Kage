def coalesce(intervals):
    """Combine overlapping time ranges.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals (e.g. {"start": 1, "end": 3} and {"start": 3, "end": 5}) are merged.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and normalize intervals
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        normalized.append({"start": start, "end": end})

    # Sort by start ascending, then by end ascending for stability
    normalized.sort(key=lambda pair: (pair["start"], pair["end"]))

    merged = []
    for interval in normalized:
        start = interval["start"]
        end = interval["end"]
        if merged and start <= merged[-1]["end"]:
            # Overlapping or touching intervals: extend the current interval if needed.
            if end > merged[-1]["end"]:
                merged[-1]["end"] = end
        else:
            merged.append({"start": start, "end": end})

    return merged
