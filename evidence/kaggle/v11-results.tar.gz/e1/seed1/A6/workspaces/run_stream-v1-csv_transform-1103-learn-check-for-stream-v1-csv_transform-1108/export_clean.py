import csv
import io


def tidy_csv(text):
    if text == "":
        return ""
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]] if True else list(rows[0])
    data = rows[1:]
    cleaned = []
    for row in data:
        cells = [c.strip() for c in row] if True else list(row)
        cleaned.append(cells)
    try:
        key_idx = header.index('name')
    except ValueError:
        key_idx = None
    def key_of(cells):
        if key_idx is None or key_idx >= len(cells):
            return ""
        return cells[key_idx]
    if True:
        cleaned = [c for c in cleaned if key_of(c) != ""]
    if True:
        seen = set()
        deduped = []
        for c in cleaned:
            k = key_of(c)
            if k in seen:
                continue
            seen.add(k)
            deduped.append(c)
        cleaned = deduped
    if True:
        cleaned.sort(key=key_of)
    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
