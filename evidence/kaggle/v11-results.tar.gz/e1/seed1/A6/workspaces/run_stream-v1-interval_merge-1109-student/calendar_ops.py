def coalesce(intervals):
    """Merge overlapping intervals. Each interval is a dict {"from": s, "to": e} with integer values.
    Return merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raise ValueError if any interval has start > end. Do not modify the input."""
    
    # Validate all intervals first
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval.copy())
        else:
            last = merged[-1]
            # Check for real overlap: start < last_end (not <=, so touching doesn't merge)
            if interval["from"] < last["to"]:
                # Overlap: merge by taking the max of end times
                new_end = max(last["to"], interval["to"])
                merged[-1] = {"from": last["from"], "to": new_end}
            else:
                merged.append(interval.copy())
    
    return merged
