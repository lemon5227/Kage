def merge_bookings(intervals):
    """Merge overlapping booking intervals.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Touching intervals (e.g. [1,3] and [3,5])
    are merged. Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    # Validate and convert to list of tuples
    validated = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                f"invalid interval: start {start} > end {end}"
            )
        validated.append((start, end))

    # Sort by start (then by end for stability)
    validated.sort(key=lambda pair: (pair[0], pair[1]))

    # Merge overlapping intervals
    merged = []
    for start, end in validated:
        if merged and start <= merged[-1][1]:
            # Overlap or touching: extend the current interval
            if end > merged[-1][1]:
                merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))

    # Convert back to dicts
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})

    return result
