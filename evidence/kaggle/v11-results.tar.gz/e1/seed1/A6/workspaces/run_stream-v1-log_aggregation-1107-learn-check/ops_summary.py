import re

LINE_RE = re.compile('^\\S+\\s+([A-Za-z]+)\\s+\\S+:\\s+.*$')


def count_entries(lines):
    counts = {}
    for line in lines:
        m = LINE_RE.match(line.strip())
        if not m:
            continue
        level = m.group(1)
        level = level.upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
