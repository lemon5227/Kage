def merge_slots(intervals):
    """Combine overlapping time ranges.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Touching intervals (e.g. {"start": 1, "end": 3}
    and {"start": 3, "end": 5}) are merged. Raises ValueError if any interval
    has start > end. The input is not modified.
    """
    # Validate and convert to [start, end] format
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                f"invalid interval: start {start} > end {end}"
            )
        normalized.append([start, end])

    # Sort by start (then by end for stability)
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    # Merge overlapping intervals, including touching ones
    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            # Overlap or touching: extend the current interval if needed
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    # Convert back to dict format
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})

    return result
