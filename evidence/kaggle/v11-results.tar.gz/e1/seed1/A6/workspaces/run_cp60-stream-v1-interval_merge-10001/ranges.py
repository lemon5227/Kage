def merge_slots(intervals):
    """
    Merge overlapping intervals. Each interval is a dict {"from": s, "to": e} with integer values.
    Return merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort intervals by start (from)
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    if not sorted_intervals:
        return []
    
    merged = [sorted_intervals[0].copy()]  # Start with the first interval
    
    for current in sorted_intervals[1:]:
        last = merged[-1]
        # Check if intervals overlap or touch (current["from"] <= last["to"])
        if current["from"] <= last["to"]:
            # Merge them: update the end to the maximum of the two ends
            last["to"] = max(last["to"], current["to"])
        else:
            # No overlap, add the current interval
            merged.append(current.copy())
    
    return merged
