def summarize(lines):
    """Count log lines per level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive and reported upper-case.
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if not level.isalpha():
            continue
        # The third token must be "<service>:" (service followed by a colon).
        if not parts[2].endswith(":"):
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts

def aggregate_log(lines):
    """Aggregate log lines by level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (reported upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if not level.isalpha():
            continue
        # The third token must be "<service>:" (service followed by a colon).
        if not parts[2].endswith(":"):
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
