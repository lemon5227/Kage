def summarize(lines):
    levels = ['ERROR', 'WARN']
    group_by = 'service'
    upper_keys = True
    require_colon = True
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in levels:
            continue
        if group_by == "level":
            key = level
        else:
            token = parts[2]
            if require_colon:
                if not token.endswith(":"):
                    continue
                token = token[:-1]
            if not token:
                continue
            key = token
        if upper_keys:
            key = key.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
