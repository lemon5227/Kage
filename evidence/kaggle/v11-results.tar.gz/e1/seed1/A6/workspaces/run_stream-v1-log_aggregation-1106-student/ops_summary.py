def summarize(lines):
    """Summarize log lines into {level: count} for all levels.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Level names are matched case-insensitively and reported in upper-case.
    Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        # Only count lines with a valid level (non-empty)
        if not level:
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
