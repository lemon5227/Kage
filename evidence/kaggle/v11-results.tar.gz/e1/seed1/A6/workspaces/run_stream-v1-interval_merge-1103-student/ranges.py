def combine_ranges(intervals):
    """
    Merge overlapping intervals. Each interval is a dict {"start": s, "end": e} with integer values.
    Return merged intervals as dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should not be merged; only real overlaps merge.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        if "start" not in interval or "end" not in interval:
            raise ValueError("Each interval must have 'start' and 'end' keys")
        start = interval["start"]
        end = interval["end"]
        if not isinstance(start, int) or not isinstance(end, int):
            raise ValueError("Start and end must be integers")
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort intervals by start
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    
    if not sorted_intervals:
        return []
    
    merged = [sorted_intervals[0].copy()]
    
    for current in sorted_intervals[1:]:
        prev = merged[-1]
        # Check for real overlap (not just touching)
        if current["start"] < prev["end"]:
            # Overlap exists, merge them
            prev["end"] = max(prev["end"], current["end"])
        else:
            # No overlap, add current interval
            merged.append(current.copy())
    
    return merged
