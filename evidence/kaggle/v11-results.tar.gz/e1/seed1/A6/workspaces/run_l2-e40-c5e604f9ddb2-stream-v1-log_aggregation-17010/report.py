def count_entries(lines):
    """
    Count log entries in format: "<timestamp> <LEVEL> <service>: <message>"
    Returns {level: count} per level, case-insensitive (upper-case keys),
    dropping malformed input lines.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed line
        
        # Check format: timestamp, LEVEL, service: message
        # parts[0] = timestamp
        # parts[1] = LEVEL
        # parts[2] should start with service:
        level = parts[1].upper()
        
        # Only count if level is a known log level
        if level not in ('INFO', 'WARN', 'ERROR', 'DEBUG', 'TRACE'):
            continue  # malformed or unknown level
        
        counts[level] = counts.get(level, 0) + 1
    
    return counts
