import csv
import io

CFG = {"strip": true, "drop": true, "fcol": "team", "lower": true, "lcol": "email", "dedup": true, "dcol": "team", "sort": true, "scol": "email", "le": "\n"}


def normalize_table(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]] if CFG["strip"] else list(rows[0])
    n = len(header)
    data = []
    for row in rows[1:]:
        cells = [c.strip() for c in row] if CFG["strip"] else list(row)
        if len(cells) < n:
            cells += [""] * (n - len(cells))
        elif len(cells) > n:
            cells = cells[:n]
        data.append(cells)
    def idx(name):
        return header.index(name) if name in header else -1
    if CFG["drop"]:
        i = idx(CFG["fcol"])
        if i >= 0:
            data = [r for r in data if r[i] != ""]
    if CFG["lower"]:
        i = idx(CFG["lcol"])
        if i >= 0:
            for r in data:
                r[i] = r[i].lower()
    if CFG["dedup"]:
        i = idx(CFG["dcol"])
        if i >= 0:
            seen = set()
            out = []
            for r in data:
                if r[i] in seen:
                    continue
                seen.add(r[i])
                out.append(r)
            data = out
    if CFG["sort"]:
        i = idx(CFG["scol"])
        if i >= 0:
            data.sort(key=lambda r: r[i])
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator=CFG["le"])
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
