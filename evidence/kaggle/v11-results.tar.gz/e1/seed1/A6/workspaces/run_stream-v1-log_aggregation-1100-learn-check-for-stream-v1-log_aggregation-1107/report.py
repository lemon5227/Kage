def tally_events(lines):
    """Count occurrences of WARN level per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive and reported upper-case.
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level != "WARN":
            continue
        # The third token must be "<service>:" (service followed by a colon).
        if not parts[2].endswith(":"):
            continue
        service = parts[2][:-1]  # Remove the trailing colon
        counts[service] = counts.get(service, 0) + 1
    return counts
