def tally_events(lines):
    """Count WARN level events per service.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Only WARN level (case-insensitive) is counted.
    Malformed lines are skipped.
    Returns a dict mapping service -> count, omitting zero counts.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level != "WARN":
            continue
        service = parts[2]
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
