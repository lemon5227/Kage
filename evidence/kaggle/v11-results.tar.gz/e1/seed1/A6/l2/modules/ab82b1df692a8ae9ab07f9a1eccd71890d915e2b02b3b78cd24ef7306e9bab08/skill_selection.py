def select(instruction, skills):
    """Show skills that are clearly the best match for this task.

    A skill is shown only if its similarity is above a modest floor AND it is
    not dominated by a much stronger match. This avoids distracting the
    student with weak/irrelevant skills while keeping genuinely relevant ones.
    """
    if not skills:
        return []
    ranked = sorted(skills, key=lambda s: (-s["similarity"], s["skill_id"]))
    top = ranked[0]["similarity"]
    floor = 0.3
    if top < floor:
        return []
    selected = []
    for s in ranked:
        # keep skills close to the best match (within 0.25) and above the floor
        if s["similarity"] >= floor and s["similarity"] >= top - 0.25:
            selected.append(s["skill_id"])
        if len(selected) == 3:
            break
    return selected