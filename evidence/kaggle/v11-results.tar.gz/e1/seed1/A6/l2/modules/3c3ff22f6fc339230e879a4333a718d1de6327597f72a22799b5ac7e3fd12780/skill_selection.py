def select(instruction, skills):
    """Show only skills that are near the best match for this task.

    A fixed low threshold (0.1) admits weakly-related skills that distract
    the student (e.g. knapsack_subset_selection_writer at 0.19 on an
    interval-merge task). Genuine matches score far above the rest
    (0.71-0.84), so require both a modest floor and closeness to the top
    similarity, which suppresses borderline distractors while keeping
    strong matches.
    """
    if not skills:
        return []
    ranked = sorted(skills, key=lambda s: (-s["similarity"], s["skill_id"]))
    best = ranked[0]["similarity"]
    floor = 0.30
    margin = 0.15
    return [
        s["skill_id"]
        for s in ranked
        if s["similarity"] >= floor and s["similarity"] >= best - margin
    ][:3]
