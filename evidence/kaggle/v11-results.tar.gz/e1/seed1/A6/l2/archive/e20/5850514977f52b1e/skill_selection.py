def select(instruction, skills):
    """Show a skill only if this task is close to an instruction it was verified on."""
    ranked = sorted(skills, key=lambda s: (-s["similarity"], s["skill_id"]))
    return [s["skill_id"] for s in ranked if s["similarity"] >= 0.3][:3]
