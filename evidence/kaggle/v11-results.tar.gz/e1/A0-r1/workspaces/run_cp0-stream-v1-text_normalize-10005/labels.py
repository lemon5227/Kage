import unicodedata


def to_key(text):
    """Normalize labels into identifiers."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we need to replace any sequence of non-alphanumeric characters with a single underscore
    result = []
    prev_char = None
    for char in lower:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                result.append('_')
                prev_char = None
            else:
                # Continue with the underscore
                prev_char = None
        else:
            result.append(char)
            prev_char = char
    
    # Join and strip leading/trailing underscores
    key = ''.join(result).strip('_')
    
    return key
