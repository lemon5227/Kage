#!/usr/bin/env python3
"""Test export_clean.py"""

from export_clean import normalize_table

# Test 1: Basic functionality
test_input = """name,team,city,id,score
Alice,TeamA,City1,100,95
Bob,TeamB,City2,200,95
Charlie,TeamC,City3,300,87
"""
result = normalize_table(test_input)
print("Test 1 - Basic:")
print(result)

# Test 2: Empty string
result2 = normalize_table('')
print("\nTest 2 - Empty string:")
print(repr(result2))

# Test 3: Header-only input
test3 = "name,team,city,id,score"
result3 = normalize_table(test3)
print("\nTest 3 - Header-only:")
print(result3)

# Test 4: Rows with empty name
test4 = """name,team,city,id,score
Alice,TeamA,City1,100,95

Bob,TeamB,City2,200,87
"""
result4 = normalize_table(test4)
print("\nTest 4 - Empty name row:")
print(result4)

# Test 5: Whitespace stripping
test5 = """ name , team , city , id , score 
 Alice , TeamA , City1 , 100 , 95 
"""
result5 = normalize_table(test5)
print("\nTest 5 - Whitespace stripping:")
print(result5)
