#!/usr/bin/env python3
"""Clean exported table CSV text."""

import csv
import io


def normalize_table(text):
    """Clean an exported table CSV text.
    
    Input: CSV text with header row (columns: name, team, city, id, score)
    Output: Cleaned CSV text with same header
    
    Cleaning steps:
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "name" cell is empty
    - Remove duplicate rows by "score", keeping the first occurrence
    - Sort rows by "id" ascending as strings (stable)
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ''
    
    # Validate header columns
    expected_cols = ['name', 'team', 'city', 'id', 'score']
    if len(header) != len(expected_cols):
        # If header doesn't match, still process what we have
        pass
    
    # Process rows
    rows = []
    seen_scores = set()
    
    for row in reader:
        # Strip whitespace from each cell
        cleaned_row = [cell.strip() for cell in row]
        
        if len(cleaned_row) < 5:
            continue
            
        name, team, city, id_val, score = cleaned_row[0], cleaned_row[1], cleaned_row[2], cleaned_row[3], cleaned_row[4]
        
        # Drop rows where name is empty
        if not name:
            continue
        
        # Remove duplicate rows by score, keeping first occurrence
        if score in seen_scores:
            continue
        seen_scores.add(score)
        
        rows.append((id_val, cleaned_row))
    
    # Sort rows by id ascending as strings (stable sort)
    rows.sort(key=lambda x: x[0])
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for _, row in rows:
        writer.writerow(row)
    
    return output.getvalue()


if __name__ == '__main__':
    # Test example
    test_input = """name,team,city,id,score
Alice,TeamA,City1,100,95
Bob,TeamB,City2,200,95
Charlie,TeamC,City3,300,87
"""
    result = normalize_table(test_input)
    print(result)
