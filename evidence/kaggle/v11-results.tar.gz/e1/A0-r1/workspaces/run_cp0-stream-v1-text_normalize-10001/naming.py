import unicodedata


def slugify(text):
    """Convert a title into a handle (slug).
    
    Args:
        text: A string to convert
        
    Returns:
        A slugified string
        
    Raises:
        TypeError: If input is not a string
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    slug = ""
    prev_char = None
    for char in lower:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            slug += char
        else:
            if prev_char is None or not char.isalnum():
                slug += "_"
            prev_char = char
    
    # Strip leading and trailing "_"
    slug = slug.strip("_")
    
    return slug
