import csv
import io

def tidy_csv(text):
    """Clean an exported CSV table with header: name, city, score, team."""
    
    # Handle empty string input
    if not text or not text.strip():
        return ''
    
    # Split into lines and handle line endings
    lines = text.split('\n')
    
    # If only header row exists, return it as is
    if len(lines) == 1:
        return lines[0]
    
    # Parse the CSV
    reader = csv.reader(io.StringIO(text))
    header = next(reader)
    
    # Validate header columns
    expected_columns = ['name', 'city', 'score', 'team']
    if header != expected_columns:
        raise ValueError(f"Expected header {expected_columns}, got {header}")
    
    # Collect rows
    rows = []
    seen_names = set()
    
    for row in reader:
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Drop rows whose "name" cell is empty
        if not cleaned_row[0]:
            continue
        
        name = cleaned_row[0]
        
        # Remove duplicate rows by "name", keeping the first occurrence
        if name in seen_names:
            continue
        seen_names.add(name)
        
        rows.append(cleaned_row)
    
    # Sort rows by "city" ascending as strings (stable)
    rows.sort(key=lambda row: row[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    writer.writerows(rows)
    
    return output.getvalue()
