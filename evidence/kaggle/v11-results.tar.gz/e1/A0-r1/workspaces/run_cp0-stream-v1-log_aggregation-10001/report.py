def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per service for levels ERROR, WARN only, case-insensitively (upper-case keys),
    dropping malformed input lines."""
    result = {}
    for line in lines:
        # Strip whitespace and check if line is empty
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Malformed line (needs at least timestamp, level, service)
            continue
        
        # Extract components
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, store as uppercase
        service = parts[2]
        
        # Check if level is ERROR or WARN
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Increment count for this service
        result[service] = result.get(service, 0) + 1
    
    return result
