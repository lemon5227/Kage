import csv
import io


def clean_rows(text):
    """Clean an exported table CSV text.
    
    Input: CSV text with header row (columns: id, team, score)
    Output: Cleaned CSV text with the same header
    
    Processing steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Remove duplicate rows by "team", keeping the first occurrence
    4. Sort rows by "score" ascending as strings (stable)
    
    Returns empty string for empty input, header-only input returns just the header line.
    """
    # Parse CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = []
    for row in rows[1:]:
        # Strip whitespace from each cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip if fewer columns than expected
        if len(cleaned_row) < 3:
            continue
        
        id_val, team_val, score_val = cleaned_row[0], cleaned_row[1], cleaned_row[2]
        
        # Drop rows whose "score" cell is empty
        if not score_val:
            continue
        
        data_rows.append((id_val, team_val, score_val))
    
    # Remove duplicate rows by "team", keeping the first occurrence
    seen_teams = set()
    unique_rows = []
    for row in data_rows:
        team_val = row[1]
        if team_val not in seen_teams:
            seen_teams.add(team_val)
            unique_rows.append(row)
    
    # Sort rows by "score" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x[2])
    
    # Build output CSV text
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
