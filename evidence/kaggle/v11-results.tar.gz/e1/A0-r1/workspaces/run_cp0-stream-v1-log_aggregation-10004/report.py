def digest_lines(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, and service:message
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1]
        
        # Validate that the level is a known log level
        # Common levels: DEBUG, INFO, WARN, WARNING, ERROR, FATAL, TRACE
        valid_levels = {'DEBUG', 'INFO', 'WARN', 'WARNING', 'ERROR', 'FATAL', 'TRACE'}
        
        # Upper-case the level and check if it's valid
        upper_level = level.upper()
        if upper_level not in valid_levels:
            continue
        
        # Count this level
        counts[upper_level] = counts.get(upper_level, 0) + 1
    
    return counts
