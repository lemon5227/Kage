def digest_lines(lines):
    """Process log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per level, treating level names case-insensitively (upper-case keys),
    dropping malformed input lines."""
    counts = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Malformed: need at least timestamp, level, and service
            continue
        
        # Check format: <timestamp> <LEVEL> <service>: <message>
        # The third part should contain a colon after the service name
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, use uppercase key
        service_part = parts[2]
        
        # Verify that service part contains a colon
        if ':' not in service_part:
            continue
        
        # Extract the service name (before the colon)
        service = service_part.split(':')[0]
        
        # Increment count for this level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
