import unicodedata

def label_id(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            # If we're not at the start and previous char was valid, add a hyphen
            if prev_char is not None and prev_char in 'abcdefghijklmnopqrstuvwxyz0123456789':
                result.append('-')
        else:
            result.append(char)
        prev_char = char
    
    # Join and strip leading/trailing hyphens
    slug = ''.join(result)
    slug = slug.strip('-')
    
    return slug
