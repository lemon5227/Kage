import re

_NEG = re.compile(r"\b(not|no|never|without|only|except|omit|drop|ignore|skip)\b", re.I)

def _polarity(text):
    t = text.lower()
    touch = None
    if "touch" in t:
        if re.search(r"touch\w*[^.]*\b(not|never|should not|must not)\b", t) or "not be merged" in t:
            touch = False
        elif re.search(r"touch\w*[^.]*\b(should|must|merge)\b", t):
            touch = True
    scope = None
    if "per level" in t or "each level" in t or "mapping each level" in t:
        scope = "level"
    elif "per service" in t or "each service" in t:
        scope = "service"
    return touch, scope

def _conflicts(instruction, verified_on):
    it, iscope = _polarity(instruction)
    for v in verified_on:
        vt, vscope = _polarity(v)
        if it is not None and vt is not None and it != vt:
            return True
        if iscope is not None and vscope is not None and iscope != vscope:
            return True
    return False

def select(instruction, skills):
    ranked = sorted(skills, key=lambda s: (-s["similarity"], s["skill_id"]))
    kept = []
    for s in ranked:
        if s["similarity"] < 0.15:
            continue
        if _conflicts(instruction, s.get("verified_on", [])):
            continue
        kept.append(s["skill_id"])
        if len(kept) >= 3:
            break
    return kept[:3]
