def select(instruction, skills):
    """Show a skill only when it is clearly the best match for this task.

    A skill is shown only if its similarity is high in absolute terms and
    clearly dominant over the runner-up, so weakly-related skills are not
    shown and distract the student.
    """
    if not skills:
        return []
    ranked = sorted(skills, key=lambda s: (-s["similarity"], s["skill_id"]))
    best = ranked[0]
    runner_up = ranked[1]["similarity"] if len(ranked) > 1 else 0.0
    if best["similarity"] >= 0.5 and (best["similarity"] - runner_up) >= 0.15:
        return [best["skill_id"]]
    return []
