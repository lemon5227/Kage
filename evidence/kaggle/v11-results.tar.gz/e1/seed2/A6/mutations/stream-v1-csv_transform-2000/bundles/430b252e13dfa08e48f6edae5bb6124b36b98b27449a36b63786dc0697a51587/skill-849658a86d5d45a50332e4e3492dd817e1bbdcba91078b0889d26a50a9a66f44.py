import csv, io

def run(arguments, context):
    fp = arguments['file_path']
    fn = arguments['function_name']
    drop_col = arguments['drop_empty_column']
    dedupe_col = arguments['dedupe_column']
    sort_col = arguments['sort_column']
    src = '''import csv
import io


def {fn}(text):
    if text == "":
        return ""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return ""
    header = [c.strip() for c in rows[0]]
    data = [[c.strip() for c in r] for r in rows[1:]]

    def idx(name):
        return header.index(name) if name in header else None

    di = idx({drop!r})
    if di is not None:
        data = [r for r in data if di < len(r) and r[di] != ""]

    ui = idx({dedupe!r})
    if ui is not None:
        seen = set()
        out = []
        for r in data:
            k = r[ui] if ui < len(r) else ""
            if k in seen:
                continue
            seen.add(k)
            out.append(r)
        data = out

    si = idx({sort!r})
    if si is not None:
        data.sort(key=lambda r: r[si] if si < len(r) else "")

    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\\n")
    w.writerow(header)
    w.writerows(data)
    return buf.getvalue()
'''.format(fn=fn, drop=drop_col, dedupe=dedupe_col, sort=sort_col)
    with open(fp, 'w') as f:
        f.write(src)
    return {'success': True, 'file_path': fp, 'function_name': fn}
