def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    idx = int(arguments.get('field_index', 1))
    colon = bool(arguments.get('require_colon_after_service', True))
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < 3:\n'
        '            continue\n'
        '        if ' + str(idx) + ' >= len(parts):\n'
        '            continue\n'
        '        field = parts[' + str(idx) + ']\n'
        '        if not field.isalpha():\n'
        '            continue\n'
        '        if ' + ('True' if colon else 'False') + ':\n'
        '            if ' + str(idx + 1) + ' >= len(parts) or not parts[' + str(idx + 1) + '].endswith(":"):\n'
        '                continue\n'
        '        key = field.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], fp)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'function_name': fn}
