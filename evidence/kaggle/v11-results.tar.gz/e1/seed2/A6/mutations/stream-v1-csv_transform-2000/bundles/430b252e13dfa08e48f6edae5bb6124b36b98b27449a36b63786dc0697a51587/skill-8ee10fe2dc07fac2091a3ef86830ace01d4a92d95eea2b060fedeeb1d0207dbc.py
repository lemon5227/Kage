def run(arguments, context):
    import os
    path = arguments['file_path']
    name = arguments['function_name']
    touching = bool(arguments.get('merge_touching', False))
    cmp = '<=' if touching else '<'
    src = (
        'def {name}(intervals):\n'
        '    norm = []\n'
        '    for iv in intervals:\n'
        '        s, e = iv[0], iv[1]\n'
        '        if s > e:\n'
        '            raise ValueError("start > end")\n'
        '        norm.append([s, e])\n'
        '    norm.sort(key=lambda x: x[0])\n'
        '    out = []\n'
        '    for s, e in norm:\n'
        '        if out and s {cmp} out[-1][1]:\n'
        '            if e > out[-1][1]:\n'
        '                out[-1][1] = e\n'
        '        else:\n'
        '            out.append([s, e])\n'
        '    return out\n'
    ).format(name=name, cmp=cmp)
    full = os.path.join(context['workspace_dir'], path)
    d = os.path.dirname(full)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(full, 'w') as f:
        f.write(src)
    return {'success': True, 'path': path, 'function_name': name}
