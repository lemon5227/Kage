def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    sk = arguments['start_key']
    ek = arguments['end_key']
    src = '''def {fn}(intervals):
    norm = []
    for iv in intervals:
        s = iv[{sk!r}]
        e = iv[{ek!r}]
        if s > e:
            raise ValueError('start > end')
        norm.append((s, e))
    norm.sort(key=lambda p: p[0])
    merged = []
    for s, e in norm:
        if merged and s <= merged[-1][1]:
            if e > merged[-1][1]:
                merged[-1][1] = e
        else:
            merged.append([s, e])
    return [{{{sk!r}: s, {ek!r}: e}} for s, e in merged]
'''.format(fn=fn, sk=sk, ek=ek)
    path = os.path.join(context['workspace_dir'], fp)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn, 'bytes_written': len(src)}
