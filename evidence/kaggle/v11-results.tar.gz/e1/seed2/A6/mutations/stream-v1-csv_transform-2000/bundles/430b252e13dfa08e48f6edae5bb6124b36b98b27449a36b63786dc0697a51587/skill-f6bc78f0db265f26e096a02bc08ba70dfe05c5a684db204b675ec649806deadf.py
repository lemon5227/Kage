def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    idx = int(arguments.get('field_index', 1))
    colon = bool(arguments.get('require_colon_after_service', True))
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) <= ' + str(idx) + ':\n'
        '            continue\n'
        '        field = parts[' + str(idx) + ']\n'
        '        if not field.isalpha():\n'
        '            continue\n'
        + ('        if len(parts) <= ' + str(idx + 1) + ' or not parts[' + str(idx + 1) + '].endswith(":"):\n'
           '            continue\n' if colon else '')
        + '        key = field.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = fp if os.path.isabs(fp) else os.path.join(context['workspace_dir'], fp)
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'file_path': fp, 'function_name': fn, 'bytes_written': len(src)}
