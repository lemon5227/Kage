def run(arguments, context):
    import os
    path = arguments['file_path']
    name = arguments['function_name']
    touching = arguments.get('merge_touching', True)
    if not os.path.isabs(path):
        path = os.path.join(context['workspace_dir'], path)
    cond = 'start <= merged[-1][1]' if touching else 'start < merged[-1][1]'
    src = (
        'def ' + name + '(intervals):\n'
        '    normalized = []\n'
        '    for interval in intervals:\n'
        '        start, end = interval[0], interval[1]\n'
        '        if start > end:\n'
        '            raise ValueError("invalid interval: start > end")\n'
        '        normalized.append([start, end])\n'
        '    normalized.sort(key=lambda pair: (pair[0], pair[1]))\n'
        '    merged = []\n'
        '    for start, end in normalized:\n'
        '        if merged and ' + cond + ':\n'
        '            if end > merged[-1][1]:\n'
        '                merged[-1][1] = end\n'
        '        else:\n'
        '            merged.append([start, end])\n'
        '    return merged\n'
    )
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'file_path': path, 'function_name': name, 'bytes_written': len(src)}
