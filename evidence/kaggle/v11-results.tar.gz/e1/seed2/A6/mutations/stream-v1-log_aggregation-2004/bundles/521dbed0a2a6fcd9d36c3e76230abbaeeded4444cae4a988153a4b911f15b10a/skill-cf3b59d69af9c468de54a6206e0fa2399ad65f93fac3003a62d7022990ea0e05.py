def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    gi = int(arguments.get('group_field_index', 2))
    li = int(arguments.get('level_field_index', 1))
    lf = arguments.get('level_filter', 'ERROR')
    strip_colon = bool(arguments.get('strip_trailing_colon', True))
    req_colon = bool(arguments.get('require_colon_after_group', True))
    src = '''def %s(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        if %d >= len(parts) or %d >= len(parts):
            continue
        level = parts[%d]
        group = parts[%d]
        if %r:
            if level.upper() != %r:
                continue
        if %r:
            if %d + 1 >= len(parts) or not parts[%d + 1].endswith(':'):
                continue
        if %r:
            if group.endswith(':'):
                group = group[:-1]
        if not group:
            continue
        counts[group] = counts.get(group, 0) + 1
    return counts
''' % (fn, gi, li, li, gi, bool(lf), lf.upper(), req_colon, gi, gi, strip_colon)
    path = os.path.join(context['workspace_dir'], fp)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'function_name': fn}
