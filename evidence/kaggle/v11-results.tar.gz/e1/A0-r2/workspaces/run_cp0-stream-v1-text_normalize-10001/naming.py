import unicodedata


def slugify(text):
    """Turn a title into a handle.
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with a single underscore,
    and strips leading/trailing underscores.
    
    Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we replace any sequence of non-alphanumeric characters with "_"
    slug = ''
    for char in lowercased:
        if char.isalnum():  # alphanumeric includes a-z and 0-9
            slug += char
        else:
            # If we encounter a non-alphanumeric character, add "_" only once
            if not slug.endswith('_'):
                slug += '_'
    
    # Strip leading and trailing underscores
    slug = slug.strip('_')
    
    return slug
