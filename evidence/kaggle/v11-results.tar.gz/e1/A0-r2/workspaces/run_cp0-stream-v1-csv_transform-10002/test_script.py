#!/usr/bin/env python3
"""Test export_clean.py functionality."""

from export_clean import normalize_table

# Test 1: Basic functionality
print("Test 1: Basic functionality")
input1 = """name,team,city,id,score
Alice,TeamA,City1,100,95
Bob,TeamB,City2,200,95
Charlie,TeamC,City3,300,80
"""
result1 = normalize_table(input1)
print(result1)

# Test 2: Strip whitespace
print("\nTest 2: Strip whitespace")
input2 = """name,team,city,id,score
  Alice  ,  TeamA  ,  City1  ,  100  ,  95  
Bob,TeamB,City2,200,95
"""
result2 = normalize_table(input2)
print(result2)

# Test 3: Drop empty name rows
print("\nTest 3: Drop empty name rows")
input3 = """name,team,city,id,score
Alice,TeamA,City1,100,95

Bob,TeamB,City2,200,95
"""
result3 = normalize_table(input3)
print(result3)

# Test 4: Remove duplicates by score (keep first)
print("\nTest 4: Remove duplicates by score")
input4 = """name,team,city,id,score
Alice,TeamA,City1,100,95
Bob,TeamB,City2,200,95
Charlie,TeamC,City3,300,95
"""
result4 = normalize_table(input4)
print(result4)

# Test 5: Sort by id ascending as strings (stable)
print("\nTest 5: Sort by id ascending as strings")
input5 = """name,team,city,id,score
Alice,TeamA,City1,200,95
Bob,TeamB,City2,100,95
Charlie,TeamC,City3,150,95
"""
result5 = normalize_table(input5)
print(result5)

# Test 6: Header-only input
print("\nTest 6: Header-only input")
input6 = """name,team,city,id,score
"""
result6 = normalize_table(input6)
print(repr(result6))

# Test 7: Empty string input
print("\nTest 7: Empty string input")
input7 = ""
result7 = normalize_table(input7)
print(repr(result7))

# Test 8: Whitespace-only cells
print("\nTest 8: Whitespace-only cells")
input8 = """name,team,city,id,score
   
   ,TeamA,City1,100,95
"""
result8 = normalize_table(input8)
print(result8)
