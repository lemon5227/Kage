def tally_events(lines):
    """Tally events from log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns a dictionary {name: count} for services with ERROR or WARN levels only,
    treating level names case-insensitively (upper-case keys), and dropping malformed input lines.
    """
    counts = {}
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Malformed line (needs at least timestamp, level, and service)
            continue
        
        # Extract components
        timestamp = parts[0]
        level = parts[1].upper()
        # The service is after the colon in the format: <LEVEL> <service>: <message>
        # So parts[2] should be the service name
        if len(parts) < 3:
            continue
        
        service = parts[2]
        
        # Check if level is ERROR or WARN (case-insensitive, already uppercased)
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Increment count for this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
