def convert_settings(cfg):
    """Convert old configuration dict to v2 layout."""
    # Raise ValueError if version is not 1
    if cfg.get("version") != 1:
        raise ValueError("Configuration must have version 1")
    
    # Create a new dictionary for the result
    result = {"version": 2}
    
    # Check for "user" key and rename to "username"
    if "user" in cfg:
        result["username"] = cfg["user"]
    
    # Check for "dir" key and rename to "directory"
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    
    # Move "cache_size" and "retries" into a sub-dict "limits"
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "retries" in cfg:
        limits["retries"] = cfg["retries"]
    result["limits"] = limits
    
    # Handle "timeout_ms" - convert to "timeout_s" if exists
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key not in ["user", "dir", "cache_size", "retries", "timeout_ms"]:
            if value is not None:
                result[key] = value
    
    return result
