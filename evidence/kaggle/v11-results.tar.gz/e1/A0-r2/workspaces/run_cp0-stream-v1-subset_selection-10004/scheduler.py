def choose(items, capacity):
    """
    Select jobs under a capacity limit to maximize total value.
    
    Args:
        items: List of dicts with keys "id", "weight", "value"
        capacity: Maximum total weight allowed
    
    Returns:
        Sorted list of ids whose total value is maximized while total weight <= capacity.
        If ties, returns lexicographically smallest sorted id list.
    
    Raises:
        ValueError: If capacity is negative or any weight is <= 0
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "id" not in item or not isinstance(item["id"], str):
            raise ValueError("Each item must have a string 'id'")
        if "weight" not in item or not isinstance(item["weight"], int):
            raise ValueError("Each item must have an integer 'weight'")
        if "value" not in item or not isinstance(item["value"], int):
            raise ValueError("Each item must have an integer 'value'")
        if item["weight"] <= 0:
            raise ValueError("Weight must be positive")
    
    if len(items) == 0:
        return []
    
    n = len(items)
    
    # dp[w] = (max_value, list of ids) for weight exactly w
    # We'll track the best value and the corresponding id list
    # Since we need lexicographically smallest when tied, we'll be careful
    
    # Initialize: dp[0] = (0, [])
    # For other weights, we start with -1 to indicate unreachable
    dp = {}
    dp[0] = (0, [])
    
    for i in range(n):
        item = items[i]
        weight = item["weight"]
        value = item["value"]
        item_id = item["id"]
        
        # Create a new dict for the next state to avoid modifying current state
        new_dp = dp.copy()
        
        # For each weight we can reach, try adding this item
        for w in list(dp.keys()):
            if w + weight <= capacity:
                new_value = dp[w][0] + value
                new_ids = dp[w][1] + [item_id]
                
                # Check if this is better than existing entry for w + weight
                if w + weight not in new_dp:
                    new_dp[w + weight] = (new_value, new_ids)
                else:
                    existing_value, existing_ids = new_dp[w + weight]
                    # Compare values first
                    if new_value > existing_value:
                        new_dp[w + weight] = (new_value, new_ids)
                    elif new_value == existing_value:
                        # Lexicographically smallest id list
                        if new_ids < existing_ids:
                            new_dp[w + weight] = (new_value, new_ids)
        
        dp = new_dp
    
    # Find the maximum value among all reachable weights
    max_value = 0
    best_ids = []
    
    for w in dp:
        value, ids = dp[w]
        if value > max_value:
            max_value = value
            best_ids = ids
        elif value == max_value:
            # Lexicographically smallest
            if ids < best_ids:
                best_ids = ids
    
    return sorted(best_ids)
