import csv
import io


def normalize_table(text):
    """
    Process CSV text with header row (columns: score, id, email, name).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "name", keeping the first occurrence
    5. Sort rows by "email" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    # Ensure we have the expected columns
    expected_cols = ['score', 'id', 'email', 'name']
    if len(header) != len(expected_cols):
        # If header doesn't match, use what we have
        pass
    
    # Process data rows
    processed_rows = []
    seen_names = set()
    
    for row in rows[1:]:
        # Strip whitespace from all cells
        cleaned_row = [cell.strip() for cell in row]
        
        if len(cleaned_row) < 4:
            continue
            
        score, id_val, email, name = cleaned_row[0], cleaned_row[1], cleaned_row[2], cleaned_row[3]
        
        # Drop rows whose "name" cell is empty
        if not name:
            continue
        
        # Lower-case the "email" column
        email = email.lower()
        
        # Remove duplicate rows by "name", keeping the first occurrence
        if name in seen_names:
            continue
        seen_names.add(name)
        
        processed_rows.append((score, id_val, email, name))
    
    # Sort rows by "email" ascending as strings (stable)
    processed_rows.sort(key=lambda x: x[2])
    
    # Build output CSV text
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in processed_rows:
        writer.writerow(row)
    
    return output.getvalue()
