def digest_lines(lines):
    result = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split by spaces to get parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part) and convert to uppercase for case-insensitive handling
        level = parts[1].upper()
        
        # Check if the format is correct: third part should be "service:"
        if not parts[2].endswith(':'):
            continue
        
        # Count by level
        result[level] = result.get(level, 0) + 1
    
    return result
