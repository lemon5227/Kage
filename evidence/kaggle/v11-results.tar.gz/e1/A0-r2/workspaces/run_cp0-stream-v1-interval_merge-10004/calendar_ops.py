def merge_slots(intervals):
    # Check for invalid intervals first
    for start, end in intervals:
        if start > end:
            raise ValueError(f"Interval {start}, {end} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    merged = []
    current_start, current_end = sorted_intervals[0]
    
    for next_start, next_end in sorted_intervals[1:]:
        # Only merge if there is an overlap (next_start < current_end)
        # Touching intervals (next_start == current_end) do not merge
        if next_start < current_end:
            # Merge by extending the end if needed
            current_end = max(current_end, next_end)
        else:
            # No overlap, push current and start new
            merged.append([current_start, current_end])
            current_start, current_end = next_start, next_end
    
    # Add the last interval
    merged.append([current_start, current_end])
    
    return merged
