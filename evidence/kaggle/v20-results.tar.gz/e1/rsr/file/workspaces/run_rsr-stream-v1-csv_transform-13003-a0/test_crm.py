import sys
sys.path.insert(0, '.')
from crm_clean import tidy_csv

# Test 1: Basic case
test1 = "email,id,name,team\na@example.com,1,Alice,Team1\nb@example.com,2,Bob,Team1"
result1 = tidy_csv(test1)
print("Test 1 (basic):")
print(result1)
print()

# Test 2: Empty input
test2 = ""
result2 = tidy_csv(test2)
print("Test 2 (empty):")
print(repr(result2))
print()

# Test 3: Row with empty name
test3 = "email,id,name,team\na@example.com,1,,Team1"
result3 = tidy_csv(test3)
print("Test 3 (empty name):")
print(repr(result3))
print()

# Test 4: Duplicate rows by team
test4 = "email,id,name,team\na@example.com,1,Alice,Team1\na@example.com,2,Alice,Team1"
result4 = tidy_csv(test4)
print("Test 4 (duplicate):")
print(result4)
print()

# Test 5: Header only
test5 = "email,id,name,team"
result5 = tidy_csv(test5)
print("Test 5 (header only):")
print(result5)
print()

# Test 6: Sorting
test6 = "email,id,name,team\nb@example.com,1,Bob,Team1\na@example.com,2,Alice,Team1"
result6 = tidy_csv(test6)
print("Test 6 (sorting):")
print(result6)
