import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "name" cell is empty
    try:
        name_idx = header.index("name")
    except ValueError:
        name_idx = None

    if name_idx is not None:
        cleaned = [r for r in cleaned if name_idx < len(r) and r[name_idx] != ""]

    # lower-case the "email" column
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    if email_idx is not None:
        for r in cleaned:
            if email_idx < len(r):
                r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "team", keeping the first occurrence
    try:
        team_idx = header.index("team")
    except ValueError:
        team_idx = None

    if team_idx is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            key = r[team_idx] if team_idx < len(r) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(r)
        cleaned = deduped

    # sort rows by "email" ascending as strings (stable)
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    if email_idx is not None:
        cleaned.sort(key=lambda r: r[email_idx] if email_idx < len(r) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()


def tidy_csv(text):
    return clean_rows(text)


if __name__ == "__main__":
    # Test cases
    test1 = "email,id,name,team\na@example.com,1,Alice,Team1\nb@example.com,2,Bob,Team1"
    print(clean_rows(test1))

    test2 = ""
    print(repr(clean_rows(test2)))

    test3 = "email,id,name,team\na@example.com,1,,Team1"
    print(repr(clean_rows(test3)))

    test4 = "email,id,name,team\na@example.com,1,Alice,Team1\na@example.com,2,Alice,Team1"
    print(clean_rows(test4))
