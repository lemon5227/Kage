import csv
import io

HEADER = ["email", "team", "id", "name", "score"]


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Ensure header matches expected columns
    if header != HEADER:
        return ""

    cleaned = []
    for row in data:
        # strip leading/trailing whitespace from every cell
        row = [cell.strip() for cell in row]
        # pad short rows so indexing is safe
        if len(row) < len(HEADER):
            row = row + [""] * (len(HEADER) - len(row))
        cleaned.append(row)

    # drop rows whose "name" cell is empty
    cleaned = [r for r in cleaned if r[3] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[4]  # score is at index 4
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)
    cleaned = deduped

    # sort rows by "name" ascending as strings (stable)
    cleaned.sort(key=lambda r: r[3])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(HEADER)
    writer.writerows(cleaned)
    return out.getvalue()
