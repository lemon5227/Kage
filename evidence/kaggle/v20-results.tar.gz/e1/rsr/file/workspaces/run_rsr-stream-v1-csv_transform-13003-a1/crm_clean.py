import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    # Parse header
    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Find column indices
    email_idx = header.index("email")
    name_idx = header.index("name")
    team_idx = header.index("team")

    cleaned = []
    for row in data:
        # Strip leading/trailing whitespace from every cell
        row = [cell.strip() for cell in row]

        # Drop rows whose "name" cell is empty
        if name_idx < len(row) and row[name_idx] == "":
            continue

        # Lower-case the "email" column
        if email_idx < len(row):
            row[email_idx] = row[email_idx].lower()

        cleaned.append(row)

    # Remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        key = row[team_idx] if team_idx < len(row) else ""
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    # Sort rows by "email" ascending as strings (stable)
    if email_idx is not None and email_idx < len(deduped[0]):
        deduped.sort(key=lambda r: r[email_idx] if email_idx < len(r) else "")

    # Write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
