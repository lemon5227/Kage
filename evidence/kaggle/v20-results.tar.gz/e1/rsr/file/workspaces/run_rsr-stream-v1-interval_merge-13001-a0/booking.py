def merge_slots(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"from": s, "to": e} with integer values.
    Returns a new list of dicts with the same "from"/"to" keys, sorted by
    from ascending. Touching intervals (e.g. {"from": 1, "to": 3} and
    {"from": 3, "to": 5}) are NOT merged; only real overlaps merge.
    Raises ValueError if any interval has from > to. The input is not modified.
    """
    normalized = []
    for interval in intervals:
        from_time = interval["from"]
        to_time = interval["to"]
        if from_time > to_time:
            raise ValueError(
                "invalid interval: from ({}) > to ({})".format(from_time, to_time)
            )
        normalized.append((from_time, to_time))

    normalized.sort(key=lambda pair: pair[0])

    merged = []
    for from_time, to_time in normalized:
        if merged and from_time < merged[-1][1]:
            # Real overlap: extend the current interval if needed.
            if to_time > merged[-1][1]:
                merged[-1][1] = to_time
        else:
            merged.append([from_time, to_time])

    return [{"from": from_time, "to": to_time} for from_time, to_time in merged]
