import re

_LINE_RE = re.compile(r"^\S+\s+(\S+)\s+\S+:\s")

def aggregate_log(lines):
    """Count log lines per level.

    Line format: "<timestamp> <LEVEL> <service>: <message>".
    Level case may vary and must be upper-cased. Non-matching lines are ignored.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        match = _LINE_RE.match(line)
        if not match:
            continue
        level = match.group(1).upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
