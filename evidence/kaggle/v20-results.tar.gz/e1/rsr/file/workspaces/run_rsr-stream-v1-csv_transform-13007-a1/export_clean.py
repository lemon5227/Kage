import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # Drop rows whose "name" cell is empty
    cleaned = [row for row in cleaned if len(row) > 1 and row[1] != ""]

    # Remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        name = row[1]
        if name in seen:
            continue
        seen.add(name)
        deduped.append(row)

    # Sort by "city" ascending as strings (stable)
    def city_key(row):
        return row[2] if len(row) > 2 else ""

    deduped.sort(key=city_key)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # Drop rows whose "name" cell is empty
    cleaned = [row for row in cleaned if len(row) > 1 and row[1] != ""]

    # Remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        name = row[1]
        if name in seen:
            continue
        seen.add(name)
        deduped.append(row)

    # Sort rows by "city" ascending as strings (stable)
    def city_key(row):
        return row[2] if len(row) > 2 else ""

    deduped.sort(key=city_key)

    # Write output with csv module using '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()


if __name__ == "__main__":
    # Test cases
    test1 = "id,name,city,team,score\n1,Alice,New York,Team A,100\n2,Bob,Los Angeles,Team B,200\n3,Alice,Chicago,Team C,300"
    print("Test 1:", normalize_table(test1))
    print("Clean rows:", clean_rows(test1))

    test2 = "id,name,city,team,score\n1,,New York,Team A,100"
    print("Test 2:", normalize_table(test2))
    print("Clean rows:", clean_rows(test2))

    test3 = "id,name,city,team,score\n1,Alice,New York,Team A,100\n2,Bob,Los Angeles,Team B,200\n3,Alice,Chicago,Team C,300"
    print("Test 3:", clean_rows(test3))

    test4 = ""
    print("Test 4 (empty):", normalize_table(test4))
    print("Clean rows:", clean_rows(test4))

    test5 = "id,name,city,team,score"
    print("Test 5 (header only):", normalize_table(test5))
    print("Clean rows:", clean_rows(test5))
