def coalesce(intervals):
    """Combine overlapping time ranges.

    Each interval is a two-element list [start, end] of integers.
    Returns merged intervals as [start, end] lists, sorted by start ascending.
    Touching intervals (e.g. [1, 3] and [3, 5]) are NOT merged; only real
    overlaps merge. Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    normalized = []
    for interval in intervals:
        start, end = interval[0], interval[1]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        normalized.append([start, end])

    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    merged = []
    for start, end in normalized:
        if merged and start < merged[-1][1]:
            # Real overlap: extend the current interval if needed.
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    return merged


def merge_bookings(intervals):
    """Combine overlapping time ranges for bookings.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns merged intervals as dicts with the same "start"/"end" keys,
    sorted by start ascending. Touching intervals like {"start": 1, "end": 3}
    and {"start": 3, "end": 5} should not be merged; only real overlaps merge.
    Raises ValueError if any interval has start > end. Do not modify the input.

    Args:
        intervals: list of dicts with keys "start" and "end".

    Returns:
        List of dicts with keys "start" and "end", sorted by start.

    Example:
        >>> merge_bookings([{"start": 1, "end": 3}, {"start": 3, "end": 5}])
        [{'start': 1, 'end': 3}, {'start': 3, 'end': 5}]
        >>> merge_bookings([{"start": 1, "end": 3}, {"start": 2, "end": 4}])
        [{'start': 1, 'end': 4}]
    """
    # Validate and convert to [start, end] pairs
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                f"invalid interval: start {start} > end {end}"
            )
        normalized.append([start, end])

    # Sort by start (then by end for deterministic order)
    normalized.sort(key=lambda pair: (pair[0], pair[1]))

    # Merge overlapping intervals
    merged = []
    for start, end in normalized:
        if merged and start < merged[-1][1]:
            # Real overlap: extend the current interval if needed.
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    # Convert back to dicts with "start" and "end" keys
    result = []
    for start, end in merged:
        result.append({"start": start, "end": end})

    return result
