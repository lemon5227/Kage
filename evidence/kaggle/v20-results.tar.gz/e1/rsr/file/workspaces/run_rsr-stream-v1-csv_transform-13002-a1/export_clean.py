import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = [[cell.strip() for cell in row] for row in data]

    # drop rows whose "email" cell is empty
    email_idx = header.index("email")
    cleaned = [row for row in cleaned if row[email_idx] != "" and row[email_idx] is not None]

    # lower-case the "email" column
    for row in cleaned:
        row[email_idx] = row[email_idx].lower()

    # remove duplicate rows by "score", keeping the first occurrence
    score_idx = header.index("score")
    seen = set()
    deduped = []
    for row in cleaned:
        key = row[score_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    # sort rows by "team" ascending as strings (stable)
    team_idx = header.index("team")
    deduped.sort(key=lambda row: row[team_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
