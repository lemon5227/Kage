import re

_LINE_RE = re.compile(r"^\S+\s+(\S+)\s+\S+:\s")

def summarize(lines):
    """Count log lines per service for levels ERROR and WARN.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the pattern.
    Returns a plain dict of counts for ERROR and WARN services only.
    """
    counts = {}
    for line in lines:
        match = _LINE_RE.match(line)
        if not match:
            continue
        level = match.group(1).upper()
        service = match.group(2) if len(match.groups()) > 1 else "unknown"
        if level in ("ERROR", "WARN"):
            counts[service] = counts.get(service, 0) + 1
    return counts
