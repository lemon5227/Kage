import csv
import io


def dedupe_export(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "email" cell is empty
    email_idx = header.index("email")
    cleaned = [r for r in cleaned if email_idx < len(r) and r[email_idx] != ""]

    # lower-case the "email" column
    for r in cleaned:
        if email_idx < len(r):
            r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "id", keeping the first occurrence
    id_idx = header.index("id")
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[id_idx] if id_idx < len(r) else ""
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)
    cleaned = deduped

    # sort rows by "email" ascending as strings (stable)
    email_idx = header.index("email")
    cleaned.sort(key=lambda r: r[email_idx] if email_idx < len(r) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
