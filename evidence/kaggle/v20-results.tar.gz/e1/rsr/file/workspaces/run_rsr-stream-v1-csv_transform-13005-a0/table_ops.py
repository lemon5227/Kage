import csv
import io

HEADER = ["name", "id", "city", "team", "score"]

def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        # pad short rows so indexing is safe
        if len(row) < len(header):
            row = row + [""] * (len(header) - len(row))
        cleaned.append(row)

    # drop rows whose "team" cell is empty
    team_idx = header.index("team")
    cleaned = [r for r in cleaned if r[team_idx] != ""]

    # remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[team_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)
    cleaned = deduped

    # sort rows by "score" ascending as strings (stable)
    score_idx = header.index("score")
    cleaned.sort(key=lambda r: r[score_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
