import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    # Parse header and find column indices
    header = [cell.strip() for cell in rows[0]]
    id_idx = header.index("id")
    score_idx = header.index("score")
    team_idx = header.index("team")
    email_idx = header.index("email")
    data = rows[1:]

    # Strip leading/trailing whitespace from every cell
    cleaned = [[cell.strip() for cell in row] for row in data]

    # Drop rows whose "id" cell is empty
    cleaned = [row for row in cleaned if row[id_idx] != ""]

    # Lower-case the "email" column
    for row in cleaned:
        row[email_idx] = row[email_idx].lower()

    # Remove duplicate rows by "team", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        key = row[team_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    # Sort rows by "score" ascending as strings (stable)
    deduped.sort(key=lambda row: row[score_idx])

    # Output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
