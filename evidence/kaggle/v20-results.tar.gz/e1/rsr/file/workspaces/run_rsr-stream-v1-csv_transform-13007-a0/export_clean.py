import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # Strip leading/trailing whitespace from every cell in data rows
    cleaned_data = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned_data.append(cells)

    # Drop rows whose "name" cell is empty
    cleaned_data = [row for row in cleaned_data if len(row) > 1 and row[1] != ""]

    # Remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned_data:
        name = row[1]
        if name in seen:
            continue
        seen.add(name)
        deduped.append(row)

    # Sort rows by "city" ascending as strings (stable)
    def city_key(row):
        return row[2] if len(row) > 2 else ""

    deduped.sort(key=city_key)

    # Write output with csv module using '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()


def normalize_table(text):
    return None
