import re

_LINE_RE = re.compile(r"^\S+\s+(\S+)\s+\S+:\s")

def summarize(lines):
    """Count log lines per service for levels ERROR, WARN only.

    Line format: "<timestamp> <LEVEL> <service>: <message>".
    Level case may vary and must be upper-cased. Ignore non-matching lines.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        match = _LINE_RE.match(line)
        if not match:
            continue
        level = match.group(1).upper()
        service = match.group(2)
        if level in ("ERROR", "WARN"):
            counts[service] = counts.get(service, 0) + 1
    return counts
