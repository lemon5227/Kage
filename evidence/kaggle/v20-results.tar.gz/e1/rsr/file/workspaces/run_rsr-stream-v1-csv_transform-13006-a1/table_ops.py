import csv
import io

HEADER = ["email", "team", "id", "name", "score"]


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        # pad short rows so indexing is safe
        if len(row) < len(header):
            row = row + [""] * (len(header) - len(row))
        cleaned.append(row)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name")
    cleaned = [r for r in cleaned if r[name_idx] != ""]

    # lower-case the "email" column
    email_idx = header.index("email")
    for r in cleaned:
        r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "score", keeping the first occurrence
    score_idx = header.index("score")
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[score_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)
    cleaned = deduped

    # sort rows by "name" ascending as strings (stable)
    name_idx = header.index("name")
    cleaned.sort(key=lambda r: r[name_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
