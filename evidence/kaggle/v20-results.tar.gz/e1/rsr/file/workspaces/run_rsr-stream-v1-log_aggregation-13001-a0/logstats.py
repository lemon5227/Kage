def count_entries(lines):
    """Count log entries per service for ERROR and WARN levels.
    
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each service (for levels ERROR, WARN only) 
    to how many lines it has. Levels are case-insensitive (reported upper-case).
    Malformed lines are skipped. Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        if level.upper() not in ('ERROR', 'WARN'):
            continue
        service = parts[2]
        if not service.endswith(':'):
            continue
        key = service
        counts[key] = counts.get(key, 0) + 1
    return counts
