import csv
import io

HEADER = ["name", "id", "city", "team", "score"]


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        # pad short rows so indexing is safe
        if len(row) < len(header):
            row = row + [""] * (len(header) - len(row))
        cleaned.append(row)

    # drop rows whose "team" cell is empty
    try:
        team_idx = header.index("team")
    except ValueError:
        team_idx = None

    if team_idx is not None:
        cleaned = [r for r in cleaned if r[team_idx] != ""]

    # remove duplicate rows by "team", keeping the first occurrence
    try:
        id_idx = header.index("id")
    except ValueError:
        id_idx = None

    if id_idx is not None:
        seen = set()
        deduped = []
        for r in cleaned:
            key = r[id_idx]
            if key in seen:
                continue
            seen.add(key)
            deduped.append(r)
        cleaned = deduped

    # sort by "score" ascending as strings (stable)
    try:
        score_idx = header.index("score")
    except ValueError:
        score_idx = None

    if score_idx is not None:
        cleaned.sort(key=lambda r: r[score_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
