# Edge Cases in `pick_jobs` Function

The `pick_jobs` function implements a brute-force solution to the knapsack problem, selecting the combination of items with maximum total gain within a given capacity.

## Edge Cases Handled

### 1. Invalid Capacity
- **Condition**: `capacity < 0`
- **Action**: Raises `ValueError('invalid input')`
- **Reason**: Negative capacity is not meaningful for knapsack problems

### 2. Non-positive Item Costs
- **Condition**: Any item has `cost <= 0`
- **Action**: Raises `ValueError('invalid input')`
- **Reason**: Items with zero or negative cost are invalid for this selection algorithm (they would always be beneficial if included, but the algorithm expects positive costs)

### 3. Empty Items List
- **Condition**: `items` is an empty list
- **Action**: Returns an empty list `[]`
- **Reason**: The combination of 0 items is valid and has value 0, which is the best possible result when no items exist

### 4. All Items Exceed Capacity
- **Condition**: Every single item has cost > capacity
- **Action**: Returns `[]` (empty list)
- **Reason**: No non-empty combination can fit within capacity; the empty combination remains valid

### 5. Tie-Breaking for Equal Values
- **Condition**: Multiple combinations have the same total value
- **Action**: Selects the combination with lexicographically smaller sorted IDs
- **Reason**: Provides deterministic behavior when multiple optimal solutions exist

## Algorithm Characteristics
- Uses brute-force enumeration of all `2^n` combinations (including empty)
- Time complexity: O(2^n × n) for n items
- Always returns a valid result (never fails except for invalid inputs)