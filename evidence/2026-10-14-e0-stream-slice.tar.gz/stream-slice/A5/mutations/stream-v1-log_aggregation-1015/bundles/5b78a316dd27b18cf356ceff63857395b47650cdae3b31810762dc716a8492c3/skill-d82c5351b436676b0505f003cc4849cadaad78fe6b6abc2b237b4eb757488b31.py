import ast
import os


def _build_function_source(function_name):
    return (
        f"def {function_name}(lines):\n"
        "    \"\"\"Aggregate log lines into {LEVEL: count}.\n\n"
        "    Each line is expected to be formatted as:\n"
        "        '<timestamp> <LEVEL> <service>: <message>'\n\n"
        "    The level name is matched case-insensitively and reported with an\n"
        "    upper-case key. Malformed lines are dropped.\n"
        "    \"\"\"\n"
        "    counts = {}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        parts = line.split()\n"
        "        if len(parts) < 3:\n"
        "            continue\n"
        "        level = parts[1]\n"
        "        if not level.isalpha():\n"
        "            continue\n"
        "        if not parts[2].endswith(':'):\n"
        "            continue\n"
        "        key = level.upper()\n"
        "        counts[key] = counts.get(key, 0) + 1\n"
        "    return counts\n"
    )


def _replace_function(source, function_name, new_source):
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name:
            start = node.lineno - 1
            end = node.end_lineno
            return ''.join(lines[:start]) + new_source + ''.join(lines[end:])
    if source and not source.endswith('\n'):
        source += '\n'
    return source + '\n' + new_source


def run(arguments, context):
    file_path = arguments['file_path']
    function_name = arguments['function_name']
    workspace = context.get('workspace_dir', '.')
    full_path = os.path.join(workspace, file_path)
    with open(full_path, 'r', encoding='utf-8') as f:
        source = f.read()
    new_source = _replace_function(source, function_name, _build_function_source(function_name))
    with open(full_path, 'w', encoding='utf-8') as f:
        f.write(new_source)
    return {'success': True, 'file_path': file_path, 'function_name': function_name}
