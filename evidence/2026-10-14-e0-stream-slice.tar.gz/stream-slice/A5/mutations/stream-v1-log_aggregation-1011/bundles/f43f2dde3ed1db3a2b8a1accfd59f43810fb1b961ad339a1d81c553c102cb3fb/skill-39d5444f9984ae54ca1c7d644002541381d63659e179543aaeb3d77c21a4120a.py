import ast
import os


def _build_function_source(function_name, level, group_by):
    level_literal = repr(level)
    group_literal = repr(group_by)
    return (
        "def {name}(lines):\n"
        "    \"\"\"Summarize log lines of the form '<timestamp> <LEVEL> <service>: <message>'.\n\n"
        "    Counts lines grouped by the requested field, optionally filtering to a\n"
        "    specific level (case-insensitive). Malformed lines are dropped.\n"
        "    Returns a plain dict mapping the group key to its count.\n"
        "    \"\"\"\n"
        "    level_filter = {level}\n"
        "    group_by = {group}\n"
        "    counts = {{}}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        parts = line.split()\n"
        "        if len(parts) < 3:\n"
        "            continue\n"
        "        level = parts[1]\n"
        "        service_token = parts[2]\n"
        "        if not service_token.endswith(':'):\n"
        "            continue\n"
        "        service = service_token[:-1]\n"
        "        if not service:\n"
        "            continue\n"
        "        if level_filter and level.upper() != level_filter.upper():\n"
        "            continue\n"
        "        if group_by == 'level':\n"
        "            key = level.upper()\n"
        "        else:\n"
        "            key = service\n"
        "        counts[key] = counts.get(key, 0) + 1\n"
        "    return counts\n"
    ).format(name=function_name, level=level_literal, group=group_literal)


def _replace_function(source, function_name, new_source):
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_source + "".join(lines[end:])
    if source and not source.endswith("\n"):
        source += "\n"
    return source + new_source


def run(arguments, context):
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    level = arguments.get("level", "") or ""
    group_by = arguments.get("group_by", "service") or "service"

    workspace = context.get("workspace_dir", ".")
    full_path = os.path.join(workspace, file_path)

    if not os.path.isfile(full_path):
        return {"success": False, "error": "file not found: %s" % file_path}

    with open(full_path, "r", encoding="utf-8") as fh:
        source = fh.read()

    new_source = _build_function_source(function_name, level, group_by)
    try:
        updated = _replace_function(source, function_name, new_source)
    except SyntaxError as exc:
        return {"success": False, "error": "syntax error in target file: %s" % exc}

    with open(full_path, "w", encoding="utf-8") as fh:
        fh.write(updated)

    return {
        "success": True,
        "file_path": file_path,
        "function_name": function_name,
        "level": level,
        "group_by": group_by,
    }
