import ast
import os


def _build_source(function_name, levels):
    levels_repr = repr([str(l).upper() for l in levels])
    return (
        "def {name}(lines):\n"
        "    accepted = set({levels})\n"
        "    counts = {{}}\n"
        "    for line in lines:\n"
        "        parts = line.split()\n"
        "        if len(parts) < 3:\n"
        "            continue\n"
        "        level = parts[1].upper()\n"
        "        if level not in accepted:\n"
        "            continue\n"
        "        service = parts[2]\n"
        "        if service.endswith(':'):\n"
        "            service = service[:-1]\n"
        "        if not service:\n"
        "            continue\n"
        "        counts[service] = counts.get(service, 0) + 1\n"
        "    return counts\n"
    ).format(name=function_name, levels=levels_repr)


def _replace_function(source, function_name, new_source):
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_source + "".join(lines[end:])
    if source and not source.endswith("\n"):
        source += "\n"
    return source + new_source


def run(arguments, context):
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    levels = arguments.get("levels") or ["ERROR", "WARN"]

    workspace = context.get("workspace_dir", ".")
    full_path = os.path.join(workspace, file_path)

    if os.path.exists(full_path):
        with open(full_path, "r", encoding="utf-8") as f:
            source = f.read()
    else:
        source = ""

    new_source = _build_source(function_name, levels)
    try:
        updated = _replace_function(source, function_name, new_source)
    except SyntaxError:
        updated = new_source

    os.makedirs(os.path.dirname(full_path) or ".", exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as f:
        f.write(updated)

    return {
        "success": True,
        "file_path": file_path,
        "function_name": function_name,
        "levels": [str(l).upper() for l in levels],
    }
