import ast
import os


def _build_source(function_name, field):
    if field == 'level':
        normalize = 'key = level.upper()'
    else:
        normalize = 'key = service'
    return (
        'def {fn}(lines):\n'
        '    """Count log lines grouped by {field}.\n\n'
        '    Each line looks like "<timestamp> <LEVEL> <service>: <message>".\n'
        '    Malformed lines are skipped and zero-count keys are omitted.\n'
        '    """\n'
        '    counts = {{}}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < 3:\n'
        '            continue\n'
        '        level = parts[1]\n'
        '        service = parts[2]\n'
        '        if not level.isalpha():\n'
        '            continue\n'
        '        if not service.endswith(":"):\n'
        '            continue\n'
        '        service = service[:-1]\n'
        '        if not service:\n'
        '            continue\n'
        '        {normalize}\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    ).format(fn=function_name, field=field, normalize=normalize)


def _replace_function(source, function_name, new_source):
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name:
            start = node.lineno - 1
            end = node.end_lineno
            return ''.join(lines[:start]) + new_source + ''.join(lines[end:])
    if source and not source.endswith('\n'):
        source += '\n'
    return source + new_source


def run(arguments, context):
    file_path = arguments['file_path']
    function_name = arguments['function_name']
    field = arguments.get('field', 'level')
    if field not in ('level', 'service'):
        return {'success': False, 'error': "field must be 'level' or 'service'"}
    workspace = context.get('workspace_dir', '.')
    full_path = os.path.join(workspace, file_path)
    if not os.path.isfile(full_path):
        return {'success': False, 'error': 'file not found: ' + file_path}
    with open(full_path, 'r', encoding='utf-8') as fh:
        source = fh.read()
    new_source = _build_source(function_name, field)
    try:
        updated = _replace_function(source, function_name, new_source)
    except SyntaxError as exc:
        return {'success': False, 'error': 'syntax error in target file: ' + str(exc)}
    with open(full_path, 'w', encoding='utf-8') as fh:
        fh.write(updated)
    return {'success': True, 'file_path': file_path, 'function_name': function_name, 'field': field}
