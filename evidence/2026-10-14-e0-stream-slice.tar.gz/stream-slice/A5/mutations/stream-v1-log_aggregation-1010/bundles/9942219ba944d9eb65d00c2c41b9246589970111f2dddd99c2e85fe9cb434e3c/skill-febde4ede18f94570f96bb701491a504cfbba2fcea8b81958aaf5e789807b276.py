import os
import re


def run(arguments, context):
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    field = arguments.get("field", "level")

    workspace = context.get("workspace_dir", ".")
    target = os.path.join(workspace, file_path)

    if field == "level":
        group_index = 1
        normalize = "level = match.group(1).upper()"
    elif field == "service":
        group_index = 2
        normalize = "value = match.group(2)"
    else:
        return {"success": False, "error": "unsupported field: %r" % (field,)}

    if field == "level":
        body = (
            "    counts = {}\n"
            "    for line in lines:\n"
            "        if not isinstance(line, str):\n"
            "            continue\n"
            "        match = _LINE_RE.match(line.strip())\n"
            "        if not match:\n"
            "            continue\n"
            "        level = match.group(1).upper()\n"
            "        counts[level] = counts.get(level, 0) + 1\n"
            "    return counts\n"
        )
    else:
        body = (
            "    counts = {}\n"
            "    for line in lines:\n"
            "        if not isinstance(line, str):\n"
            "            continue\n"
            "        match = _LINE_RE.match(line.strip())\n"
            "        if not match:\n"
            "            continue\n"
            "        value = match.group(2)\n"
            "        counts[value] = counts.get(value, 0) + 1\n"
            "    return counts\n"
        )

    content = (
        "import re\n\n"
        "_LINE_RE = re.compile(r\"^\\S+\\s+(\\S+)\\s+(\\S+):\\s+.*$\")\n\n\n"
        "def %s(lines):\n"
        "    \"\"\"Count log lines grouped by %s.\n\n"
        "    Expected line format: \"<timestamp> <LEVEL> <service>: <message>\".\n"
        "    Lines that do not match are ignored.\n"
        "    Returns a plain dict mapping %s -> count.\n"
        "    \"\"\"\n"
        "%s"
    ) % (function_name, field, field, body)

    try:
        with open(target, "w", encoding="utf-8") as fh:
            fh.write(content)
    except OSError as exc:
        return {"success": False, "error": str(exc)}

    return {"success": True, "path": file_path, "field": field}
