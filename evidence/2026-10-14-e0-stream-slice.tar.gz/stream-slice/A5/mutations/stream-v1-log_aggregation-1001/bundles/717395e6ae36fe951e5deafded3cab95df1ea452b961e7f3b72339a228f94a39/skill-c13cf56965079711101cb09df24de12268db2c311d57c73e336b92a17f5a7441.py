import os
import re


def run(arguments, context):
    workspace = context.get('workspace_dir', '.')
    file_path = arguments['file_path']
    function_name = arguments['function_name']
    level = arguments.get('level', 'ERROR').upper()

    full_path = os.path.join(workspace, file_path)
    if not os.path.isfile(full_path):
        return {'success': False, 'error': f'File not found: {file_path}'}

    with open(full_path, 'r', encoding='utf-8') as f:
        source = f.read()

    new_func = (
        f'def {function_name}(lines):\n'
        f'    """Count {level} lines per service.\n\n'
        f'    Each line looks like "<timestamp> <LEVEL> <service>: <message>".\n'
        f'    Levels are case-insensitive; only {level} lines are counted.\n'
        f'    Malformed lines are skipped. Services with zero count are omitted.\n'
        f'    """\n'
        f'    counts = {{}}\n'
        f'    for line in lines:\n'
        f'        if not isinstance(line, str):\n'
        f'            continue\n'
        f'        parts = line.split(None, 2)\n'
        f'        if len(parts) < 3:\n'
        f'            continue\n'
        f'        _timestamp, lvl, rest = parts\n'
        f'        if lvl.upper() != "{level}":\n'
        f'            continue\n'
        f'        if ":" not in rest:\n'
        f'            continue\n'
        f'        service = rest.split(":", 1)[0].strip()\n'
        f'        if not service:\n'
        f'            continue\n'
        f'        counts[service] = counts.get(service, 0) + 1\n'
        f'    return counts\n'
    )

    pattern = re.compile(r'^def\s+' + re.escape(function_name) + r'\s*\(', re.MULTILINE)
    match = pattern.search(source)
    if match:
        start = match.start()
        rest = source[start:]
        next_def = re.search(r'^def\s+', rest[1:], re.MULTILINE)
        if next_def:
            end = start + 1 + next_def.start()
        else:
            end = len(source)
        source = source[:start] + new_func + source[end:]
    else:
        if source and not source.endswith('\n'):
            source += '\n'
        source += '\n' + new_func

    with open(full_path, 'w', encoding='utf-8') as f:
        f.write(source)

    return {'success': True, 'file_path': file_path, 'function_name': function_name, 'level': level}
