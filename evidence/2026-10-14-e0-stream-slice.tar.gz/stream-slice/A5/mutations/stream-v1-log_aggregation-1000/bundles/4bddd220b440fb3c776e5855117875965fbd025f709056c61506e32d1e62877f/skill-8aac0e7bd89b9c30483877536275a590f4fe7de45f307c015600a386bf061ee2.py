import re
import os


def run(arguments, context):
    file_path = arguments['file_path']
    function_name = arguments['function_name']
    allowed_levels = [str(l).upper() for l in arguments['allowed_levels']]

    workspace = context['workspace_dir']
    full_path = os.path.join(workspace, file_path)

    with open(full_path, 'r', encoding='utf-8') as f:
        source = f.read()

    levels_repr = repr(allowed_levels)

    new_func = (
        "import re\n\n"
        "_LOG_LINE_RE = re.compile(r\"^\\S+\\s+(\\S+)\\s+([^:]+):\\s\")\n\n\n"
        "def " + function_name + "(lines):\n"
        "    allowed = set(" + levels_repr + ")\n"
        "    counts = {}\n"
        "    for line in lines:\n"
        "        m = _LOG_LINE_RE.match(line)\n"
        "        if not m:\n"
        "            continue\n"
        "        level = m.group(1).upper()\n"
        "        if level not in allowed:\n"
        "            continue\n"
        "        service = m.group(2).strip()\n"
        "        counts[service] = counts.get(service, 0) + 1\n"
        "    return counts\n"
    )

    pattern = re.compile(
        r'^def\s+' + re.escape(function_name) + r'\s*\([^)]*\)\s*:.*?(?=^\S|\Z)',
        re.MULTILINE | re.DOTALL,
    )

    if pattern.search(source):
        source = pattern.sub(new_func, source, count=1)
    else:
        if not source.endswith('\n'):
            source += '\n'
        source += '\n' + new_func

    with open(full_path, 'w', encoding='utf-8') as f:
        f.write(source)

    return {'success': True, 'file_path': file_path, 'function_name': function_name}
