import ast
import os


def _build_function_source(function_name, field):
    if field == "level":
        key_expr = "level.upper()"
    else:
        key_expr = "service"
    src = (
        "def {name}(lines):\n"
        "    counts = {{}}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        parts = line.split(\" \", 2)\n"
        "        if len(parts) < 3:\n"
        "            continue\n"
        "        timestamp, level, rest = parts\n"
        "        if not timestamp or not level:\n"
        "            continue\n"
        "        if \":\" not in rest:\n"
        "            continue\n"
        "        service, _, message = rest.partition(\":\")\n"
        "        if not service or not message.strip():\n"
        "            continue\n"
        "        key = {key}\n"
        "        counts[key] = counts.get(key, 0) + 1\n"
        "    return counts\n"
    ).format(name=function_name, key=key_expr)
    return src


def _replace_function(source, function_name, new_source):
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_source + "".join(lines[end:])
    if source and not source.endswith("\n"):
        source += "\n"
    return source + new_source


def run(arguments, context):
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    field = arguments.get("field", "level")
    if field not in ("level", "service"):
        return {"success": False, "error": "field must be 'level' or 'service'"}

    workspace = context.get("workspace_dir", ".")
    full_path = os.path.join(workspace, file_path)

    if os.path.exists(full_path):
        with open(full_path, "r", encoding="utf-8") as fh:
            source = fh.read()
    else:
        source = ""

    new_source = _build_function_source(function_name, field)
    try:
        updated = _replace_function(source, function_name, new_source)
    except SyntaxError:
        updated = new_source

    os.makedirs(os.path.dirname(full_path) or ".", exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as fh:
        fh.write(updated)

    return {
        "success": True,
        "file_path": file_path,
        "function_name": function_name,
        "field": field,
        "bytes_written": len(updated.encode("utf-8")),
    }
