import ast
import os


def _build_function_source(function_name, level):
    level_upper = level.upper()
    template = (
        "def {name}(lines):\n"
        "    \"\"\"Count {lvl} lines per service.\n\n"
        "    Each line looks like \"<timestamp> <LEVEL> <service>: <message>\".\n"
        "    Levels are case-insensitive; only {lvl} lines are counted.\n"
        "    Malformed lines are skipped. Services with zero count are omitted.\n"
        "    \"\"\"\n"
        "    counts = {{}}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        parts = line.split(None, 2)\n"
        "        if len(parts) < 3:\n"
        "            continue\n"
        "        _timestamp, lvl, rest = parts\n"
        "        if \":\" not in rest:\n"
        "            continue\n"
        "        service, _message = rest.split(\":\", 1)\n"
        "        service = service.strip()\n"
        "        if not service:\n"
        "            continue\n"
        "        if lvl.upper() != {lvl!r}:\n"
        "            continue\n"
        "        counts[service] = counts.get(service, 0) + 1\n"
        "    return counts\n"
    )
    return template.format(name=function_name, lvl=level_upper)


def _replace_function(source, function_name, new_source):
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_source + "".join(lines[end:])
    return source.rstrip("\n") + "\n\n\n" + new_source


def run(arguments, context):
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    level = arguments.get("level", "ERROR")
    workspace = context.get("workspace_dir", ".")
    full_path = os.path.join(workspace, file_path)
    with open(full_path, "r", encoding="utf-8") as fh:
        source = fh.read()
    new_source = _build_function_source(function_name, level)
    updated = _replace_function(source, function_name, new_source)
    with open(full_path, "w", encoding="utf-8") as fh:
        fh.write(updated)
    return {"success": True, "file_path": file_path, "function_name": function_name, "level": level.upper()}
