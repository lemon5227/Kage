import os
import re


def run(arguments, context):
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    workspace = context.get("workspace_dir", ".")
    full_path = os.path.join(workspace, file_path)

    with open(full_path, "r", encoding="utf-8") as f:
        source = f.read()

    new_func = '''import re

_LINE_RE = re.compile(r"^\\S+ +(\\S+) +\\S+:")


def {name}(lines):
    """Count log lines per level.

    Line format: "<timestamp> <LEVEL> <service>: <message>".
    Level case may vary and is upper-cased. Lines that do not match
    the format are ignored. Returns a plain dict of counts.
    """
    counts = {{}}
    for line in lines:
        if not isinstance(line, str):
            continue
        match = _LINE_RE.match(line)
        if not match:
            continue
        level = match.group(1).upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
'''.format(name=function_name)

    pattern = re.compile(
        r"^def\s+" + re.escape(function_name) + r"\s*\(.*?(?=^def\s|\Z)",
        re.MULTILINE | re.DOTALL,
    )
    if pattern.search(source):
        source = pattern.sub(new_func, source, count=1)
    else:
        if source and not source.endswith("\n"):
            source += "\n"
        source += "\n" + new_func

    with open(full_path, "w", encoding="utf-8") as f:
        f.write(source)

    return {"success": True, "path": file_path, "function": function_name}
