import ast
import os


def _build_function_source(function_name, levels):
    levels_repr = repr(tuple(l.upper() for l in levels))
    template = (
        "def {name}(lines):\n"
        "    \"\"\"Count log entries per service for the configured levels.\n\n"
        "    Each line is expected to be formatted as:\n"
        "        '<timestamp> <LEVEL> <service>: <message>'\n\n"
        "    Level names are matched case-insensitively. Malformed lines are\n"
        "    dropped. Returns a dict mapping service name -> count.\n"
        "    \"\"\"\n"
        "    counts = {{}}\n"
        "    accepted = {levels}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        parts = line.split()\n"
        "        if len(parts) < 3:\n"
        "            continue\n"
        "        level = parts[1].upper()\n"
        "        if level not in accepted:\n"
        "            continue\n"
        "        service = parts[2]\n"
        "        if not service.endswith(':'):\n"
        "            continue\n"
        "        service = service[:-1]\n"
        "        if not service:\n"
        "            continue\n"
        "        counts[service] = counts.get(service, 0) + 1\n"
        "    return counts\n"
    )
    return template.format(name=function_name, levels=levels_repr)


def _replace_function(source, function_name, new_source):
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_source + "".join(lines[end:])
    if source and not source.endswith("\n"):
        source += "\n"
    return source + "\n" + new_source


def run(arguments, context):
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    levels = arguments.get("levels") or ["ERROR", "WARN"]

    workspace = context.get("workspace_dir", ".")
    full_path = os.path.join(workspace, file_path)

    if os.path.exists(full_path):
        with open(full_path, "r", encoding="utf-8") as fh:
            source = fh.read()
    else:
        source = ""

    new_source = _build_function_source(function_name, levels)
    updated = _replace_function(source, function_name, new_source)

    os.makedirs(os.path.dirname(full_path) or ".", exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as fh:
        fh.write(updated)

    return {
        "success": True,
        "file_path": file_path,
        "function_name": function_name,
        "levels": [l.upper() for l in levels],
        "bytes_written": len(updated),
    }
