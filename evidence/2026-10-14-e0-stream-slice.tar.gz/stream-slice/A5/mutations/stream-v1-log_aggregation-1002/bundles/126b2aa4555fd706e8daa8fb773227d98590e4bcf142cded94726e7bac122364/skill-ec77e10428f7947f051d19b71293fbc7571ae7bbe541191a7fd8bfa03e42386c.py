import os


def run(arguments, context):
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    level = arguments.get("level", "ERROR")

    workspace = context.get("workspace_dir", ".")
    target = os.path.join(workspace, file_path)

    if not os.path.isfile(target):
        return {"success": False, "error": f"File not found: {file_path}"}

    level_upper = level.upper()

    impl = (
        f"def {function_name}(lines):\n"
        f"    \"\"\"Count {level_upper}-level lines per service.\n\n"
        f"    Each line looks like \"<timestamp> <LEVEL> <service>: <message>\".\n"
        f"    Levels are case-insensitive. Malformed lines are skipped.\n"
        f"    Returns a dict mapping service -> count for {level_upper} lines only,\n"
        f"    omitting services with a zero count.\n"
        f"    \"\"\"\n"
        f"    counts = {{}}\n"
        f"    for line in lines:\n"
        f"        if not isinstance(line, str):\n"
        f"            continue\n"
        f"        parts = line.split()\n"
        f"        if len(parts) < 3:\n"
        f"            continue\n"
        f"        if parts[1].upper() != {level_upper!r}:\n"
        f"            continue\n"
        f"        service_part = parts[2]\n"
        f"        if not service_part.endswith(':'):\n"
        f"            continue\n"
        f"        service = service_part[:-1]\n"
        f"        if not service:\n"
        f"            continue\n"
        f"        counts[service] = counts.get(service, 0) + 1\n"
        f"    return counts\n"
    )

    with open(target, "w", encoding="utf-8") as fh:
        fh.write(impl)

    return {
        "success": True,
        "file_path": file_path,
        "function_name": function_name,
        "level": level_upper,
    }
