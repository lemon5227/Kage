import os
import re


def _build_function_source(function_name):
    return (
        "import re\n"
        "\n"
        "_LOG_LINE_RE = re.compile(r\"^\\S+\\s+([A-Za-z]+)\\s+\\S+:\\s\")\n"
        "\n"
        "\n"
        "def {name}(lines):\n"
        "    counts = {{}}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        match = _LOG_LINE_RE.match(line)\n"
        "        if not match:\n"
        "            continue\n"
        "        level = match.group(1).upper()\n"
        "        counts[level] = counts.get(level, 0) + 1\n"
        "    return counts\n"
    ).format(name=function_name)


def _replace_function(source, function_name, new_source):
    pattern = re.compile(
        r"(?m)^def\s+" + re.escape(function_name) + r"\s*\([^)]*\)\s*:"
    )
    match = pattern.search(source)
    if not match:
        if source and not source.endswith("\n"):
            source += "\n"
        return source + "\n" + new_source
    start = match.start()
    rest = source[match.end():]
    lines = rest.split("\n")
    end_offset = match.end()
    for i, line in enumerate(lines):
        if i == 0:
            end_offset += len(line) + 1
            continue
        if line.strip() == "":
            end_offset += len(line) + 1
            continue
        if line[0] in " \t":
            end_offset += len(line) + 1
            continue
        break
    return source[:start] + new_source + source[end_offset:]


def run(arguments, context):
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    workspace = context.get("workspace_dir", ".")
    full_path = os.path.join(workspace, file_path)
    if not os.path.isfile(full_path):
        return {"success": False, "error": "file not found: " + file_path}
    with open(full_path, "r", encoding="utf-8") as fh:
        source = fh.read()
    new_source = _build_function_source(function_name)
    updated = _replace_function(source, function_name, new_source)
    with open(full_path, "w", encoding="utf-8") as fh:
        fh.write(updated)
    return {"success": True, "file_path": file_path, "function_name": function_name}
