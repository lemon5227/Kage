def summarize(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Check if the third part starts with ':' (service:)
        if not parts[2].startswith(':'):
            continue
        
        # Extract the level from the second part
        level = parts[1]
        
        # Upper-case the level
        level = level.upper()
        
        # Count the level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
