def aggregate_log(lines):
    """Aggregate log lines by level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    - Level case may vary and must be upper-cased
    - Ignore lines that do not match the format
    
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Skip lines that don't have at least timestamp, level, and service
            continue
        
        # Check if the third part contains a colon (for service:)
        if ':' not in parts[2]:
            # Skip lines that don't match the format
            continue
        
        # Extract the level (second part) and upper-case it
        level = parts[1].upper()
        
        # Count the level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
