def summarize(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    - Level is case-insensitive and should be upper-cased in output
    - Ignore lines that do not match the format
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split by spaces to get parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Check if the rest of the line matches the pattern
        # Format: <timestamp> <LEVEL> <service>: <message>
        # After the level, we should have service followed by colon
        if len(parts) >= 3:
            # The third part should be a service name (no colon in it)
            # But we need to ensure there's a colon after the service
            # Let's check if parts[2] contains a colon or if there are more parts
            # Actually, the format is: timestamp level service: message
            # So parts[2] should be the service name, and then there should be a colon
            # We can check if parts[2] ends with ':' or if there's a colon in the line
            
            # Simpler approach: check if the line has the pattern
            # We'll just count if we have at least 3 parts and the level is valid
            # The requirement says "ignore lines that do not match" - so we need to be strict
            
            # Let's parse more carefully:
            # timestamp (any string)
            # level (any string, but should be a log level like ERROR, INFO, etc.)
            # service: (service name followed by colon)
            # message (rest of the line)
            
            # Check if parts[2] contains a colon or if there's a colon in the line after parts[2]
            # Actually, the format is: <timestamp> <LEVEL> <service>: <message>
            # So after splitting by space, we get: [timestamp, LEVEL, service, ':', message...]
            # But if the service name contains spaces, this breaks.
            
            # Let's use a regex approach or check for colon in parts[2]
            # The safest is to check if there's a colon in the line after the level
            
            # Check if parts[2] ends with ':' or if there's a colon in the remaining string
            rest = ' '.join(parts[2:])
            if ':' in rest:
                # This line matches the format
                counts[level] = counts.get(level, 0) + 1
    
    return counts
