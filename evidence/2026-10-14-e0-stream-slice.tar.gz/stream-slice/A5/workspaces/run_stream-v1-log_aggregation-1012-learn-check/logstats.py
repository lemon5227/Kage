def tally_events(lines):
    """Count log lines by level, skipping malformed lines."""
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip malformed lines
        # Format: <timestamp> <LEVEL> <service>: <message>
        # The second part is the level
        level = parts[1].upper()
        counts[level] = counts.get(level, 0) + 1
    return {level: count for level, count in counts.items() if count > 0}
