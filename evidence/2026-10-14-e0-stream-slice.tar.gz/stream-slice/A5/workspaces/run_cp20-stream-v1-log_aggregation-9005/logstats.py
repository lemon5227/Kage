def count_entries(lines):
    """Count log lines grouped by service for ERROR level only.
    
    Each line looks like '<timestamp> <LEVEL> <service>: <message>'.
    Returns a dict mapping each service to its ERROR count.
    """
    error_counts = {}
    
    for line in lines:
        # Skip malformed lines (must have at least 3 parts)
        parts = line.strip().split()
        if len(parts) < 3:
            continue
        
        # Check if level is ERROR (case-insensitive)
        level = parts[1].upper()
        if level != 'ERROR':
            continue
        
        # Extract service from parts[2]
        service = parts[2]
        
        # Count only if service exists
        if service:
            error_counts[service] = error_counts.get(service, 0) + 1
    
    return error_counts
