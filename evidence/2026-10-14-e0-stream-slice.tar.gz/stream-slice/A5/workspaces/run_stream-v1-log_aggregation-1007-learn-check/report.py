def aggregate_log(lines):
    """Aggregate log lines per service for ERROR and WARN levels."""
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        timestamp, level, rest = parts[0], parts[1], ' '.join(parts[2:])
        # Check if level is ERROR or WARN (case-insensitive)
        if level.upper() not in ('ERROR', 'WARN'):
            continue
        # Extract service from "service: message" format
        if ':' in rest:
            service = rest.split(':')[0]
        else:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
