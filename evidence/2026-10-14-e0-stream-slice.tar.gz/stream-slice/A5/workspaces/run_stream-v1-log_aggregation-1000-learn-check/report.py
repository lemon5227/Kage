def digest_lines(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        service = parts[2]
        if level in ['ERROR', 'WARN']:
            counts[service] = counts.get(service, 0) + 1
    return counts
