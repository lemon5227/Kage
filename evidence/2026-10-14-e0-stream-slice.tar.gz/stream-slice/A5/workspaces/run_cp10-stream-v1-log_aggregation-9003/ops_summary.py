def count_entries(lines):
    """Count log entries per service for ERROR and WARN levels only.
    
    Log format: "<timestamp> <LEVEL> <service>: <message>"
    Returns: {name: count} with uppercase keys, dropping malformed lines.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) < 3:
            # Malformed line (need at least timestamp, level, service)
            continue
        
        # Extract level and service
        level = parts[1].upper()
        service = parts[2]
        
        # Only count ERROR and WARN levels
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Increment count for this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
