def tally_events(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level may vary in case and must be upper-cased.
    Ignore lines that do not match the format.
    
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, upper-case the level
        rest = ' '.join(parts[2:])
        
        # Check if the rest starts with ": " (service followed by colon and space)
        if not rest.startswith(':'):
            continue
        
        # Extract service name (everything before the first colon)
        service_part = rest.split(':', 1)[0]
        
        # If there's no service part, skip this line
        if not service_part.strip():
            continue
        
        # Count this level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
