def count_entries(lines):
    """Count log entries by level, handling format '<timestamp> <LEVEL> <service>: <message>'"""
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        # Parse the line: expected format "<timestamp> <LEVEL> <service>: <message>"
        parts = line.split()
        if len(parts) < 3:
            # Malformed line - skip
            continue
        
        # Check if third part contains a colon (to separate service from message)
        # Format: timestamp level service: message
        # We need to find the level token (second part) and ensure it's followed by ': '
        # Actually, let's parse more carefully:
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # So parts[0] = timestamp, parts[1] = LEVEL, parts[2] should start with service name and contain ':'
        
        # Check if the third part has a colon to validate the format
        if ':' not in parts[2]:
            # Malformed line - skip
            continue
        
        level = parts[1].upper()  # Case-insensitive, store as uppercase
        level_counts[level] = level_counts.get(level, 0) + 1
    
    return level_counts
