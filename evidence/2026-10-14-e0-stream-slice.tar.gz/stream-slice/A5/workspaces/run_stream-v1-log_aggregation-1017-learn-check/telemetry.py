def aggregate_log(lines):
    """Aggregate log lines per service for WARN level only.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased; ignore lines that do not match.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            continue
        
        # Check if second part is a log level (case-insensitive)
        level = parts[1].upper()
        
        # Only count WARN level
        if level != 'WARN':
            continue
        
        # Extract service from third part (after the level)
        # Format: "<timestamp> <LEVEL> <service>: <message>"
        # The service is the third token, followed by a colon
        service = parts[2]
        
        # Count per service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
