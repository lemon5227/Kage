def tally_events(lines):
    """Count lines per service for WARN level only."""
    counts = {}
    for line in lines:
        parts = line.strip().split()
        if len(parts) < 3:
            continue  # Skip malformed lines
        
        # Check if second part is a log level (case-insensitive)
        level = parts[1].upper()
        if level != 'WARN':
            continue
        
        # Extract service from third part (format: <service>: <message>)
        service_part = parts[2]
        if not service_part.endswith(':'):
            continue  # Skip malformed lines
        
        service = service_part[:-1]
        counts[service] = counts.get(service, 0) + 1
    
    return counts
