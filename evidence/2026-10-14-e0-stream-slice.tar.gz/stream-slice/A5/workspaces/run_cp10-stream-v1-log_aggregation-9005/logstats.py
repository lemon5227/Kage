def count_entries(lines):
    """Count entries per service for ERROR level only.
    
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each service (for ERROR level) to its count.
    Levels are case-insensitive (reported as upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
            
        timestamp = parts[0]
        level = parts[1].upper()
        service_part = parts[2]
        
        # Check if service part contains a colon (service: message)
        if ':' not in service_part:
            continue
            
        # Extract service name before the colon
        service = service_part.split(':')[0]
        
        # Only count ERROR level entries
        if level == 'ERROR':
            counts[service] = counts.get(service, 0) + 1
    
    return counts
