def aggregate_log(lines):
    """Aggregate log lines by level, returning a dict of level -> count.
    
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive (reported as uppercase).
    Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
            
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report as uppercase
        rest = ' '.join(parts[2:])
        
        # Check if the format is correct: should have "service:" pattern
        if not rest.startswith(':'):
            continue
            
        # Extract service name (optional, but we need to ensure format)
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # We just need to verify the level exists and the line has the colon
        
        # Count this line for the level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    # Return only non-zero counts (already handled by dict)
    return level_counts
