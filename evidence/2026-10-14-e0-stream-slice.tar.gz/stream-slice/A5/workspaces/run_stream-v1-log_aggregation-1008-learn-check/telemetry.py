def tally_events(lines):
    """Count ERROR level events per service from log lines.
    
    Each line looks like '<timestamp> <LEVEL> <service>: <message>'.
    Returns a dict mapping each service for levels ERROR only to how many lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines.
    Omit keys with zero count.
    """
    counts = {}
    
    for line in lines:
        # Strip whitespace and check if line is empty
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report as uppercase
        service_part = parts[2]
        
        # Check if the service part contains a colon (service: message)
        if ':' not in service_part:
            continue
        
        # Extract the service name (before the colon)
        service = service_part.split(':')[0]
        
        # Only count ERROR level events
        if level == 'ERROR':
            counts[service] = counts.get(service, 0) + 1
    
    # Return only services with non-zero counts
    return {k: v for k, v in counts.items() if v > 0}
