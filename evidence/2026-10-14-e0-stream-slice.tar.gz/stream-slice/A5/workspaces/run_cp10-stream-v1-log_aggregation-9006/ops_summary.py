def count_entries(lines):
    """Count log entries by level, handling format '<timestamp> <LEVEL> <service>: <message>'"""
    counts = {}
    
    for line in lines:
        # Strip whitespace and check if line is empty
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 4 parts: timestamp, level, service, message (with colon)
        if len(parts) < 4:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()  # Case-insensitive, use uppercase
        
        # Check that the level is not empty
        if not level:
            continue
        
        # Increment count for this level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
