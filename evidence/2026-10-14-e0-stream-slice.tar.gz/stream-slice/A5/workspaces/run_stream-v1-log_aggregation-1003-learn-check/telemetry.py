def count_entries(lines):
    """Count log entries per service for ERROR and WARN levels only.
    
    Lines are formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} with uppercase keys, dropping malformed lines.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed line
        
        level = parts[1].upper()
        service = parts[2]
        
        if level in ('ERROR', 'WARN'):
            counts[service] = counts.get(service, 0) + 1
    
    return counts
