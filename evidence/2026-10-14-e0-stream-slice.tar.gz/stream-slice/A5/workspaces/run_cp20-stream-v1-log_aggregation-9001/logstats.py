def aggregate_log(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed line
        # Format: timestamp level service: message
        # parts[0] = timestamp, parts[1] = LEVEL, parts[2] = service (before colon)
        # Need to check if parts[2] contains a colon
        if ':' in parts[2]:
            service = parts[2].split(':')[0]
            level = parts[1].upper()
            if level == 'ERROR':
                counts[service] = counts.get(service, 0) + 1
    return {k: v for k, v in counts.items() if v > 0}
