def digest_lines(lines):
    """
    Digest log lines formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per service for levels ERROR and WARN only,
    treating level names case-insensitively (upper-case keys), dropping malformed input lines.
    """
    result = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service (message may be absent)
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Check if level is ERROR or WARN
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Extract service (third part)
        service = parts[2]
        
        # Count per service
        result[service] = result.get(service, 0) + 1
    
    return result
