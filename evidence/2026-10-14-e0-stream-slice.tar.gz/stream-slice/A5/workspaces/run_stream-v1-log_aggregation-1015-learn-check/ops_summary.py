def aggregate_log(lines):
    """Aggregate log lines by level, returning {level: count}."""
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Parse format: <timestamp> <LEVEL> <service>: <message>
        parts = line.split()
        if len(parts) < 3:
            # Malformed line, skip
            continue
        
        # Check if third part contains colon (for service:)
        if parts[2].endswith(':'):
            # Format is correct: timestamp level service: message
            level = parts[1]
            # Count by upper-cased level
            level_counts[level.upper()] = level_counts.get(level.upper(), 0) + 1
        else:
            # Malformed line (no colon after service), skip
            continue
    
    return level_counts
