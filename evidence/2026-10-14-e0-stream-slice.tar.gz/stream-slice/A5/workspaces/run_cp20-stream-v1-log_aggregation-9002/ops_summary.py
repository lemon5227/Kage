def aggregate_log(lines):
    """Aggregate log lines by level, returning a dict of level -> count."""
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Parse the line: "<timestamp> <LEVEL> <service>: <message>"
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        # Check if the third part contains a colon (for service:)
        if parts[2].startswith(':'):
            # Malformed - skip
            continue
        
        # Extract level from parts[1]
        level = parts[1].upper()
        
        # Count this level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    # Return only non-zero counts (already handled by dict)
    return level_counts
