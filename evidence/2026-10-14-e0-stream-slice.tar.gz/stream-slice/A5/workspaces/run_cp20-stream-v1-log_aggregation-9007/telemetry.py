def digest_lines(lines):
    """
    Digest log lines formatted as '<timestamp> <LEVEL> <service>: <message>'
    Returns {name: count} per service for levels ERROR, WARN only.
    Level names are compared case-insensitively (upper-case keys).
    Malformed input lines are dropped.
    """
    result = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split by spaces to get timestamp, level, service, and message
        parts = line.split()
        if len(parts) < 3:
            # Malformed line (need at least timestamp, level, service)
            continue
        
        # Extract level and service
        level = parts[1]
        service = parts[2]
        
        # Check if level is ERROR or WARN (case-insensitive)
        if level.upper() not in ['ERROR', 'WARN']:
            continue
        
        # Count per service
        result[service] = result.get(service, 0) + 1
    
    return result
