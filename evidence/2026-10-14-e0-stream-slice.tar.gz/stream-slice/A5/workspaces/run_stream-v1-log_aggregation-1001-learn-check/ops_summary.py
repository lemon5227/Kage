def summarize(lines):
    """Count ERROR lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive; only ERROR lines are counted.
    Malformed lines are skipped. Services with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        _timestamp, lvl, rest = parts
        if lvl.upper() != "ERROR":
            continue
        if ":" not in rest:
            continue
        service = rest.split(":", 1)[0].strip()
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
