def aggregate_log(lines):
    """
    Aggregate log lines of the form '<timestamp> <LEVEL> <service>: <message>'.
    Returns a dict mapping each service for levels ERROR only to how many lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines.
    Omit keys with zero count.
    """
    error_counts = {}
    
    for line in lines:
        # Strip whitespace and check if line is empty
        line = line.strip()
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Extract components
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report as uppercase
        service_part = parts[2]
        
        # Check if the format is correct: service should be followed by ':'
        if not service_part.startswith(':'):
            continue
        
        # Extract service name (everything after the first ':')
        service = service_part[1:]
        
        # Only count ERROR level
        if level == 'ERROR':
            error_counts[service] = error_counts.get(service, 0) + 1
    
    return error_counts
