def summarize(lines):
    """Summarize log lines by service for WARN level only.
    
    Log format: '<timestamp> <LEVEL> <service>: <message>'
    Returns: {service_name: count} with uppercase keys.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed
        
        # Check level (case-insensitive)
        level = parts[1].upper()
        if level != 'WARN':
            continue
        
        # Extract service name (after the colon)
        # Format: <timestamp> <LEVEL> <service>: <message>
        # parts[0] = timestamp, parts[1] = LEVEL, parts[2] = service, parts[3] = ':', rest = message
        if len(parts) < 4 or parts[2].startswith(':'):
            continue  # malformed
        
        service = parts[2].upper()
        counts[service] = counts.get(service, 0) + 1
    
    return counts
