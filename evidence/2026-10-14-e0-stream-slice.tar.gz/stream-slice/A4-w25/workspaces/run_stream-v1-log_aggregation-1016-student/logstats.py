def tally_events(lines):
    counts = {}
    allowed = ['ERROR', 'WARN']
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in allowed:
            continue
        service = parts[2].rstrip(":")
        key = service
        counts[key] = counts.get(key, 0) + 1
    return counts
