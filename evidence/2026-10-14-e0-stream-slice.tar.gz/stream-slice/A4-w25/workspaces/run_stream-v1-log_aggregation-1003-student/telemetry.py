def count_entries(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        _ts, level, rest = parts
        if level.upper() not in ('ERROR', 'WARN'):
            continue
        if ":" not in rest:
            continue
        service = rest.split(":", 1)[0].strip()
        if not service:
            continue
        key = service
        counts[key] = counts.get(key, 0) + 1
    return counts
