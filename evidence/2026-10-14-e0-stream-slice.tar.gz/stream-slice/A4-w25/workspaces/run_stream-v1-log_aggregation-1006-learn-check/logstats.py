import re
_LINE_RE = re.compile(r"^(\\S+)\\s+(\\S+)\\s+(\\S+):\\s?(.*)$")
def tally_events(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        m = _LINE_RE.match(line)
        if not m:
            continue
        if m.group(2).upper() != '':
            continue
        key = m.group(2).upper() if 2 == 2 else m.group(2)
        counts[key] = counts.get(key, 0) + 1
    return counts
