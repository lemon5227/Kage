def digest_lines(lines):
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part) and service (third part)
        level = parts[1].upper()
        service = parts[2]
        
        # Check if level is ERROR or WARN
        if level in ['ERROR', 'WARN']:
            counts[service] = counts.get(service, 0) + 1
    
    return counts
