def aggregate_log(lines):
    """
    Parse log lines in format '<timestamp> <LEVEL> <service>: <message>'.
    Return a dict mapping each level to how many lines it has.
    Levels are case-insensitive (report them upper-case).
    Skip malformed lines. Omit keys with zero count.
    """
    counts = {}
    for line in lines:
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Malformed line (need at least timestamp, level, and service)
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report as uppercase
        rest = ' '.join(parts[2:])
        
        # Check if the rest starts with ': <service>: <message>'
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # So after level, we should have service followed by colon
        if not rest.startswith(':'):
            # Malformed line - skip
            continue
        
        # Extract service from the rest
        # Format: service: message
        # We need to find the first colon after the level
        # Actually, the format is: <timestamp> <LEVEL> <service>: <message>
        # So parts[2] should be the service name, and then there's a colon
        # But we need to ensure the line matches the expected format
        
        # Let's check if the line has the expected structure
        # We need at least: timestamp level service: message
        # The service is parts[2], and it should be followed by ':'
        if len(parts) < 3 or not rest.startswith(':'):
            continue
        
        # Extract service from the colon-separated part
        # The format is: service: message
        # We need to find the first colon in the rest string
        colon_index = rest.find(':')
        if colon_index == -1:
            continue
        
        service = rest[:colon_index]
        # If service is empty, it's malformed
        if not service.strip():
            continue
        
        # Count the level
        counts[level] = counts.get(level, 0) + 1
    
    # Return only non-zero counts
    return {level: count for level, count in counts.items() if count > 0}
