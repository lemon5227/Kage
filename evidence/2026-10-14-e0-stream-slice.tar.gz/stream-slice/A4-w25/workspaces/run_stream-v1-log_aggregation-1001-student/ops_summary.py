def summarize(lines):
    """
    Summarize log lines by service for ERROR level only.
    
    Each line format: "<timestamp> <LEVEL> <service>: <message>"
    Returns a dict mapping each service (for ERROR level) to count of lines.
    Levels are case-insensitive (reported as upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    error_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Check if it's an ERROR level line
        if level != "ERROR":
            continue
        
        # Count this line for the service
        error_counts[service] = error_counts.get(service, 0) + 1
    
    return error_counts
