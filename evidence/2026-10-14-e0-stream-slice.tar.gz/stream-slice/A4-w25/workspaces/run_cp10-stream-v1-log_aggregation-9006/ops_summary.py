def count_entries(lines):
    """Count log entries by level, handling format '<timestamp> <LEVEL> <service>: <message>'"""
    counts = {}
    for line in lines:
        # Parse the line
        parts = line.split()
        if len(parts) < 3:
            # Malformed line - skip
            continue
        # Format: timestamp level service: message
        # Check if the third part contains a colon (service name followed by colon)
        if ':' not in parts[2]:
            # Malformed - skip
            continue
        level = parts[1].upper()  # Case-insensitive, store as uppercase
        counts[level] = counts.get(level, 0) + 1
    return counts
