def tally_events(lines):
    """
    Parse log lines in format: '<timestamp> <LEVEL> <service>: <message>'
    Count occurrences of WARN level per service (case-insensitive).
    Return dict mapping service to count, omitting zero counts.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
            
        level = parts[1].upper()
        service = parts[2]
        
        # Only count WARN level
        if level == 'WARN':
            counts[service] = counts.get(service, 0) + 1
    
    # Return only non-zero counts
    return {k: v for k, v in counts.items() if v > 0}
