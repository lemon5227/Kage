def tally_events(lines):
    """
    Parse log lines in format '<timestamp> <LEVEL> <service>: <message>'.
    Return a dict mapping each level (upper-case) to its count.
    Skip malformed lines and omit keys with zero count.
    """
    counts = {}
    for line in lines:
        # Strip whitespace
        line = line.strip()
        if not line:
            continue
        
        parts = line.split()
        if len(parts) < 2:
            continue  # malformed
        
        timestamp = parts[0]
        level = parts[1].upper()
        
        # Check if there's a colon in the rest of the line
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # So after the level, we need at least one more token before the colon
        rest = ' '.join(parts[2:])
        if ':' not in rest:
            continue  # malformed
        
        counts[level] = counts.get(level, 0) + 1
    
    return counts
