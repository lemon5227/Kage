def run(arguments, context):
    import os
    path = os.path.join(context['workspace_dir'], arguments['file_path'])
    fn = arguments['function_name']
    lvl = arguments['level_filter']
    grp = arguments['group_by']
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split(None, 2)\n'
        '        if len(parts) < 3:\n'
        '            continue\n'
        '        _ts, level, rest = parts\n'
        '        if level.upper() != ' + repr(lvl.upper()) + ':\n'
        '            continue\n'
        '        if ":" not in rest:\n'
        '            continue\n'
        '        service = rest.split(":", 1)[0].strip()\n'
        '        if not service:\n'
        '            continue\n'
        '        key = service if ' + repr(grp) + ' == "service" else level.upper()\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': arguments['file_path']}
