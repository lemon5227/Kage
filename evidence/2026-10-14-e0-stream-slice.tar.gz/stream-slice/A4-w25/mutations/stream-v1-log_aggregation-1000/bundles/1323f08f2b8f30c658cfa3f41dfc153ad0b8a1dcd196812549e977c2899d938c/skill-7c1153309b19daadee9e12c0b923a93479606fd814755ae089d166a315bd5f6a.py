import re

_LINE_RE = re.compile(r"^\S+\s+(\S+)\s+([^:]+):\s")


def run(arguments, context):
    path = arguments["file_path"]
    fn = arguments["function_name"]
    group_field = arguments.get("group_field", "service")
    allowed = arguments.get("allowed_levels", [])
    lines = [
        "import re",
        "",
        "_LINE_RE = re.compile(r\"^\\\\S+\\\\s+(\\\\S+)\\\\s+([^:]+):\\\\s\")",
        "",
        "",
        "def " + fn + "(lines):",
        "    allowed = {l.upper() for l in " + repr(list(allowed)) + "}",
        "    counts = {}",
        "    for line in lines:",
        "        m = _LINE_RE.match(line)",
        "        if not m:",
        "            continue",
        "        level = m.group(1).upper()",
        "        if allowed and level not in allowed:",
        "            continue",
        "        service = m.group(2).strip()",
        "        key = level if " + repr(group_field) + " == 'level' else service",
        "        counts[key] = counts.get(key, 0) + 1",
        "    return counts",
        "",
    ]
    with open(path, "w") as f:
        f.write("\n".join(lines))
    return {"success": True, "path": path, "function": fn}
