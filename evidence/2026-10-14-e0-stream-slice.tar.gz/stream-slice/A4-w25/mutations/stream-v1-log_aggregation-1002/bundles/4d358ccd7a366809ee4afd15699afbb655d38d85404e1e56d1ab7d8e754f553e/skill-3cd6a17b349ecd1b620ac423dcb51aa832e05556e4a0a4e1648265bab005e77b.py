def run(arguments, context):
    import os
    fp = arguments['file_path']
    fn = arguments['function_name']
    lvl = arguments['level_filter']
    grp = arguments['group_by']
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    for line in lines:\n'
        '        if not isinstance(line, str):\n'
        '            continue\n'
        '        parts = line.split()\n'
        '        if len(parts) < 3:\n'
        '            continue\n'
        '        level = parts[1].upper()\n'
        '        if level != ' + repr(lvl.upper()) + ':\n'
        '            continue\n'
        '        sp = parts[2]\n'
        '        if not sp.endswith(":"):\n'
        '            continue\n'
        '        service = sp[:-1]\n'
        '        if not service:\n'
        '            continue\n'
        '        key = service if ' + repr(grp) + ' == "service" else level\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    path = os.path.join(context['workspace_dir'], fp)
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': fp, 'bytes_written': len(src)}
