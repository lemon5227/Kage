def run(arguments, context):
    import os
    path = os.path.join(context['workspace_dir'], arguments['file_path'])
    fn = arguments['function_name']
    levels = [l.upper() for l in arguments['levels']]
    group_by = arguments['group_by']
    src = (
        'def ' + fn + '(lines):\n'
        '    counts = {}\n'
        '    allowed = ' + repr(levels) + '\n'
        '    for line in lines:\n'
        '        parts = line.split()\n'
        '        if len(parts) < 3:\n'
        '            continue\n'
        '        level = parts[1].upper()\n'
        '        if level not in allowed:\n'
        '            continue\n'
        '        service = parts[2].rstrip(":")\n'
        '        key = ' + ('level' if group_by == 'level' else 'service') + '\n'
        '        counts[key] = counts.get(key, 0) + 1\n'
        '    return counts\n'
    )
    with open(path, 'w') as f:
        f.write(src)
    return {'success': True, 'path': arguments['file_path'], 'bytes_written': len(src)}
