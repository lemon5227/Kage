import re

_LINE_RE = re.compile(r"^(\S+)\s+(\S+)\s+(\S+):\s?(.*)$")


def run(arguments, context):
    path = arguments["file_path"]
    fname = arguments["function_name"]
    level_filter = arguments["level_filter"].upper()
    group_by = arguments["group_by"]
    idx = {"timestamp": 1, "level": 2, "service": 3, "message": 4}[group_by]
    src = (
        "import re\n"
        "_LINE_RE = re.compile(r\"^(\\\\S+)\\\\s+(\\\\S+)\\\\s+(\\\\S+):\\\\s?(.*)$\")\n"
        "def %s(lines):\n"
        "    counts = {}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        m = _LINE_RE.match(line)\n"
        "        if not m:\n"
        "            continue\n"
        "        if m.group(2).upper() != %r:\n"
        "            continue\n"
        "        key = m.group(%d).upper() if %d == 2 else m.group(%d)\n"
        "        counts[key] = counts.get(key, 0) + 1\n"
        "    return counts\n"
    ) % (fname, level_filter, idx, idx, idx)
    with open(path, "w", encoding="utf-8") as f:
        f.write(src)
    return {"success": True, "path": path, "bytes_written": len(src)}
