def tally_events(lines):
    """Count WARN-level lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive. Malformed lines are skipped.
    Returns a dict mapping service -> count for WARN lines only,
    omitting services with a zero count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level != "WARN":
            continue
        service_part = parts[2]
        if not service_part.endswith(":"):
            continue
        service = service_part[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
