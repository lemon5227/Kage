import re

_LINE_RE = re.compile(r"^\S+\s+(\S+)\s+([^:]+):\s")


def digest_lines(lines):
    counts = {}
    for line in lines:
        m = _LINE_RE.match(line)
        if not m:
            continue
        level = m.group(1).upper()
        if level not in ("ERROR", "WARN"):
            continue
        service = m.group(2).strip()
        counts[service] = counts.get(service, 0) + 1
    return counts
