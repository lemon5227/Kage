def tally_events(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service = parts[2]
        if service.endswith(":"):
            service = service[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
