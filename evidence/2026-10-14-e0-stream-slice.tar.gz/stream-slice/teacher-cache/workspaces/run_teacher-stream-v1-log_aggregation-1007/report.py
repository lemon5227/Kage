def aggregate_log(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service = parts[2].rstrip(":")
        counts[service] = counts.get(service, 0) + 1
    return counts
