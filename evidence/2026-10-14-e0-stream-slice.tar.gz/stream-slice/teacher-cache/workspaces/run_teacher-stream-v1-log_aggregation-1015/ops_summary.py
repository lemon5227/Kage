def aggregate_log(lines):
    """Aggregate log lines into {LEVEL: count}.

    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"

    The level name is matched case-insensitively and reported with an
    upper-case key. Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        if not level.isalpha():
            continue
        if not parts[2].endswith(":"):
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
