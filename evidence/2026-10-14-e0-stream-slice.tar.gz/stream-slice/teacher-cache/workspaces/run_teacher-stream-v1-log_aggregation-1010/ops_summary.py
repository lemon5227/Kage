import re

_LINE_RE = re.compile(r"^\S+\s+(\S+)\s+\S+:\s+.*$")


def digest_lines(lines):
    """Count log lines per level.

    Expected line format: "<timestamp> <LEVEL> <service>: <message>".
    The level is upper-cased; lines that do not match are ignored.
    Returns a plain dict mapping level -> count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        match = _LINE_RE.match(line.strip())
        if not match:
            continue
        level = match.group(1).upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
