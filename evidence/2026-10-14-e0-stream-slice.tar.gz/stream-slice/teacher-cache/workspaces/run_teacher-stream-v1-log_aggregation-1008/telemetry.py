def tally_events(lines):
    """Count ERROR lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive; only ERROR lines are counted.
    Malformed lines are skipped. Services with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        _timestamp, level, rest = parts
        if ":" not in rest:
            continue
        service, _message = rest.split(":", 1)
        service = service.strip()
        if not service:
            continue
        if level.upper() != "ERROR":
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
