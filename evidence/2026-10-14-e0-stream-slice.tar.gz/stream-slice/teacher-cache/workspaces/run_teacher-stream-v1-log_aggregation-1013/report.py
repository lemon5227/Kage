def aggregate_log(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(" ", 2)
        if len(parts) != 3:
            continue
        timestamp, level, rest = parts
        if not timestamp or not level:
            continue
        if ":" not in rest:
            continue
        service, _, message = rest.partition(":")
        service = service.strip()
        if not service:
            continue
        level = level.upper()
        if level not in ("ERROR", "WARN"):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
