def summarize(lines):
    """Summarize log lines by service for WARN-level entries.

    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"

    Returns a dict mapping service name -> count of WARN lines.
    Level matching is case-insensitive; malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        if level.upper() != "WARN":
            continue
        service = parts[2]
        if not service.endswith(":"):
            continue
        name = service[:-1]
        if not name:
            continue
        counts[name] = counts.get(name, 0) + 1
    return counts
