def count_entries(lines):
    """Count log entries by level, handling format: <timestamp> <LEVEL> <service>: <message>"""
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
            
        # Check format: first part is timestamp, second is LEVEL, third should be "service:"
        level = parts[1].upper()
        
        # Validate that the third part starts with "service:"
        if not parts[2].startswith("service:"):
            continue
            
        # Count this entry
        counts[level] = counts.get(level, 0) + 1
    
    return counts
