def count_entries(lines):
    """Count log entries for ERROR and WARN levels per service.
    
    Expected format: "<timestamp> <LEVEL> <service>: <message>"
    Returns: {service_name: count} with uppercase keys, only for ERROR/WARN.
    Malformed lines are dropped.
    """
    counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive comparison
        service = parts[2]
        
        # Check if level is ERROR or WARN
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Increment count for this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
