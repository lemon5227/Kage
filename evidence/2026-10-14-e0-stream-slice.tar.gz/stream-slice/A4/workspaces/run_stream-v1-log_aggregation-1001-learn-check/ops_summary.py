def summarize(lines):
    """Count ERROR level log lines per service.
    
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each service for levels ERROR only to how many lines it has.
    Levels are case-insensitive (report them upper-case). Skip malformed lines. Omit keys with zero count.
    """
    service_counts = {}
    
    for line in lines:
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        level = parts[1].upper()
        service = parts[2]
        
        # Only count ERROR level
        if level != 'ERROR':
            continue
        
        # Increment count for this service
        service_counts[service] = service_counts.get(service, 0) + 1
    
    return service_counts
