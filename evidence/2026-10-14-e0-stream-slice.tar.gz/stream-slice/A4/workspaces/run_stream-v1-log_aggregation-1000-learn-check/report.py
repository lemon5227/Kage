def digest_lines(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        # Format: <timestamp> <LEVEL> <service>: <message>
        level = parts[1].upper()
        service = parts[2].split(':')[0]
        if level in ('ERROR', 'WARN'):
            counts[service] = counts.get(service, 0) + 1
    return counts
