def aggregate_log(lines):
    """Aggregate log lines per service for WARN level only.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    - Level is case-insensitive and must be upper-cased
    - Only counts lines with WARN level
    - Returns a dict mapping service names to counts
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Check if the second part is a valid level (case-insensitive)
        level = parts[1].upper()
        
        # Only process WARN level
        if level != 'WARN':
            continue
        
        # Extract service name (third part, before colon)
        service_part = parts[2]
        
        # Check if service part contains a colon
        if ':' not in service_part:
            continue
        
        service = service_part.split(':')[0]
        
        # Count this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
