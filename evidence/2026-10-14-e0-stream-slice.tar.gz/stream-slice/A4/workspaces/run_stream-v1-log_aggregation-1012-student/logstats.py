def tally_events(lines):
    """Count occurrences of log levels in lines.
    
    Each line format: <timestamp> <LEVEL> <service>: <message>
    Returns a dict mapping each level (upper-case) to its count.
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line or not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
            
        # Extract level (second part)
        level = parts[1].upper()
        
        # Skip if level is empty or not a valid log level
        if not level:
            continue
            
        # Increment count for this level
        counts[level] = counts.get(level, 0) + 1
    
    # Return only non-zero counts (already handled by dict)
    return counts
