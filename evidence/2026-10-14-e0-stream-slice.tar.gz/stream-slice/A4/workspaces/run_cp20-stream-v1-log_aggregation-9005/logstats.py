def count_entries(lines):
    """Count ERROR entries per service from log lines.
    
    Each line looks like: "<timestamp> <LEVEL> <service>: <message>"
    Returns a dict mapping each service for levels ERROR only to count.
    Levels are case-insensitive (reported upper-case). Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    error_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        level = parts[1].upper()
        service = parts[2]
        
        # Check if it's an ERROR level
        if level == "ERROR":
            error_counts[service] = error_counts.get(service, 0) + 1
    
    return error_counts
