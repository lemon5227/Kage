def tally_events(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip lines that don't match the format
        
        # Check if the second part is a valid level (non-empty string)
        level = parts[1].upper()
        if not level:
            continue
            
        counts[level] = counts.get(level, 0) + 1
    
    return counts
