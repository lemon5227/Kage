def aggregate_log(lines):
    """Aggregate log lines by level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    - Level case may vary and must be upper-cased
    - Ignore lines that do not match the format
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip lines that don't match format
        
        # Check if third part starts with service name followed by colon
        if not parts[2].startswith(':'):
            continue
            
        # Extract level from second part and upper-case it
        level = parts[1].upper()
        
        # Count the level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
