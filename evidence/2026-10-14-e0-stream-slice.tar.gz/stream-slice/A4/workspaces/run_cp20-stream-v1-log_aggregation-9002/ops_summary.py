def aggregate_log(lines):
    """Aggregate log lines by level, returning a dict of level -> count.
    
    Each line format: '<timestamp> <LEVEL> <service>: <message>'
    Levels are case-insensitive (reported upper-case).
    Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
            
        timestamp = parts[0]
        level = parts[1].upper()
        rest = ' '.join(parts[2:])
        
        # Check if the format is correct: should have "service:" pattern
        # The third part should be a service name followed by colon
        if not rest.startswith(':'):
            continue
            
        # Extract service name (optional, but we need to ensure valid format)
        # Actually, the requirement says lines look like "<timestamp> <LEVEL> <service>: <message>"
        # So we need to verify that parts[2] ends with ':' or that rest starts with ':'
        # Let's be more strict: check that parts[2] contains a colon
        if ':' not in parts[2]:
            continue
            
        # Count this level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    # Return only non-zero counts
    return {level: count for level, count in level_counts.items() if count > 0}
