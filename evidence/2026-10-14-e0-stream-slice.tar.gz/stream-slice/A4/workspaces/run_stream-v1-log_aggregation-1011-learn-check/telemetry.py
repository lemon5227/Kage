def summarize(lines):
    """Summarize log lines formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns a dict {name: count} for WARN level entries only, with uppercase keys.
    Malformed lines are dropped.
    """
    service_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed line
        
        # Extract level from parts[1]
        level = parts[1].upper()
        
        # Check if level is WARN (case-insensitive)
        if level != 'WARN':
            continue
            
        # Extract service from parts[2]
        service = parts[2]
        
        # Count the service
        service_counts[service] = service_counts.get(service, 0) + 1
    
    return service_counts
