def digest_lines(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        # Format: <timestamp> <LEVEL> <service>: <message>
        # At least 3 parts needed: timestamp, level, and service: message
        if len(parts) < 3:
            continue
        # The second part is the level
        level = parts[1].upper()
        # Check that there's a colon after the service name (at least 3 parts)
        # The third part should contain a colon to match "service:"
        if ':' not in parts[2]:
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts
