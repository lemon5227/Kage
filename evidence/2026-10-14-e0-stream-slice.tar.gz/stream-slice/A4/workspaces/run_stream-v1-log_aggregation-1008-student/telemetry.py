def tally_events(lines):
    """
    Process telemetry lines and count ERROR level events per service.
    
    Each line format: <timestamp> <LEVEL> <service>: <message>
    Returns a dict mapping each service (for ERROR level only) to its count.
    Levels are case-insensitive (reported as upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    error_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Check if the line has the expected format (service should be followed by ':')
        # The format is: <timestamp> <LEVEL> <service>: <message>
        # We need to ensure that after the service there's a colon
        if not service.endswith(':'):
            continue
        
        # Only count ERROR level events
        if level == 'ERROR':
            error_counts[service] = error_counts.get(service, 0) + 1
    
    return error_counts
