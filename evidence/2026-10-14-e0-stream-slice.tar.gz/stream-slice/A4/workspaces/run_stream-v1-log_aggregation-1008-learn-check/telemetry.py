def tally_events(lines):
    """
    Parse lines in format: "<timestamp> <LEVEL> <service>: <message>"
    Return a dict mapping each service for levels ERROR only to count.
    Levels are case-insensitive (report them upper-case).
    Skip malformed lines. Omit keys with zero count.
    """
    result = {}
    for line in lines:
        parts = line.strip().split()
        if len(parts) < 3:
            continue  # Skip malformed lines
        
        # parts[0] = timestamp, parts[1] = LEVEL, parts[2] = service: ...
        level = parts[1].upper()
        if level != "ERROR":
            continue
        
        # Extract service name (parts[2] ends with ':')
        service_part = parts[2]
        if not service_part.endswith(':'):
            continue  # Skip malformed lines
        
        service = service_part[:-1]
        result[service] = result.get(service, 0) + 1
    
    return result
