def aggregate_log(lines):
    """
    Parse log lines in format: '<timestamp> <LEVEL> <service>: <message>'
    Return a dict mapping each service for levels ERROR only to count.
    Levels are case-insensitive (reported upper-case). Skip malformed lines.
    Omit keys with zero count.
    """
    error_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
            
        timestamp = parts[0]
        level = parts[1].upper()
        service_part = parts[2]
        
        # Check if service part contains colon (service: message)
        if ':' not in service_part:
            continue
            
        service = service_part.split(':')[0]
        
        # Only count ERROR level
        if level == 'ERROR':
            error_counts[service] = error_counts.get(service, 0) + 1
    
    # Return only services with non-zero counts
    return {k: v for k, v in error_counts.items() if v > 0}
