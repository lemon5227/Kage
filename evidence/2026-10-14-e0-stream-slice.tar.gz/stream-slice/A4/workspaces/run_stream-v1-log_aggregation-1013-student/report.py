def aggregate_log(lines):
    """Aggregate log lines by service for ERROR and WARN levels.
    
    Each line format: '<timestamp> <LEVEL> <service>: <message>'
    Returns a dict mapping service to count of ERROR/WARN lines.
    Levels are case-insensitive (reported upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        if len(parts) < 3:
            # Malformed line (need at least timestamp, level, service)
            continue
            
        timestamp = parts[0]
        level = parts[1].upper()
        
        # Check if level is ERROR or WARN
        if level not in ('ERROR', 'WARN'):
            continue
            
        # Service is after the colon
        rest = parts[2]
        if ':' not in rest:
            # Malformed line (service should be followed by colon)
            continue
            
        service = rest.split(':')[0]
        
        # Count this line for the service
        counts[service] = counts.get(service, 0) + 1
    
    # Return only services with non-zero counts
    return {k: v for k, v in counts.items() if v > 0}
