def aggregate_log(lines):
    """Aggregate log strings formatted as '<timestamp> <LEVEL> <service>: <message>' into a dict mapping level names (uppercase) to counts."""
    level_counts = {}
    
    for line in lines:
        # Split the line into parts
        parts = line.split()
        
        # Need at least 4 parts: timestamp, LEVEL, service, and message (or at least up to service)
        if len(parts) < 4:
            continue
        
        # Check format: first part is timestamp, second is LEVEL, third should be service followed by colon
        # The pattern is: <timestamp> <LEVEL> <service>: <message>
        # We need to ensure the third part ends with ':'
        if parts[2].endswith(':'):
            level = parts[1].upper()  # Case-insensitive, store as uppercase
            level_counts[level] = level_counts.get(level, 0) + 1
    
    return level_counts
