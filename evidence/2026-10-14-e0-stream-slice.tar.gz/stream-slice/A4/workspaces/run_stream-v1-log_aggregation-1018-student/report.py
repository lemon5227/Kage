def digest_lines(lines):
    """Parse log lines and count occurrences of each level."""
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Check format: <timestamp> <LEVEL> <service>: <message>
        # The third part should end with ':'
        if parts[2].endswith(':'):
            level = parts[1].upper()
            level_counts[level] = level_counts.get(level, 0) + 1
    
    # Return only non-zero counts (already filtered by dict)
    return level_counts
