def count_entries(lines):
    """Count log entries by level, handling format '<timestamp> <LEVEL> <service>: <message>'"""
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # malformed line
        try:
            timestamp, level, rest = parts[0], parts[1], ' '.join(parts[2:])
            # Validate format: should have service: message after level
            if not rest.startswith(':'):
                continue  # malformed line
            # Extract service and message (not needed for counting)
            # Count by level, case-insensitive, store as uppercase key
            level_upper = level.upper()
            counts[level_upper] = counts.get(level_upper, 0) + 1
        except Exception:
            continue  # malformed line
    return counts
