def summarize(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match.
    """
    counts = {}
    for line in lines:
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            continue
        
        # Check if the second part is a valid level (must be uppercase)
        level = parts[1].upper()
        if not level.isalpha():
            continue
        
        # Count the level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
