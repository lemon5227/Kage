def count_entries(lines):
    """Count log entries per service for ERROR and WARN levels only.
    
    Expected format: "<timestamp> <LEVEL> <service>: <message>"
    Returns: {name: count} with uppercase keys, dropping malformed lines.
    """
    counts = {}
    accepted_levels = ['ERROR', 'WARN']
    
    for line in lines:
        parts = line.strip().split()
        if len(parts) < 3:
            continue  # Skip malformed lines
        
        # parts[0] = timestamp, parts[1] = level, parts[2] = service (with trailing colon)
        level = parts[1].upper()
        service = parts[2].rstrip(':')
        
        if level in accepted_levels:
            counts[service] = counts.get(service, 0) + 1
    
    return counts
