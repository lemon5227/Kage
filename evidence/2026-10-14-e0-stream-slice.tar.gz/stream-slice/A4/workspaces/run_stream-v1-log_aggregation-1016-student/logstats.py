def tally_events(lines):
    """Count log lines per service for ERROR and WARN levels only.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level is case-insensitive and should be upper-cased.
    Ignore lines that do not match the expected format.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip lines that don't match format
        
        # Check if second part is ERROR or WARN (case-insensitive)
        level = parts[1].upper()
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Extract service from third part (before the colon)
        service_part = parts[2]
        if ':' not in service_part:
            continue  # Skip lines without colon
        
        service = service_part.split(':')[0]
        
        counts[service] = counts.get(service, 0) + 1
    
    return counts
