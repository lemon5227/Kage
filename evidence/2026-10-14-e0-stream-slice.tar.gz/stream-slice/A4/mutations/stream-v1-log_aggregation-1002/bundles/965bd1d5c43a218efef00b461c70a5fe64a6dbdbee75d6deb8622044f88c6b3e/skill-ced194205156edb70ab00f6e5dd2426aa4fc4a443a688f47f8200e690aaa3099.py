import os

def run(arguments, context):
    file_path = arguments['file_path']
    function_name = arguments['function_name']
    level = arguments['level']
    workspace = context['workspace_dir']
    full_path = os.path.join(workspace, file_path)

    # Read existing file content if it exists
    if os.path.exists(full_path):
        with open(full_path, 'r') as f:
            content = f.read()
    else:
        content = ''

    # Generate the function code
    func_code = f'''def {function_name}(lines):
    """Count lines of level {level} per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive. Malformed lines are skipped.
    Returns a dict mapping service -> count for {level} lines only,
    omitting services with a zero count.
    """
    counts = {{}}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        lvl = parts[1].upper()
        if lvl != "{level.upper()}":
            continue
        service_part = parts[2]
        if not service_part.endswith(":"):
            continue
        service = service_part[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
'''

    # Replace existing function definition or append
    import re
    pattern = re.compile(r'^def\s+' + re.escape(function_name) + r'\s*\(.*?\)\s*:.*?(?=^\S|\Z)', re.MULTILINE | re.DOTALL)
    if pattern.search(content):
        new_content = pattern.sub(func_code, content)
    else:
        if content and not content.endswith('\n'):
            content += '\n'
        new_content = content + func_code

    # Write back
    with open(full_path, 'w') as f:
        f.write(new_content)

    return {"success": True, "file_path": file_path, "function_name": function_name, "level": level}
