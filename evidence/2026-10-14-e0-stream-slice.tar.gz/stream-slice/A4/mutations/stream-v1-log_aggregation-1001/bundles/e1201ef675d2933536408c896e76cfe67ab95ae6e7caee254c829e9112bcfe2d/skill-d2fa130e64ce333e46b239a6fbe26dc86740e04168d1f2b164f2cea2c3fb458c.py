import os
import re


def run(arguments, context):
    file_path = arguments['file_path']
    function_name = arguments['function_name']
    level = arguments['level']
    input_param = arguments.get('input_param', 'lines')

    workspace = context.get('workspace_dir', '.')
    full_path = os.path.join(workspace, file_path)

    if not os.path.exists(full_path):
        return {'success': False, 'error': f'File not found: {file_path}'}

    with open(full_path, 'r', encoding='utf-8') as f:
        source = f.read()

    level_upper = level.upper()

    new_func = (
        f"def {function_name}({input_param}):\n"
        f"    \"\"\"Count {level_upper} lines per service.\"\"\"\n"
        f"    counts = {{}}\n"
        f"    for line in {input_param}:\n"
        f"        if not isinstance(line, str):\n"
        f"            continue\n"
        f"        parts = line.split(None, 2)\n"
        f"        if len(parts) < 3:\n"
        f"            continue\n"
        f"        _timestamp, lvl, rest = parts\n"
        f"        if lvl.upper() != {level_upper!r}:\n"
        f"            continue\n"
        f"        if ':' not in rest:\n"
        f"            continue\n"
        f"        service = rest.split(':', 1)[0].strip()\n"
        f"        if not service:\n"
        f"            continue\n"
        f"        counts[service] = counts.get(service, 0) + 1\n"
        f"    return counts\n"
    )

    pattern = re.compile(
        r'^def\s+' + re.escape(function_name) + r'\s*\(.*?\)\s*:.*?(?=^\S|\Z)',
        re.MULTILINE | re.DOTALL,
    )

    if pattern.search(source):
        new_source = pattern.sub(new_func, source, count=1)
    else:
        new_source = source.rstrip() + '\n\n\n' + new_func

    with open(full_path, 'w', encoding='utf-8') as f:
        f.write(new_source)

    return {
        'success': True,
        'file_path': file_path,
        'function_name': function_name,
        'level': level_upper,
    }
