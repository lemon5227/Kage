import os


def run(arguments, context):
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    allowed_levels = [lvl.upper() for lvl in arguments["allowed_levels"]]
    count_field = arguments.get("count_field", "service")

    if count_field != "service":
        return {"success": False, "error": "unsupported count_field: %s" % count_field}

    workspace = context["workspace_dir"]
    full_path = os.path.join(workspace, file_path)

    allowed_repr = repr(tuple(allowed_levels))

    source = (
        "import re\n"
        "\n"
        "_LINE_RE = re.compile(r\"^\\S+\\s+(\\S+)\\s+([^:]+):\\s\")\n"
        "_ALLOWED = set(%s)\n"
        "\n"
        "\n"
        "def %s(lines):\n"
        "    counts = {}\n"
        "    for line in lines:\n"
        "        m = _LINE_RE.match(line)\n"
        "        if not m:\n"
        "            continue\n"
        "        level = m.group(1).upper()\n"
        "        if level not in _ALLOWED:\n"
        "            continue\n"
        "        service = m.group(2).strip()\n"
        "        counts[service] = counts.get(service, 0) + 1\n"
        "    return counts\n"
    ) % (allowed_repr, function_name)

    with open(full_path, "w") as f:
        f.write(source)

    return {"success": True, "path": file_path, "source": source}
