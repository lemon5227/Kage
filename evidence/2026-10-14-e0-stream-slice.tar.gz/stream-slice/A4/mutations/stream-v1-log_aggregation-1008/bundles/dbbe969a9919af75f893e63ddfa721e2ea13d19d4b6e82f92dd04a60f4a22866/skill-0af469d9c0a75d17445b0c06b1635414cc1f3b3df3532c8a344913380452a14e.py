import os
import re

def run(arguments, context):
    file_path = arguments['file_path']
    function_name = arguments['function_name']
    level_filter = arguments['level_filter'].upper()
    key_field = arguments['key_field']
    workspace = context['workspace_dir']
    full_path = os.path.join(workspace, file_path)

    # Read existing file content if it exists
    if os.path.exists(full_path):
        with open(full_path, 'r') as f:
            content = f.read()
    else:
        content = ''

    # Generate the function implementation
    func_code = f'''def {function_name}(lines):
    """Count {level_filter} lines per {key_field}.

    Each line looks like "<timestamp> <LEVEL> <{key_field}>: <message>".
    Levels are case-insensitive; only {level_filter} lines are counted.
    Malformed lines are skipped. {key_field.capitalize()}s with zero count are omitted.
    """
    counts = {{}}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        _timestamp, level, rest = parts
        if ":" not in rest:
            continue
        {key_field}, _message = rest.split(":", 1)
        {key_field} = {key_field}.strip()
        if not {key_field}:
            continue
        if level.upper() != "{level_filter}":
            continue
        counts[{key_field}] = counts.get({key_field}, 0) + 1
    return counts
'''

    # Replace existing function definition or append
    pattern = re.compile(r'^def\s+' + re.escape(function_name) + r'\s*\(.*?\)\s*:.*?(?=^\S|\Z)', re.MULTILINE | re.DOTALL)
    if pattern.search(content):
        new_content = pattern.sub(func_code, content)
    else:
        new_content = content.rstrip() + '\n\n' + func_code

    # Write the updated file
    with open(full_path, 'w') as f:
        f.write(new_content)

    return {
        'success': True,
        'file_path': file_path,
        'function_name': function_name,
        'message': f'Implemented {function_name} in {file_path}'
    }
