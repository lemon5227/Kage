import ast
import re
from pathlib import Path


def _build_function_source(function_name, allowed_levels):
    levels_literal = repr([str(level).upper() for level in allowed_levels])
    return (
        f"def {function_name}(lines):\n"
        f"    import re\n"
        f"    allowed = set({levels_literal})\n"
        f"    pattern = re.compile(r'^\\S+\\s+(\\S+)\\s+([^:\\s]+):\\s*(.*)$')\n"
        f"    counts = {{}}\n"
        f"    for line in lines:\n"
        f"        match = pattern.match(line.strip())\n"
        f"        if not match:\n"
        f"            continue\n"
        f"        level = match.group(1).upper()\n"
        f"        if level not in allowed:\n"
        f"            continue\n"
        f"        service = match.group(2)\n"
        f"        counts[service] = counts.get(service, 0) + 1\n"
        f"    return counts\n"
    )


def _replace_function(source, function_name, new_source):
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name:
            start = node.lineno - 1
            end = node.end_lineno
            return ''.join(lines[:start]) + new_source + ''.join(lines[end:])
    return source.rstrip() + '\n\n' + new_source


def run(arguments, context):
    workspace = Path(context['workspace_dir'])
    file_path = workspace / arguments['file_path']
    function_name = arguments['function_name']
    allowed_levels = arguments['allowed_levels']

    if not file_path.exists():
        return {'success': False, 'error': f'File not found: {arguments["file_path"]}'}

    source = file_path.read_text(encoding='utf-8')
    new_source = _build_function_source(function_name, allowed_levels)
    updated = _replace_function(source, function_name, new_source)
    file_path.write_text(updated, encoding='utf-8')

    return {
        'success': True,
        'file_path': arguments['file_path'],
        'function_name': function_name,
        'allowed_levels': [str(level).upper() for level in allowed_levels],
    }
