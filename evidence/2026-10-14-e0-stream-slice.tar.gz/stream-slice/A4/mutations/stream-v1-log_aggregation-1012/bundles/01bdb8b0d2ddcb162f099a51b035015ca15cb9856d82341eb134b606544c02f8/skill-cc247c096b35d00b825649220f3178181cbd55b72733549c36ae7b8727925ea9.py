def run(arguments, context):
    import os

    file_path = arguments["file_path"]
    function_name = arguments["function_name"]

    workspace = context.get("workspace_dir", ".")
    target = os.path.join(workspace, file_path)
    os.makedirs(os.path.dirname(target) or ".", exist_ok=True)

    source = '''def {fn}(lines):
    """Count log lines by level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive and reported upper-case. Malformed lines
    are skipped, and levels with a zero count are omitted.
    """
    counts = {{}}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        if not level.isalpha():
            continue
        if not parts[2].endswith(":"):
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
'''.format(fn=function_name)

    with open(target, "w", encoding="utf-8") as fh:
        fh.write(source)

    return {"success": True, "path": file_path, "function": function_name}
