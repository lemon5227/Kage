import os
import re


def _build_source(function_name, target_level, output_key_case):
    level_literal = repr(target_level.upper())
    case_literal = repr(output_key_case)
    template = (
        "def {fn}(lines):\n"
        "    \"\"\"Summarize log lines by service for {lvl}-level entries.\"\"\"\n"
        "    counts = {{}}\n"
        "    target = {lvl}\n"
        "    key_case = {kc}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        parts = line.split()\n"
        "        if len(parts) < 3:\n"
        "            continue\n"
        "        level = parts[1]\n"
        "        if level.upper() != target:\n"
        "            continue\n"
        "        service = parts[2]\n"
        "        if not service.endswith(':'):\n"
        "            continue\n"
        "        name = service[:-1]\n"
        "        if not name:\n"
        "            continue\n"
        "        if key_case == 'upper':\n"
        "            name = name.upper()\n"
        "        elif key_case == 'lower':\n"
        "            name = name.lower()\n"
        "        counts[name] = counts.get(name, 0) + 1\n"
        "    return counts\n"
    )
    return template.format(fn=function_name, lvl=level_literal, kc=case_literal)


def _replace_function(source, function_name, new_source):
    pattern = re.compile(
        r"^def\s+" + re.escape(function_name) + r"\s*\([^)]*\)\s*:",
        re.MULTILINE,
    )
    match = pattern.search(source)
    if not match:
        return source.rstrip() + "\n\n\n" + new_source
    start = match.start()
    rest = source[match.end():]
    lines = rest.splitlines(keepends=True)
    end_offset = 0
    for i, line in enumerate(lines):
        stripped = line.strip()
        if i == 0:
            end_offset += len(line)
            continue
        if stripped == "" or line[:1] in (" ", "\t"):
            end_offset += len(line)
            continue
        break
    end = match.end() + end_offset
    return source[:start] + new_source + source[end:]


def run(arguments, context):
    workspace = context.get("workspace_dir", ".")
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    target_level = arguments.get("target_level", "WARN")
    output_key_case = arguments.get("output_key_case", "preserve")

    full_path = os.path.join(workspace, file_path)
    if os.path.exists(full_path):
        with open(full_path, "r", encoding="utf-8") as fh:
            source = fh.read()
    else:
        source = ""

    new_source = _build_source(function_name, target_level, output_key_case)
    updated = _replace_function(source, function_name, new_source)

    os.makedirs(os.path.dirname(full_path) or ".", exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as fh:
        fh.write(updated)

    return {
        "success": True,
        "file_path": file_path,
        "function_name": function_name,
        "target_level": target_level,
        "output_key_case": output_key_case,
        "bytes_written": len(updated),
    }
