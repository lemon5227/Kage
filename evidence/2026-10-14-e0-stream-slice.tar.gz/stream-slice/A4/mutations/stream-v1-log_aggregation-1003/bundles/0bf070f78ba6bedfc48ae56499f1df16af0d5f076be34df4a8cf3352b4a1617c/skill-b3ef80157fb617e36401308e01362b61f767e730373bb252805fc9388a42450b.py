import os
import re


def _build_function_source(function_name, accepted_levels, service_index, level_index):
    levels_repr = repr(tuple(accepted_levels))
    return (
        "def {name}(lines):\n"
        "    \"\"\"Count log entries per service for accepted levels.\n\n"
        "    Each line is expected to be formatted as:\n"
        "        '<timestamp> <LEVEL> <service>: <message>'\n\n"
        "    Levels are matched case-insensitively; only accepted levels are\n"
        "    counted. Malformed lines are dropped.\n\n"
        "    Returns a dict mapping service name -> count.\n"
        "    \"\"\"\n"
        "    accepted = {levels}\n"
        "    counts = {{}}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        parts = line.split()\n"
        "        if len(parts) <= max({level_index}, {service_index}):\n"
        "            continue\n"
        "        level = parts[{level_index}].upper()\n"
        "        if level not in accepted:\n"
        "            continue\n"
        "        service = parts[{service_index}]\n"
        "        if service.endswith(':'):\n"
        "            service = service[:-1]\n"
        "        if not service:\n"
        "            continue\n"
        "        counts[service] = counts.get(service, 0) + 1\n"
        "    return counts\n"
    ).format(
        name=function_name,
        levels=levels_repr,
        level_index=level_index,
        service_index=service_index,
    )


def _replace_function(source, function_name, new_source):
    pattern = re.compile(
        r"^(?P<indent>[ \t]*)(?:async[ \t]+)?def[ \t]+" + re.escape(function_name) + r"[ \t]*\(",
        re.MULTILINE,
    )
    match = pattern.search(source)
    if not match:
        if source and not source.endswith("\n"):
            source += "\n"
        return source + "\n" + new_source

    start = match.start()
    indent = match.group("indent")
    lines = source[start:].splitlines(keepends=True)
    end_offset = len(lines[0])
    for line in lines[1:]:
        stripped = line.strip()
        if stripped and not line.startswith(indent + " ") and not line.startswith(indent + "\t"):
            break
        end_offset += len(line)

    indented = "".join(
        (indent + ln if ln.strip() else ln) for ln in new_source.splitlines(keepends=True)
    )
    return source[:start] + indented + source[start + end_offset:]


def run(arguments, context):
    workspace = context.get("workspace_dir") or "."
    target_file = arguments["target_file"]
    function_name = arguments["function_name"]
    accepted_levels = arguments.get("accepted_levels") or ["ERROR", "WARN"]
    service_index = arguments.get("service_index", 2)
    level_index = arguments.get("level_index", 1)

    path = os.path.join(workspace, target_file)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as fh:
            source = fh.read()
    else:
        source = ""

    new_source = _build_function_source(
        function_name, accepted_levels, service_index, level_index
    )
    updated = _replace_function(source, function_name, new_source)

    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(updated)

    return {
        "success": True,
        "target_file": target_file,
        "function_name": function_name,
        "accepted_levels": list(accepted_levels),
        "bytes_written": len(updated.encode("utf-8")),
    }
