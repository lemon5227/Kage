import os
import re


def _build_source(function_name, lines_param, counts_var, line_pattern, level_group):
    pattern_literal = repr(line_pattern)
    return (
        "import re\n\n"
        "_LINE_RE = re.compile(" + pattern_literal + ")\n\n\n"
        "def " + function_name + "(" + lines_param + "):\n"
        "    " + counts_var + " = {}\n"
        "    for line in " + lines_param + ":\n"
        "        match = _LINE_RE.match(line)\n"
        "        if not match:\n"
        "            continue\n"
        "        level = match.group(" + str(level_group) + ").upper()\n"
        "        " + counts_var + "[level] = " + counts_var + ".get(level, 0) + 1\n"
        "    return " + counts_var + "\n"
    )


def run(arguments, context):
    workspace = context.get("workspace_dir") or "."
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    lines_param = arguments.get("lines_param", "lines")
    counts_var = arguments.get("counts_var", "counts")
    line_pattern = arguments.get("line_pattern", r"^\S+\s+([A-Za-z]+)\s+\S+:\s")
    level_group = int(arguments.get("level_group", 1))

    # Validate the pattern compiles and has the requested capture group.
    try:
        compiled = re.compile(line_pattern)
    except re.error as exc:
        return {"success": False, "error": "invalid line_pattern: %s" % exc}
    if compiled.groups < level_group:
        return {
            "success": False,
            "error": "line_pattern has %d capture groups, need group %d"
            % (compiled.groups, level_group),
        }

    target = os.path.join(workspace, file_path)
    if not os.path.isfile(target):
        return {"success": False, "error": "file not found: %s" % file_path}

    source = _build_source(
        function_name, lines_param, counts_var, line_pattern, level_group
    )

    with open(target, "w", encoding="utf-8") as handle:
        handle.write(source)

    return {
        "success": True,
        "path": file_path,
        "function": function_name,
        "bytes_written": len(source.encode("utf-8")),
    }
