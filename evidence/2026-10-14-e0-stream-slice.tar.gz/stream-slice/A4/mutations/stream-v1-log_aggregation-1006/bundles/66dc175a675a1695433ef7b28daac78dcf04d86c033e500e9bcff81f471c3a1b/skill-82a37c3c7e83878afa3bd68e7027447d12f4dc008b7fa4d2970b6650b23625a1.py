import os
import re


def _default_pattern():
    return r"^\S+ +(\S+) +\S+:"


def _build_function_source(function_name, pattern):
    return (
        "import re\n\n"
        "_LINE_RE = re.compile(r" + repr(pattern) + ")\n\n\n"
        "def " + function_name + "(lines):\n"
        "    \"\"\"Count log lines per level.\n\n"
        "    Line format: \"<timestamp> <LEVEL> <service>: <message>\".\n"
        "    Level case may vary and is upper-cased. Lines that do not match\n"
        "    the format are ignored. Returns a plain dict of counts.\n"
        "    \"\"\"\n"
        "    counts = {}\n"
        "    for line in lines:\n"
        "        if not isinstance(line, str):\n"
        "            continue\n"
        "        match = _LINE_RE.match(line)\n"
        "        if not match:\n"
        "            continue\n"
        "        level = match.group(1).upper()\n"
        "        counts[level] = counts.get(level, 0) + 1\n"
        "    return counts\n"
    )


def _replace_function(source, function_name, new_source):
    pattern = re.compile(
        r"(?ms)^def\s+" + re.escape(function_name) + r"\s*\(.*?(?=^\S|\Z)"
    )
    if pattern.search(source):
        return pattern.sub(new_source.rstrip("\n") + "\n", source, count=1)
    if source and not source.endswith("\n"):
        source += "\n"
    return source + "\n" + new_source


def run(arguments, context):
    workspace = context.get("workspace_dir", ".")
    file_path = arguments["file_path"]
    function_name = arguments["function_name"]
    pattern = arguments.get("line_pattern") or _default_pattern()

    full_path = os.path.join(workspace, file_path)
    if os.path.exists(full_path):
        with open(full_path, "r", encoding="utf-8") as fh:
            source = fh.read()
    else:
        source = ""

    new_source = _build_function_source(function_name, pattern)
    updated = _replace_function(source, function_name, new_source)

    os.makedirs(os.path.dirname(full_path) or ".", exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as fh:
        fh.write(updated)

    return {
        "success": True,
        "file_path": file_path,
        "function_name": function_name,
        "bytes_written": len(updated.encode("utf-8")),
    }
