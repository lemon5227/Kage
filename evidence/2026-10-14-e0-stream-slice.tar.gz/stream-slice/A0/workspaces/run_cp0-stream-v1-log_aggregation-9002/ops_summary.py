def aggregate_log(lines):
    """Aggregate log lines by level, returning a dict of level -> count.
    
    Each line format: <timestamp> <LEVEL> <service>: <message>
    Levels are case-insensitive (reported as uppercase).
    Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        # Extract the level (second token)
        level = parts[1].upper()
        
        # Increment count for this level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    # Return only non-zero counts (already handled by dict)
    return level_counts
