import re

def aggregate_log(lines):
    """Aggregate log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    - Level case may vary and must be upper-cased
    - Ignore lines that do not match the format
    
    Returns a plain dict of counts.
    """
    level_counts = {}
    # Pattern: timestamp (any characters), space, level (any characters), space, service: (service name followed by colon), space, message
    pattern = r'^[\s\S]*?\s+(\S+)\s+(\S+)\s+:\s+(.*)$'
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        match = re.match(pattern, line)
        if match:
            level = match.group(1).upper()
            level_counts[level] = level_counts.get(level, 0) + 1
    
    return level_counts
