def summarize(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split by whitespace
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        # Check format: first part is timestamp, second is LEVEL, third should contain ":"
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, upper-case the level
        rest = ' '.join(parts[2:])
        
        # Verify the line matches the expected format
        # The third part should start with "service:"
        if not rest.startswith(':'):
            continue
        
        # Extract service name (optional, but we just need to verify format)
        # We'll accept any line that has at least 3 parts where the second is a level
        # and the rest starts with ":"
        
        counts[level] = counts.get(level, 0) + 1
    
    return counts
