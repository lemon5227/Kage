def aggregate_log(lines):
    """Count log lines per service for levels ERROR and WARN only.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    """
    service_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        # Extract level and service
        level = parts[1].upper()
        service = parts[2]
        
        # Check if level is ERROR or WARN
        if level in ('ERROR', 'WARN'):
            service_counts[service] = service_counts.get(service, 0) + 1
    
    return service_counts
