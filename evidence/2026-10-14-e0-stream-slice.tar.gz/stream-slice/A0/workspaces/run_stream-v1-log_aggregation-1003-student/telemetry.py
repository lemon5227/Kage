def count_entries(lines):
    """Count log entries per service for ERROR and WARN levels.
    
    Expected format: <timestamp> <LEVEL> <service>: <message>
    Returns: {name: count} per service for levels ERROR, WARN only,
             treating level names case-insensitively (upper-case keys).
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) < 3:
            # Malformed line - skip
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Only process ERROR and WARN levels
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Extract service name (third part, before the colon)
        # Format: <timestamp> <LEVEL> <service>: <message>
        # parts[2] should be the service name
        service = parts[2]
        
        # Count the service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
