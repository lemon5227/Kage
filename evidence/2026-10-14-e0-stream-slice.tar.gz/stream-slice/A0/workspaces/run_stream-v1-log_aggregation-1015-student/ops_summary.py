def aggregate_log(lines):
    """Aggregate log strings into {name: count} per level.
    
    Log format: "<timestamp> <LEVEL> <service>: <message>"
    - Case-insensitive level names, stored as uppercase keys
    - Malformed lines are dropped
    """
    counts = {}
    
    for line in lines:
        # Strip whitespace and check if line is empty
        line = line.strip()
        if not line:
            continue
        
        # Split into parts: timestamp, level, service: message
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, and the rest (service: message)
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, store as uppercase
        rest = ' '.join(parts[2:])
        
        # Check if the rest starts with "service: message"
        # The format is "<service>: <message>"
        if not rest.startswith(':'):
            # Malformed - skip
            continue
        
        # Split off the service name
        service_part, message_part = rest.split(':', 1)
        
        # Extract service name (strip whitespace)
        service_name = service_part.strip()
        
        # If we can't extract a service name, it's malformed
        if not service_name:
            continue
        
        # Increment count for this level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
