def count_entries(lines):
    """Count ERROR level entries per service from log lines.
    
    Each line format: <timestamp> <LEVEL> <service>: <message>
    Returns dict mapping service (for ERROR level) to count.
    Levels are case-insensitive (reported as upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
            
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Only count ERROR level entries
        if level == 'ERROR':
            counts[service] = counts.get(service, 0) + 1
    
    return counts
