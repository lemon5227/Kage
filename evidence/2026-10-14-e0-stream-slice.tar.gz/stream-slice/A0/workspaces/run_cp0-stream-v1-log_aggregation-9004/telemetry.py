import re

def aggregate_log(lines):
    """Aggregate log lines by level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    - Level case may vary and must be upper-cased
    - Ignore lines that do not match the format
    
    Returns a plain dict of counts.
    """
    level_counts = {}
    
    # Pattern to match: timestamp (any chars), level (word), service: (word followed by colon), message (rest)
    pattern = r'^[\s\S]*?\s+(\w+)\s+[\w]+:\s*(.*)$'
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        match = re.match(pattern, line)
        if match:
            level = match.group(1).upper()
            level_counts[level] = level_counts.get(level, 0) + 1
    
    return level_counts
