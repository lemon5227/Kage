def count_entries(lines):
    """Count entries with ERROR level per service."""
    error_counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service:
        if len(parts) < 3:
            continue
        
        # Extract level (second part, case-insensitive)
        level = parts[1].upper()
        
        # Check if it's ERROR
        if level != 'ERROR':
            continue
        
        # Extract service (third part, before the colon)
        service_part = parts[2]
        if ':' not in service_part:
            continue
        
        service = service_part.split(':')[0].strip()
        
        # Count this service
        error_counts[service] = error_counts.get(service, 0) + 1
    
    return error_counts
