def digest_lines(lines):
    """Count occurrences of log levels in lines.
    
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level (case-insensitive, upper-case) to its count.
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Skip if level is empty or not a valid log level
        if not level:
            continue
        
        # Increment count for this level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    # Return only non-zero counts
    return level_counts
