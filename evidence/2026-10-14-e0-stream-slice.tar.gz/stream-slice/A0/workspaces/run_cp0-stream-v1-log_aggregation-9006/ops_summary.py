def count_entries(lines):
    """Count log entries by level, handling format: <timestamp> <LEVEL> <service>: <message>"""
    level_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part)
        level = parts[1].upper()
        
        # Increment count for this level
        level_counts[level] = level_counts.get(level, 0) + 1
    
    return level_counts
