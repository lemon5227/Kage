def tally_events(lines):
    """
    Process telemetry lines and count ERROR level events per service.
    
    Each line format: <timestamp> <LEVEL> <service>: <message>
    Returns a dict mapping service (for ERROR level) to count.
    """
    error_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
            
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report as upper-case
        service = parts[2]
        
        # Only count ERROR level events
        if level == "ERROR":
            error_counts[service] = error_counts.get(service, 0) + 1
    
    # Omit keys with zero count (already handled by not adding them)
    return error_counts
