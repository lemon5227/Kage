def tally_events(lines):
    counts = {}
    for line in lines:
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip lines that don't match format
        
        # Check if the second part is a valid level (ERROR or WARN, case-insensitive)
        level = parts[1].upper()
        if level not in ['ERROR', 'WARN']:
            continue
        
        # The third part should be the service name
        service = parts[2]
        
        # Count the service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
