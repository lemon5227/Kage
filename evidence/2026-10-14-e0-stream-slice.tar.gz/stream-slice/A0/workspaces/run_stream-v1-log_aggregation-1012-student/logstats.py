def tally_events(lines):
    """Count occurrences of log levels in lines.
    
    Each line format: <timestamp> <LEVEL> <service>: <message>
    Returns dict mapping each level (upper-case) to count.
    Skips malformed lines. Omits keys with zero count.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        level = parts[1].upper()
        
        # Skip if level is empty or not a valid log level
        if not level:
            continue
        
        counts[level] = counts.get(level, 0) + 1
    
    # Return only non-zero counts
    return {level: count for level, count in counts.items() if count > 0}
