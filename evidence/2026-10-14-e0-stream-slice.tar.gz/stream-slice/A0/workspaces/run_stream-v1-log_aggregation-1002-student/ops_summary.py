def tally_events(lines):
    """
    Parse lines in format: <timestamp> <LEVEL> <service>: <message>
    Return a dict mapping each service for levels WARN only to count.
    Levels are case-insensitive (reported as upper-case).
    Skip malformed lines. Omit keys with zero count.
    """
    counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()  # Case-insensitive, report as upper-case
        service = parts[2]
        
        # Only count WARN level
        if level == 'WARN':
            counts[service] = counts.get(service, 0) + 1
    
    # Return only services with non-zero counts
    return counts
