def aggregate_log(lines):
    counts = {}
    for line in lines:
        # Parse line format: "<timestamp> <LEVEL> <service>: <message>"
        parts = line.split()
        if len(parts) < 3:
            continue  # ignore lines that don't match
        
        # Check if the second part is a level (case-insensitive)
        level = parts[1].upper()
        if level != 'WARN':
            continue
        
        # Extract service from parts[2] which should be "<service>:"
        service_part = parts[2]
        if not service_part.endswith(':'):
            continue  # ignore lines that don't match format
        
        service = service_part[:-1]
        
        counts[service] = counts.get(service, 0) + 1
    
    return counts
