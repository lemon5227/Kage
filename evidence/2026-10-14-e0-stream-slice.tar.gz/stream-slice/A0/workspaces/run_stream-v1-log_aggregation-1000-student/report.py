def digest_lines(lines):
    """Count log lines per service for levels ERROR and WARN only.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            continue
        
        # Extract level (second part) and service (third part)
        level = parts[1].upper()
        service = parts[2]
        
        # Check if level is ERROR or WARN
        if level in ('ERROR', 'WARN'):
            counts[service] = counts.get(service, 0) + 1
    
    return counts
