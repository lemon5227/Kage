import csv
import io

def normalize_table(text):
    """Clean an exported CSV table.
    
    Input: CSV text with a header row (columns: team, city, email, score, name)
    Output: Cleaned CSV text with the same header
    
    Cleaning steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "city" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "name", keeping the first occurrence
    5. Sort rows by "name" ascending as strings (stable)
    
    Returns: '' for empty input, header-only input returns just the header line
    """
    # Parse the CSV text
    lines = text.strip().split('\n')
    
    if len(lines) == 0:
        return ''
    
    # Check if it's header-only
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    if 'city' not in header or 'name' not in header:
        return ''
    
    # Parse rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) < len(header):
            continue
        
        row = {}
        for i, col in enumerate(header):
            if i < len(cells):
                # Strip whitespace from every cell
                row[col] = cells[i].strip()
            else:
                row[col] = ''
        rows.append(row)
    
    # Drop rows whose "city" cell is empty
    rows = [row for row in rows if row.get('city', '').strip() != '']
    
    # Lower-case the "email" column
    for row in rows:
        row['email'] = row.get('email', '').lower()
    
    # Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        name = row.get('name', '').strip()
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Sort rows by "name" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row.get('name', ''), stable=True)
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write rows
    for row in unique_rows:
        writer.writerow([row.get(col, '') for col in header])
    
    return output.getvalue()
