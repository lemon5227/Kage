def to_v2(cfg):
    """Upgrade settings from version 1 to version 2."""
    # Check if cfg has version 1
    if cfg.get("version") != 1:
        raise ValueError(f"Expected version 1, got {cfg.get('version')}")
    
    # Create new dict with version 2
    result = {"version": 2}
    
    # Rename keys
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    if "user" in cfg:
        result["username"] = cfg["user"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    
    # Move port and workers into limits sub-dict
    limits = {}
    if "port" in cfg:
        limits["port"] = cfg["port"]
    if "workers" in cfg:
        limits["workers"] = cfg["workers"]
    result["limits"] = limits
    
    # Handle timeout_ms
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["max_conn", "user", "pwd_file", "port", "workers", "timeout_ms", "version"]:
            if value is not None:
                result[key] = value
    
    return result
