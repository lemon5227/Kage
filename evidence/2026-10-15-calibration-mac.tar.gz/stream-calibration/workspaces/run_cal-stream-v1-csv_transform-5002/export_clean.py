import csv
import io

def clean_rows(text):
    # Handle empty string
    if not text or not text.strip():
        return ''
    
    # Parse CSV text
    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ''
    
    # Validate header columns: id, team, name, score
    expected_columns = ['id', 'team', 'name', 'score']
    if len(header) != len(expected_columns):
        return ''
    
    # Process rows
    rows = []
    seen_scores = set()
    
    for row in reader:
        # Strip whitespace from each cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip if team is empty
        if not cleaned_row[1]:
            continue
        
        # Remove duplicate rows by score (keep first occurrence)
        score = cleaned_row[3]
        if score in seen_scores:
            continue
        seen_scores.add(score)
        
        rows.append(cleaned_row)
    
    # Sort rows by score ascending as strings (stable sort)
    rows.sort(key=lambda row: row[3])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in rows:
        writer.writerow(row)
    
    return output.getvalue()
