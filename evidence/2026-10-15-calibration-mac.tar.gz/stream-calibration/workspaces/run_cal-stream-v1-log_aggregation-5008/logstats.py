def aggregate_log(lines):
    """Count log lines per service for levels ERROR only.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    """
    service_counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
            
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
            
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Check if the line matches the expected format
        # Format: <timestamp> <LEVEL> <service>: <message>
        # We need to ensure there's a colon after the service name
        if ':' not in service:
            continue
            
        # Only count ERROR level
        if level == 'ERROR':
            service_counts[service] = service_counts.get(service, 0) + 1
    
    return service_counts
