def select_tasks(items, capacity):
    """
    Select tasks to maximize total value while keeping total weight <= capacity.
    
    Args:
        items: List of dicts with keys 'id' (unique string), 'weight' (positive int), 'value' (non-negative int)
        capacity: Maximum total weight allowed
    
    Returns:
        Sorted list of ids of selected tasks
    
    Raises:
        ValueError: If capacity is negative or any weight is <= 0
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if 'id' not in item or 'weight' not in item or 'value' not in item:
            raise ValueError("Each item must have 'id', 'weight', and 'value' keys")
        if not isinstance(item['id'], str):
            raise ValueError("Item id must be a string")
        if item['weight'] <= 0:
            raise ValueError("Weight must be positive")
        if item['value'] < 0:
            raise ValueError("Value must be non-negative")
    
    # Handle empty items list
    if not items:
        return []
    
    n = len(items)
    
    # dp[w] = (max_value, sorted_ids) for weight exactly w
    # We'll use a dictionary to store the best (value, ids) for each weight
    dp = {}
    dp[0] = ([], 0)  # weight 0: empty selection
    
    # Process each item
    for item in items:
        item_id = item['id']
        weight = item['weight']
        value = item['value']
        
        # Create a copy of dp to avoid modifying while iterating
        new_dp = dp.copy()
        
        # For each existing weight, try adding this item
        for w in sorted(dp.keys()):
            if w + weight <= capacity:
                prev_value, prev_ids = dp[w]
                new_value = prev_value + value
                new_ids = prev_ids + [item_id]
                # Sort ids to ensure lexicographic order for tie-breaking
                new_ids.sort()
                
                # Check if this is better than existing entry for w + weight
                new_w = w + weight
                if new_w not in new_dp:
                    new_dp[new_w] = (new_value, new_ids)
                else:
                    existing_value, existing_ids = new_dp[new_w]
                    # Compare: higher value is better, or same value with lexicographically smaller ids
                    if new_value > existing_value:
                        new_dp[new_w] = (new_value, new_ids)
                    elif new_value == existing_value and new_ids < existing_ids:
                        new_dp[new_w] = (new_value, new_ids)
        
        dp = new_dp
    
    # Find the maximum value among all weights <= capacity
    max_value = 0
    best_ids = []
    
    for w in sorted(dp.keys()):
        if w <= capacity:
            value, ids = dp[w]
            if value > max_value:
                max_value = value
                best_ids = ids
            elif value == max_value and ids < best_ids:
                best_ids = ids
    
    return best_ids
