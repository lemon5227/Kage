def aggregate_log(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    - Level case may vary and must be upper-cased
    - Ignore lines that do not match the format
    """
    counts = {}
    for line in lines:
        parts = line.strip().split()
        if len(parts) < 3:
            continue  # Skip lines that don't have at least 3 parts
        
        # Check if third part contains ':' to identify service and message
        if parts[2].startswith(':'):
            continue  # Skip lines where service is not properly formatted
        
        # Extract level from second part
        level = parts[1].upper()
        
        # Count the level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
