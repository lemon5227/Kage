import unicodedata

def label_id(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for char in lower:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            result.append(char)
        else:
            # If we encounter a non-alphanumeric character, add a hyphen only once
            if prev_char is None or prev_char != '-':
                result.append('-')
            prev_char = '-'
    
    # Join and strip leading/trailing hyphens
    slug = ''.join(result)
    slug = slug.strip('-')
    
    return slug
