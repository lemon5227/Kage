import unicodedata
import re


def make_handle(text):
    """Turn a title into a handle.
    
    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with a single '_', and
    strips leading and trailing underscores.
    
    Args:
        text: A string title
        
    Returns:
        A handle string
        
    Raises:
        TypeError: If text is not a string
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single '_'
    handle = re.sub(r'[^a-z0-9]+', '_', lowercased)
    
    # Strip leading and trailing '_'
    handle = handle.strip('_')
    
    return handle
