def summarize(lines):
    """Count log lines per service for levels ERROR and WARN only."""
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        # Parse line format: <timestamp> <LEVEL> <service>: <message>
        parts = line.split()
        if len(parts) < 3:
            continue
        # Extract level (second part) and service (third part before colon)
        level = parts[1].upper()
        service_part = parts[2]
        if ':' not in service_part:
            continue
        service = service_part.split(':')[0]
        # Check if level is ERROR or WARN
        if level in ('ERROR', 'WARN'):
            counts[service] = counts.get(service, 0) + 1
    return counts
