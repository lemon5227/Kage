def aggregate_log(lines):
    """Count log lines per level.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased.
    Ignore lines that do not match the format.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split by whitespace
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, and service:message
        if len(parts) < 3:
            continue
        
        # The second part (index 1) is the log level
        level = parts[1].upper()
        
        # Basic validation: level should be a non-empty string
        if not level:
            continue
        
        # Count the level
        counts[level] = counts.get(level, 0) + 1
    
    return counts
