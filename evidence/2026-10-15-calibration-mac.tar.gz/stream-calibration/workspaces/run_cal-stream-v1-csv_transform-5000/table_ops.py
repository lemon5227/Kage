def normalize_table(text):
    """
    Normalize CSV text with header row (columns: id, name, city).
    
    Process:
    - Strip leading/trailing whitespace from every cell
    - Drop rows whose "id" cell is empty
    - Remove duplicate rows by "id", keeping the first occurrence
    - Sort rows by "city" ascending as strings (stable)
    
    Returns cleaned CSV text with same header, using '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    if not text or not text.strip():
        return ''
    
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Parse header
    header = lines[0].split(',')
    if len(header) != 3 or header[0] != 'id' or header[1] != 'name' or header[2] != 'city':
        return ''
    
    # Process data rows
    data_rows = []
    seen_ids = set()
    
    for line in lines[1:]:
        if not line.strip():
            continue
        
        cells = line.split(',')
        if len(cells) != 3:
            continue
        
        id_val, name_val, city_val = cells[0].strip(), cells[1].strip(), cells[2].strip()
        
        # Drop rows whose "id" cell is empty
        if not id_val:
            continue
        
        # Remove duplicate rows by "id", keeping the first occurrence
        if id_val in seen_ids:
            continue
        seen_ids.add(id_val)
        
        data_rows.append((id_val, name_val, city_val))
    
    # Sort rows by "city" ascending as strings (stable)
    data_rows.sort(key=lambda row: row[2])
    
    # Build output CSV
    output_lines = [','.join(header)]
    for id_val, name_val, city_val in data_rows:
        output_lines.append(f"{id_val},{name_val},{city_val}")
    
    return '\n'.join(output_lines)
