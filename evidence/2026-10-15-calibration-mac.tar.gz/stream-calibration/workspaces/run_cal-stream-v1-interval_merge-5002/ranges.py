def merge_bookings(intervals):
    # Validate intervals first
    for interval in intervals:
        begin = interval["begin"]
        finish = interval["finish"]
        if begin > finish:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by begin time
    sorted_intervals = sorted(intervals, key=lambda x: x["begin"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last = merged[-1]
            # Check if current interval overlaps with the last one
            # Overlap occurs if current begin < last finish (not <=, since touching doesn't merge)
            if interval["begin"] < last["finish"]:
                # Merge by updating the finish time to the maximum of both
                merged[-1]["finish"] = max(last["finish"], interval["finish"])
            else:
                merged.append(interval)
    
    return merged
