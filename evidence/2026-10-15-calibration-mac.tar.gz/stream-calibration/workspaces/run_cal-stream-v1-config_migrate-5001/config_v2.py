def migrate(cfg):
    # Raise ValueError if version is not 1
    if cfg.get("version") != 1:
        raise ValueError("Configuration must be version 1 to migrate")
    
    # Create new config dict with version 2
    new_cfg = {"version": 2}
    
    # Rename top-level keys
    if "host" in cfg:
        new_cfg["hostname"] = cfg["host"]
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    
    # Move retries and workers into network sub-dict
    network = {}
    if "retries" in cfg:
        network["retries"] = cfg["retries"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    new_cfg["network"] = network
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged
    for key, value in cfg.items():
        if key not in ["host", "pwd_file", "retries", "workers", "timeout_ms", "version"]:
            # Drop keys whose value is None
            if value is not None:
                new_cfg[key] = value
    
    return new_cfg
