import unicodedata
import re

def make_handle(text):
    # Check if input is a string
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = re.sub(r'[^a-z0-9]+', '_', lower)
    
    # Strip leading and trailing "_"
    result = result.strip('_')
    
    # If result is longer than 12 characters, cut to 12 and then strip trailing "_"
    if len(result) > 12:
        result = result[:12].strip('_')
    
    return result
