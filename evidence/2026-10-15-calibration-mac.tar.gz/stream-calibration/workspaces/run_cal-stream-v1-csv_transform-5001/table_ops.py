def clean_rows(text):
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines
    lines = text.strip().split('\n')
    
    # Check if header-only input
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    # Expected columns: id, city, score, team, name
    
    # Process data rows
    rows = []
    for line in lines[1:]:
        # Skip empty lines
        if not line.strip():
            continue
        
        cells = line.split(',')
        # Strip whitespace from each cell
        cells = [cell.strip() for cell in cells]
        
        # Ensure we have enough columns
        if len(cells) < 5:
            continue
        
        # Check if city is empty
        if not cells[1]:  # city is at index 1
            continue
        
        # Store row data
        rows.append(cells)
    
    # Remove duplicates by id, keeping first occurrence
    seen_ids = set()
    unique_rows = []
    for row in rows:
        if len(row) < 5:
            continue
        row_id = row[0]
        if row_id not in seen_ids:
            seen_ids.add(row_id)
            unique_rows.append(row)
    
    # Sort by team (index 3) ascending as strings, stable sort
    unique_rows.sort(key=lambda row: row[3])
    
    # Build output CSV
    output_lines = [header[0]]  # header
    for row in unique_rows:
        # Ensure all cells are present
        output_lines.append(','.join(row[:5]))
    
    return '\n'.join(output_lines)
