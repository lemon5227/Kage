def combine_ranges(intervals):
    rep, keys, touching = 'dict', ['start', 'end'], False
    pairs = [(iv[0], iv[1]) if rep == 'pair' else (iv[keys[0]], iv[keys[1]]) for iv in intervals]
    if any(s > e for s, e in pairs):
        raise ValueError('start > end')
    merged = []
    for s, e in sorted(pairs):
        if merged and (s < merged[-1][1] or (touching and s == merged[-1][1])):
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    return merged if rep == 'pair' else [{keys[0]: s, keys[1]: e} for s, e in merged]
