def coalesce(intervals):
    # Check for invalid intervals (start > end)
    for interval in intervals:
        if interval[0] > interval[1]:
            raise ValueError("Interval start > end")
    
    # Sort intervals by start
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        start, end = interval
        if merged and start <= merged[-1][1]:
            # Overlapping or touching - merge
            merged[-1] = [merged[-1][0], max(merged[-1][1], end)]
        else:
            merged.append(interval)
    
    return merged
