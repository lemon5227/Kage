import unicodedata


def label_id(text):
    """Convert a title into a handle."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we replace any sequence of non-alphanumeric characters with a single underscore
    result = []
    prev_char = None
    for char in lower:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is not None:
                result.append('_')
        else:
            result.append(char)
        prev_char = char
    
    # Strip leading and trailing "_"
    handle = ''.join(result).strip('_')
    
    # If the result is longer than 14 characters, cut it to 14 and then strip a trailing "_"
    if len(handle) > 14:
        handle = handle[:14].strip('_')
    
    return handle
