from itertools import combinations


def allocate(items, capacity):
    wkey, vkey = 'weight', 'value'
    if capacity < 0 or any(it[wkey] <= 0 for it in items):
        raise ValueError('invalid input')
    best = (-1, None)
    for r in range(len(items) + 1):
        for combo in combinations(items, r):
            if sum(it[wkey] for it in combo) <= capacity:
                value, ids = sum(it[vkey] for it in combo), sorted(it['id'] for it in combo)
                if value > best[0] or (value == best[0] and ids < best[1]):
                    best = (value, ids)
    return best[1]
