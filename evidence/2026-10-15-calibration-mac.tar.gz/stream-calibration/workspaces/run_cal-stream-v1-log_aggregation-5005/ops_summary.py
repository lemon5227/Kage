def aggregate_log(lines):
    """Count log lines per service for levels WARN only.
    
    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and must be upper-cased; ignore lines that do not match.
    """
    counts = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        # Split the line into parts
        parts = line.split()
        if len(parts) < 3:
            # Line does not match expected format, ignore
            continue
        
        # Extract level (second part) and service (third part before colon)
        level = parts[1].upper()
        
        # Check if the third part contains a colon (service:)
        if len(parts) < 3 or ':' not in parts[2]:
            # Line does not match expected format, ignore
            continue
        
        service = parts[2].split(':')[0]
        
        # Only count WARN level
        if level == 'WARN':
            counts[service] = counts.get(service, 0) + 1
    
    return counts
