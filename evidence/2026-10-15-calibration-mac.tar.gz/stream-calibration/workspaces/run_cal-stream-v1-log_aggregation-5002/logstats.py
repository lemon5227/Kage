def aggregate_log(lines):
    """Aggregate log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns {name: count} per service for levels ERROR only, treating level names
    case-insensitively (upper-case keys), dropping malformed input lines.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, LEVEL, service
        if len(parts) < 3:
            continue
        
        # Extract level (second part) and service (third part)
        level = parts[1].upper()
        service = parts[2]
        
        # Only count ERROR level
        if level != 'ERROR':
            continue
        
        # Increment count for this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
