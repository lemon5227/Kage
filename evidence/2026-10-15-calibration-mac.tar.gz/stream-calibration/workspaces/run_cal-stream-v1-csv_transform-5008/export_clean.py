import csv
import io


def tidy_csv(text):
    """
    Clean CSV text with header row (columns: city, email, score, name).
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "name", keeping first occurrence
    5. Sort rows by "score" ascending as strings (stable)
    
    Returns:
        Cleaned CSV text with same header, or '' if input is empty string.
    """
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Parse the CSV text
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Parse header
    header = lines[0].strip().split(',')
    if len(header) != 4 or header != ['city', 'email', 'score', 'name']:
        return ''
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        cells = line.split(',')
        if len(cells) != 4:
            continue
        
        city, email, score, name = [cell.strip() for cell in cells]
        
        # Drop rows whose "name" cell is empty
        if not name:
            continue
        
        # Lower-case the "email" column
        email = email.lower()
        
        rows.append({
            'city': city,
            'email': email,
            'score': score,
            'name': name
        })
    
    # Remove duplicate rows by "name", keeping first occurrence
    seen_names = set()
    unique_rows = []
    for row in rows:
        if row['name'] not in seen_names:
            seen_names.add(row['name'])
            unique_rows.append(row)
    
    # Sort rows by "score" ascending as strings (stable)
    # Use a secondary key to ensure stability
    unique_rows.sort(key=lambda x: x['score'])
    
    # Build output CSV text
    output_lines = [','.join(header)]
    for row in unique_rows:
        output_lines.append(f"{row['city']},{row['email']},{row['score']},{row['name']}")
    
    return '\n'.join(output_lines)
