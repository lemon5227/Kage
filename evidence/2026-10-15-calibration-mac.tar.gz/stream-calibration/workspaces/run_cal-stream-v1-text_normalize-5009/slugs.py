import unicodedata

def label_id(text):
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for char in lower:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            result.append(char)
        else:
            if prev_char is not None:
                # We're starting a new run of non-alphanumeric characters
                result.append('_')
            prev_char = char
    
    # Join the result
    slug = ''.join(result)
    
    # Strip leading and trailing "_"
    slug = slug.strip('_')
    
    # If the result is longer than 22 characters, cut to 22 and then strip a trailing "_"
    if len(slug) > 22:
        slug = slug[:22]
        slug = slug.rstrip('_')
    
    return slug
