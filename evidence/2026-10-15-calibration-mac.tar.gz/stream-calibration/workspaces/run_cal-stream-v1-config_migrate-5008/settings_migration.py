def upgrade_config(cfg):
    """Upgrade settings from version 1 to version 2."""
    # Check if current version is 1
    if cfg.get("version") != 1:
        raise ValueError(f"Expected version 1, got {cfg.get('version')}")
    
    # Create new config dict
    new_cfg = {"version": 2}
    
    # Rename keys
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    if "dir" in cfg:
        new_cfg["directory"] = cfg["dir"]
    if "host" in cfg:
        new_cfg["hostname"] = cfg["host"]
    
    # Move port and workers into limits
    limits = {}
    if "port" in cfg:
        limits["port"] = cfg["port"]
    if "workers" in cfg:
        limits["workers"] = cfg["workers"]
    new_cfg["limits"] = limits
    
    # Handle timeout_ms
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys with None value)
    for key, value in cfg.items():
        if key not in ["pwd_file", "dir", "host", "port", "workers", "timeout_ms", "version"]:
            if value is not None:
                new_cfg[key] = value
    
    return new_cfg
