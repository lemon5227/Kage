def combine_ranges(intervals):
    """
    Combines overlapping time ranges. Each interval is a dict {"from": s, "to": e} with integer values.
    Returns merged intervals as dicts with the same "from"/"to" keys, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raises ValueError if any interval has start > end.
    Does not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        from_val = interval["from"]
        to_val = interval["to"]
        if not isinstance(from_val, int) or not isinstance(to_val, int):
            raise ValueError("Interval values must be integers")
        if from_val > to_val:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort intervals by 'from' value
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    # Merge overlapping or touching intervals
    merged = []
    if not sorted_intervals:
        return merged
    
    current_from = sorted_intervals[0]["from"]
    current_to = sorted_intervals[0]["to"]
    
    for interval in sorted_intervals[1:]:
        next_from = interval["from"]
        next_to = interval["to"]
        
        # If intervals overlap or touch (next_from <= current_to + 1, but since they're integers and touching means next_from == current_to, we check next_from <= current_to)
        if next_from <= current_to:
            # Merge by extending the current range
            current_to = max(current_to, next_to)
        else:
            # No overlap, add current interval and start a new one
            merged.append({"from": current_from, "to": current_to})
            current_from = next_from
            current_to = next_to
    
    # Add the last interval
    merged.append({"from": current_from, "to": current_to})
    
    return merged
