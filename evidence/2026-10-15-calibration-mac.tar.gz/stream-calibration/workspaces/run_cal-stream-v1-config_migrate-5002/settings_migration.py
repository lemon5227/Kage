def convert_settings(cfg):
    # Check version
    if cfg.get("version") != 1:
        raise ValueError("Only v1 config dicts are supported for migration")
    
    # Create new dict
    new_cfg = {"version": 2}
    
    # Initialize limits dict
    new_cfg["limits"] = {}
    
    # Process keys
    keys = list(cfg.keys())
    for key in keys:
        value = cfg[key]
        
        # Skip None values
        if value is None:
            continue
        
        # Handle specific key transformations
        if key == "host":
            new_cfg["hostname"] = value
        elif key == "dir":
            new_cfg["directory"] = value
        elif key == "cache_size":
            new_cfg["limits"]["cache_size"] = value
        elif key == "retries":
            new_cfg["limits"]["retries"] = value
        elif key == "timeout_ms":
            new_cfg["timeout_s"] = value / 1000.0
        else:
            new_cfg[key] = value
    
    return new_cfg
