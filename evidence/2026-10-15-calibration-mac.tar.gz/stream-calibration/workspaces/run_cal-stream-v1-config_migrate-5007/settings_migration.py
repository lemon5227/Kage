def to_v2(cfg):
    # Raise ValueError unless version is 1
    if cfg.get("version") != 1:
        raise ValueError("Only v1 config dicts can be migrated")
    
    # Create a new dict for the v2 configuration
    result = {"version": 2}
    
    # Process top-level keys
    # Rename keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "user" in cfg:
        result["username"] = cfg["user"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    
    # Handle cache_size and port - move into storage sub-dict
    storage = {}
    if "cache_size" in cfg:
        storage["cache_size"] = cfg["cache_size"]
    if "port" in cfg:
        storage["port"] = cfg["port"]
    result["storage"] = storage
    
    # Handle timeout_ms - convert to timeout_s if exists
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["dir", "user", "max_conn", "cache_size", "port", "timeout_ms"]:
            if value is not None:
                result[key] = value
    
    return result
