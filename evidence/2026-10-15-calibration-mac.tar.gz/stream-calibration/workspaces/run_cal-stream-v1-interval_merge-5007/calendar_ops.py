def merge_bookings(intervals):
    # Check for invalid intervals
    for interval in intervals:
        if interval["begin"] > interval["finish"]:
            raise ValueError("Interval start > finish")
    
    # Sort by begin time
    sorted_intervals = sorted(intervals, key=lambda x: x["begin"])
    
    # Merge overlapping intervals
    merged = []
    for interval in sorted_intervals:
        if not merged:
            merged.append(interval)
        else:
            last = merged[-1]
            # Check if there's a real overlap (not just touching)
            if interval["begin"] < last["finish"]:
                # Overlap exists, merge them
                new_finish = max(last["finish"], interval["finish"])
                merged[-1] = {"begin": last["begin"], "finish": new_finish}
            else:
                # No overlap, add the interval
                merged.append(interval)
    
    return merged
