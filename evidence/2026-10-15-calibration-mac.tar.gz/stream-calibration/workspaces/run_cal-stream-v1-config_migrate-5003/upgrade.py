def to_v2(cfg):
    # Raise ValueError if version is not 1
    if cfg.get("version") != 1:
        raise ValueError("Expected version 1, got " + str(cfg.get("version")))
    
    # Create new dict with version 2
    result = {"version": 2}
    
    # Process keys
    # Rename top-level keys
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    
    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    result["network"] = network
    
    # Handle timeout_ms
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key not in ["version", "pwd_file", "host", "cache_size", "workers", "timeout_ms"]:
            if value is not None:
                result[key] = value
    
    return result
