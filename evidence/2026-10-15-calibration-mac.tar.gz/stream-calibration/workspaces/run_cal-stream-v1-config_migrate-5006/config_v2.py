def to_v2(cfg):
    """Upgrade settings from version 1 to version 2."""
    # Check if cfg is version 1
    if cfg.get("version") != 1:
        raise ValueError("Configuration must be version 1")
    
    # Create new dict with version 2
    new_cfg = {"version": 2}
    
    # Process keys
    # Rename "host" -> "hostname"
    if "host" in cfg:
        new_cfg["hostname"] = cfg["host"]
    
    # Rename "max_conn" -> "max_connections"
    if "max_conn" in cfg:
        new_cfg["max_connections"] = cfg["max_conn"]
    
    # Move "region" and "workers" into a sub-dict "storage"
    storage = {}
    if "region" in cfg:
        storage["region"] = cfg["region"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    new_cfg["storage"] = storage
    
    # Handle "timeout_ms" -> "timeout_s"
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key not in ["host", "max_conn", "region", "workers", "timeout_ms"]:
            if value is not None:
                new_cfg[key] = value
    
    return new_cfg
