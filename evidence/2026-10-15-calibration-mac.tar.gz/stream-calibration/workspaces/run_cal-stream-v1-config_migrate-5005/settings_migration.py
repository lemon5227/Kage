def upgrade_config(cfg):
    # Check version - must be 1
    if cfg.get("version") != 1:
        raise ValueError("Configuration version must be 1")
    
    # Create new config dict
    new_cfg = {"version": 2}
    
    # Process keys
    if "user" in cfg:
        new_cfg["username"] = cfg["user"]
    
    if "max_conn" in cfg:
        new_cfg["max_connections"] = cfg["max_conn"]
    
    # Move cache_size and region into limits
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    new_cfg["limits"] = limits
    
    # Handle timeout_ms
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Keep other keys unchanged (but drop None values)
    for key, value in cfg.items():
        if key not in ["user", "max_conn", "cache_size", "region", "timeout_ms"]:
            if value is not None:
                new_cfg[key] = value
    
    return new_cfg
