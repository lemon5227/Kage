def aggregate_log(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        # Format: <timestamp> <LEVEL> <service>: <message>
        # parts[0] = timestamp, parts[1] = LEVEL, parts[2] = service: ...
        level = parts[1].upper()
        service = parts[2].split(':')[0]
        if level == 'ERROR':
            counts[service] = counts.get(service, 0) + 1
    return counts
