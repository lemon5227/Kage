def to_v2(cfg):
    # Check version requirement
    if cfg.get("version") != 1:
        raise ValueError("Config must have version 1")
    
    # Create new config dict
    new_cfg = {"version": 2}
    
    # Process keys
    keys_to_process = ["host", "pwd_file", "retries", "workers", "timeout_ms"]
    
    # Rename host -> hostname
    if "host" in cfg:
        new_cfg["hostname"] = cfg["host"]
    
    # Rename pwd_file -> password_file
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    
    # Move retries and workers into storage sub-dict
    storage = {}
    if "retries" in cfg:
        storage["retries"] = cfg["retries"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    new_cfg["storage"] = storage
    
    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged (but drop keys with None value)
    for key, value in cfg.items():
        if key not in ["host", "pwd_file", "retries", "workers", "timeout_ms"]:
            if value is not None:
                new_cfg[key] = value
    
    return new_cfg
