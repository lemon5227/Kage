def combine_ranges(intervals):
    # Validate intervals
    for interval in intervals:
        if "from" not in interval or "to" not in interval:
            raise ValueError("Each interval must have 'from' and 'to' keys")
        s = interval["from"]
        e = interval["to"]
        if s > e:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Convert to list of tuples for sorting
    sorted_intervals = sorted(intervals, key=lambda x: x["from"])
    
    if not sorted_intervals:
        return []
    
    merged = []
    current_start = sorted_intervals[0]["from"]
    current_end = sorted_intervals[0]["to"]
    
    for interval in sorted_intervals[1:]:
        s = interval["from"]
        e = interval["to"]
        
        # Only merge if there is an overlap (not just touching)
        if s < current_end:
            # Overlap exists, merge by extending the end
            current_end = max(current_end, e)
        else:
            # No overlap, add current interval and start new one
            merged.append({"from": current_start, "to": current_end})
            current_start = s
            current_end = e
    
    # Add the last interval
    merged.append({"from": current_start, "to": current_end})
    
    return merged
