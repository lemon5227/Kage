import csv
import io


def dedupe_export(text):
    """
    Process CSV text with header row (columns: score, team, id).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "team" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "team" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Check if header has the expected columns
    if len(header) != 3:
        return ''
    
    score_col = 0
    team_col = 1
    id_col = 2
    
    # Process data rows
    data_rows = []
    for row in rows[1:]:
        if len(row) != 3:
            continue
        
        # Strip whitespace from every cell
        score = row[score_col].strip()
        team = row[team_col].strip()
        id_val = row[id_col].strip()
        
        # Drop rows whose "team" cell is empty
        if not team:
            continue
        
        data_rows.append((score, team, id_val))
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in data_rows:
        score = row[0]
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort rows by "team" ascending as strings (stable)
    unique_rows.sort(key=lambda x: x[1])
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
