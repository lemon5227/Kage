import csv
import io

def normalize_table(text):
    """Clean an exported CSV table with specified transformations."""
    
    # Parse the input text into lines
    lines = text.strip().split('\n')
    
    if not lines:
        return ''
    
    # Check if it's header-only
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    # Expected columns: score, city, team, id, email
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) < 5:
            continue
        row = {
            'score': cells[0].strip(),
            'city': cells[1].strip(),
            'team': cells[2].strip(),
            'id': cells[3].strip(),
            'email': cells[4].strip()
        }
        rows.append(row)
    
    # Drop rows whose "email" cell is empty
    rows = [row for row in rows if row['email'] != '' and row['email'].strip() != '']
    
    # Lower-case the "email" column
    for row in rows:
        row['email'] = row['email'].lower()
    
    # Remove duplicate rows by "city", keeping the first occurrence
    seen_cities = set()
    unique_rows = []
    for row in rows:
        if row['city'] not in seen_cities:
            seen_cities.add(row['city'])
            unique_rows.append(row)
    
    # Sort rows by "score" ascending as strings (stable)
    # Using stable sort with key=str
    unique_rows.sort(key=lambda row: row['score'], reverse=False)
    
    # Write output using csv module with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for row in unique_rows:
        writer.writerow([row['score'], row['city'], row['team'], row['id'], row['email']])
    
    return output.getvalue()
