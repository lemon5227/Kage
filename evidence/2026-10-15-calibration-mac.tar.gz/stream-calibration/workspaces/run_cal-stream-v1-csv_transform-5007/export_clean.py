import csv
import io

def clean_rows(text):
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Split into lines
    lines = text.strip().split('\n')
    
    # Check if header-only input
    if len(lines) == 1:
        return lines[0]
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = []
    for row in rows[1:]:
        # Strip whitespace from each cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip if id is empty
        if not cleaned_row[-1]:  # id is the last column
            continue
        
        data_rows.append(cleaned_row)
    
    # Remove duplicate rows by "score" (4th column, index 3), keeping first occurrence
    seen_scores = set()
    unique_rows = []
    for row in data_rows:
        score = row[3]
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort by "team" (2nd column, index 1) ascending as strings (stable sort)
    unique_rows.sort(key=lambda row: row[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
