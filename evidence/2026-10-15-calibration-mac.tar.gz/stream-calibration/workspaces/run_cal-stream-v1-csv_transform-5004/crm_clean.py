import csv
import io


def normalize_table(text):
    """
    Process CSV text with header row (columns: team, city, score, id).
    Returns cleaned CSV text with the same header.
    
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "id" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "city" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Parse CSV
    lines = text.strip().split('\n')
    if len(lines) < 1:
        return ''
    
    # Extract header
    header = lines[0].strip()
    if not header:
        return ''
    
    # Check if header matches expected columns
    expected_columns = ['team', 'city', 'score', 'id']
    if header != ','.join(expected_columns):
        # If header doesn't match, we still process it but use the given columns
        pass
    
    # Parse data rows
    rows = []
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        
        # Split by comma, strip each cell
        cells = [cell.strip() for cell in line.split(',')]
        
        # Need at least 4 columns
        if len(cells) < 4:
            continue
        
        team, city, score, id_val = cells[:4]
        
        # Drop rows whose "id" cell is empty
        if not id_val:
            continue
        
        rows.append((team, city, score, id_val))
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in rows:
        team, city, score, id_val = row
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort rows by "city" ascending as strings (stable)
    # Use a stable sort - Python's sorted is stable
    sorted_rows = sorted(unique_rows, key=lambda x: x[1])
    
    # Build output CSV
    output_lines = [header]
    for row in sorted_rows:
        team, city, score, id_val = row
        output_lines.append(f"{team},{city},{score},{id_val}")
    
    # Join with '\n' line endings
    return '\n'.join(output_lines)


if __name__ == '__main__':
    # Test examples
    test1 = "team,city,score,id\nA,B,10,1\nC,D,10,2\nE,F,20,3"
    print("Test 1:")
    print(normalize_table(test1))
    
    test2 = "team,city,score,id\nA,B,10,1"
    print("\nTest 2:")
    print(normalize_table(test2))
    
    test3 = ""
    print("\nTest 3 (empty):")
    print(repr(normalize_table(test3)))
    
    test4 = "team,city,score,id"
    print("\nTest 4 (header only):")
    print(normalize_table(test4))
