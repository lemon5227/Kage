def allocate(items, capacity):
    """
    Allocate items under a capacity limit.
    
    Args:
        items: List of dicts with keys "id", "size", "score"
        capacity: Maximum total size allowed
    
    Returns:
        Sorted list of ids with maximum total score within capacity
    
    Raises:
        ValueError: If capacity is negative or any item has size <= 0
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "id" not in item or "size" not in item or "score" not in item:
            raise ValueError("Each item must have 'id', 'size', and 'score' keys")
        if not isinstance(item["size"], int) or item["size"] <= 0:
            raise ValueError("Size must be a positive integer")
        if not isinstance(item["score"], int) or item["score"] < 0:
            raise ValueError("Score must be a non-negative integer")
    
    # Handle empty items list
    if not items:
        return []
    
    # Create list of (id, size, score) tuples
    items_list = [(item["id"], item["size"], item["score"]) for item in items]
    
    # Sort by score descending, then by id ascending for tie-breaking
    # We'll use a custom sorting approach to handle the lexicographic requirement
    # First, sort by score descending
    items_list.sort(key=lambda x: (-x[2], x[0]))
    
    # Greedy approach: select items in order until capacity is exceeded
    total_size = 0
    selected_ids = []
    
    for item_id, size, score in items_list:
        if total_size + size <= capacity:
            total_size += size
            selected_ids.append(item_id)
    
    # Return sorted list of ids (lexicographically smallest when ties occur)
    return sorted(selected_ids)
