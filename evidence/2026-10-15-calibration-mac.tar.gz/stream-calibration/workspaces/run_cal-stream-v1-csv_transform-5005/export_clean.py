import csv
import io

def normalize_table(text):
    # Handle empty input
    if not text or not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        return ''
    
    # Check if header has expected columns
    expected_cols = ['id', 'email', 'city', 'score']
    if len(header) != len(expected_cols):
        # Return just the header if format doesn't match
        return '\n'.join(header) + '\n'
    
    # Process rows
    rows = []
    for row in reader:
        if len(row) != len(expected_cols):
            continue
        
        # Strip leading/trailing whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Drop rows whose "id" cell is empty
        if not cleaned_row[0]:
            continue
        
        # Lower-case the "email" column
        cleaned_row[1] = cleaned_row[1].lower()
        
        rows.append(cleaned_row)
    
    # Remove duplicate rows by "city", keeping the first occurrence
    seen_cities = set()
    unique_rows = []
    for row in rows:
        city = row[2]
        if city not in seen_cities:
            seen_cities.add(city)
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    unique_rows.sort(key=lambda row: row[1])
    
    # Write output with csv module using '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(unique_rows[0])  # header
    for row in unique_rows[1:]:
        writer.writerow(row)
    
    return output.getvalue()
