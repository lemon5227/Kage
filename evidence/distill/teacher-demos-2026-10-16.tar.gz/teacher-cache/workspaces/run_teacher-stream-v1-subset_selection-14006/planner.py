def pick_jobs(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids whose total value is as large as possible while the total
    weight stays <= capacity.  Ties on total value are broken by choosing
    the lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data so the input is never modified.
    data = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        data.append((item["id"], weight, value))

    # 0/1 knapsack.  dp[w] = best (value, sorted_id_list) using capacity w.
    # We iterate items and update capacities downward so each item is used
    # at most once.
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for item_id, weight, value in data:
        for w in range(capacity, weight - 1, -1):
            prev = dp[w - weight]
            if prev is None:
                continue
            cand_value = prev[0] + value
            cand_ids = prev[1] + [item_id]
            cand_ids.sort()
            cur = dp[w]
            if cur is None:
                dp[w] = (cand_value, cand_ids)
            else:
                if cand_value > cur[0]:
                    dp[w] = (cand_value, cand_ids)
                elif cand_value == cur[0] and cand_ids < cur[1]:
                    dp[w] = (cand_value, cand_ids)

    # Best over all capacities <= capacity.
    best = (0, [])
    for w in range(capacity + 1):
        cur = dp[w]
        if cur is None:
            continue
        if cur[0] > best[0]:
            best = cur
        elif cur[0] == best[0] and cur[1] < best[1]:
            best = cur

    return best[1]
