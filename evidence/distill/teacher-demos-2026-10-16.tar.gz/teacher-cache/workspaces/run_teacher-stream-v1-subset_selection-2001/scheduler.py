def allocate(items, capacity):
    """Pick parcels to maximize total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of chosen ids.
    Ties on total gain are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and snapshot the input without modifying it.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # 0/1 knapsack over capacity, tracking the best (gain, sorted ids) per
    # capacity. We compare candidate selections by (gain, reversed ids) so that
    # the lexicographically smallest sorted id list wins ties.
    # dp[c] = (gain, ids) best selection with total cost exactly <= c.
    dp = [(0, ()) for _ in range(capacity + 1)]

    for item_id, cost, gain in entries:
        if cost > capacity:
            continue
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            cand_gain = prev_gain + gain
            cand_ids = tuple(sorted(prev_ids + (item_id,)))
            cur_gain, cur_ids = dp[c]
            if cand_gain > cur_gain or (cand_gain == cur_gain and cand_ids < cur_ids):
                dp[c] = (cand_gain, cand_ids)

    best_gain, best_ids = 0, ()
    for c in range(capacity + 1):
        gain, ids = dp[c]
        if gain > best_gain or (gain == best_gain and ids < best_ids):
            best_gain, best_ids = gain, ids

    return list(best_ids)
