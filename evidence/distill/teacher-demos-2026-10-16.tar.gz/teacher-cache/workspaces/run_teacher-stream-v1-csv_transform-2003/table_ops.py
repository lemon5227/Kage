import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "id" cell is empty
    try:
        id_idx = header.index("id")
    except ValueError:
        id_idx = None

    filtered = []
    for cells in cleaned:
        if id_idx is not None:
            if id_idx >= len(cells) or cells[id_idx] == "":
                continue
        filtered.append(cells)

    # lower-case the "email" column
    try:
        email_idx = header.index("email")
    except ValueError:
        email_idx = None

    if email_idx is not None:
        for cells in filtered:
            if email_idx < len(cells):
                cells[email_idx] = cells[email_idx].lower()

    # remove duplicate rows by "email", keeping the first occurrence
    if email_idx is not None:
        seen = set()
        deduped = []
        for cells in filtered:
            key = cells[email_idx] if email_idx < len(cells) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(cells)
        filtered = deduped

    # sort rows by "city" ascending as strings (stable)
    try:
        city_idx = header.index("city")
    except ValueError:
        city_idx = None

    if city_idx is not None:
        filtered.sort(key=lambda cells: cells[city_idx] if city_idx < len(cells) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for cells in filtered:
        writer.writerow(cells)
    return out.getvalue()
