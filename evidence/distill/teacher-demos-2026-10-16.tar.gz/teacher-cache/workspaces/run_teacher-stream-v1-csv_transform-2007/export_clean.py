import csv
import io

HEADER = ["score", "team", "id", "name", "city"]


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        # pad/truncate to header length
        if len(cells) < len(header):
            cells = cells + [""] * (len(header) - len(cells))
        elif len(cells) > len(header):
            cells = cells[: len(header)]
        cleaned.append(cells)

    # drop rows whose "team" cell is empty
    try:
        team_idx = header.index("team")
    except ValueError:
        team_idx = 1
    cleaned = [r for r in cleaned if r[team_idx] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    try:
        score_idx = header.index("score")
    except ValueError:
        score_idx = 0
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[score_idx]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    # sort by "id" ascending as strings (stable)
    try:
        id_idx = header.index("id")
    except ValueError:
        id_idx = 2
    deduped.sort(key=lambda r: r[id_idx])

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(deduped)
    return out.getvalue()
