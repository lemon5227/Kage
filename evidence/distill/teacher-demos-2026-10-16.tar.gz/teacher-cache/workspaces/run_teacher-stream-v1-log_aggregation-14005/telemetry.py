def count_entries(lines):
    """Count log entries per service for ERROR and WARN levels.

    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"

    Level names are matched case-insensitively (only ERROR and WARN count).
    Malformed lines are dropped. Returns {service_name: count} with
    upper-case service keys.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service = parts[2]
        if not service.endswith(":"):
            continue
        name = service[:-1]
        if not name:
            continue
        counts[name] = counts.get(name, 0) + 1
    return counts
