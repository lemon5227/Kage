def select_tasks(items, capacity):
    """Choose a subset of items maximizing total score subject to total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size" and a
    non-negative integer "score". Returns the sorted list of chosen ids. Ties on total
    score are broken by the lexicographically smallest sorted id list. An empty
    selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data so the input is never modified.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by id so that, when scores tie, we can prefer the lexicographically
    # smallest sorted id list. We process ids in ascending order and, on ties,
    # prefer the selection that includes the smaller id.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    # dp[c] = best (score, chosen_ids) using a subset of the first i items with
    # total size exactly <= c. We track the chosen ids to resolve ties.
    # Use a list of (score, ids_tuple) where ids_tuple is kept sorted ascending.
    NEG = None
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for idx in range(n):
        iid, size, score = entries[idx]
        # iterate capacity downward for 0/1 semantics
        for c in range(capacity, size - 1, -1):
            prev = dp[c - size]
            if prev is None:
                continue
            cand_score = prev[0] + score
            # Build candidate id tuple keeping ascending order (iid is the largest
            # id seen so far since we process in ascending id order).
            cand_ids = prev[1] + (iid,)
            cur = dp[c]
            if cur is None:
                dp[c] = (cand_score, cand_ids)
            else:
                if cand_score > cur[0]:
                    dp[c] = (cand_score, cand_ids)
                elif cand_score == cur[0]:
                    # Prefer lexicographically smallest sorted id list.
                    if cand_ids < cur[1]:
                        dp[c] = (cand_score, cand_ids)

    # Best over all capacities (empty selection allowed).
    best = (0, ())
    for c in range(capacity + 1):
        cur = dp[c]
        if cur is None:
            continue
        if cur[0] > best[0]:
            best = cur
        elif cur[0] == best[0] and cur[1] < best[1]:
            best = cur

    return list(best[1])
