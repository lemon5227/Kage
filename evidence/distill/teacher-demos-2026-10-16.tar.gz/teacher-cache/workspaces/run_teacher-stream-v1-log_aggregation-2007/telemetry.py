def summarize(lines):
    """Summarize log lines into {LEVEL: count}.

    Each line is expected to look like "<timestamp> <LEVEL> <service>: <message>".
    Level names are matched case-insensitively and reported upper-cased.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        if not level.isalpha():
            continue
        # The service token must be followed by a colon-terminated field.
        if not parts[2].endswith(":"):
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
