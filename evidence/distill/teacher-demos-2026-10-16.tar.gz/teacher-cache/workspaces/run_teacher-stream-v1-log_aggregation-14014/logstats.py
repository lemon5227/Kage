def tally_events(lines):
    """Tally log lines by level.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Returns a dict mapping the upper-cased level name to the number of
    occurrences. Malformed lines are ignored.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        if not level.isalpha():
            continue
        # The service token must be followed by a colon-terminated token.
        if not parts[2].endswith(":"):
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
