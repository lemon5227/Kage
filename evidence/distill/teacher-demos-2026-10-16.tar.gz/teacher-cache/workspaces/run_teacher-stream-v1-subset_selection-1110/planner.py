def allocate(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids whose total value is as large as possible while the total
    weight stays <= capacity.  Ties on total value are broken by choosing
    the lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is never modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the data so the input is never mutated.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # Sort by id so that, among equal-value solutions, we can prefer the
    # lexicographically smallest sorted id list.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    # dp[w] = best (value, id_list) achievable with total weight <= w.
    # We process items one at a time (0/1 knapsack) and keep, for each
    # capacity, the best value and the lexicographically smallest id list
    # achieving it.
    dp = [(0, []) for _ in range(capacity + 1)]

    for idx in range(n):
        item_id, weight, value = entries[idx]
        # Iterate capacities downward to avoid reusing the same item.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = prev_ids + [item_id]
            best_value, best_ids = dp[w]
            if cand_value > best_value:
                dp[w] = (cand_value, cand_ids)
            elif cand_value == best_value:
                # Prefer the lexicographically smaller sorted id list.
                if sorted(cand_ids) < sorted(best_ids):
                    dp[w] = (cand_value, cand_ids)

    return sorted(dp[capacity][1])
