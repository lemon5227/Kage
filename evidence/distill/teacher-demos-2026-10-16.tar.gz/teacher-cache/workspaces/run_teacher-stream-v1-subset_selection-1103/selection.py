def pick_jobs(items, capacity):
    """Choose a subset of items maximizing total score subject to total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size" and a
    non-negative integer "score". Returns the sorted list of chosen ids. Ties on total
    score are broken by choosing the lexicographically smallest sorted id list. An empty
    selection is allowed. Raises ValueError if capacity is negative or any size <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant fields so the input is never mutated.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        entries.append((item["id"], size, score))

    # Sort by id so that we can build the lexicographically smallest id list.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    # dp[c] = best (score, id_list) achievable with capacity c using processed items.
    # We process items in ascending id order and, on ties, prefer the candidate whose
    # sorted id list is lexicographically smaller.
    dp = [(0, []) for _ in range(capacity + 1)]

    for idx in range(n):
        item_id, size, score = entries[idx]
        # Iterate capacity downward for 0/1 semantics.
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = dp[c - size]
            cand_score = prev_score + score
            cand_ids = prev_ids + [item_id]
            best_score, best_ids = dp[c]
            if cand_score > best_score or (cand_score == best_score and cand_ids < best_ids):
                dp[c] = (cand_score, cand_ids)

    return sorted(dp[capacity][1])
