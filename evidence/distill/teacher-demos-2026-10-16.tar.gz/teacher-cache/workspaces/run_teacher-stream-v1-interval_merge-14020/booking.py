def merge_slots(intervals):
    """Merge overlapping time ranges.

    Each interval is a dict {"begin": s, "finish": e} with integer values.
    Returns a new list of dicts with the same "begin"/"finish" keys, sorted by
    start ascending. Touching intervals (e.g. [1, 3] and [3, 5]) are not merged;
    only real overlaps merge. Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    normalized = []
    for interval in intervals:
        begin = interval["begin"]
        finish = interval["finish"]
        if begin > finish:
            raise ValueError(
                "invalid interval: begin %r is greater than finish %r"
                % (begin, finish)
            )
        normalized.append((begin, finish))

    normalized.sort(key=lambda pair: pair[0])

    merged = []
    for begin, finish in normalized:
        if merged and begin < merged[-1][1]:
            # Real overlap: extend the current interval if needed.
            if finish > merged[-1][1]:
                merged[-1][1] = finish
        else:
            merged.append([begin, finish])

    return [{"begin": begin, "finish": finish} for begin, finish in merged]
