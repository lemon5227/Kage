def allocate(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Return the sorted list of
    ids whose total value is as large as possible while the total weight
    stays <= capacity.  Ties on total value are broken by choosing the
    lexicographically smallest sorted id list.  An empty selection is allowed.

    Raise ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Copy the items so the input is never modified.
    entries = []
    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, item["value"]))

    # Sort by id so that ties can be resolved lexicographically.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    # best[w] = (total_value, tuple_of_ids) for the best selection using
    # exactly the items processed so far with total weight <= w.
    best = [(0, ()) for _ in range(capacity + 1)]

    for idx in range(n):
        item_id, weight, value = entries[idx]
        # Iterate weights downward so each item is used at most once.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = best[w - weight]
            cand_value = prev_value + value
            cand_ids = prev_ids + (item_id,)
            cur_value, cur_ids = best[w]
            if cand_value > cur_value or (
                cand_value == cur_value and cand_ids < cur_ids
            ):
                best[w] = (cand_value, cand_ids)

    # The best selection for capacity is the max over all weights <= capacity.
    best_value, best_ids = 0, ()
    for w in range(capacity + 1):
        value, ids = best[w]
        if value > best_value or (value == best_value and ids < best_ids):
            best_value, best_ids = value, ids

    return sorted(best_ids)
