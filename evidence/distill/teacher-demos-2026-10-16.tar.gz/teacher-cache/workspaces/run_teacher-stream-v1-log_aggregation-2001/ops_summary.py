import re

_LINE_RE = re.compile(r"^\S+\s+(\S+)\s+\S+:\s+.*$")


def tally_events(lines):
    """Count log lines per level.

    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and is upper-cased. Lines that do not match are ignored.
    Returns a plain dict of counts.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        match = _LINE_RE.match(line.strip())
        if not match:
            continue
        level = match.group(1).upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
