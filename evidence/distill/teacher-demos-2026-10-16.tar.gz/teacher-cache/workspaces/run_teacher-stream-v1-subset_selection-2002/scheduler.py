def allocate(items, capacity):
    """Pick jobs to maximize total score with total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids of an
    optimal selection. Ties on total score are broken by choosing the
    lexicographically smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and snapshot the input without modifying it.
    entries = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("size must be positive")
        entries.append((item["id"], size, score))

    # DP over capacity: best (score, sorted_ids) for each exact/at-most weight.
    # best[w] = best selection using total size <= w.
    best = [(0, []) for _ in range(capacity + 1)]

    for idx, (item_id, size, score) in enumerate(entries):
        if size > capacity:
            continue
        # Iterate weights downward so each item is used at most once.
        for w in range(capacity, size - 1, -1):
            prev_score, prev_ids = best[w - size]
            cand_score = prev_score + score
            cand_ids = sorted(prev_ids + [item_id])
            cur_score, cur_ids = best[w]
            if cand_score > cur_score or (cand_score == cur_score and cand_ids < cur_ids):
                best[w] = (cand_score, cand_ids)

    return best[capacity][1]
