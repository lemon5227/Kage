def digest_lines(lines):
    """Count log lines per level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive and reported upper-case. Malformed lines
    are skipped. Levels with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1]
        if not level.isalpha():
            continue
        # The service token must be followed by a colon, e.g. "svc:".
        if not parts[2].endswith(":"):
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
