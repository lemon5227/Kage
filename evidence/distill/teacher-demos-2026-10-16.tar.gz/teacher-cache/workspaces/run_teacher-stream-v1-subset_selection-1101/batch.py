def allocate(items, capacity):
    """Choose a subset of items maximizing total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of chosen ids.
    Ties on total gain are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the data so the input is never modified.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # dp[c] = best (gain, sorted_id_list) achievable with total cost exactly <= c
    # We track the best selection for each capacity using a dict keyed by cost.
    # best[c] holds the optimal (gain, ids) for capacity limit c.
    best = [(0, []) for _ in range(capacity + 1)]

    for c in range(capacity + 1):
        if c == 0:
            best[0] = (0, [])
            continue
        # Start from the best of the previous capacity (allows unused capacity).
        best_gain, best_ids = best[c - 1]
        for item_id, cost, gain in entries:
            if cost <= c:
                prev_gain, prev_ids = best[c - cost]
                cand_gain = prev_gain + gain
                cand_ids = sorted(prev_ids + [item_id])
                if cand_gain > best_gain or (
                    cand_gain == best_gain and cand_ids < best_ids
                ):
                    best_gain, best_ids = cand_gain, cand_ids
        best[c] = (best_gain, best_ids)

    return best[capacity][1]
