def pick_jobs(items, capacity):
    """Pick parcels to maximise total score with total size <= capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score".  Returns the sorted list of ids of an
    optimal selection.  Ties on total score are broken by choosing the
    lexicographically smallest sorted id list.  An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must not be negative")

    # Work on copies so the caller's data is never touched.
    work = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("item size must be positive")
        work.append((item["id"], size, score))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_score, sorted_id_list) for capacity c.
    best = [(0, []) for _ in range(capacity + 1)]

    for item_id, size, score in work:
        if size > capacity:
            continue
        # Iterate downwards so each item is used at most once.
        for c in range(capacity, size - 1, -1):
            prev_score, prev_ids = best[c - size]
            cand_score = prev_score + score
            cand_ids = sorted(prev_ids + [item_id])
            cur_score, cur_ids = best[c]
            if cand_score > cur_score or (
                cand_score == cur_score and cand_ids < cur_ids
            ):
                best[c] = (cand_score, cand_ids)

    # The best value for capacity c is non-decreasing in c, so the answer is
    # the entry for the full capacity.
    return list(best[capacity][1])
