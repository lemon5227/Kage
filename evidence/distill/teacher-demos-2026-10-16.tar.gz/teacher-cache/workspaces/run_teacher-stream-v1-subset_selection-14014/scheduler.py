def choose(items, capacity):
    """Choose a subset of items maximizing total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of chosen ids.
    Ties on total gain are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # Sort by id so that we can build the lexicographically smallest answer.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    # dp[c] = best (gain, chosen_ids) using a subset of processed items with
    # total cost exactly <= c. We track the chosen id list to resolve ties.
    # Use a list of (gain, ids) where ids is a tuple kept sorted.
    NEG = None
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for idx in range(n):
        item_id, cost, gain = entries[idx]
        # Iterate capacities downward for 0/1 semantics.
        for c in range(capacity, cost - 1, -1):
            prev = dp[c - cost]
            if prev is None:
                continue
            cand_gain = prev[0] + gain
            cand_ids = prev[1] + (item_id,)
            cur = dp[c]
            if cur is None:
                dp[c] = (cand_gain, cand_ids)
            else:
                if cand_gain > cur[0]:
                    dp[c] = (cand_gain, cand_ids)
                elif cand_gain == cur[0]:
                    # Tie on gain: prefer lexicographically smaller sorted list.
                    if cand_ids < cur[1]:
                        dp[c] = (cand_gain, cand_ids)

    # Best over all capacities <= capacity.
    best = (0, ())
    for c in range(capacity + 1):
        cur = dp[c]
        if cur is None:
            continue
        if cur[0] > best[0]:
            best = cur
        elif cur[0] == best[0]:
            if cur[1] < best[1]:
                best = cur

    return sorted(best[1])
