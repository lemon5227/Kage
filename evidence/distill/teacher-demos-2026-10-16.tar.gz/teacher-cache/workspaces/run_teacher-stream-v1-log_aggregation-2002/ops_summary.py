def digest_lines(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        service = parts[2]
        if not service.endswith(":"):
            continue
        level = parts[1].upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
