def pick_jobs(items, capacity):
    """Choose parcels to maximise total value within a weight capacity.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids whose total value is as large as possible while the total
    weight stays <= capacity.  Ties on total value are broken by choosing
    the lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is never modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on a copy so the caller's data is never touched.
    work = []
    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("item weight must be positive")
        work.append((item["id"], weight, item["value"]))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_value, sorted_id_list) achievable with capacity c.
    best = [(0, []) for _ in range(capacity + 1)]

    for item_id, weight, value in work:
        # Iterate downwards so each item is used at most once.
        for c in range(capacity, weight - 1, -1):
            prev_value, prev_ids = best[c - weight]
            candidate_value = prev_value + value
            candidate_ids = sorted(prev_ids + [item_id])
            cur_value, cur_ids = best[c]
            if candidate_value > cur_value or (
                candidate_value == cur_value and candidate_ids < cur_ids
            ):
                best[c] = (candidate_value, candidate_ids)

    return best[capacity][1]
