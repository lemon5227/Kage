def aggregate_log(lines):
    """Count ERROR/WARN lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive and reported upper-case. Malformed lines
    are skipped, and services with a zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        _timestamp, level, service_field, _message = parts
        level = level.upper()
        if level not in ("ERROR", "WARN"):
            continue
        if not service_field.endswith(":"):
            continue
        service = service_field[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
