def coalesce(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"begin": s, "finish": e} with integer values.
    Returns a new list of dicts with the same "begin"/"finish" keys, sorted by
    start ascending. Touching intervals (e.g. [1, 3] and [3, 5]) are not merged;
    only real overlaps merge. Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    items = []
    for interval in intervals:
        begin = interval["begin"]
        finish = interval["finish"]
        if begin > finish:
            raise ValueError(
                "invalid interval: begin %r > finish %r" % (begin, finish)
            )
        items.append((begin, finish))

    items.sort(key=lambda pair: (pair[0], pair[1]))

    merged = []
    for begin, finish in items:
        if merged and begin < merged[-1]["finish"]:
            if finish > merged[-1]["finish"]:
                merged[-1]["finish"] = finish
        else:
            merged.append({"begin": begin, "finish": finish})

    return merged
