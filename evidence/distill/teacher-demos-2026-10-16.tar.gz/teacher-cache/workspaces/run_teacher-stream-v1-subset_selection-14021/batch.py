def pick_jobs(items, capacity):
    """Pick jobs to maximize total value with total weight <= capacity.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list of
    ids of the chosen jobs. Ties on total value are broken by choosing the
    lexicographically smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on a copy so the input is never modified.
    jobs = []
    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        jobs.append((item["id"], weight, item["value"]))

    # Sort by id so that we can build the lexicographically smallest
    # tie-breaking selection deterministically.
    jobs.sort(key=lambda j: j[0])

    n = len(jobs)
    # dp[w] = best (value, chosen_ids) using processed items with weight <= w.
    # We track the chosen id list to resolve ties lexicographically.
    dp = [(0, []) for _ in range(capacity + 1)]

    for jid, weight, value in jobs:
        # Iterate weights descending for 0/1 semantics.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = prev_ids + [jid]
            cur_value, cur_ids = dp[w]
            if cand_value > cur_value:
                dp[w] = (cand_value, cand_ids)
            elif cand_value == cur_value:
                # Tie on value: prefer lexicographically smallest sorted list.
                if sorted(cand_ids) < sorted(cur_ids):
                    dp[w] = (cand_value, cand_ids)

    best_value, best_ids = dp[capacity]
    return sorted(best_ids)
