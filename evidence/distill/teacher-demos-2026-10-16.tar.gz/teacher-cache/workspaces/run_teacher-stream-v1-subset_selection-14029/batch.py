def allocate(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids whose total value is as large as possible while the total weight
    stays <= capacity.  Ties on total value are broken by returning the
    lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Copy the relevant fields so the input is never modified.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # Sort by id so that greedy reconstruction yields the lexicographically
    # smallest sorted id list.
    entries.sort(key=lambda e: e[0])
    n = len(entries)

    # suffix[i][w] = max value using entries[i:] with capacity w.
    suffix = [[0] * (capacity + 1) for _ in range(n + 1)]
    for i in range(n - 1, -1, -1):
        _, weight, value = entries[i]
        row = suffix[i]
        nxt = suffix[i + 1]
        for w in range(capacity + 1):
            best = nxt[w]
            if weight <= w:
                cand = value + nxt[w - weight]
                if cand > best:
                    best = cand
            row[w] = best

    # Greedily include the smallest id whenever it is part of some optimal
    # solution for the remaining capacity.
    chosen = []
    remaining = capacity
    for i in range(n):
        item_id, weight, value = entries[i]
        if weight <= remaining and value + suffix[i + 1][remaining - weight] == suffix[i][remaining]:
            chosen.append(item_id)
            remaining -= weight

    return chosen
