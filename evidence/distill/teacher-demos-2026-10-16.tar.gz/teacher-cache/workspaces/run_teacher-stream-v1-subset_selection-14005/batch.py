def pick_jobs(items, capacity):
    """Pick a subset of items maximizing total value with total weight <= capacity.

    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Returns the sorted list of chosen ids.
    Ties on total value are broken by choosing the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on a copy so the input is never modified.
    work = []
    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("item weight must be positive")
        work.append((item["id"], weight, item["value"]))

    # Sort by id so that we can reason about lexicographic ordering of the
    # sorted id list directly on this order.
    work.sort(key=lambda t: t[0])
    n = len(work)

    # dp[w] = best (value, chosen_indices) using a subset of the first i items
    # with total weight exactly <= w. We store the chosen indices as a tuple
    # in the sorted-by-id order, which lets us compare lexicographically.
    NEG = None
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for idx in range(n):
        _id, weight, value = work[idx]
        # Iterate weights descending for 0/1 semantics.
        for w in range(capacity, weight - 1, -1):
            prev = dp[w - weight]
            if prev is None:
                continue
            cand_value = prev[0] + value
            cand_choice = prev[1] + (idx,)
            cur = dp[w]
            if cur is None or cand_value > cur[0] or (
                cand_value == cur[0] and cand_choice < cur[1]
            ):
                dp[w] = (cand_value, cand_choice)

    # Find the best reachable state across all capacities.
    best = None
    for w in range(capacity + 1):
        state = dp[w]
        if state is None:
            continue
        if best is None or state[0] > best[0] or (
            state[0] == best[0] and state[1] < best[1]
        ):
            best = state

    if best is None:
        return []

    chosen = [work[i][0] for i in best[1]]
    chosen.sort()
    return chosen
