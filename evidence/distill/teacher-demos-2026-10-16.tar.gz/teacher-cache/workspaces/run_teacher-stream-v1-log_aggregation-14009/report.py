def count_entries(lines):
    """Count ERROR/WARN entries per service.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Returns a dict mapping service name -> count, considering only lines
    whose level is ERROR or WARN (case-insensitive). Malformed lines are
    dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service = parts[2]
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
