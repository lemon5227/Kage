def summarize(lines):
    """Count ERROR lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive. Malformed lines are skipped.
    Returns a dict mapping service -> count for ERROR lines only,
    omitting services with a zero count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        # Split off the message after the first ":"
        if ":" not in line:
            continue
        head, _sep, _message = line.partition(":")
        parts = head.split()
        if len(parts) < 3:
            continue
        _timestamp, level, service = parts[0], parts[1], parts[2]
        if level.upper() != "ERROR":
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
