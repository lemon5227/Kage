def allocate(items, capacity):
    """Pick parcels to maximise total value within a weight capacity.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids with the greatest total value whose total weight is <= capacity.
    Ties on total value are broken by choosing the lexicographically
    smallest sorted id list.  An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is never modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on copies so the caller's data is never touched.
    entries = []
    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, item["value"]))

    # Sort by id so that, when values tie, the lexicographically smallest
    # sorted id list is preferred.  We compare candidate selections as
    # sorted id tuples, so we build the best selection for each capacity.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    # best[w] = (total_value, sorted_id_tuple) for the best selection using
    # the items processed so far with total weight exactly <= w.
    best = [(0, ()) for _ in range(capacity + 1)]

    for idx in range(n):
        item_id, weight, value = entries[idx]
        # Iterate downwards so each item is used at most once.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = best[w - weight]
            cand_value = prev_value + value
            cand_ids = tuple(sorted(prev_ids + (item_id,)))
            cur_value, cur_ids = best[w]
            if cand_value > cur_value or (
                cand_value == cur_value and cand_ids < cur_ids
            ):
                best[w] = (cand_value, cand_ids)

    # The best selection for capacity is the best over all weights <= capacity.
    best_value = -1
    best_ids = ()
    for w in range(capacity + 1):
        value, ids = best[w]
        if value > best_value or (value == best_value and ids < best_ids):
            best_value = value
            best_ids = ids

    return list(best_ids)
