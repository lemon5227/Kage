import re

_LINE_RE = re.compile(r"^\S+ +(\S+) +\S+: .*$")


def tally_events(lines):
    """Count log lines per level.

    Line format: "<timestamp> <LEVEL> <service>: <message>"
    Level case may vary and is upper-cased. Lines that do not match are ignored.
    Returns a plain dict mapping upper-cased level -> count.
    """
    counts = {}
    for line in lines:
        match = _LINE_RE.match(line.strip())
        if not match:
            continue
        level = match.group(1).upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
