def allocate(items, capacity):
    """Select items under a capacity limit maximizing total value.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity. Ties on total value are broken by returning the
    lexicographically smallest sorted id list. An empty selection is
    allowed. Raises ValueError if capacity is negative or any weight <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant fields so the input is never modified.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # Sort by id so that we can build the lexicographically smallest
    # selection deterministically.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    # dp[w] = best (value, id-tuple) achievable with total weight exactly <= w
    # We track the chosen id tuple to resolve ties lexicographically.
    # best[w] holds the optimal (value, ids) for capacity w.
    best = [(0, ()) for _ in range(capacity + 1)]

    for idx in range(n):
        iid, weight, value = entries[idx]
        # Iterate capacities downward for 0/1 semantics.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = best[w - weight]
            cand_value = prev_value + value
            cand_ids = prev_ids + (iid,)
            cur_value, cur_ids = best[w]
            if cand_value > cur_value:
                best[w] = (cand_value, cand_ids)
            elif cand_value == cur_value:
                # Tie on value: prefer lexicographically smaller sorted id list.
                if cand_ids < cur_ids:
                    best[w] = (cand_value, cand_ids)

    # The best over all capacities up to `capacity`.
    best_value = -1
    best_ids = ()
    for w in range(capacity + 1):
        value, ids = best[w]
        if value > best_value:
            best_value = value
            best_ids = ids
        elif value == best_value:
            if ids < best_ids:
                best_ids = ids

    return sorted(best_ids)
