import csv
import io


def tidy_csv(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "score" cell is empty
    cleaned = [r for r in cleaned if len(r) > 0 and r[0] != ""]

    # remove duplicates by "score", keeping first occurrence
    seen = set()
    deduped = []
    for r in cleaned:
        key = r[0]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    # stable sort by "name" ascending as strings
    deduped.sort(key=lambda r: r[2] if len(r) > 2 else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for r in deduped:
        writer.writerow(r)
    return out.getvalue()
