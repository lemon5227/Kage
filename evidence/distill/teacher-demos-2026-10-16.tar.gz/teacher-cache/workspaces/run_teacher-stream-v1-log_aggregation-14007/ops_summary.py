def tally_events(lines):
    """Tally ERROR/WARN events per service.

    Each line is formatted as "<timestamp> <LEVEL> <service>: <message>".
    Level names are matched case-insensitively; only ERROR and WARN count.
    Malformed lines are dropped. Returns {service_name: count}.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service = parts[2]
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
