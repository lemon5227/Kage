def select_tasks(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids whose total value is as large as possible while the total
    weight stays <= capacity.  Ties on total value are broken by choosing
    the lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the data so the input is never mutated.
    data = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        data.append((item["id"], weight, value))

    # Sort by id so that we can reason about lexicographic tie-breaking.
    data.sort(key=lambda t: t[0])

    n = len(data)
    # dp[w] = best (value, chosen_ids_tuple) achievable with weight <= w.
    # We iterate items and update a weight-indexed table.
    # To break ties lexicographically we compare the sorted id tuples.
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for idx in range(n):
        item_id, weight, value = data[idx]
        # Iterate weights downward for 0/1 semantics.
        for w in range(capacity, weight - 1, -1):
            prev = dp[w - weight]
            if prev is None:
                continue
            cand_value = prev[0] + value
            cand_ids = prev[1] + (item_id,)
            cur = dp[w]
            if cur is None:
                dp[w] = (cand_value, cand_ids)
            else:
                if cand_value > cur[0]:
                    dp[w] = (cand_value, cand_ids)
                elif cand_value == cur[0]:
                    # Tie on value: prefer lexicographically smaller id list.
                    if cand_ids < cur[1]:
                        dp[w] = (cand_value, cand_ids)

    # Find the best value across all capacities, then the lexicographically
    # smallest id list among those achieving it.
    best_value = -1
    best_ids = ()
    for w in range(capacity + 1):
        entry = dp[w]
        if entry is None:
            continue
        value, ids = entry
        if value > best_value:
            best_value = value
            best_ids = ids
        elif value == best_value:
            if ids < best_ids:
                best_ids = ids

    return sorted(best_ids)
