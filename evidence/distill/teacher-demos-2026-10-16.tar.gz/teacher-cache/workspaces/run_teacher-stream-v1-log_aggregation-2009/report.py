def count_entries(lines):
    """Count log entries per service for ERROR and WARN levels.

    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"

    - Level names are matched case-insensitively (e.g. "error", "Error").
    - Only ERROR and WARN levels are counted.
    - Malformed lines are dropped.
    - Returns a dict mapping service name -> count.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service: (with optional message)
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service_token = parts[2]
        if not service_token.endswith(":"):
            continue
        service = service_token[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
