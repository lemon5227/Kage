def aggregate_log(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        timestamp, level, rest = parts
        if not timestamp or not level:
            continue
        if ":" not in rest:
            continue
        counts[level.upper()] = counts.get(level.upper(), 0) + 1
    return counts
