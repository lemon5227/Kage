def plan_batch(items, capacity):
    """Pick jobs to maximize total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of chosen ids.
    Ties on total gain are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on a copy so the input is never modified.
    work = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        work.append((item["id"], cost, gain))

    # Sort by id so that, among equal-gain solutions, we can prefer the
    # lexicographically smallest sorted id list.
    work.sort(key=lambda t: t[0])

    n = len(work)
    # dp[c] = best (gain, id_list) achievable with capacity c using items
    # processed so far. id_list is kept sorted.
    NEG = None
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for idx in range(n):
        iid, cost, gain = work[idx]
        # Iterate capacity downward for 0/1 semantics.
        for c in range(capacity, cost - 1, -1):
            prev = dp[c - cost]
            if prev is None:
                continue
            cand_gain = prev[0] + gain
            cand_ids = prev[1] + [iid]
            cur = dp[c]
            if cur is None:
                dp[c] = (cand_gain, cand_ids)
            else:
                if cand_gain > cur[0]:
                    dp[c] = (cand_gain, cand_ids)
                elif cand_gain == cur[0]:
                    # Prefer lexicographically smallest sorted id list.
                    if cand_ids < cur[1]:
                        dp[c] = (cand_gain, cand_ids)

    best = None
    for c in range(capacity + 1):
        cur = dp[c]
        if cur is None:
            continue
        if best is None:
            best = cur
        else:
            if cur[0] > best[0]:
                best = cur
            elif cur[0] == best[0] and cur[1] < best[1]:
                best = cur

    if best is None:
        return []
    return sorted(best[1])
