def pick_jobs(items, capacity):
    """Choose a subset of jobs maximizing total score within capacity.

    Each item is a dict with a unique string "id", a positive integer "size"
    and a non-negative integer "score". Returns the sorted list of ids whose
    total score is as large as possible while total size stays <= capacity.
    Ties on total score are broken by the lexicographically smallest sorted
    id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any size is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant fields (do not modify the input).
    jobs = []
    for item in items:
        size = item["size"]
        score = item["score"]
        if size <= 0:
            raise ValueError("size must be positive")
        jobs.append((item["id"], size, score))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_score, best_sorted_id_list) using exactly capacity <= c.
    # We track the best achievable score for each capacity and the
    # lexicographically smallest sorted id list achieving it.
    best_score = [0] * (capacity + 1)
    best_ids = [[] for _ in range(capacity + 1)]

    for jid, size, score in jobs:
        # Iterate capacities downward so each job is used at most once.
        for c in range(capacity, size - 1, -1):
            cand_score = best_score[c - size] + score
            cand_ids = best_ids[c - size] + [jid]
            cand_ids.sort()
            if cand_score > best_score[c]:
                best_score[c] = cand_score
                best_ids[c] = cand_ids
            elif cand_score == best_score[c]:
                if cand_ids < best_ids[c]:
                    best_ids[c] = cand_ids

    # The answer is the best over all capacities <= capacity.
    result_score = -1
    result_ids = []
    for c in range(capacity + 1):
        if best_score[c] > result_score:
            result_score = best_score[c]
            result_ids = best_ids[c]
        elif best_score[c] == result_score:
            if best_ids[c] < result_ids:
                result_ids = best_ids[c]

    return result_ids
