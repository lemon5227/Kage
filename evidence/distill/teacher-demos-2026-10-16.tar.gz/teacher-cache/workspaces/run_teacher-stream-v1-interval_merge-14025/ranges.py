def merge_slots(intervals):
    """Merge overlapping booking intervals.

    Each interval is a dict {"begin": s, "finish": e} with integer values.
    Overlapping intervals are merged; touching intervals (e.g. [1,3] and [3,5])
    are NOT merged. Returns a new list of dicts with "begin"/"finish" keys,
    sorted by start ascending. The input is not modified.

    Raises ValueError if any interval has start > end.
    """
    items = []
    for interval in intervals:
        begin = interval["begin"]
        finish = interval["finish"]
        if begin > finish:
            raise ValueError(
                "invalid interval: begin %r > finish %r" % (begin, finish)
            )
        items.append((begin, finish))

    items.sort(key=lambda pair: (pair[0], pair[1]))

    merged = []
    for begin, finish in items:
        if merged and begin < merged[-1][1]:
            # Real overlap: extend the current interval if needed.
            if finish > merged[-1][1]:
                merged[-1][1] = finish
        else:
            merged.append([begin, finish])

    return [{"begin": b, "finish": f} for b, f in merged]
