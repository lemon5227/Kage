def summarize(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        timestamp, level, service, message = parts
        if not timestamp or not level or not service:
            continue
        if not service.endswith(":"):
            continue
        service = service[:-1]
        if not service:
            continue
        level = level.upper()
        if level != "WARN":
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
