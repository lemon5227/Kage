def summarize(lines):
    """Summarize log lines into {service: count} for WARN-level entries.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    - Only lines whose level is WARN (case-insensitive) are counted.
    - Keys are service names, upper-cased.
    - Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        _timestamp, level, rest = parts
        if level.upper() != "WARN":
            continue
        if ":" not in rest:
            continue
        service, _sep, _message = rest.partition(":")
        service = service.strip()
        if not service:
            continue
        key = service.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
