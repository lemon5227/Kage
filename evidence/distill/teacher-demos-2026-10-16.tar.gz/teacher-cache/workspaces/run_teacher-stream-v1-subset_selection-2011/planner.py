def choose(items, capacity):
    """Choose parcels maximizing total gain within a cost capacity.

    Each item is a dict with a unique string "id", a positive integer
    "cost" and a non-negative integer "gain". Returns the sorted list of
    ids whose total gain is maximal while total cost <= capacity. Ties on
    total gain are broken by the lexicographically smallest sorted id list.
    An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and snapshot the input without mutating it.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # dp[c] = best (gain, sorted id list) achievable with cost exactly <= c.
    # We track the best selection for each capacity, comparing by gain first
    # then by lexicographically smallest sorted id list.
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for item_id, cost, gain in entries:
        if cost > capacity:
            continue
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev = dp[c - cost]
            if prev is None:
                continue
            cand_gain = prev[0] + gain
            cand_ids = sorted(prev[1] + [item_id])
            cur = dp[c]
            if cur is None or cand_gain > cur[0] or (
                cand_gain == cur[0] and cand_ids < cur[1]
            ):
                dp[c] = (cand_gain, cand_ids)

    best = None
    for c in range(capacity + 1):
        cur = dp[c]
        if cur is None:
            continue
        if best is None or cur[0] > best[0] or (
            cur[0] == best[0] and cur[1] < best[1]
        ):
            best = cur

    return best[1] if best is not None else []
