def count_entries(lines):
    """Count log lines per service for ERROR and WARN levels.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are matched case-insensitively and reported upper-case.
    Malformed lines are skipped. Services with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service_part = parts[2]
        if not service_part.endswith(":"):
            continue
        service = service_part[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
