def plan_batch(items, capacity):
    """Pick jobs to maximize total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer
    "cost" and a non-negative integer "gain". Returns the sorted list of
    ids of an optimal selection. Ties on total gain are broken by
    choosing the lexicographically smallest sorted id list. An empty
    selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on a copy so the input is never modified.
    work = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        work.append((item["id"], cost, gain))

    # Sort by id so that, when gains tie, we can prefer the
    # lexicographically smallest id list deterministically.
    work.sort(key=lambda t: t[0])

    n = len(work)
    # dp[c] = best (gain, id_list) achievable with capacity c using the
    # items processed so far. id_list is kept sorted.
    dp = [(0, []) for _ in range(capacity + 1)]

    for idx in range(n):
        item_id, cost, gain = work[idx]
        # Iterate capacity downward for 0/1 semantics.
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = dp[c - cost]
            cand_gain = prev_gain + gain
            cand_ids = prev_ids + [item_id]
            cur_gain, cur_ids = dp[c]
            if cand_gain > cur_gain:
                dp[c] = (cand_gain, cand_ids)
            elif cand_gain == cur_gain:
                # Tie on gain: prefer lexicographically smaller id list.
                if cand_ids < cur_ids:
                    dp[c] = (cand_gain, cand_ids)

    # Best over all capacities (empty selection allowed).
    best_gain = -1
    best_ids = []
    for c in range(capacity + 1):
        gain, ids = dp[c]
        if gain > best_gain:
            best_gain = gain
            best_ids = ids
        elif gain == best_gain:
            if ids < best_ids:
                best_ids = ids

    return sorted(best_ids)
