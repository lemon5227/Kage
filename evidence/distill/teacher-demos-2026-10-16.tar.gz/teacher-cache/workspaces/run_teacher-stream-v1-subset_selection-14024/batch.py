def pick_jobs(items, capacity):
    """Select projects under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Return the sorted list of
    ids whose total value is as large as possible while the total weight
    stays <= capacity.  Ties on total value are broken by returning the
    lexicographically smallest sorted id list.  An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data so the input is never modified.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # 0/1 knapsack.  dp[w] = best (value, sorted_id_list) achievable with
    # total weight exactly <= w.  We track the chosen ids so we can apply the
    # lexicographic tie-break on the final sorted id list.
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for item_id, weight, value in entries:
        # Iterate weights downward so each item is used at most once.
        for w in range(capacity, weight - 1, -1):
            prev = dp[w - weight]
            if prev is None:
                continue
            cand_value = prev[0] + value
            cand_ids = sorted(prev[1] + [item_id])
            cur = dp[w]
            if cur is None or cand_value > cur[0] or (
                cand_value == cur[0] and cand_ids < cur[1]
            ):
                dp[w] = (cand_value, cand_ids)

    best = None
    for w in range(capacity + 1):
        cur = dp[w]
        if cur is None:
            continue
        if best is None or cur[0] > best[0] or (
            cur[0] == best[0] and cur[1] < best[1]
        ):
            best = cur

    if best is None:
        return []
    return best[1]
