def allocate(items, capacity):
    """Choose a subset of items maximizing total value with total weight <= capacity.

    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Returns the sorted list of chosen ids.
    Ties on total value are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on a copy so the input is never modified.
    work = []
    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("item weight must be positive")
        work.append((item["id"], weight, item["value"]))

    # Sort by id so that we can build the lexicographically smallest id list.
    work.sort(key=lambda t: t[0])

    n = len(work)
    # dp[w] = best (value, id_list) achievable with capacity w using processed items.
    # We iterate items and update capacities downward (0/1 knapsack).
    # id_list is kept sorted; comparison is (value, then lexicographically smallest list).
    dp = [(0, []) for _ in range(capacity + 1)]

    for idx in range(n):
        item_id, weight, value = work[idx]
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = prev_ids + [item_id]
            cur_value, cur_ids = dp[w]
            if cand_value > cur_value or (cand_value == cur_value and cand_ids < cur_ids):
                dp[w] = (cand_value, cand_ids)

    best_value, best_ids = dp[capacity]
    return sorted(best_ids)
