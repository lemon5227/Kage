def plan_batch(items, capacity):
    """Choose parcels to maximize total value within a weight capacity.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list of
    ids whose total value is as large as possible while total weight stays
    <= capacity. Ties on total value are broken by the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant fields so the input is never mutated.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    n = len(entries)
    # dp[w] = best (value, sorted_id_list) achievable with weight <= w.
    # We keep the lexicographically smallest id list among equal values.
    dp = [(0, []) for _ in range(capacity + 1)]

    for i in range(n):
        item_id, weight, value = entries[i]
        # Iterate weights downward for 0/1 semantics.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = sorted(prev_ids + [item_id])
            best_value, best_ids = dp[w]
            if cand_value > best_value or (
                cand_value == best_value and cand_ids < best_ids
            ):
                dp[w] = (cand_value, cand_ids)

    return dp[capacity][1]
