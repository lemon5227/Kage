def merge_bookings(intervals):
    """Merge overlapping or touching intervals.

    Each interval is a dict {"begin": s, "finish": e} with integer values.
    Returns a new list of dicts with the same "begin"/"finish" keys, sorted by
    start ascending. Touching intervals (e.g. [1, 3] and [3, 5]) are merged.

    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    normalized = []
    for interval in intervals:
        start = interval["begin"]
        end = interval["finish"]
        if start > end:
            raise ValueError(
                "invalid interval: begin %r is greater than finish %r" % (start, end)
            )
        normalized.append((start, end))

    normalized.sort(key=lambda pair: pair[0])

    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    return [{"begin": start, "finish": end} for start, end in merged]
