def select_tasks(items, capacity):
    """Choose a subset of items maximizing total value within capacity.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list of
    ids whose total value is as large as possible while total weight stays
    <= capacity. Ties on total value are broken by choosing the
    lexicographically smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant fields so the input is never modified.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # 0/1 knapsack DP over capacities.
    # best[c] = best (value, id_list) achievable with capacity exactly <= c.
    # We track the chosen id list to resolve ties lexicographically.
    best_value = [0] * (capacity + 1)
    best_ids = [[] for _ in range(capacity + 1)]

    for item_id, weight, value in entries:
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, weight - 1, -1):
            candidate_value = best_value[c - weight] + value
            candidate_ids = best_ids[c - weight] + [item_id]
            if candidate_value > best_value[c]:
                best_value[c] = candidate_value
                best_ids[c] = candidate_ids
            elif candidate_value == best_value[c]:
                # Tie on value: prefer the lexicographically smallest sorted
                # id list.
                cand_sorted = sorted(candidate_ids)
                cur_sorted = sorted(best_ids[c])
                if cand_sorted < cur_sorted:
                    best_ids[c] = candidate_ids

    return sorted(best_ids[capacity])
