def summarize(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        timestamp, level, service, message = parts
        if not service.endswith(":"):
            continue
        level = level.upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
