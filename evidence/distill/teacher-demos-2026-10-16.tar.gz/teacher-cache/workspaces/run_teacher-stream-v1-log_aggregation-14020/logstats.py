def aggregate_log(lines):
    """Aggregate log lines into {service: count} for ERROR and WARN levels.

    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"

    - Only lines whose level is ERROR or WARN (case-insensitive) are counted.
    - Keys are the service names.
    - Malformed lines are silently dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        _timestamp, level, rest = parts
        level = level.upper()
        if level not in ("ERROR", "WARN"):
            continue
        if ":" not in rest:
            continue
        service = rest.split(":", 1)[0].strip()
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
