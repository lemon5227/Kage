def choose(items, capacity):
    """Select items maximizing total value under a weight capacity.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list
    of ids whose total value is maximal while total weight <= capacity.
    Ties on total value are broken by the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and snapshot the input without mutating it.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # 0/1 knapsack with lexicographic tie-breaking on the sorted id list.
    # dp[w] = best (value, sorted_id_tuple) achievable with weight <= w.
    dp = [(0, ()) for _ in range(capacity + 1)]

    for item_id, weight, value in entries:
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = tuple(sorted(prev_ids + (item_id,)))
            cur_value, cur_ids = dp[w]
            if cand_value > cur_value or (
                cand_value == cur_value and cand_ids < cur_ids
            ):
                dp[w] = (cand_value, cand_ids)

    return list(dp[capacity][1])
