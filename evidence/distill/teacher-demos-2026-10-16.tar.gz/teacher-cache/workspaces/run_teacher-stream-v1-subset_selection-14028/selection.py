def allocate(items, capacity):
    """Select projects under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Return the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raise ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Copy the items so the input is never modified.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # 0/1 knapsack: dp[c] = best (gain, sorted id list) using cost <= c.
    # We track the lexicographically smallest id list among equal gains.
    dp = [None] * (capacity + 1)
    dp[0] = (0, [])

    for item_id, cost, gain in entries:
        for c in range(capacity, cost - 1, -1):
            if dp[c - cost] is None:
                continue
            prev_gain, prev_ids = dp[c - cost]
            cand_gain = prev_gain + gain
            cand_ids = sorted(prev_ids + [item_id])
            cur = dp[c]
            if cur is None:
                dp[c] = (cand_gain, cand_ids)
            else:
                cur_gain, cur_ids = cur
                if cand_gain > cur_gain or (cand_gain == cur_gain and cand_ids < cur_ids):
                    dp[c] = (cand_gain, cand_ids)

    best = None
    for c in range(capacity + 1):
        if dp[c] is None:
            continue
        gain, ids = dp[c]
        if best is None:
            best = (gain, ids)
        else:
            best_gain, best_ids = best
            if gain > best_gain or (gain == best_gain and ids < best_ids):
                best = (gain, ids)

    if best is None:
        return []
    return best[1]
