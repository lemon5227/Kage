def pick_jobs(items, capacity):
    """Choose parcels to maximize total value within a weight capacity.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids whose total value is as large as possible while the total
    weight stays <= capacity.  Ties on total value are broken by choosing
    the lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on a copy so the caller's data is never mutated.
    entries = []
    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, item["value"]))

    # Sort by id so that, when values tie, the lexicographically smallest
    # sorted id list is preferred.  We compare candidate selections as
    # sorted id tuples.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    # dp[w] = best (value, sorted_id_tuple) achievable with weight <= w.
    # Using tuples lets us compare value first, then lexicographic ids.
    dp = [(0, ()) for _ in range(capacity + 1)]

    for i in range(n):
        item_id, weight, value = entries[i]
        # Iterate weights downward for 0/1 semantics.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = tuple(sorted(prev_ids + (item_id,)))
            cur_value, cur_ids = dp[w]
            if cand_value > cur_value or (
                cand_value == cur_value and cand_ids < cur_ids
            ):
                dp[w] = (cand_value, cand_ids)

    return list(dp[capacity][1])
