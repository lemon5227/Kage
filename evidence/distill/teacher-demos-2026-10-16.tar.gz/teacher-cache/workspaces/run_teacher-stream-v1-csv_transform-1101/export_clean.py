import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "team" cell is empty
    cleaned = [row for row in cleaned if len(row) > 0 and row[0] != ""]

    # remove duplicate rows by "city" (index 2), keeping first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        city = row[2] if len(row) > 2 else ""
        if city in seen:
            continue
        seen.add(city)
        deduped.append(row)

    # sort by "id" (index 3) ascending as strings, stable
    deduped.sort(key=lambda row: row[3] if len(row) > 3 else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()
