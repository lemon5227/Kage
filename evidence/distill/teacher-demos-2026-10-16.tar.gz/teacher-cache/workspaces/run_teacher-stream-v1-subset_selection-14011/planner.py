def select_tasks(items, capacity):
    """Choose a subset of items maximizing total value with total weight <= capacity.

    Each item is a dict with a unique string "id", a positive integer "weight"
    and a non-negative integer "value". Returns the sorted list of chosen ids.
    Ties on total value are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data so the input is never modified.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # Sort ids so that we can build the lexicographically smallest solution.
    entries.sort(key=lambda e: e[0])

    n = len(entries)
    # dp[w] = best (value, id_list) achievable with capacity w using processed items.
    # We track the id list to resolve ties lexicographically.
    dp = [(0, []) for _ in range(capacity + 1)]

    for idx in range(n):
        item_id, weight, value = entries[idx]
        # Iterate weights descending for 0/1 semantics.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = prev_ids + [item_id]
            cur_value, cur_ids = dp[w]
            if cand_value > cur_value:
                dp[w] = (cand_value, cand_ids)
            elif cand_value == cur_value:
                # Tie on value: prefer lexicographically smaller sorted id list.
                if sorted(cand_ids) < sorted(cur_ids):
                    dp[w] = (cand_value, cand_ids)

    best_value = -1
    best_ids = []
    for w in range(capacity + 1):
        value, ids = dp[w]
        if value > best_value:
            best_value = value
            best_ids = ids
        elif value == best_value:
            if sorted(ids) < sorted(best_ids):
                best_ids = ids

    return sorted(best_ids)
