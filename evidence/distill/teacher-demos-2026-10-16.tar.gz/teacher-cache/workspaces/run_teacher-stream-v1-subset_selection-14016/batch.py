def pick_jobs(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Return the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by the lexicographically smallest sorted
    id list. An empty selection is allowed.

    Raise ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant fields (do not modify the input).
    jobs = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        jobs.append((item["id"], cost, gain))

    n = len(jobs)

    # 0/1 knapsack: best[c] = max gain achievable with capacity exactly <= c,
    # tracked together with the lexicographically smallest sorted id list.
    # We store, for each capacity, the best (gain, sorted_ids) pair.
    # To make tie-breaking deterministic and lexicographically smallest, we
    # compare candidate id lists directly.
    best = [None] * (capacity + 1)  # best[c] = (gain, tuple(sorted ids))
    best[0] = (0, ())

    for (jid, cost, gain) in jobs:
        # iterate capacities downward to keep 0/1 semantics
        for c in range(capacity, cost - 1, -1):
            prev = best[c - cost]
            if prev is None:
                continue
            cand_gain = prev[0] + gain
            cand_ids = tuple(sorted(prev[1] + (jid,)))
            cur = best[c]
            if cur is None:
                best[c] = (cand_gain, cand_ids)
            else:
                if cand_gain > cur[0]:
                    best[c] = (cand_gain, cand_ids)
                elif cand_gain == cur[0] and cand_ids < cur[1]:
                    best[c] = (cand_gain, cand_ids)

    # Find the best over all capacities <= capacity.
    result = (0, ())
    for c in range(capacity + 1):
        cur = best[c]
        if cur is None:
            continue
        if cur[0] > result[0]:
            result = cur
        elif cur[0] == result[0] and cur[1] < result[1]:
            result = cur

    return list(result[1])
