def choose(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids whose total value is as large as possible while the total
    weight stays <= capacity.  Ties on total value are broken by choosing
    the lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on copies so the input is never modified.
    entries = []
    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, item["value"]))

    # 0/1 knapsack over capacities 0..capacity.
    # best[w] = (max_value, sorted_id_list) achievable with weight <= w.
    best = [(0, []) for _ in range(capacity + 1)]

    for item_id, weight, value in entries:
        # Iterate downwards so each item is used at most once.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = best[w - weight]
            cand_value = prev_value + value
            cand_ids = sorted(prev_ids + [item_id])
            cur_value, cur_ids = best[w]
            if cand_value > cur_value or (cand_value == cur_value and cand_ids < cur_ids):
                best[w] = (cand_value, cand_ids)

    return best[capacity][1]
