def aggregate_log(lines):
    """Aggregate log lines into {service: count} for ERROR and WARN levels.

    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"

    - Only lines whose level is ERROR or WARN (case-insensitive) are counted.
    - Service names are used as-is (upper-case keys are not applied to names).
    - Malformed lines are silently dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        level = parts[1].upper()
        if level not in ("ERROR", "WARN"):
            continue
        service_token = parts[2]
        if not service_token.endswith(":"):
            continue
        service = service_token[:-1]
        if not service:
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
