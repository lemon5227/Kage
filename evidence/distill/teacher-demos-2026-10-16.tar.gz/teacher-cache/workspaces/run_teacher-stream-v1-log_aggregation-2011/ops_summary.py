def aggregate_log(lines):
    """Aggregate log lines into {LEVEL: count}.

    Each line is expected to be formatted as:
        "<timestamp> <LEVEL> <service>: <message>"

    Level names are matched case-insensitively and reported as upper-case
    keys. Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service: (with message optional)
        if len(parts) < 3:
            continue
        level = parts[1]
        service = parts[2]
        # Service token must end with ':' to be well-formed
        if not service.endswith(":"):
            continue
        # Level must be alphabetic
        if not level.isalpha():
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
