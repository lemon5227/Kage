def digest_lines(lines):
    """Count log lines per level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Levels are case-insensitive and reported upper-case.
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, and a "service:" token
        if len(parts) < 3:
            continue
        level = parts[1]
        if not level.isalpha():
            continue
        if not parts[2].endswith(":"):
            continue
        level = level.upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
