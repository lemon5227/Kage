def plan_batch(items, capacity):
    """Select parcels under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids whose total value is as large as possible while the total
    weight stays <= capacity.  Ties on total value are broken by choosing
    the lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the data so the input is never modified.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # Sort by id so that we can reason about lexicographic tie-breaking.
    entries.sort(key=lambda e: e[0])

    n = len(entries)

    # dp[w] = best (value, id_list) achievable with total weight exactly <= w.
    # We track the chosen id list to resolve ties lexicographically.
    # Using a list of (value, ids) where ids is a sorted tuple.
    dp = [(0, ()) for _ in range(capacity + 1)]

    for idx in range(n):
        iid, weight, value = entries[idx]
        # Iterate weights downward for 0/1 knapsack.
        for w in range(capacity, weight - 1, -1):
            prev_value, prev_ids = dp[w - weight]
            cand_value = prev_value + value
            cand_ids = tuple(sorted(prev_ids + (iid,)))
            cur_value, cur_ids = dp[w]
            if cand_value > cur_value or (
                cand_value == cur_value and cand_ids < cur_ids
            ):
                dp[w] = (cand_value, cand_ids)

    # Best over all capacities up to `capacity`.
    best_value = -1
    best_ids = ()
    for w in range(capacity + 1):
        value, ids = dp[w]
        if value > best_value or (value == best_value and ids < best_ids):
            best_value = value
            best_ids = ids

    return list(best_ids)
