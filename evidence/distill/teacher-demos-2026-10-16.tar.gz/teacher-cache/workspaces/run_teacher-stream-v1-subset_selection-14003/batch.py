def select_tasks(items, capacity):
    """Choose a subset of items maximizing total value within capacity.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value". Returns the sorted list of
    ids whose total value is as large as possible while total weight stays
    <= capacity. Ties on total value are broken by the lexicographically
    smallest sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Work on a copy so the input is never modified.
    work = []
    for item in items:
        weight = item["weight"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        work.append((item["id"], weight, item["value"]))

    # Sort by id so that, when values tie, we can prefer the lexicographically
    # smallest sorted id list deterministically.
    work.sort(key=lambda t: t[0])

    n = len(work)
    # dp[w] = best (value, chosen_ids) achievable with capacity w.
    # We iterate items and update capacities downward (0/1 knapsack).
    dp = [None] * (capacity + 1)
    dp[0] = (0, ())

    for idx in range(n):
        item_id, weight, value = work[idx]
        for w in range(capacity, weight - 1, -1):
            prev = dp[w - weight]
            if prev is None:
                continue
            cand_value = prev[0] + value
            cand_ids = prev[1] + (item_id,)
            cur = dp[w]
            if cur is None or cand_value > cur[0] or (
                cand_value == cur[0] and cand_ids < cur[1]
            ):
                dp[w] = (cand_value, cand_ids)

    best = None
    for w in range(capacity + 1):
        cur = dp[w]
        if cur is None:
            continue
        if best is None or cur[0] > best[0] or (
            cur[0] == best[0] and cur[1] < best[1]
        ):
            best = cur

    if best is None:
        return []
    return sorted(best[1])
