def digest_lines(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(" ", 2)
        if len(parts) < 3:
            continue
        timestamp, level, rest = parts
        if not timestamp or not level:
            continue
        if ":" not in rest:
            continue
        service, _, message = rest.partition(":")
        if not service or not message.strip():
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
