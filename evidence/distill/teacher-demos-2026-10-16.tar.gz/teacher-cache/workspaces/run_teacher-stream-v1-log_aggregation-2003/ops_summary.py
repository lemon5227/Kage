def aggregate_log(lines):
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, LEVEL, service:, message
        if len(parts) < 4:
            continue
        level = parts[1]
        service = parts[2]
        if not service.endswith(":"):
            continue
        level = level.upper()
        counts[level] = counts.get(level, 0) + 1
    return counts
