def pick_jobs(items, capacity):
    """Choose a subset of items maximizing total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of chosen ids.
    Ties on total gain are broken by the lexicographically smallest sorted id
    list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and snapshot the input without mutating it.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # 0/1 knapsack over integer capacities.
    # best[c] = (max_gain, sorted_id_list) achievable with capacity exactly <= c.
    best = [(0, []) for _ in range(capacity + 1)]

    for item_id, cost, gain in entries:
        if cost > capacity:
            continue
        # Iterate downward so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = best[c - cost]
            cand_gain = prev_gain + gain
            cand_ids = sorted(prev_ids + [item_id])
            cur_gain, cur_ids = best[c]
            if cand_gain > cur_gain or (cand_gain == cur_gain and cand_ids < cur_ids):
                best[c] = (cand_gain, cand_ids)

    # best[c] is monotonic in c, so the answer is at the full capacity.
    return best[capacity][1]
