def discounted(price, percent):
    if price < 0:
        raise ValueError("Price cannot be negative")
    if percent < 0 or percent > 100:
        raise ValueError("Percent must be between 0 and 100")
    return price * (1 - percent / 100)
