from pricing import discounted

# Test valid cases
print(f"Discount 20% on $100: ${discounted(100, 20)}")  # Should be 80
print(f"Discount 50% on $100: ${discounted(100, 50)}")  # Should be 50

# Test invalid cases
try:
    discounted(-10, 10)
except ValueError as e:
    print(f"Error (negative price): {e}")

try:
    discounted(100, 150)
except ValueError as e:
    print(f"Error (percent > 100): {e}")

try:
    discounted(100, -10)
except ValueError as e:
    print(f"Error (percent < 0): {e}")
