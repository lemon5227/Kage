import subprocess
result = subprocess.run(['python', 'test_pricing.py'], capture_output=True, text=True)
print(result.stdout)
if result.stderr:
    print("STDERR:", result.stderr)
