def choose(jobs, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for j in jobs:
        if j['weight'] <= 0:
            raise ValueError("job weight must be positive")
    # Greedy selection maximizing total value under weight constraint.
    # On ties, pick the lexicographically smallest ID list.
    selected = []
    used_weight = 0
    remaining = list(jobs)
    while True:
        best = None
        best_ratio = None
        best_id = None
        for j in remaining:
            if used_weight + j['weight'] <= capacity:
                v = j['value']
                w = j['weight']
                ratio = v / w if w else float('inf')
                if best is None or ratio > best_ratio or (ratio == best_ratio and j['id'] < best_id):
                    best = j
                    best_ratio = ratio
                    best_id = j['id']
        if best is None:
            break
        selected.append(best['id'])
        used_weight += best['weight']
        remaining = [j for j in remaining if j['id'] != best['id']]
    return sorted(selected)
