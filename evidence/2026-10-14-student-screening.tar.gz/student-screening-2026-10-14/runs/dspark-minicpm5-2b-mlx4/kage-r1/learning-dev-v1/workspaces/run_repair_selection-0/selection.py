def choose(jobs, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for job in jobs:
        if job['weight'] <= 0:
            raise ValueError("job weight must be positive")
    selected = []
    # 0-1 knapsack (each job at most once)
    items = sorted(jobs, key=lambda j: (-j['value'], j['id']))
    for job in items:
        if job['weight'] <= capacity and len(selected) * job['weight'] + sum(job['weight'] for j in selected) <= capacity:
            selected.append(job['id'])
    # selected is currently in insertion order; sort IDs for consistent output
    return sorted(selected)
