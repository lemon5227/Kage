def choose(jobs, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for job in jobs:
        if job['weight'] <= 0:
            raise ValueError("job weight must be positive")
    # sort jobs by value descending, weight ascending, then id lexicographically
    sorted_jobs = sorted(jobs, key=lambda x: (-x['value'], x['weight'], x['id']))
    selected_ids = []
    total_weight = 0
    for job in sorted_jobs:
        if total_weight + job['weight'] <= capacity:
            selected_ids.append(job['id'])
            total_weight += job['weight']
    # lexicographically smallest ID list when values equal
    if len(selected_ids) > 1 and all(j['value'] == 0 for j in jobs):
        selected_ids.sort()
    return sorted(selected_ids)
