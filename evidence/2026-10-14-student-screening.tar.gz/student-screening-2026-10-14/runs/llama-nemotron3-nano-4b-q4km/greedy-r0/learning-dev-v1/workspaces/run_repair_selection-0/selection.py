def choose(jobs, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for job in jobs:
        if job['weight'] <= 0:
            raise ValueError("job weight must be positive")
    
    # Sort jobs by value descending, then by id ascending (lexicographically smallest)
    sorted_jobs = sorted(jobs, key=lambda x: (-x['value'], x['id']))
    
    selected = []
    total_weight = 0
    for job in sorted_jobs:
        if total_weight + job['weight'] <= capacity:
            selected.append(job['id'])
            total_weight += job['weight']
    
    return selected
