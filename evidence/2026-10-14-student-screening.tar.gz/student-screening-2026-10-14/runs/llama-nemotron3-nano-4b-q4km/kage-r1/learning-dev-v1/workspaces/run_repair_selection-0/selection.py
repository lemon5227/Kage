def choose(jobs, capacity):
    if capacity < 0:
        raise ValueError('capacity cannot be negative')
    for job in jobs:
        if job['weight'] <= 0:
            raise ValueError('job weight must be positive')
    
    # Sort jobs by value (desc) and then by id (asc)
    sorted_jobs = sorted(jobs, key=lambda x: (-x['value'], x['id']))
    
    total_value = 0
    selected_ids = []
    for job in sorted_jobs:
        if total_value + job['value'] <= capacity:
            selected_ids.append(job['id'])
            total_value += job['value']
    
    return selected_ids
