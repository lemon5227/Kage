def discounted(price, percent):
    if price < 0 or percent < 0 or percent > 100:
        raise ValueError("price must be non-negative and percent between 0 and 100")
    return price * (1 - percent / 100)
