def choose(jobs, capacity):
    if capacity < 0:
        raise ValueError('capacity must be nonnegative')
    for j in jobs:
        if j['weight'] <= 0:
            raise ValueError('job weight must be positive')
        if j['value'] < 0:
            raise ValueError('job value must be nonnegative')
    
    # Sort by value descending, id ascending
    sorted_jobs = sorted(jobs, key=lambda x: (-x['value'], x['id']))
    selected = []
    total_weight = 0
    for job in sorted_jobs:
        if total_weight + job['weight'] <= capacity:
            selected.append(job['id'])
            total_weight += job['weight']
    return selected
