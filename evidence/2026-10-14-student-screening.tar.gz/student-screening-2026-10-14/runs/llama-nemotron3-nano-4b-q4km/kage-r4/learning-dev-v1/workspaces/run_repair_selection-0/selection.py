def choose(jobs, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    
    total_weight = sum(j['weight'] for j in jobs)
    if any(j['weight'] <= 0 for j in jobs):
        raise ValueError("job weights must be positive integers")
    
    # Sort jobs by value (descending), then by id (ascending) for lexicographic tie-breaking
    sorted_jobs = sorted(jobs, key=lambda x: (-x['value'], x['id']))
    
    selected = []
    current_weight = 0
    max_value = 0
    best_selection = []  # default is empty selection
    
    for job in sorted_jobs:
        if current_weight + job['weight'] > capacity:
            break
        selected.append(job['id'])
        current_weight += job['weight']
        max_value += job['value']
        
        if max_value > best_selection[0] or (max_value == best_selection[0] and selected < best_selection):
            # Compare as strings for lexicographic order
            best_selection = selected.copy()
    
    return best_selection
