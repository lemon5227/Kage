def choose(jobs, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for j in jobs:
        if j.get('weight', 0) <= 0:
            raise ValueError("job weight must be positive")
    selected = []
    total_value = 0
    total_weight = 0
    for job in jobs:
        job_id = job['id']
        w = job['weight']
        v = job['value']
        if total_weight + w <= capacity:
            selected.append(job_id)
            total_value += v
            total_weight += w
    # On equal value, prefer the lexicographically smallest selection.
    # Standard knapsack ensures the max value; if there are ties, pick the one with
    # the lexicographically smallest list of IDs (which we already produce by processing
    # jobs in input order and only adding when they fit).
    result = selected
    return result
