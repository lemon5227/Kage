def choose(jobs, capacity):
    if capacity < 0:
        raise ValueError("capacity must be non-negative")
    for j in jobs:
        if j.get('weight', 0) <= 0:
            raise ValueError("all job weights must be positive")
    selected = []
    remaining_capacity = capacity
    for job in jobs:
        if remaining_capacity >= job['weight']:
            selected.append(job['id'])
            remaining_capacity -= job['weight']
    return sorted(selected)
