"""Engine-neutral streaming speed probe: TTFT/prefill tok/s on a fixed Kage request, decode tok/s on fixed prose."""
import json, os, sys, time, uuid, urllib.request
from pathlib import Path
port, model, out = sys.argv[1], sys.argv[2], Path(sys.argv[3])
base = json.loads((Path(__file__).parent / "probe_prompt.json").read_text())

def stream(messages, tools, max_tokens):
    payload = {"model": model, "messages": messages, "max_tokens": max_tokens, "temperature": 0, "stream": True,
               "stream_options": {"include_usage": True}, "cache_prompt": False}
    payload.update(json.loads(os.environ.get("SCREEN_SAMPLING", "{}")))
    if tools: payload["tools"] = tools
    req = urllib.request.Request(f"http://127.0.0.1:{port}/v1/chat/completions", json.dumps(payload).encode(),
                                 {"Content-Type": "application/json"})
    t0 = time.monotonic(); first = last = None; chunks = 0; usage = None; timings = None
    with urllib.request.urlopen(req, timeout=300) as r:
        for line in r:
            line = line.strip()
            if not line.startswith(b"data:") or line.endswith(b"[DONE]"): continue
            d = json.loads(line[5:])
            usage = d.get("usage") or usage; timings = d.get("timings") or timings
            for ch in d.get("choices") or []:
                delta = ch.get("delta") or {}
                if delta.get("content") or delta.get("tool_calls") or delta.get("reasoning_content") or delta.get("reasoning"):
                    now = time.monotonic(); first = first or now; last = now; chunks += 1
    return {"ttft_s": (first - t0) if first else None, "decode_s": (last - first) if first else None,
            "chunks": chunks, "usage": usage, "timings": timings, "wall_s": time.monotonic() - t0}

res = {"prefill": [], "decode": []}
for i in range(3):
    msgs = json.loads(json.dumps(base["messages"]))
    msgs[0]["content"] = f"[probe {uuid.uuid4().hex}]\n" + msgs[0]["content"]
    r = stream(msgs, None, 16); pt = (r["usage"] or {}).get("prompt_tokens")
    r["prompt_tokens"] = pt; r["prefill_tok_s"] = pt / r["ttft_s"] if pt and r["ttft_s"] else None
    res["prefill"].append(r)
    r = stream([{"role": "user", "content": f"[{uuid.uuid4().hex}] Write a detailed 400-word essay about the history of maps. Do not use tools."}], None, 128)
    n = (r["usage"] or {}).get("completion_tokens") or r["chunks"]
    r["completion_tokens"] = n; r["decode_tok_s"] = (n - 1) / r["decode_s"] if r["decode_s"] else None
    res["decode"].append(r)
med = lambda xs: sorted(x for x in xs if x is not None)[len([x for x in xs if x is not None]) // 2] if any(x is not None for x in xs) else None
res["median"] = {"ttft_s": med([r["ttft_s"] for r in res["prefill"]]), "prefill_tok_s": med([r["prefill_tok_s"] for r in res["prefill"]]),
                 "decode_tok_s": med([r["decode_tok_s"] for r in res["decode"]])}
out.write_text(json.dumps(res, indent=1)); print(json.dumps(res["median"]))
