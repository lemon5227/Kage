#!/bin/bash
# prints used MB = (active + wired + compressor-occupied) pages * pagesize
vm_stat | awk '/page size of/ {ps=$8} /Pages active/ {a=$3} /Pages wired down/ {w=$4} /occupied by compressor/ {c=$5} END {gsub("\\.","",a); gsub("\\.","",w); gsub("\\.","",c); printf "%d\n", (a+w+c)*ps/1048576}'
