"""Summarize screening matrix: runs/<engine-label>/<tag>/{files-v1,learning-dev-v1,probe.json,mem.txt,env.txt}."""
import json, re, statistics, sys
from collections import defaultdict
from pathlib import Path

LEAK = re.compile(r"<tool_call>|<function[ =>]|<\|tool|\"arguments\"\s*:|<param name=", re.I)
TASKS = ["csv_totals", "inventory_join", "repair_discount", "incident_counts", "meeting_slot", "extract_actions", "repair_selection"]

def med(xs):
    xs = [x for x in xs if isinstance(x, (int, float))]
    return round(statistics.median(xs), 2) if xs else None

def unit_stats(u: Path):
    s = defaultdict(float); per_task = {}; accept = []
    for suite in ("files-v1", "learning-dev-v1"):
        rp = u / suite / "results.json"
        if not rp.exists(): continue
        for row in json.loads(rp.read_text()):
            meta = row.get("metadata") or {}
            chain = (meta.get("chain") or [{}])[0]
            mf = u / suite / f"{row['run_id']}-model.jsonl"
            calls = [json.loads(l) for l in mf.open()] if mf.exists() else []
            pe = sum((c["response"].get("error") or "").startswith("InvalidToolArguments") for c in calls)
            other_err = sum(bool(c["response"].get("error")) and not (c["response"].get("error") or "").startswith("InvalidToolArguments") for c in calls)
            leak = sum((not c["response"].get("tool_calls")) and bool(LEAK.search(c["response"].get("text") or "")) for c in calls)
            for c in calls:
                try: body = json.loads(c["response"].get("raw_output") or "{}")
                except json.JSONDecodeError: continue
                x = body.get("x_mlx_dspark") or {}
                for k in ("mean_accept_len", "accept_len", "mean_acceptance_length"):
                    if isinstance(x.get(k), (int, float)): accept.append(x[k]); break
            ok = row["status"] == "passed"
            per_task[row["task"]] = ok
            s["runs"] += 1; s["passed"] += ok; s["parse_err"] += pe; s["leak"] += leak; s["model_err_other"] += other_err
            s["tool_err"] += len(chain.get("tool_errors") or []); s["model_calls"] += meta.get("chain_model_calls", len(calls))
            s["seconds"] += row["seconds"]; s["timeout"] += row["status"] == "timeout"; s["crashed"] += row["status"] == "crashed"
    probe = json.loads((u / "probe.json").read_text())["median"] if (u / "probe.json").exists() else {}
    mem = [l.split() for l in (u / "mem.txt").open()] if (u / "mem.txt").exists() else []
    rss = [int(m[1]) for m in mem if len(m) == 3 and m[1].isdigit()]
    sysm = [int(m[2]) for m in mem if len(m) == 3 and m[2].isdigit()]
    env = (u / "env.txt").read_text() if (u / "env.txt").exists() else ""
    before = re.search(r"sysmem_before_mb (\d+)", env)
    therm = re.findall(r"thermal_(?:before|after) (\d)", env)
    spec = {}
    if (u / "dflash-metrics.json").exists():
        try:
            m = json.loads((u / "dflash-metrics.json").read_text()); spec["dflash_metrics"] = {k: m.get(k) for k in ("rates", "totals", "acceptance", "speculative") if k in m}
            rr = m.get("recent_requests") or []
            spec["dflash_tokens_per_cycle"] = med([r.get("tokens_per_cycle") for r in rr])
        except Exception as e: spec["dflash_metrics_error"] = str(e)
    if accept: spec["dspark_mean_accept_len"] = med(accept)
    return {"stats": dict(s), "per_task": per_task, "probe": probe,
            "peak_rss_mb": round(max(rss) / 1024) if rss else None,
            "peak_sys_delta_mb": (max(sysm) - int(before.group(1))) if sysm and before else None,
            "thermal": therm, "spec": spec, "complete": (u / "learning-dev-v1" / "results.json").exists()}

def main(root: Path, prefix: str):
    out = {}
    for cfg in sorted(p for p in root.iterdir() if p.is_dir()):
        units = {u.name: unit_stats(u) for u in sorted(cfg.iterdir()) if u.is_dir() and u.name.startswith(prefix)}
        units = {k: v for k, v in units.items() if v["complete"]}
        if not units: continue
        tot = defaultdict(float); task_pass = defaultdict(int)
        for v in units.values():
            for k, x in v["stats"].items(): tot[k] += x
            for t, ok in v["per_task"].items(): task_pass[t] += ok
        out[cfg.name] = {"units": len(units), "tot": dict(tot), "task_pass": dict(task_pass),
                         "ttft_s": med([v["probe"].get("ttft_s") for v in units.values()]),
                         "prefill_tok_s": med([v["probe"].get("prefill_tok_s") for v in units.values()]),
                         "decode_tok_s": med([v["probe"].get("decode_tok_s") for v in units.values()]),
                         "decode_tok_s_per_unit": [v["probe"].get("decode_tok_s") for v in units.values()],
                         "peak_rss_mb": max((v["peak_rss_mb"] or 0) for v in units.values()),
                         "peak_sys_delta_mb": max((v["peak_sys_delta_mb"] or 0) for v in units.values()),
                         "thermal": [v["thermal"] for v in units.values()],
                         "spec": [v["spec"] for v in units.values() if v["spec"]]}
    return out

if __name__ == "__main__":
    root = Path(sys.argv[1]); prefix = sys.argv[2] if len(sys.argv) > 2 else "kage-"
    res = main(root, prefix)
    print("cfg | units | pass | " + " ".join(t[:8] for t in TASKS) + " | parse_err | leak | other_err | tool_err | calls/run | s/run | TTFT s | prefill t/s | decode t/s | RSS MB | sysΔ MB")
    for k, v in res.items():
        t = v["tot"]; n = t.get("runs", 1) or 1
        print(f"{k} | {v['units']} | {int(t.get('passed',0))}/{int(n)} | " + " ".join(str(v['task_pass'].get(x, '-')) for x in TASKS) +
              f" | {int(t.get('parse_err',0))} | {int(t.get('leak',0))} | {int(t.get('model_err_other',0))} | {int(t.get('tool_err',0))} | {t.get('model_calls',0)/n:.1f} | {t.get('seconds',0)/n:.1f} | "
              f"{v['ttft_s']} | {v['prefill_tok_s']} | {v['decode_tok_s']} | {v['peak_rss_mb']} | {v['peak_sys_delta_mb']}")
    (root.parent / f"summary-{prefix.rstrip('-')}.json").write_text(json.dumps(res, indent=1, ensure_ascii=False))
