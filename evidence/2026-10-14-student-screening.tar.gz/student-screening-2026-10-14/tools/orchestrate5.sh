#!/bin/bash
# Main matrix: 13 engine x model configs, Kage sampling, 3 rounds with rotated order; then temp=0 reference units.
# Waits (never runs concurrently) while the other session's stream experiment or a busy :18082 is detected.
T=$(dirname "$0"); A=/Users/wenbo/Kage/artifacts/student-screening-2026-10-14/runs
G=$HOME/.kage/models; X=$G/mlx; DR=$X/drafts
KAGE='{"temperature":0.85,"top_p":0.95,"top_k":20,"min_p":0.0,"presence_penalty":1.1}'
GREEDY='{"temperature":0}'
# engine|label|weights|draft|rapid_parser
CFGS=("llama|agents-a1-4b-q4km|$G/agents-a1-4b/Agents-A1-4B-Q4_K_M.gguf|-|-"
      "llama|minicpm5-2b-q8|$G/minicpm5-2b/MiniCPM5-2B-Q8_0.gguf|-|-"
      "llama|minicpm5-2b-q4km|$G/minicpm5-2b/MiniCPM5-2B-Q4_K_M.gguf|-|-"
      "llama|qwen3.5-9b-q4km|$G/qwen3.5-9b/Qwen3.5-9B-Q4_K_M.gguf|-|-"
      "llama|nemotron3-nano-4b-q4km|$G/nemotron-3-nano-4b/NVIDIA-Nemotron3-Nano-4B-Q4_K_M.gguf|-|-"
      "mlxlm|agents-a1-4b-mlx4|$X/agents-a1-4b-mlx-4bit|-|-"
      "mlxlm|qwen3.5-9b-mlx4|$X/qwen3.5-9b-mlx-4bit|-|-"
      "rapid|agents-a1-4b-mlx4|$X/agents-a1-4b-mlx-4bit|-|auto"
      "rapid|minicpm5-2b-mlx4|$X/minicpm5-2b-mlx-4bit|-|minicpm"
      "rapid|qwen3.5-9b-mlx4|$X/qwen3.5-9b-mlx-4bit|-|auto"
      "dspark|minicpm5-2b-mlx4|$X/minicpm5-2b-mlx-4bit|$DR/MiniCPM5-2B-DSpark|-"
      "dflash|qwen3.5-9b-mlx4|$X/qwen3.5-9b-mlx-4bit|$DR/Qwen3.5-9B-DFlash|-"
      "dflash|agents-a1-4b-mlx4|$X/agents-a1-4b-mlx-4bit|$DR/Qwen3.5-4B-DFlash|-")
busy() {
  pgrep -f "run_unit2.sh" >/dev/null && return 0
  pgrep -f "night-2026-10-14.sh" >/dev/null && [ "$(date +%H%M)" -ge 2245 ] && return 0
  pgrep -f "stream_run.py|stream_calibrate.py|chain-2026-10-14.sh" >/dev/null && return 0
  curl -s --max-time 3 http://127.0.0.1:18082/slots 2>/dev/null | grep -q '"is_processing":true' && return 0
  return 1
}
wait_idle() { local w=0; while busy; do [ $w = 0 ] && echo "waiting for other experiment $(date)"; w=1; sleep 60; done; }
unit() { # cfg-index sampling tag
  IFS='|' read -r eng label w d parser <<< "${CFGS[$1]}"
  out="$A/$eng-$label/$3"
  [ -f "$out/learning-dev-v1/results.json" ] && return
  wait_idle
  rm -rf "$out"
  echo "unit $eng-$label $3 start $(date)"
  RAPID_PARSER=$([ "$parser" = - ] && echo auto || echo $parser) "$T/run_unit2.sh" "$eng" "$label" "$w" "$d" "$out" "$2"
  echo "unit $eng-$label $3 end rc=$? $(date)"
  sleep 30
}
# Focused follow-up: Agents-A1 (llama, rapid) vs Nemotron (llama), Kage sampling to 7 rounds each, rotated; then greedy refs.
F=(0 4 7)
for round in 2 3 4 5 6; do
  for k in 0 1 2; do idx=${F[$(( (k + round) % 3 ))]}; unit $idx "$KAGE" "kage-r$round"; done
done
for idx in 0 4 7; do unit $idx "$GREEDY" "greedy-r0"; done
echo "all done $(date)"
