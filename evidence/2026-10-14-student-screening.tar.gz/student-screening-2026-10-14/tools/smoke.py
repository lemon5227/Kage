"""Tool-call parse smoke test through Kage's OpenAICompatibleProvider."""
import json, sys
sys.path.insert(0, sys.argv[1])
from core.model_provider import OpenAICompatibleProvider
port, model = sys.argv[2], sys.argv[3]
p = OpenAICompatibleProvider(api_key="local", model_name=model, base_url=f"http://127.0.0.1:{port}/v1")
tools = [{"type": "function", "function": {"name": "read_file", "description": "Read a text file",
          "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
         {"type": "function", "function": {"name": "write_file", "description": "Write a text file",
          "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"]}}}]
out = []
for prompt in ["Read the file notes.txt.", "Write a file out.json containing {\"a\": 1}."]:
    r = p.generate([{"role": "system", "content": "You are an agent. Use tools."}, {"role": "user", "content": prompt}],
                   tools=tools, max_tokens=512, temperature=0)
    body = json.loads(r.raw_output) if r.raw_output else {}
    msg = (body.get("choices") or [{}])[0].get("message", {})
    out.append({"prompt": prompt, "parsed_tool_calls": r.tool_calls, "error": r.error, "text": r.text[:300],
                "raw_tool_calls": msg.get("tool_calls"), "finish_reason": (body.get("choices") or [{}])[0].get("finish_reason"),
                "timings": body.get("timings")})
print(json.dumps(out, ensure_ascii=False, indent=1))
