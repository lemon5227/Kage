#!/bin/bash
# At 22:58 abort any in-flight screening unit so nothing overlaps the 23:00 chain; aborted units are re-run later.
until [ "$(date +%H%M)" -ge 2258 ]; do sleep 20; done
if pgrep -f run_unit2.sh >/dev/null; then
  echo "abort in-flight unit at $(date): $(pgrep -fl run_unit2.sh | head -1 | cut -c1-300)"
  pkill -f run_unit2.sh; pkill -f screen_suite.py; pkill -f probe.py
  for p in $(lsof -t -nP -iTCP:18090 -sTCP:LISTEN); do kill $p; done
  sleep 5; for p in $(lsof -t -nP -iTCP:18090 -sTCP:LISTEN); do kill -9 $p; done
else echo "no unit in flight at $(date)"; fi
lsof -nP -iTCP:18090 -sTCP:LISTEN || echo "18090 free"
