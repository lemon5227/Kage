"""Screening-only wrapper around scripts/experiments/task_suite.py.

Overrides the request sampling (task_suite pins temperature=0) without touching Kage code:
SCREEN_SAMPLING='{"temperature":0.85,"top_p":0.95,"top_k":20,"presence_penalty":1.1}'.
The recorded *-model.jsonl keeps task_suite's kwargs; the actual payload sampling is written to sampling.json.
"""
import json, os, sys
from pathlib import Path
REPO = Path(sys.argv.pop(1)).resolve()
sys.path.insert(0, str(REPO))
import scripts.experiments.task_suite as ts

SAMPLING = json.loads(os.environ.get("SCREEN_SAMPLING", "{}"))
_orig = ts.RecordedLocalProvider._request_payload

def _payload(self, messages, tools=None, max_tokens=200, temperature=0.7):
    p = _orig(self, messages, tools, max_tokens, temperature)
    p.update(SAMPLING)
    return p

ts.RecordedLocalProvider._request_payload = _payload
if "--output-dir" in sys.argv:
    out = Path(sys.argv[sys.argv.index("--output-dir") + 1])
    out.parent.mkdir(parents=True, exist_ok=True)
    (out.parent / f"{out.name}.sampling.json").write_text(json.dumps(SAMPLING))
ts.main()
