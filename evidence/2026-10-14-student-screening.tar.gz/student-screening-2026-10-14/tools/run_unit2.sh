#!/bin/bash
# usage: run_unit2.sh <engine llama|mlxlm|rapid|dspark|dflash> <label> <weights> <draft|-> <outdir> <sampling-json>
# One unit = own server on :18090, smoke (temp0), speed probe + 7 exposed tasks x1 with given sampling, stop server.
set -u
ENGINE=$1; LABEL=$2; W=$3; DRAFT=$4; OUT=$5; SAMP=$6
REPO=/Users/wenbo/Kage/.claude/worktrees/upbeat-meninsky-4dcbd9
PY=/Users/wenbo/.codex/worktrees/c2-learning-loop/Kage/.venv-computer-use/bin/python
T=$(dirname "$0"); V=$T/../venvs; PORT=18090; MODEL="$W"
export RAPID_MLX_TELEMETRY=0 DO_NOT_TRACK=1 HF_HUB_OFFLINE=1 SCREEN_SAMPLING="$SAMP"
mkdir -p "$OUT"
if lsof -nP -iTCP:$PORT -sTCP:LISTEN >/dev/null; then echo "$(date +%s) port_busy" >> "$OUT/env.txt"; exit 2; fi
echo "$(date +%s) thermal_before $($T/therm) sysmem_before_mb $($T/sysmem.sh) engine $ENGINE parser ${RAPID_PARSER:-auto} draft $DRAFT sampling $SAMP" >> "$OUT/env.txt"
case $ENGINE in
 llama) MODEL="$LABEL"
  /opt/homebrew/bin/llama-server -m "$W" --alias "$LABEL" --jinja --host 127.0.0.1 --port $PORT -ngl 99 --flash-attn auto -c 8192 -np 1 -n 1024 --reasoning off --cache-type-k q8_0 --cache-type-v q8_0 --temp 0.85 --top-p 0.95 --top-k 20 --presence-penalty 1.1 > "$OUT/server.log" 2>&1 & ;;
 mlxlm)
  "$PY" -m mlx_lm.server --model "$W" --host 127.0.0.1 --port $PORT --max-tokens 1024 --temp 0.85 --top-p 0.95 --top-k 20 --chat-template-args '{"enable_thinking":false}' > "$OUT/server.log" 2>&1 & ;;
 rapid)
  "$V/rapid-mlx/bin/rapid-mlx" serve "$W" --host 127.0.0.1 --port $PORT --served-model-name "$W" --text-only --no-thinking --enable-auto-tool-choice --tool-call-parser ${RAPID_PARSER:-auto} --disable-model-downloads --max-tokens 1024 --context-length 8192 --default-temperature 0.85 --default-top-p 0.95 --default-top-k 20 --default-presence-penalty 1.1 > "$OUT/server.log" 2>&1 & ;;
 dspark)
  "$V/mlx-dspark/bin/mlx-dspark" serve --model "$W" --drafter "$DRAFT" --host 127.0.0.1 --port $PORT --no-thinking --context-window 8192 --default-max-tokens 1024 --default-temperature 0.85 --default-top-p 0.95 --default-top-k 20 > "$OUT/server.log" 2>&1 & ;;
 dflash)
  "$V/dflash-mlx/bin/dflash" serve --model "$W" --draft "$DRAFT" --host 127.0.0.1 --port $PORT --max-tokens 1024 --temp 0.85 --top-p 0.95 --top-k 20 --chat-template-args '{"enable_thinking":false}' > "$OUT/server.log" 2>&1 & ;;
esac
SPID=$!
( while kill -0 $SPID 2>/dev/null; do echo "$(date +%s) $(ps -o rss= -p $SPID) $($T/sysmem.sh)"; sleep 1; done ) > "$OUT/mem.txt" &
MPID=$!
cleanup() { pkill -P $SPID 2>/dev/null; kill $SPID 2>/dev/null; sleep 3; kill -9 $SPID 2>/dev/null; kill $MPID 2>/dev/null; }
trap cleanup EXIT
ok=0; for i in $(seq 300); do curl -sf http://127.0.0.1:$PORT/v1/models >/dev/null && { ok=1; break; }; kill -0 $SPID 2>/dev/null || break; sleep 1; done
[ $ok = 1 ] || { echo "$(date +%s) server_failed" >> "$OUT/env.txt"; exit 1; }
echo "$(date +%s) server_ready" >> "$OUT/env.txt"
SCREEN_SAMPLING='{}' "$PY" -I "$T/smoke.py" "$REPO" $PORT "$MODEL" > "$OUT/smoke.json" 2>&1
[ "${SMOKE_ONLY:-0}" = 1 ] && exit 0
"$PY" -I "$T/probe.py" $PORT "$MODEL" "$OUT/probe.json" > "$OUT/probe.stdout" 2>&1
for suite in files-v1 learning-dev-v1; do
  echo "$(date +%s) suite $suite" >> "$OUT/env.txt"
  "$PY" -I "$T/screen_suite.py" "$REPO" --suite "$REPO/eval/computer-use/$suite.json" --split all --runs 1 --port $PORT --model "$MODEL" --output-dir "$OUT/$suite" > "$OUT/$suite.stdout" 2>&1
done
[ $ENGINE = dflash ] && curl -s http://127.0.0.1:$PORT/metrics > "$OUT/dflash-metrics.json"
echo "$(date +%s) thermal_after $($T/therm)" >> "$OUT/env.txt"
