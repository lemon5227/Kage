import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)
    data = cleaned

    # drop rows whose "id" cell is empty
    id_idx = header.index("id")
    filtered = []
    for cells in data:
        if id_idx >= len(cells):
            continue
        if cells[id_idx] == "":
            continue
        filtered.append(cells)
    data = filtered

    # lower-case the "email" column
    email_idx = header.index("email")
    for cells in data:
        if email_idx < len(cells):
            cells[email_idx] = cells[email_idx].lower()

    # remove duplicate rows by "email", keeping the first occurrence
    seen = set()
    deduped = []
    for cells in data:
        key = cells[email_idx] if email_idx < len(cells) else ""
        if key in seen:
            continue
        seen.add(key)
        deduped.append(cells)
    data = deduped

    # sort rows by "email" ascending as strings (stable)
    email_idx = header.index("email")
    data.sort(key=lambda cells: cells[email_idx] if email_idx < len(cells) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for cells in data:
        writer.writerow(cells)
    return out.getvalue()
