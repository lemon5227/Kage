def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity.  Ties on total value are broken by choosing the
    lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_value, chosen_ids) for capacity c.
    # We track the chosen ids so we can reconstruct the solution.
    prev = [None] * (capacity + 1)
    for idx in range(len(entries)):
        item_id, weight, value = entries[idx]
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, weight - 1, -1):
            cand_value = prev[c - weight][1] + value
            if (cand_value > prev[c][1]) or \
               (cand_value == prev[c][1] and
                sorted(cand_value[2] + [item_id]) < sorted(prev[c][2] + [item_id])):
                prev[c] = (cand_value, [item_id] + prev[c - weight][2])

    return sorted(prev[capacity][2])
