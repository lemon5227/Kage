def select_tasks(items, capacity):
    """Select a subset of items maximizing total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by choosing the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_gain, sorted_id_list) achievable with cost exactly c.
    # We track the chosen subset so we can reconstruct the lexicographically
    # smallest tie-breaker.
    prev = [(None, None)] * (capacity + 1)
    for item_id, cost, gain in entries:
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            if prev[c - cost][1] is None:
                continue
            cand_gain = prev[c - cost][0] + gain
            cand_ids = list(prev[c - cost][1]) + [item_id]
            cand_ids.sort()
            if prev[c][0] is None or cand_gain > prev[c][0]:
                prev[c] = (cand_gain, cand_ids)
            elif cand_gain == prev[c][0]:
                # Tie on gain: prefer lexicographically smallest sorted id list.
                if cand_ids < prev[c][1]:
                    prev[c] = (cand_gain, cand_ids)

    # The optimal gain is the maximum over all feasible costs.
    best_gain = None
    best_ids = None
    for c in range(capacity + 1):
        gain, ids = prev[c]
        if gain is None:
            continue
        if best_gain is None or gain > best_gain:
            best_gain = gain
            best_ids = ids
        elif gain == best_gain:
            if best_ids is None or ids < best_ids:
                best_ids = ids

    return best_ids if best_ids is not None else []
