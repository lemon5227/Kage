def summarize(lines):
    """Count WARN lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each service to the number of WARN lines it has.
    Levels are case-insensitive. Malformed lines are skipped.
    Services with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # split into timestamp, level, service, message
        if len(parts) < 3:
            continue
        _timestamp, level, service = parts[0], parts[1], parts[2]
        if not service.endswith(':'):
            continue
        service = service[:-1]
        if not service:
            continue
        if level.upper() != "WARN":
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
