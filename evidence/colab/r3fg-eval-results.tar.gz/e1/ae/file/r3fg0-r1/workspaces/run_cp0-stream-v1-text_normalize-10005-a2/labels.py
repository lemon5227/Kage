import unicodedata


def to_key(text):
    """Normalize labels into identifiers."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # Apply NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize('NFKD', text)
    # Keep only ASCII characters (0-127)
    ascii_only = ''.join(c for c in normalized if ord(c) < 128)

    # Lower-case
    lowercased = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is not None:
                result.append('_')
            prev_char = None
        else:
            result.append(char)
            prev_char = char
    return ''.join(result)
