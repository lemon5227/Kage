import unicodedata

def slugify(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lowercase
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # Split on non-alphanumeric characters and join with hyphen
    parts = [part for part in lower_text.split() if part.isalnum()]
    slug = '-'.join(parts)
    
    # Strip leading and trailing "-"
    slug = slug.strip('-')
    
    return slug
