import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)

    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "score" cell is empty
    score_idx = header.index("score") if "score" in header else -1
    if score_idx >= 0:
        cleaned = [row for row in cleaned if len(row) > score_idx and row[score_idx] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    seen = set()
    deduped = []
    for row in cleaned:
        key = row[score_idx] if score_idx >= 0 and len(row) > score_idx else None
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    # sort rows by "name" ascending as strings (stable)
    name_idx = header.index("name") if "name" in header else -1
    if name_idx >= 0:
        deduped.sort(key=lambda row: row[name_idx] if len(row) > name_idx else "")

    # write output with '\n' line endings
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()
