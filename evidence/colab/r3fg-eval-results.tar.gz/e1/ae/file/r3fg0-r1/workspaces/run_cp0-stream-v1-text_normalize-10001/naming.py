import unicodedata


def slugify(text):
    """Turn a title into a handle."""
    if not isinstance(text, str):
        raise TypeError("Expected string, got %s" % type(text).__name__)

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize('NFKD', text)
    ascii_only = ''.join(c for c in normalized if ord(c) < 128)

    # lower-case
    lower = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for char in lower:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is not None:
                result.append('_')
            prev_char = None
        else:
            result.append(char)
            prev_char = char
    slug = ''.join(result)

    # strip leading and trailing "_"
    return slug.strip('_')
