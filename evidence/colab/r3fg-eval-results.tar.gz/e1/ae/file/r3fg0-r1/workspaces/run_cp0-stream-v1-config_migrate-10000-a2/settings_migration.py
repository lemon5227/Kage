def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported")

    # Create new dict with version 2
    new_cfg = {"version": 2}

    # Handle top-level keys
    if "max_conn" in cfg:
        new_cfg["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        new_cfg["directory"] = cfg["dir"]
    if "host" in cfg:
        new_cfg["hostname"] = cfg["host"]

    # Move cache_size and region into limits sub-dict
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    new_cfg["limits"] = limits

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged (copy them)
    for key, value in cfg.items():
        if key not in ("max_conn", "dir", "host", "cache_size", "region", "timeout_ms", "version"):
            if value is not None:
                new_cfg[key] = value

    return new_cfg
