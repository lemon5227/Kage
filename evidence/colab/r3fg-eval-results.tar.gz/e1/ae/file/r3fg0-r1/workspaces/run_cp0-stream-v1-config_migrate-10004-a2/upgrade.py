def migrate(cfg):
    """Migrate a v1 config dict to v2."""
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1")
    
    # Create new dict without modifying input
    result = {}
    result["version"] = 2
    
    # Process keys
    for key, value in cfg.items():
        if key == "pwd_file":
            result["password_file"] = value
        elif key == "user":
            result["username"] = value
        elif key == "cache_size":
            # Move into network dict
            if "network" not in result:
                result["network"] = {}
            result["network"]["cache_size"] = value
        elif key == "workers":
            # Move into network dict
            if "network" not in result:
                result["network"] = {}
            result["network"]["workers"] = value
        elif key == "timeout_ms":
            # Convert to timeout_s (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged, but drop if value is None
            if value is not None:
                result[key] = value
    
    # Ensure network dict exists (always present, possibly empty)
    if "network" not in result:
        result["network"] = {}
    
    return result
