def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported")

    # Create new dict with version 2
    result = {"version": 2}

    # Rename top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]

    # Handle port and workers - move into storage sub-dict
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    result["storage"] = storage

    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged (but drop keys with None values)
    for key, value in cfg.items():
        if key not in ["dir", "host", "port", "workers", "timeout_ms", "version"]:
            if value is not None:
                result[key] = value

    return result
