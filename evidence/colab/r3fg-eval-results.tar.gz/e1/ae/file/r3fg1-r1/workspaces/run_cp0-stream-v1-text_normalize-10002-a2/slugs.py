import unicodedata

def slugify(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization to decompose characters
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace sequences of non-alphanumeric characters with a single hyphen
    slug = []
    previous_char = None
    for char in lower_text:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            slug.append(char)
        else:
            if previous_char is not None:
                # We're in a run of non-alphanumeric characters
                slug.append('-')
            previous_char = char
    
    # Join and strip leading/trailing hyphens
    result = ''.join(slug).strip('-')
    
    return result
