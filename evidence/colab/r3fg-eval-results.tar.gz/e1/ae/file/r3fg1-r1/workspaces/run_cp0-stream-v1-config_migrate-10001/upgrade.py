def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported")

    # Make a copy to avoid modifying input
    result = dict(cfg)
    result["version"] = 2

    # Rename top-level keys
    if "host" in result:
        result["hostname"] = result.pop("host")
    if "max_conn" in result:
        result["max_connections"] = result.pop("max_conn")
    if "pwd_file" in result:
        result["password_file"] = result.pop("pwd_file")

    # Move port and retries into storage sub-dict
    storage = {}
    if "port" in result:
        storage["port"] = result.pop("port")
    if "retries" in result:
        storage["retries"] = result.pop("retries")
    result["storage"] = storage

    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in result:
        result["timeout_s"] = result["timeout_ms"] / 1000.0
        result.pop("timeout_ms", None)

    # Drop keys whose value is None
    result = {k: v for k, v in result.items() if v is not None}

    return result
