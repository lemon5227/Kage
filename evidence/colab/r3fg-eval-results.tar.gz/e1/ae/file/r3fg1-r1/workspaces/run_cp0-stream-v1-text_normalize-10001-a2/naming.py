import unicodedata


def slugify(text):
    """Turn a title into a handle."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization to decompose characters
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    # This means we replace any sequence of non-alphanumeric characters with "_"
    slug = ""
    for char in lower_text:
        if char.isalnum():  # alphanumeric means a-z, A-Z, 0-9
            slug += char
        else:
            # If we encounter a non-alphanumeric character, add "_" only once
            if not slug.endswith("_"):
                slug += "_"
    
    # Strip leading and trailing "_"
    return slug.strip("_")
