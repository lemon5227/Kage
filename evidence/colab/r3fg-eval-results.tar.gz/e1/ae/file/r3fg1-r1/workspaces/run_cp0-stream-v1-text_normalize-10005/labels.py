import unicodedata


def to_key(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters
    ascii_only = "".join(ch for ch in normalized if ord(ch) < 128)

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for ch in lower:
        if ch not in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev_char is not None:
                result.append("_")
            prev_char = None
        else:
            result.append(ch)
            prev_char = ch
    return "".join(result)

