def digest_lines(lines):
    counts = {}
    for line in lines:
        parts = line.split()
        # Need at least 3 parts: timestamp, level, service: ...
        if len(parts) < 3:
            continue
        # The second part is the level; upper-case it
        level = parts[1].upper()
        # Count it
        counts[level] = counts.get(level, 0) + 1
    return counts
