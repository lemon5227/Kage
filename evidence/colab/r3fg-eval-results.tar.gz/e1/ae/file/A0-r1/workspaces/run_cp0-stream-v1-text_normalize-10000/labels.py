import unicodedata

def make_handle(text):
    """Turn a title into a handle according to specified rules."""
    # Raise TypeError for non-string input
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace any sequence of non-alphanumeric characters with a single hyphen
    result = []
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is None or prev_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                result.append('-')
                prev_char = '-'
            else:
                prev_char = char  # Keep the character, but it's not alphanumeric so we'll handle it
        else:
            result.append(char)
            prev_char = char
    
    # Actually, let me reconsider: we need to replace every run of non-alphanumeric chars with a single "-"
    # A simpler approach: split by non-alphanumeric and join with hyphen
    import re
    parts = re.split(r'[^a-z0-9]+', lowercased)
    # Filter out empty strings
    parts = [p for p in parts if p]
    # Join with single hyphen
    result = '-'.join(parts)
    
    # Strip leading and trailing "-"
    result = result.strip('-')
    
    # If the result is longer than 23 characters, cut to 23 and then strip a trailing "-"
    if len(result) > 23:
        result = result[:23]
        result = result.rstrip('-')
    
    return result
