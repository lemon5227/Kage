def aggregate_log(lines):
    """Aggregate log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    
    Returns {name: count} per service for levels ERROR, WARN only,
    treating level names case-insensitively (upper-case keys), dropping malformed input lines.
    """
    counts = {}
    
    for line in lines:
        # Strip whitespace from the line
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Split the line into parts
        parts = line.split()
        
        # Need at least 4 parts: timestamp, level, service, and message (at least)
        if len(parts) < 4:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Only process ERROR and WARN levels
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Increment count for this service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
