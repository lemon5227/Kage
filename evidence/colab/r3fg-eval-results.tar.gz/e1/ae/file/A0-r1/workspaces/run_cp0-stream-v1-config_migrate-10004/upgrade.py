def migrate(cfg):
    """Migrate a v1 config dict to v2 format."""
    # Check if version is 1, otherwise raise ValueError
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1")
    
    # Create a new dict for the migrated configuration
    migrated = {}
    migrated["version"] = 2
    
    # Process keys
    for key, value in cfg.items():
        # Drop keys with None values
        if value is None:
            continue
        
        # Handle specific key transformations
        if key == "pwd_file":
            migrated["password_file"] = value
        elif key == "user":
            migrated["username"] = value
        elif key == "cache_size":
            # Move into network sub-dict
            if "network" not in migrated:
                migrated["network"] = {}
            migrated["network"]["cache_size"] = value
        elif key == "workers":
            # Move into network sub-dict
            if "network" not in migrated:
                migrated["network"] = {}
            migrated["network"]["workers"] = value
        elif key == "timeout_ms":
            # Convert to timeout_s (float)
            migrated["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged
            migrated[key] = value
    
    return migrated
