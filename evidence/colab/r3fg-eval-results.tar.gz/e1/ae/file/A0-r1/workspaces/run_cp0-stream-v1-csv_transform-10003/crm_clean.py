import csv
import io


def tidy_csv(text):
    """Clean an exported CSV table with columns: name, city, score, team."""
    
    # Handle empty string input
    if not text or not text.strip():
        return ''
    
    # Split into lines and handle line endings
    lines = text.split('\n')
    
    # Check if it's header-only
    if len(lines) == 1:
        return lines[0]
    
    # Parse the CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # The first row is the header
    header = rows[0]
    
    # Validate header columns
    expected_columns = ['name', 'city', 'score', 'team']
    if len(header) != len(expected_columns):
        return ''
    
    # Process data rows (skip header)
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        new_row = [cell.strip() for cell in row]
        cleaned_rows.append(new_row)
    
    # Step 2: Drop rows whose "name" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if not row[0]:  # name is at index 0
            continue
        filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "name", keeping the first occurrence
    seen_names = set()
    unique_rows = []
    for row in filtered_rows:
        name = row[0]
        if name not in seen_names:
            seen_names.add(name)
            unique_rows.append(row)
    
    # Step 4: Sort rows by "city" ascending as strings (stable)
    # Use a stable sort - Python's sorted is stable
    sorted_rows = sorted(unique_rows, key=lambda row: row[1])
    
    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in sorted_rows:
        writer.writerow(row)
    
    return output.getvalue()
