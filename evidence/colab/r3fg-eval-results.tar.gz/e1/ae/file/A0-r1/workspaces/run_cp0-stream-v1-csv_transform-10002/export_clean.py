import csv
import io


def normalize_table(text):
    """Clean an exported CSV table.
    
    Input: CSV text with header row (columns: name, team, city, id, score)
    Returns: Cleaned CSV text with the same header.
    """
    # Handle empty input
    if not text.strip():
        return ''
    
    # Parse the CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    # Check if it's header-only input
    if len(rows) == 1:
        return rows[0][0] + ',' + ','.join(rows[0][1:])
    
    # Extract header
    header = rows[0]
    
    # Process data rows
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)
    
    # Step 2: Drop rows whose "name" cell is empty
    filtered_rows = []
    for row in cleaned_rows:
        if not row[0]:  # name column (index 0)
            continue
        filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in filtered_rows:
        score = row[4]  # score column (index 4)
        if score not in seen_scores:
            seen_scores.add(score)
            deduped_rows.append(row)
    
    # Step 4: Sort rows by "id" ascending as strings (stable)
    # We need to sort by id (column index 3) as strings, maintaining stability
    # Python's sort is stable, so we can just sort by id
    deduped_rows.sort(key=lambda row: row[3])
    
    # Build output CSV text with '\n' line endings
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in deduped_rows:
        writer.writerow(row)
    
    return output.getvalue()
