import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with header row (columns: id, email, city, name)
    Output: Cleaned CSV text with the same header
    
    Processing steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "id" cell is empty
    3. Lower-case the "email" column
    4. Remove duplicate rows by "email", keeping the first occurrence
    5. Sort rows by "email" ascending as strings (stable)
    
    Returns:
        Empty string returns ''
        Header-only input returns just the header line
    """
    # Parse the CSV text
    lines = text.strip().split('\n')
    
    if not lines:
        return ''
    
    # Check if it's header-only
    if len(lines) == 1:
        return lines[0]
    
    # Parse header
    header = lines[0].split(',')
    if 'id' not in header or 'email' not in header:
        return ''
    
    # Find column indices
    id_idx = header.index('id')
    email_idx = header.index('email')
    
    # Parse rows
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        cells = line.split(',')
        if len(cells) < max(id_idx + 1, email_idx + 1):
            continue
        
        # Strip whitespace from every cell
        cells = [cell.strip() for cell in cells]
        
        # Get id and email
        row_id = cells[id_idx]
        email = cells[email_idx].lower() if cells[email_idx] else ''
        
        # Drop rows whose "id" cell is empty
        if not row_id:
            continue
        
        # Store row with original index for stable sort later
        row_data = {
            'id': row_id,
            'email': email,
            'original_index': len(rows),
            'cells': cells
        }
        rows.append(row_data)
    
    # Remove duplicate rows by "email", keeping the first occurrence
    seen_emails = set()
    unique_rows = []
    for row in rows:
        if row['email'] not in seen_emails:
            seen_emails.add(row['email'])
            unique_rows.append(row)
    
    # Sort rows by "email" ascending as strings (stable)
    # Use original_index as tiebreaker for stability
    unique_rows.sort(key=lambda r: (r['email'], r['original_index']))
    
    # Build output CSV
    output_lines = [','.join(header)]
    for row in unique_rows:
        output_lines.append(','.join(row['cells']))
    
    return '\n'.join(output_lines)
