def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity.  Ties on total value are broken by choosing the
    lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_value, chosen_ids) for capacity c.
    # We track the chosen ids so we can reconstruct the optimal set.
    prev = [None] * (capacity + 1)
    for c in range(capacity + 1):
        prev[c] = (0, [])

    for item_id, weight, value in entries:
        # Iterate capacities downward so each item is used at most once.
        for c in range(weight, capacity + 1):
            prev_value, chosen_ids = prev[c - weight]
            candidate_value = prev_value + value
            candidate_ids = chosen_ids + [item_id]
            if candidate_value > prev[c][0]:
                prev[c] = (candidate_value, candidate_ids)
            elif candidate_value == prev[c][0]:
                # Tie on value: prefer lexicographically smallest sorted id list.
                if sorted(candidate_ids) < sorted(prev[c][1]):
                    prev[c] = (candidate_value, candidate_ids)

    # The optimal value is at capacity = capacity.
    # Choose the lexicographically smallest sorted id list among all
    # capacities that achieve the same maximum value.
    max_value = prev[capacity][0]
    best_ids = prev[capacity][1]

    for c in range(capacity):
        value, ids = prev[c]
        if value > max_value:
            max_value = value
            best_ids = ids
        elif value == max_value:
            if sorted(ids) < sorted(best_ids):
                best_ids = ids

    return sorted(best_ids)
