import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name") if "name" in header else 0
    cleaned = [row for row in cleaned if len(row) > name_idx and row[name_idx] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    score_idx = header.index("score") if "score" in header else 0
    seen = set()
    deduped = []
    for row in cleaned:
        key = row[score_idx] if score_idx < len(row) else ""
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    # sort rows by "id" ascending as strings (stable)
    id_idx = header.index("id") if "id" in header else 0
    deduped.sort(key=lambda row: row[id_idx] if id_idx < len(row) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in deduped:
        writer.writerow(row)

    return out.getvalue()
