import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)
    data = cleaned

    # drop rows whose "name" cell is empty
    name_idx = header.index("name") if "name" in header else -1
    if name_idx >= 0:
        data = [row for row in data if name_idx < len(row) and row[name_idx] != ""]

    # lower-case the "email" column
    email_idx = header.index("email") if "email" in header else -1
    if email_idx >= 0:
        for row in data:
            if email_idx < len(row):
                row[email_idx] = row[email_idx].lower()

    # remove duplicate rows by "name", keeping the first occurrence
    seen = set()
    deduped = []
    for row in data:
        key = row[name_idx] if name_idx >= 0 and name_idx < len(row) else ""
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    data = deduped

    # sort rows by "email" ascending as strings (stable)
    if email_idx >= 0:
        data.sort(key=lambda row: row[email_idx] if email_idx < len(row) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for row in data:
        writer.writerow(row)
    return out.getvalue()
