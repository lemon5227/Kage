def migrate(cfg):
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1")
    
    # Create a new dict without modifying input
    result = {}
    result["version"] = 2
    
    # Process keys
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]
    if "user" in cfg:
        result["username"] = cfg["user"]
    
    # Move cache_size and workers into network sub-dict
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    result["network"] = network
    
    # Handle timeout_ms
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Keep other keys unchanged (but drop keys with value None)
    for key, value in cfg.items():
        if key in ["pwd_file", "user", "cache_size", "workers", "timeout_ms"]:
            continue  # already handled
        if value is None:
            continue  # drop keys with None value
        result[key] = value
    
    return result
