import unicodedata

def slugify(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lowercase
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace sequences of non-alphanumeric characters with a single hyphen
    slug = []
    previous_char_was_alnum = False
    for char in lower_text:
        if char.isalnum():  # alphanumeric (a-z, 0-9)
            slug.append(char)
            previous_char_was_alnum = True
        else:
            if previous_char_was_alnum:
                slug.append('-')
                previous_char_was_alnum = False
            # else: skip non-alnum characters at the start
    
    result = ''.join(slug)
    
    # Strip leading and trailing "-"
    return result.strip('-')
