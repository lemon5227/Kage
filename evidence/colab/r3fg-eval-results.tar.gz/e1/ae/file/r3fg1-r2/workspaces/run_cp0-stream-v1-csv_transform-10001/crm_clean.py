import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    # strip leading/trailing whitespace from every cell
    cleaned = []
    for row in data:
        cells = [cell.strip() for cell in row]
        cleaned.append(cells)

    # drop rows whose "score" cell is empty
    score_idx = header.index("score") if "score" in header else -1
    filtered = []
    for cells in cleaned:
        if score_idx >= 0 and len(cells) > score_idx:
            if cells[score_idx] == "":
                continue
        filtered.append(cells)

    # remove duplicate rows by "score", keeping the first occurrence
    seen = set()
    deduped = []
    for cells in filtered:
        key = cells[score_idx] if score_idx >= 0 and len(cells) > score_idx else None
        if key in seen:
            continue
        seen.add(key)
        deduped.append(cells)

    # sort rows by "name" ascending as strings (stable)
    name_idx = header.index("name") if "name" in header else -1
    def row_key(row):
        return row[name_idx] if name_idx >= 0 and len(row) > name_idx else ""

    deduped.sort(key=row_key, stable=True)

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    for cells in deduped:
        writer.writerow(cells)

    return out.getvalue()
