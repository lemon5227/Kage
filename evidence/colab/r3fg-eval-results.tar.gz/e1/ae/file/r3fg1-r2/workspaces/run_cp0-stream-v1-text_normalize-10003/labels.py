import unicodedata


def make_handle(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to find sequences of non-alphanumeric characters and replace them with "-"
    result = []
    prev_char = None
    for char in lower:
        if char.isalnum():  # alphanumeric means a-z0-9 (since we're only dealing with ASCII)
            result.append(char)
            prev_char = char
        else:
            # Non-alphanumeric character - check if we need to add a separator
            if prev_char is not None and prev_char != "-":
                result.append("-")
                prev_char = "-"
            # else: already have a "-" or start of string, skip

    # Strip leading and trailing "-"
    handle = "".join(result).strip("-")

    return handle
