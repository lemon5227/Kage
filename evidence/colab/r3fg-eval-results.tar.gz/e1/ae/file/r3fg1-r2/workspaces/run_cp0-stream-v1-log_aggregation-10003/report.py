def aggregate_log(lines):
    """Aggregate log lines into {service: count} for ERROR and WARN levels.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Level names are matched case-insensitively and only ERROR/WARN are counted.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # split into at most 4 parts
        if len(parts) < 4:
            continue
        _timestamp, level, service, message = parts
        if not service.endswith(':'):
            continue
        service = service[:-1]
        if not service:
            continue
        if level.upper() not in ("ERROR", "WARN"):
            continue
        counts[service.upper()] = counts.get(service.upper(), 0) + 1
    return counts
