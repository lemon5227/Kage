import unicodedata


def slugify(text):
    """Turn a title into a handle."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for char in lower_text:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is not None:
                result.append('_')
            prev_char = None
        else:
            result.append(char)
            prev_char = char
    
    slug = ''.join(result)
    
    # Strip leading and trailing "_"
    slug = slug.strip('_')
    
    return slug
