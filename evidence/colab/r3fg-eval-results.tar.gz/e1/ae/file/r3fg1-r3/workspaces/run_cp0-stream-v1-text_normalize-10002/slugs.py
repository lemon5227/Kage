import unicodedata

def slugify(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization to separate accents and symbols
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_text = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Lower-case
    lower_text = ascii_text.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to split on non-alphanumeric characters and join with "-"
    parts = [part for part in lower_text.split() if part.isalnum()]
    slug = "-".join(parts)
    
    # Strip leading and trailing "-"
    slug = slug.strip("-")
    
    return slug
