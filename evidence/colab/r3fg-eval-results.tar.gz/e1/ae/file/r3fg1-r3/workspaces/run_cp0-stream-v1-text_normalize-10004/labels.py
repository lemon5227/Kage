import unicodedata

def label_id(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to replace sequences of non-alphanumeric characters with a single hyphen
    slug = []
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is not None:
                # Start a new run of non-alphanumerics, add hyphen
                slug.append('-')
        else:
            # Alphanumeric character, reset the run
            slug.append(char)
        prev_char = char
    
    # Join and strip leading/trailing hyphens
    result = ''.join(slug).strip('-')
    
    return result
