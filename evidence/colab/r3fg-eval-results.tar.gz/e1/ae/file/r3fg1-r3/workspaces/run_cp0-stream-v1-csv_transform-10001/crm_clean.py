import csv
import io


def clean_rows(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "score" cell is empty
    score_idx = header.index("score") if "score" in header else -1
    if score_idx >= 0:
        cleaned = [r for r in cleaned if score_idx < len(r) and r[score_idx] != ""]

    # remove duplicate rows by "score", keeping the first occurrence
    if score_idx >= 0:
        seen = set()
        deduped = []
        for r in cleaned:
            key = r[score_idx] if score_idx < len(r) else ""
            if key in seen:
                continue
            seen.add(key)
            deduped.append(r)
        cleaned = deduped

    # sort rows by "name" ascending as strings (stable)
    name_idx = header.index("name") if "name" in header else -1
    if name_idx >= 0:
        cleaned.sort(key=lambda r: r[name_idx] if name_idx < len(r) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
