def choose(items, capacity):
    """Select jobs under a capacity limit.

    Each item is a dict with a unique string "id", a positive integer
    "weight" and a non-negative integer "value".  Returns the sorted list
    of ids whose total value is as large as possible while total weight
    stays <= capacity.  Ties on total value are broken by choosing the
    lexicographically smallest sorted id list.  An empty selection is
    allowed.

    Raises ValueError if capacity is negative or any weight is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        weight = item["weight"]
        value = item["value"]
        if weight <= 0:
            raise ValueError("weight must be positive")
        entries.append((item["id"], weight, value))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_value, chosen_ids) for capacity c.
    # We track the chosen ids so we can reconstruct the optimal set.
    prev = [None] * (capacity + 1)
    prev[0] = (0, [])

    for item_id, weight, value in entries:
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, weight - 1, -1):
            prev_value, chosen = prev[c - weight]
            candidate = (value + prev_value, [item_id] + chosen)
            if c in prev:
                cur_value, cur_chosen = prev[c]
                if candidate[0] > cur_value or \
                        (candidate[0] == cur_value and candidate[1] < cur_chosen):
                    prev[c] = candidate
    best_value, best_ids = prev[capacity]
    return sorted(best_ids)
