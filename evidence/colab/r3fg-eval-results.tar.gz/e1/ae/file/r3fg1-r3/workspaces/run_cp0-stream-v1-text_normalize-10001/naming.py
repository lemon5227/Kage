import unicodedata


def slugify(text):
    """Turn a title into a handle."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode('ascii', 'ignore').decode('ascii')

    # Lower-case
    lowercased = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is not None:
                # Skip consecutive non-alphanumeric characters
                continue
            else:
                result.append('_')
                prev_char = char
        else:
            result.append(char)
            prev_char = char

    slug = ''.join(result)

    # Strip leading and trailing "_"
    return slug.strip('_')
