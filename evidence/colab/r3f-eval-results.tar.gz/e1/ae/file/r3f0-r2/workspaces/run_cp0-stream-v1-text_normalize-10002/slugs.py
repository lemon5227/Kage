import unicodedata


def slugify(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # lower-case
    ascii_only = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "-"
    runs = []
    prev_char = None
    for char in ascii_only:
        if char.isdigit() or char.isalpha():
            if prev_char is not None and (char != prev_char):
                runs.append("-")
            runs.append(char)
        else:
            if prev_char is not None and (char != prev_char):
                runs.append("-")
            prev_char = char
    result = "".join(runs)

    # strip leading and trailing "-"
    return result.strip("-")
