def allocate(items, capacity):
    """Select a subset of items maximizing total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by choosing the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_gain, sorted_id_list) achievable with total cost exactly c.
    # We also track the predecessor cost to reconstruct the chosen items.
    prev = [(None, []) for _ in range(capacity + 1)]
    for idx in range(len(entries)):
        item_id, cost, gain = entries[idx]
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev_c = c - cost
            cand_gain = prev[prev_c][0] + gain
            cand_ids = prev[prev_c][1] + [item_id]
            cur_gain, cur_ids = prev[c][0], prev[c][1]
            if cand_gain > cur_gain or (cand_gain == cur_gain and sorted(cand_ids) < sorted(cur_ids)):
                prev[c] = (cand_gain, sorted(cand_ids))

    # The best achievable gain is the maximum over all capacities.
    max_gain = None
    best_ids = None
    for c in range(capacity + 1):
        gain, ids = prev[c]
        if max_gain is None or gain > max_gain or (gain == max_gain and (best_ids is None or sorted(ids) < sorted(best_ids))):
            max_gain = gain
            best_ids = sorted(ids)

    return best_ids
