def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Top-level keys:
      - "user" -> "username"
      - "dir" -> "directory"
      - "cache_size" and "retries" are moved into a sub-dict "limits" (always present, possibly empty).
      - If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Other keys are kept unchanged. Keys whose value is None are dropped.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError("Expected configuration version 1, got %r" % version)

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process known old keys
    username = cfg.get("user")
    if username is not None:
        result["username"] = username

    directory = cfg.get("dir")
    if directory is not None:
        result["directory"] = directory

    # Move cache_size and retries into limits
    limits = {}
    cache_size = cfg.get("cache_size")
    if cache_size is not None:
        limits["cache_size"] = cache_size
    retries = cfg.get("retries")
    if retries is not None:
        limits["retries"] = retries
    result["limits"] = limits

    # Handle timeout_ms -> timeout_s
    timeout_ms = cfg.get("timeout_ms")
    if timeout_ms is not None:
        result["timeout_s"] = timeout_ms / 1000.0

    # Copy other keys that are present and not None
    for key, value in cfg.items():
        if key in ("user", "dir", "cache_size", "retries", "timeout_ms"):
            continue
        if value is None:
            continue
        result[key] = value

    return result
