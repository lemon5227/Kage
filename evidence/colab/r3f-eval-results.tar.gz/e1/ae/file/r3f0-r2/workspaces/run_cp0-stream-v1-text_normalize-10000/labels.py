import unicodedata


def make_handle(text):
    """Turn a title into a handle."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # Apply NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize('NFKD', text)
    ascii_only = ''.join(c for c in normalized if ord(c) < 128)

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_is_sep = False
    for c in lower:
        if c.isalnum():
            result.append(c)
            prev_is_sep = False
        else:
            if not prev_is_sep:
                result.append('-')
                prev_is_sep = True
    handle = ''.join(result)

    # Strip leading and trailing "-"
    handle = handle.strip('-')

    # If longer than 23 characters, cut to 23 and then strip trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.rstrip('-')

    return handle
