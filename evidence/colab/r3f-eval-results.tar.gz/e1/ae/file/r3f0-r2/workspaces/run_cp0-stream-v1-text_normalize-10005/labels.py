import unicodedata


def to_key(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters
    ascii_only = ""
    for ch in normalized:
        if ord(ch) < 128:
            ascii_only += ch
    normalized = ascii_only

    # Lower-case
    normalized = normalized.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = ""
    prev_is_sep = False
    for ch in normalized:
        if ch.isalnum():
            result += ch
            prev_is_sep = False
        else:
            if not prev_is_sep:
                result += "_"
                prev_is_sep = True
    # Strip leading and trailing "_"
    return result.strip("_")
