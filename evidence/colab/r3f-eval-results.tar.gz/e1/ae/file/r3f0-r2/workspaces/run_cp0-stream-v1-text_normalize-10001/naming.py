import unicodedata


def slugify(text):
    """Turn a title into a handle."""
    if not isinstance(text, str):
        raise TypeError("Expected string, got %s" % type(text).__name__)

    # NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = "".join(c for c in normalized if ord(c) < 128)

    # lower-case
    lower = ascii_only.lower()

    # replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_is_sep = False
    for c in lower:
        if c.isalnum():
            result.append(c)
            prev_is_sep = False
        else:
            if not prev_is_sep:
                result.append("_")
                prev_is_sep = True
    return "".join(result)
