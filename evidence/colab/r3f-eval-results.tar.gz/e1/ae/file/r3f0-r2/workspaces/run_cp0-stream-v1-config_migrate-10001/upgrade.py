def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            f"Expected version 1, got {version!r}. "
            "Only version 1 configurations are supported for upgrade."
        )

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Rename top-level keys
    if "host" in cfg:
        result["hostname"] = cfg["host"]
    if "max_conn" in cfg:
        result["max_connections"] = cfg["max_conn"]
    if "pwd_file" in cfg:
        result["password_file"] = cfg["pwd_file"]

    # Build the storage sub-dict
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "retries" in cfg:
        storage["retries"] = cfg["retries"]
    result["storage"] = storage

    # Handle timeout_ms -> timeout_s conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key in ("host", "max_conn", "pwd_file", "port", "retries", "timeout_ms"):
            continue  # already handled above
        if value is None:
            continue  # drop None values
        if key not in result:
            result[key] = value

    return result
