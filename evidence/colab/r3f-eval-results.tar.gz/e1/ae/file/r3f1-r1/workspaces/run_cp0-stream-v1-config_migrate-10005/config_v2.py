def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Raise ValueError unless version is 1
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")
    
    # Create a new dict without modifying input
    result = {"version": 2}
    
    # Rename top-level keys
    if "user" in cfg:
        result["username"] = cfg["user"]
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    
    # Move cache_size and retries into limits sub-dict
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "retries" in cfg:
        limits["retries"] = cfg["retries"]
    result["limits"] = limits
    
    # Handle timeout_ms conversion
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0
    
    # Keep other keys unchanged and drop keys whose value is None
    for key, value in cfg.items():
        if key not in ["user", "dir", "cache_size", "retries", "timeout_ms"]:
            if value is not None:
                result[key] = value
    
    return result
