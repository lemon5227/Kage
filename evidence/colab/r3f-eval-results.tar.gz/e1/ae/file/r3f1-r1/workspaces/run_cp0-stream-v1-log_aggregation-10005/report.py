def summarize(lines):
    """Count WARN lines per service.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each service to the number of WARN lines it has.
    Levels are case-insensitive. Malformed lines are skipped.
    Services with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # split on whitespace, max 3 splits
        if len(parts) < 3:
            continue
        _timestamp, level, service_part = parts[0], parts[1], parts[2]
        if not service_part.endswith(':'):
            continue
        service = service_part[:-1]
        if not service.isalnum():
            continue
        if level.upper() != "WARN":
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
