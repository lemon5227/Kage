import unicodedata


def slugify(text):
    """Build a URL slug from text.

    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces every run of characters outside [a-z0-9] with a single "-",
    and strips leading and trailing "-". Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters into base + combining marks
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    prev_char_is_alnum = False
    for char in lower:
        if char.isalnum():  # a-z and 0-9
            if not prev_char_is_alnum:
                slug.append("-")
            slug.append(char)
            prev_char_is_alnum = True
        else:
            if prev_char_is_alnum:
                slug.append("-")
            prev_char_is_alnum = False

    result = "".join(slug)

    # Strip leading and trailing "-"
    return result.strip("-")
