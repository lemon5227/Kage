import unicodedata


def to_key(text):
    """Normalize labels into identifiers."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # Apply NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize('NFKD', text)
    # Keep only ASCII characters (0-127)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)

    # Lower-case
    lowercased = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = []
    prev_char = None
    for char in lowercased:
        if not char.isalnum():
            if prev_char is not None:
                result.append('_')
        else:
            result.append(char)
        prev_char = char

    # Strip leading and trailing "_"
    return ''.join(result).strip('_')
