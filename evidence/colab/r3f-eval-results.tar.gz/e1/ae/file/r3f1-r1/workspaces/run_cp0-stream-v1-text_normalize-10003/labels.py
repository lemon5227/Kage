import unicodedata

def make_handle(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we need to split on non-alphanumeric characters and join with single hyphens
    parts = []
    current = ""
    for char in lowercased:
        if char.isalnum():  # a-z and 0-9
            current += char
        else:
            if current:
                parts.append(current)
                current = ""
            # Non-alphanumeric characters are separators
    
    if current:
        parts.append(current)
    
    # Join with single hyphens
    result = "-".join(parts)
    
    # Strip leading and trailing "-"
    result = result.strip("-")
    
    return result
