def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported for upgrade")

    # Create a new dict with version 2
    new_cfg = {"version": 2}

    # Handle top-level keys
    if "max_conn" in cfg:
        new_cfg["max_connections"] = cfg["max_conn"]
    if "dir" in cfg:
        new_cfg["directory"] = cfg["dir"]
    if "host" in cfg:
        new_cfg["hostname"] = cfg["host"]

    # Handle cache_size and region - move into limits sub-dict
    limits = {}
    if "cache_size" in cfg:
        limits["cache_size"] = cfg["cache_size"]
    if "region" in cfg:
        limits["region"] = cfg["region"]
    new_cfg["limits"] = limits

    # Handle timeout_ms - convert to timeout_s if present
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Drop keys whose value is None
    # (already handled by not copying them)

    return new_cfg
