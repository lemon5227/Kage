import unicodedata


def make_handle(text):
    """Turn a title into a handle."""
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Apply NFKD normalization and drop non-ASCII characters
    normalized = unicodedata.normalize('NFKD', text)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    result = []
    prev_char = None
    for char in lower:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            if prev_char is not None:
                result.append('-')
            prev_char = None
        else:
            result.append(char)
            prev_char = char
    handle = ''.join(result)
    
    # Strip leading and trailing "-"
    handle = handle.strip('-')
    
    # If longer than 23 characters, cut to 23 and then strip trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.strip('-')
    
    return handle
