def allocate(items, capacity):
    """Select a subset of items maximizing total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by choosing the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_gain, sorted_id_list) achievable with total cost exactly c.
    # We also track the predecessor cost to reconstruct the chosen items.
    prev = [(None, []) for _ in range(capacity + 1)]

    for item_id, cost, gain in entries:
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev_c = c - cost
            cand_gain = prev[prev_c][0] + gain
            cand_ids = prev[prev_c][1] + [item_id]
            if c in prev and (cand_gain > prev[c][0] or
                    (cand_gain == prev[c][0] and sorted(cand_ids) < sorted(prev[c][1]))):
                prev[c] = (cand_gain, sorted(cand_ids))

    # The best achievable gain is at capacity <= capacity.
    best_gain = None
    best_ids = None
    for c in range(capacity + 1):
        gain, ids = prev[c]
        if best_gain is None or gain > best_gain or \
           (gain == best_gain and (best_ids is None or sorted(ids) < sorted(best_ids))):
            best_gain = gain
            best_ids = sorted(ids)

    return best_ids
