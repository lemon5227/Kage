def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError("Expected configuration version 1, got {}".format(version))

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Rename top-level keys
    if "dir" in cfg:
        result["directory"] = cfg["dir"]
    if "host" in cfg:
        result["hostname"] = cfg["host"]

    # Move port and workers into a sub-dict "storage"
    storage = {}
    if "port" in cfg:
        storage["port"] = cfg["port"]
    if "workers" in cfg:
        storage["workers"] = cfg["workers"]
    result["storage"] = storage

    # Handle timeout_ms -> timeout_s
    if "timeout_ms" in cfg:
        result["timeout_s"] = cfg["timeout_ms"] / 1000.0

    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key in ("dir", "host", "port", "workers", "timeout_ms", "version"):
            continue
        if value is None:
            continue
        result[key] = value

    return result
