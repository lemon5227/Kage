def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError if cfg.get("version") != 1.
    The output has "version": 2.
    Rename top-level keys "user" -> "username", "dir" -> "directory".
    Move "cache_size" and "retries" into a sub-dict "limits" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keep other keys unchanged and drop keys whose value is None.
    """
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Expected configuration version 1")

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process top-level keys
    for key, value in cfg.items():
        if key == "user":
            result["username"] = value
        elif key == "dir":
            result["directory"] = value
        elif key == "cache_size":
            # Move into limits sub-dict
            if "limits" not in result:
                result["limits"] = {}
            result["limits"]["cache_size"] = value
        elif key == "retries":
            # Move into limits sub-dict
            if "limits" not in result:
                result["limits"] = {}
            result["limits"]["retries"] = value
        elif key == "timeout_ms":
            # Convert to seconds (float)
            result["timeout_s"] = value / 1000.0
        else:
            # Keep other keys unchanged, but drop None values
            if value is not None:
                result[key] = value

    return result
