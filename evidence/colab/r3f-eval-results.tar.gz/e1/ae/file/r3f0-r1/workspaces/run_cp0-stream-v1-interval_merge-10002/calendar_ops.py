def coalesce(intervals):
    """Merge overlapping intervals.

    Each interval is a dict {"start": s, "end": e} with integer values.
    Returns a new list of dicts with the same "start"/"end" keys, sorted by start ascending.
    Touching intervals (e.g. [1, 3] and [3, 5]) are merged.
    Raises ValueError if any interval has start > end.
    The input is not modified.
    """
    normalized = []
    for interval in intervals:
        start = interval["start"]
        end = interval["end"]
        if start > end:
            raise ValueError(
                "invalid interval: start %r > end %r" % (start, end)
            )
        normalized.append({"start": start, "end": end})

    normalized.sort(key=lambda pair: (pair["start"], pair["end"]))

    merged = []
    for start, end in normalized:
        if merged and start <= merged[-1]["end"]:
            # Overlapping or touching intervals: extend the current interval if needed.
            if end > merged[-1]["end"]:
                merged[-1]["end"] = end
        else:
            merged.append({"start": start, "end": end})

    return merged
