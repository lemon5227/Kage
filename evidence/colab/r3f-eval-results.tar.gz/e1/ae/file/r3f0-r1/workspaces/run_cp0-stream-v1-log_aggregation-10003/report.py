def aggregate_log(lines):
    """Aggregate log lines into a dict of {service: count}.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Only counts entries with level ERROR or WARN (case-insensitive).
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        _timestamp, level, service, message = parts
        if service.startswith(':'):
            continue
        if level.upper() not in ("ERROR", "WARN"):
            continue
        key = service.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
