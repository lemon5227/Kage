import unicodedata


def slugify(text):
    """Build a URL slug from text.

    Applies NFKD normalization, drops non-ASCII characters, lower-cases,
    replaces runs of non-alphanumeric characters with a single "-", and
    strips leading/trailing "-". Raises TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization separates composed characters
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    slug = []
    prev_char = None
    for char in lower:
        if char.isalnum():  # a-z and 0-9
            slug.append(char)
        else:
            if prev_char is not None:
                # Same non-alphanumeric run - skip
                continue
            elif slug and slug[-1] != "-":
                # Start of a new non-alphanumeric run - add "-"
                slug.append("-")
            prev_char = char

    result = "".join(slug)

    # Strip leading and trailing "-"
    return result.strip("-")
