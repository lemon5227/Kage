def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported for upgrade")

    # Make a copy to avoid modifying the input
    result = dict(cfg)
    result["version"] = 2

    # Rename top-level keys
    if "dir" in result:
        result["directory"] = result.pop("dir")
    if "pwd_file" in result:
        result["password_file"] = result.pop("pwd_file")
    if "max_conn" in result:
        result["max_connections"] = result.pop("max_conn")

    # Move "region" and "retries" into a sub-dict "network"
    network = {}
    if "region" in result:
        network["region"] = result.pop("region")
    if "retries" in result:
        network["retries"] = result.pop("retries")
    result["network"] = network

    # Handle timeout_ms -> timeout_s conversion
    if "timeout_ms" in result:
        result["timeout_s"] = result["timeout_ms"] / 1000.0
        # Remove the original key
        del result["timeout_ms"]

    # Drop keys whose value is None
    result = {k: v for k, v in result.items() if v is not None}

    return result
