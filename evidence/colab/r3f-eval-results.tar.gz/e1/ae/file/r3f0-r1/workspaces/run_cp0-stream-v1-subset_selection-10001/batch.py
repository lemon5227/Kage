def allocate(items, capacity):
    """Select a subset of items maximizing total gain with total cost <= capacity.

    Each item is a dict with a unique string "id", a positive integer "cost"
    and a non-negative integer "gain". Returns the sorted list of ids whose
    total gain is as large as possible while total cost stays <= capacity.
    Ties on total gain are broken by choosing the lexicographically smallest
    sorted id list. An empty selection is allowed.

    Raises ValueError if capacity is negative or any cost is <= 0.
    The input is not modified.
    """
    if capacity < 0:
        raise ValueError("capacity must be non-negative")

    # Validate and copy the relevant data without mutating the input.
    entries = []
    for item in items:
        cost = item["cost"]
        gain = item["gain"]
        if cost <= 0:
            raise ValueError("cost must be positive")
        entries.append((item["id"], cost, gain))

    # 0/1 knapsack over capacities 0..capacity.
    # best[c] = (max_gain, sorted_id_list) achievable with total cost exactly c.
    # We also track the predecessor cost to reconstruct the chosen items.
    prev = [(None, []) for _ in range(capacity + 1)]

    for idx in range(len(entries)):
        item_id, cost, gain = entries[idx]
        # Iterate capacities downward so each item is used at most once.
        for c in range(capacity, cost - 1, -1):
            prev_gain, prev_ids = prev[c]
            if prev_gain is None:
                continue
            cand_gain = prev_gain + gain
            cand_ids = sorted(prev_ids + [item_id])
            if cand_gain > best[c][0]:
                best[c] = (cand_gain, cand_ids)
            elif cand_gain == best[c][0] and cand_ids < best[c][1]:
                best[c] = (cand_gain, cand_ids)

    # Find the best gain across all feasible total costs.
    best_gain = None
    best_ids = None
    for c in range(capacity + 1):
        gain, ids = best[c]
        if gain is None:
            continue
        if best_gain is None or gain > best_gain:
            best_gain = gain
            best_ids = ids
        elif gain == best_gain and (best_ids is None or ids < best_ids):
            best_ids = ids

    return best_ids if best_ids is not None else []
