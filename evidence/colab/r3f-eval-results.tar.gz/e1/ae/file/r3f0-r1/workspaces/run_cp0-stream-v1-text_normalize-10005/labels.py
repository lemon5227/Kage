import unicodedata


def to_key(text):
    if not isinstance(text, str):
        raise TypeError("Input must be a string")

    # NFKD normalization
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters
    ascii_only = ""
    for ch in normalized:
        if ord(ch) < 128:
            ascii_only += ch
    normalized = ascii_only

    # Lower-case
    normalized = normalized.lower()

    # Replace every run of characters outside [a-z0-9] with a single "_"
    result = ""
    prev_char = None
    for ch in normalized:
        if ch not in "abcdefghijklmnopqrstuvwxyz0123456789":
            if prev_char is not None:
                result += "_"
            prev_char = None
        else:
            result += ch
            prev_char = ch
    # Strip leading and trailing "_"
    return result.strip("_")
