def convert_settings(cfg):
    """Convert old configuration dicts to the v2 layout.

    Returns a new dict without modifying the input.
    Raises ValueError unless cfg.get("version") == 1.
    The output has "version": 2.
    Rename top-level keys:
      - "host" -> "hostname"
      - "max_conn" -> "max_connections"
      - "pwd_file" -> "password_file"
    Move "port" and "retries" into a sub-dict "storage" (always present, possibly empty).
    If "timeout_ms" exists, output "timeout_s" = timeout_ms / 1000 (a float) instead.
    Keep other keys unchanged and drop keys whose value is None.
    """
    # Validate version
    version = cfg.get("version")
    if version != 1:
        raise ValueError(
            "Only version 1 configurations are supported for upgrade. "
            f"Got version: {version}"
        )

    # Work on a copy so the input is never modified
    result = {}
    result["version"] = 2

    # Process top-level keys
    host = cfg.get("host")
    if host is not None:
        result["hostname"] = host

    max_conn = cfg.get("max_conn")
    if max_conn is not None:
        result["max_connections"] = max_conn

    pwd_file = cfg.get("pwd_file")
    if pwd_file is not None:
        result["password_file"] = pwd_file

    # Move port and retries into storage sub-dict
    storage = {}
    port = cfg.get("port")
    if port is not None:
        storage["port"] = port
    retries = cfg.get("retries")
    if retries is not None:
        storage["retries"] = retries
    result["storage"] = storage

    # Handle timeout_ms -> timeout_s conversion
    timeout_ms = cfg.get("timeout_ms")
    if timeout_ms is not None:
        result["timeout_s"] = float(timeout_ms) / 1000.0

    # Copy other keys unchanged (excluding those already handled)
    for key in cfg:
        if key not in (
            "host",
            "max_conn",
            "pwd_file",
            "port",
            "retries",
            "timeout_ms",
            "version",
        ):
            value = cfg[key]
            if value is not None:
                result[key] = value

    return result
