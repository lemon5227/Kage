def upgrade_config(cfg):
    """Convert old configuration dicts to the v2 layout."""
    # Validate version
    if cfg.get("version") != 1:
        raise ValueError("Only version 1 configurations are supported")

    # Make a copy to avoid modifying the input
    result = dict(cfg)
    result["version"] = 2

    # Rename top-level keys
    if "max_conn" in result:
        result["max_connections"] = result.pop("max_conn")
    if "dir" in result:
        result["directory"] = result.pop("dir")
    if "host" in result:
        result["hostname"] = result.pop("host")

    # Move cache_size and region into a sub-dict "limits"
    limits = {}
    if "cache_size" in result:
        limits["cache_size"] = result.pop("cache_size")
    if "region" in result:
        limits["region"] = result.pop("region")
    result["limits"] = limits

    # Handle timeout_ms -> timeout_s conversion
    if "timeout_ms" in result:
        result["timeout_s"] = result["timeout_ms"] / 1000.0
        result.pop("timeout_ms", None)

    # Drop keys whose value is None
    result = {k: v for k, v in result.items() if v is not None}

    return result
