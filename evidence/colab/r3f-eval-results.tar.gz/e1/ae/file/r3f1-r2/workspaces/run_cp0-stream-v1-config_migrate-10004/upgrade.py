def migrate(cfg):
    """Migrate a v1 config dict to v2."""
    # Check if version is 1, otherwise raise ValueError
    if cfg.get("version") != 1:
        raise ValueError("Expected config version 1")
    
    # Create a new dict for the migrated config
    new_cfg = {"version": 2}
    
    # Rename top-level keys
    if "pwd_file" in cfg:
        new_cfg["password_file"] = cfg["pwd_file"]
    if "user" in cfg:
        new_cfg["username"] = cfg["user"]
    
    # Handle timeout_ms if exists
    if "timeout_ms" in cfg:
        new_cfg["timeout_s"] = cfg["timeout_ms"] / 1000
    
    # Move cache_size and workers into a sub-dict "network"
    network = {}
    if "cache_size" in cfg:
        network["cache_size"] = cfg["cache_size"]
    if "workers" in cfg:
        network["workers"] = cfg["workers"]
    new_cfg["network"] = network
    
    # Keep other keys unchanged (but drop keys whose value is None)
    for key, value in cfg.items():
        if key in ("pwd_file", "user", "cache_size", "workers", "timeout_ms"):
            continue  # Already handled above
        if value is None:
            continue  # Drop keys with None value
        if key not in new_cfg:
            new_cfg[key] = value
    
    return new_cfg
