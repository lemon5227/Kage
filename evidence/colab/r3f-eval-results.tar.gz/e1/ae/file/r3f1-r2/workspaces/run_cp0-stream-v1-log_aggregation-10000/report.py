def count_entries(lines):
    """Count lines by log level.

    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level to how many lines it has.
    Levels are case-insensitive (reported upper-case). Malformed lines are skipped.
    Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)
        if len(parts) < 3:
            continue
        _timestamp, level, rest = parts[0], parts[1], parts[2]
        if not rest.startswith(":"):
            continue
        service, message = rest[1:].split(None, 1)
        if not service or not message:
            continue
        # Level is the second token; it must be a non-empty string.
        if not level:
            continue
        level_upper = level.upper()
        counts[level_upper] = counts.get(level_upper, 0) + 1
    return counts
