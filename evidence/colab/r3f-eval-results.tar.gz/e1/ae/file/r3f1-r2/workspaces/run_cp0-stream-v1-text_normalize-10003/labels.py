import unicodedata


def make_handle(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization decomposes characters, then filter to ASCII only
    normalized = unicodedata.normalize("NFKD", text)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace runs of non-alphanumeric characters with a single "-"
    segments = []
    current = ""
    for char in lower:
        if char.isalnum():
            current += char
        else:
            if current:
                segments.append(current)
                current = ""
            # Non-alphanumeric runs are replaced by "-" but we'll handle them below

    if current:
        segments.append(current)

    # Join with "-", then strip leading/trailing "-"
    result = "-".join(segments)
    return result.lstrip("-").rstrip("-")
