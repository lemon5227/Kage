import unicodedata
import re


def label_id(text):
    """Build a URL slug from text."""
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lower = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single '-'
    slug = re.sub(r'[^a-z0-9]+', '-', lower)
    
    # Strip leading and trailing '-'
    slug = slug.strip('-')
    
    return slug
