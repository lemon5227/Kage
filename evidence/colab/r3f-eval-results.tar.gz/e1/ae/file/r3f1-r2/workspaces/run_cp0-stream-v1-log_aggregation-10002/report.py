def digest_lines(lines):
    """Count log lines per level.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    Level names are matched case-insensitively and stored with uppercase keys.
    Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split()
        # Need at least: timestamp, level, service: (with message optional)
        if len(parts) < 3:
            continue
        level = parts[1]
        service = parts[2]
        # The service token must end with a colon (e.g. "auth:")
        if not service.endswith(":"):
            continue
        # Extract the service name without the colon
        service_name = service[:-1] if len(service) > 0 else ""
        if not service_name:
            continue
        # Level must be non-empty
        if not level:
            continue
        key = level.upper()
        counts[key] = counts.get(key, 0) + 1
    return counts
