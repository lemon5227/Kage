import csv
import io


def normalize_table(text):
    """Clean an exported table from CSV text.
    
    Input: CSV text with a header row (columns: name, team, city, id, score)
    Output: Cleaned CSV text with the same header
    
    Cleaning steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "name" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "id" ascending as strings (stable)
    
    Returns: '' for empty input, header-only input returns just the header line
    """
    # Parse CSV text
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Check if header-only input
    if len(rows) == 1:
        return '\n'.join(header)
    
    # Process data rows
    data_rows = []
    for row in rows[1:]:
        # Strip whitespace from every cell
        cleaned_row = [cell.strip() for cell in row]
        
        # Skip rows where name is empty
        if not cleaned_row[0]:
            continue
        
        data_rows.append(cleaned_row)
    
    # Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    unique_rows = []
    for row in data_rows:
        score = row[-1]  # score is the last column
        if score not in seen_scores:
            seen_scores.add(score)
            unique_rows.append(row)
    
    # Sort rows by "id" ascending as strings (stable)
    # id is at index 3
    unique_rows.sort(key=lambda row: row[3])
    
    # Build output CSV text
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(header)
    for row in unique_rows:
        writer.writerow(row)
    
    return output.getvalue()
