import unicodedata


def make_handle(text):
    """Turn a title into a handle.
    
    Applies NFKD normalization, drops non-ASCII characters, lowercases,
    replaces runs of non-alphanumeric characters with a single "-",
    strips leading/trailing "-", and truncates to 23 characters if needed.
    
    Args:
        text: A string title
        
    Returns:
        A handle string
        
    Raises:
        TypeError: If input is not a string
    """
    # Check if input is a string
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Convert to lowercase
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "-"
    # This means we replace any sequence of non-alphanumeric characters with a single hyphen
    result = []
    prev_char = None
    for char in lowercased:
        if char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
            # If previous char was also non-alphanumeric, skip it (already replaced)
            if prev_char is not None and prev_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                continue
            # Add a single hyphen
            result.append('-')
        else:
            result.append(char)
        prev_char = char
    
    # Join the result
    handle = ''.join(result)
    
    # Strip leading and trailing "-"
    handle = handle.strip('-')
    
    # If result is longer than 23 characters, cut to 23 and then strip a trailing "-"
    if len(handle) > 23:
        handle = handle[:23]
        handle = handle.rstrip('-')
    
    return handle
