def summarize(lines):
    """
    Summarize log lines in format: <timestamp> <LEVEL> <service>: <message>
    Returns a dict mapping each service (for WARN level only) to count.
    Levels are case-insensitive (reported upper-case).
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        
        # Need at least 3 parts: timestamp, level, service
        if len(parts) < 3:
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Only process WARN level
        if level != 'WARN':
            continue
        
        # Count the service
        counts[service] = counts.get(service, 0) + 1
    
    return counts
