import unicodedata


def slugify(text):
    """Convert a title into a handle (slug).
    
    Args:
        text: A string to convert
        
    Returns:
        A slugified string
        
    Raises:
        TypeError: If input is not a string
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")
    
    # Apply NFKD normalization
    normalized = unicodedata.normalize('NFKD', text)
    
    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = ''.join(char for char in normalized if ord(char) < 128)
    
    # Lower-case
    lowercased = ascii_only.lower()
    
    # Replace every run of characters outside [a-z0-9] with a single "_"
    slug = []
    previous_char_is_alnum = False
    for char in lowercased:
        if char.isalnum():  # a-z and 0-9
            slug.append(char)
            previous_char_is_alnum = True
        else:
            if not previous_char_is_alnum:
                slug.append('_')
                previous_char_is_alnum = False
    
    result = ''.join(slug)
    
    # Strip leading and trailing "_"
    return result.strip('_')
