def aggregate_log(lines):
    """Aggregate log strings formatted as '<timestamp> <LEVEL> <service>: <message>'.
    Returns {name: count} per service for levels ERROR, WARN only, case-insensitive.
    Drops malformed input lines."""
    result = {}
    for line in lines:
        # Skip empty lines
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) < 3:
            # Malformed: need at least timestamp, level, service
            continue
        
        timestamp = parts[0]
        level = parts[1].upper()
        service = parts[2]
        
        # Check if level is ERROR or WARN (case-insensitive)
        if level not in ('ERROR', 'WARN'):
            continue
        
        # Count by service
        result[service] = result.get(service, 0) + 1
    
    return result
