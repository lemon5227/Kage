def coalesce(intervals):
    """
    Combine overlapping time ranges. Each interval is a two-element list [start, end] of integers.
    Return merged intervals in the same [start, end] list form, sorted by start ascending.
    Touching intervals like [1,3] and [3,5] should be merged.
    Raise ValueError if any interval has start > end.
    Do not modify the input.
    """
    # Validate all intervals first
    for interval in intervals:
        start, end = interval
        if start > end:
            raise ValueError(f"Interval {interval} has start > end")
    
    # Sort by start time
    sorted_intervals = sorted(intervals, key=lambda x: x[0])
    
    # Merge overlapping or touching intervals
    merged = []
    current_start, current_end = sorted_intervals[0]
    
    for interval in sorted_intervals[1:]:
        start, end = interval
        if end <= current_end:  # Overlapping or touching
            current_end = max(current_end, end)
        else:
            merged.append([current_start, current_end])
            current_start, current_end = start, end
    
    merged.append([current_start, current_end])
    return merged
