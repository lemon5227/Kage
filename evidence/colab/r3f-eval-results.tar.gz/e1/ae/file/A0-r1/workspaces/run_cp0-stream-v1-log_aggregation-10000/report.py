def count_entries(lines):
    """Count entries by level in log lines.
    
    Each line looks like "<timestamp> <LEVEL> <service>: <message>".
    Returns a dict mapping each level (case-insensitive, upper-case) to its count.
    Malformed lines are skipped. Keys with zero count are omitted.
    """
    counts = {}
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue  # Skip malformed lines
        
        # Check format: timestamp, level, service: message
        # We need at least 3 parts: timestamp, level, and the rest should start with service:
        if parts[1].upper() not in {'INFO', 'DEBUG', 'WARN', 'ERROR', 'FATAL', 'TRACE'}:
            # If the second part is not a valid level, skip
            continue
        
        level = parts[1].upper()
        counts[level] = counts.get(level, 0) + 1
    
    return counts
