import csv
import io


def clean_rows(text):
    """
    Clean CSV text with header row (columns: team, name, city, id, score).
    
    Returns cleaned CSV text with the same header.
    Steps:
    1. Strip leading/trailing whitespace from every cell
    2. Drop rows whose "score" cell is empty
    3. Remove duplicate rows by "score", keeping the first occurrence
    4. Sort rows by "name" ascending as strings (stable)
    
    Output uses '\n' line endings.
    Empty string returns ''; header-only input returns just the header line.
    """
    if not text.strip():
        return ''
    
    # Parse CSV
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    
    if not rows:
        return ''
    
    # Extract header
    header = rows[0]
    
    # Check if header has expected columns
    expected_cols = ['team', 'name', 'city', 'id', 'score']
    if len(header) != len(expected_cols):
        # If header doesn't match, still process what we have
        pass
    
    # Process data rows
    data_rows = rows[1:]
    
    # Step 1: Strip leading/trailing whitespace from every cell
    cleaned_rows = []
    for row in data_rows:
        stripped_row = [cell.strip() for cell in row]
        cleaned_rows.append(stripped_row)
    
    # Step 2: Drop rows whose "score" cell is empty
    # The score column is at index 4 (0-based: team=0, name=1, city=2, id=3, score=4)
    filtered_rows = []
    for row in cleaned_rows:
        if len(row) > 4 and row[4] != '':
            filtered_rows.append(row)
    
    # Step 3: Remove duplicate rows by "score", keeping the first occurrence
    seen_scores = set()
    deduped_rows = []
    for row in filtered_rows:
        if len(row) > 4:
            score = row[4]
            if score not in seen_scores:
                seen_scores.add(score)
                deduped_rows.append(row)
    
    # Step 4: Sort rows by "name" ascending as strings (stable)
    # The name column is at index 1
    sorted_rows = sorted(deduped_rows, key=lambda row: row[1] if len(row) > 1 else '')
    
    # Build output CSV
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    
    # Write header
    writer.writerow(header)
    
    # Write data rows
    for row in sorted_rows:
        writer.writerow(row)
    
    return output.getvalue()
