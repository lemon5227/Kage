def allocate(items, capacity):
    """
    Select jobs under a capacity limit to maximize total gain.
    
    Args:
        items: List of dicts with keys "id", "cost", "gain"
        capacity: Maximum total cost allowed
    
    Returns:
        Sorted list of ids whose total gain is maximized while total cost <= capacity
    
    Raises:
        ValueError: If capacity is negative or any cost is <= 0
    """
    # Validate inputs
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    
    for item in items:
        if "id" not in item or not isinstance(item["id"], str):
            raise ValueError("Each item must have a string 'id'")
        if "cost" not in item or not isinstance(item["cost"], int):
            raise ValueError("Each item must have an integer 'cost'")
        if "gain" not in item or not isinstance(item["gain"], int):
            raise ValueError("Each item must have an integer 'gain'")
        if item["cost"] <= 0:
            raise ValueError("Cost must be positive")
    
    if len(items) == 0:
        return []
    
    # Dynamic programming for 0/1 knapsack
    # dp[i][w] = maximum gain using first i items with total cost <= w
    n = len(items)
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    
    # Track which items were selected to reconstruct the solution
    # parent[i][w] stores the item index if it was included, otherwise None
    parent = [[None] * (capacity + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        cost = items[i-1]["cost"]
        gain = items[i-1]["gain"]
        for w in range(capacity + 1):
            # Don't include item i
            dp[i][w] = dp[i-1][w]
            
            # Include item i if it fits
            if w >= cost:
                if dp[i-1][w-cost] + gain > dp[i-1][w]:
                    dp[i][w] = dp[i-1][w-cost] + gain
                    parent[i][w] = i - 1
    
    # Find the maximum gain achievable with capacity <= capacity
    max_gain = dp[n][capacity]
    
    # Reconstruct the solution by backtracking from dp[n][capacity]
    selected_ids = []
    i, w = n, capacity
    while i > 0:
        if parent[i][w] is not None:
            selected_ids.append(items[i-1]["id"])
            w -= items[i-1]["cost"]
        i -= 1
    
    # Sort the ids lexicographically
    selected_ids.sort()
    
    return selected_ids
