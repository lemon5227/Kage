import csv
import io


def normalize_table(text):
    if text == "":
        return ""

    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""

    header = [cell.strip() for cell in rows[0]]
    data = rows[1:]

    cleaned = []
    for row in data:
        row = [cell.strip() for cell in row]
        cleaned.append(row)

    # drop rows whose "name" cell is empty
    name_idx = header.index("name") if "name" in header else -1
    if name_idx >= 0:
        cleaned = [r for r in cleaned if name_idx < len(r) and r[name_idx] != ""]

    # lower-case the "email" column
    if "email" in header:
        email_idx = header.index("email")
        for r in cleaned:
            if email_idx < len(r):
                r[email_idx] = r[email_idx].lower()

    # remove duplicate rows by "name", keeping the first occurrence
    if name_idx >= 0:
        seen = set()
        deduped = []
        for r in cleaned:
            key = r[name_idx]
            if key in seen:
                continue
            seen.add(key)
            deduped.append(r)
        cleaned = deduped

    # sort rows by "email" ascending as strings (stable)
    if "email" in header:
        email_idx = header.index("email")
        cleaned.sort(key=lambda r: r[email_idx] if email_idx < len(r) else "")

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(cleaned)
    return out.getvalue()
