def aggregate_log(lines):
    """Aggregate log lines into {service: count} for ERROR and WARN levels.

    Each line is expected to look like:
        "<timestamp> <LEVEL> <service>: <message>"

    - Level names are matched case-insensitively (only ERROR and WARN counted).
    - Malformed lines are dropped.
    """
    counts = {}
    for line in lines:
        if not isinstance(line, str):
            continue
        parts = line.split(None, 3)  # split on whitespace, max 3 splits
        if len(parts) < 4:
            continue
        _timestamp, level, service_part, message = parts
        if not service_part.endswith(':'):
            continue
        service = service_part[:-1]
        if not service.isalnum():
            continue
        level_upper = level.upper()
        if level_upper not in ("ERROR", "WARN"):
            continue
        counts[service] = counts.get(service, 0) + 1
    return counts
