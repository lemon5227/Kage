import unicodedata


def slugify(text):
    """Build a URL slug from text.

    - Apply NFKD normalization and drop non-ASCII characters.
    - Lower-case.
    - Replace every run of characters outside [a-z0-9] with a single "-".
    - Strip leading and trailing "-".
    - Raise TypeError for non-string input.
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected string, got {type(text).__name__}")

    # NFKD normalization separates characters into base + decomposition
    normalized = unicodedata.normalize("NFKD", text)

    # Drop non-ASCII characters (keep only ASCII)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")

    # Lower-case
    lower = ascii_only.lower()

    # Replace every run of characters outside [a-z0-9] with a single "-"
    segments = []
    current = ""
    for char in lower:
        if char.isalnum():  # a-z and 0-9
            current += char
        else:
            if current:
                segments.append(current)
                current = ""
            # Non-alnum runs are replaced by a single "-"
            segments.append("-")
    if current:
        segments.append(current)

    # Join segments and strip leading/trailing "-"
    result = "".join(segments)
    return result.strip("-")
